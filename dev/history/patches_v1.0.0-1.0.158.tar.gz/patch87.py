import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# QRの部品（作る：qrcode-generator MIT／読む：jsQR Apache-2.0）をエラー表示の直後に置く
LIB=open('/home/claude/lib/qrcode-generator/js/dist/qrcode.js').read()+"\n;"+open('/home/claude/lib/jsQR/dist/jsQR.js').read()
END='window.showErr=show})();\n</script>'
rep(END,END+'\n<script>/* qrcode-generator (MIT, Kazuhiko Arase) / jsQR (Apache-2.0, Cosmo Wolfe) */\n'+LIB+'\n</script>')
# 訪問中は保存しない（Gが相手のお店に入れ替わっているため）
rep('const save=()=>{try{if(typeof clrChk','const save=()=>{if(typeof R!=="undefined"&&R&&R.vis)return;try{if(typeof clrChk')
# 座る前・歩いている間はシーシャ台を出さない
rep('if(s.p===p&&p.st!=="in"){const hc=hkCenter(p);','if(s.p===p&&p.st!=="in"&&!p.nohk){const hc=hkCenter(p);')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 🏪 お店めぐり：リアルで会った人のQRを読むと、15分だけその人のお店に遊びに行ける（通信なし） ===== */
const VIS_MS=15*60*1000;
const VISL={any:["遊びに来てくれてありがとう〜！","自慢のお店です","ゆっくりしていってね","内装、こだわったんだ〜","今度はそっちのお店にも行かせてね","会えてうれしい！","最近なに吸ってる？","このお店、どう？"],pre:["シーシャ吸う？","好きな席に座ってね","今日のおすすめもあるよ"],smk:["いい煙出てるね〜","どう？うまい？","チルいね〜","炭、替えようか？","もくもく〜"],end:["そろそろ時間かな？","また会いに来てね！"]};
const VSTP=["いいお店！","また来ます","内装すてき","シーシャうまい！","チルい〜","最高でした"];
try{document.head.insertAdjacentHTML("beforeend",`<style>
body.vis #app>*:not(.cvw){display:none!important}body.vis .cvw .hint,body.vis #mvbtn,body.vis #xrow,body.vis #shopln,body.vis #bar,body.vis #tutarw{display:none!important}
#vishd{position:fixed;top:calc(env(safe-area-inset-top,0px) + 8px);left:50%;transform:translateX(-50%);z-index:60;background:rgba(30,20,45,.9);color:#fff;border-radius:14px;padding:6px 14px;font-size:13px;font-weight:700;white-space:nowrap;max-width:94vw;overflow:hidden;text-overflow:ellipsis}
#vishd b{color:#ffd54a;margin-left:6px}
#visbar{position:fixed;left:8px;right:8px;bottom:calc(env(safe-area-inset-bottom,0px) + 8px);z-index:60;max-width:540px;margin:0 auto;background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:8px;display:grid;grid-template-columns:repeat(3,1fr);gap:6px;box-shadow:0 6px 20px rgba(0,0,0,.25)}
#visbar button{padding:10px 2px;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#visbar .wide{grid-column:1/-1}
#visstp{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.vsl{display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--bd);padding:8px 0}.vsl div{flex:1;min-width:0}.vsl b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.vsl small{color:var(--mut)}.vsl.ex{opacity:.55}
</style>`)}catch(e){}
function visLook(o){o=o||{};const r={eye:o.eye||0,hs:o.hs,hair:o.hair,skin:o.skin,shirt:o.shirt,acc:o.acc,accC:o.accC,h2:o.h2|0,t2:o.t2|0,b2:o.b2|0};if(o.top!=null)r.top=o.top;if(o.bot!=null)r.bot=o.bot;if(o.pants)r.pants=o.pants;return r}
function visId(){if(!G.vid){G.vid=Math.random().toString(36).slice(2,10);save()}return G.vid}
function visSnap(lv){const o=G.ow||{},d={v:1,u:visId(),n:shopNm(),on:o.name||"店長",ow:visLook(o),fl:G.fl,wcl:G.wcl||0,fcl:G.fcl,loc:G.loc,furn:G.furn};if(lv<2)d.decor=G.decor||[];if(lv<1)d.wall=G.wall||[];return d}
async function visZ(u8,de){const st=new Blob([u8]).stream().pipeThrough(de?new DecompressionStream("deflate"):new CompressionStream("deflate"));return new Uint8Array(await new Response(st).arrayBuffer())}
async function visEnc(lv){let b=new TextEncoder().encode(JSON.stringify(visSnap(lv))),z=0;if(typeof CompressionStream==="function"){try{b=await visZ(b,0);z=1}catch(e){}}let s="SV1"+(z?"Z":"J");for(let i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);return s}
async function visDec(u8){if(String.fromCharCode(u8[0],u8[1],u8[2])!=="SV1")throw new Error("シーシャ屋さん経営のお店QRではありません");let b=u8.slice(4);if(u8[3]===90){if(typeof DecompressionStream!=="function")throw new Error("この端末では読み込めません（iOS/ブラウザを最新にしてください）");b=await visZ(b,1)}
const o=JSON.parse(new TextDecoder().decode(b));if(!o||o.v!==1||!o.u||!Array.isArray(o.fl)||!Array.isArray(o.furn))throw new Error("お店のデータが読み取れませんでした");return o}
function visQR(str){let q=null;for(const ec of["M","L"]){try{q=qrcode(0,ec);q.addData(str,"Byte");q.make();break}catch(e){q=null}}if(!q)return null;const n=q.getModuleCount(),m=4,px=Math.max(3,Math.ceil(700/(n+m*2))),c=document.createElement("canvas");c.width=c.height=(n+m*2)*px;const g=c.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,c.width,c.height);g.fillStyle="#000";for(let r=0;r<n;r++)for(let k=0;k<n;k++)if(q.isDark(r,k))g.fillRect((k+m)*px,(r+m)*px,px,px);c.style.cssText="width:100%;max-width:360px;image-rendering:pixelated;display:block;margin:6px auto;border-radius:8px;background:#fff";return c}
const visOk=e=>{const n=Date.now();return n>=e.at&&n-e.at<VIS_MS},visRem=e=>{const r=Math.max(0,VIS_MS-(Date.now()-e.at)),t=Math.ceil(r/1000);return Math.floor(t/60)+":"+String(t%60).padStart(2,"0")};
function visPan(h){const o=$("#visp");if(o){if(o._stop)o._stop();o.remove()}const d=document.createElement("div");d.id="visp";d.className="xpan";d.innerHTML=`<div class="xin">${h}</div>`;document.body.appendChild(d);return d}
function visPanel(){if(!G.setup||G.over)return;const L=(G.vsh||[]).slice().sort((a,b)=>b.at-a.at),run=R.phase!=="prep";
const d=visPan(`<div class="xh">🏪 お店めぐり</div><div class="xs">リアルで会った店主さんとQRを読み合うと、<b>15分だけ</b>その人のお店に遊びに行けます</div>
<div class="xb" style="gap:6px"><button data-vp="show" style="flex:1">📱 自分のQRを見せる</button><button data-vp="scan" class="on" style="flex:1">📷 QRを読み取る</button></div>
${run?`<div class="xw">営業中は遊びに行けません（営業前・閉店後に行けます）</div>`:""}
<div style="margin-top:6px">${L.length?L.map(e=>{const ok=visOk(e);return`<div class="vsl ${ok?"":"ex"}"><div><b>🏪 ${esc(e.n)}</b><small>店主：${esc(e.on)}${e.vn?"・訪問"+e.vn+"回":""}${e.lk?"・👍"+e.lk:""}</small><br><small>${ok?"⏳ あと "+visRem(e):"また会った時にQRを読もう"}</small></div>${ok?`<button data-vgo="${esc(e.u)}" class="on" ${run?"disabled":""}>遊びに行く</button>`:`<button data-vdel="${esc(e.u)}" title="一覧から消す">✕</button>`}</div>`}).join(""):`<div class="xs" style="text-align:center;margin:14px 0">まだ行けるお店がありません。<br>友だちの店主さんに会ったら、QRを読み合おう！</div>`}</div>
<div class="xb"><button data-vp="x" style="flex:1">閉じる</button></div>`);
d.onclick=e=>{const b=e.target.closest("[data-vp],[data-vgo],[data-vdel]");if(!b)return;if(b.dataset.vp==="x"){d.remove();return}if(b.dataset.vp==="show"){visShow();return}if(b.dataset.vp==="scan"){visScan();return}
if(b.dataset.vdel){G.vsh=(G.vsh||[]).filter(x=>x.u!==b.dataset.vdel);save();visPanel();return}if(b.dataset.vgo){const x=(G.vsh||[]).find(q=>q.u===b.dataset.vgo);if(!x||!visOk(x)){toast("時間切れです。また会った時にQRを読んでね");visPanel();return}d.remove();visEnter(x)}}}
async function visShow(){const d=visPan(`<div class="xh">📱 自分のお店のQR</div><div id="visq" class="xs" style="text-align:center;margin:20px 0">作成中…</div><div class="xb"><button data-vp="b" style="flex:1">戻る</button></div>`);d.onclick=e=>{if(e.target.closest("[data-vp=b]"))visPanel()};
let c=null,lv=0;for(;lv<3&&!c;lv++){try{c=visQR(await visEnc(lv))}catch(e){c=null}}const q=d.querySelector("#visq");if(!q)return;if(!c){q.textContent="お店のデータが大きすぎてQRにできませんでした";return}
q.innerHTML=`<div>会った相手に、ゲームの「🏪 お店めぐり → 📷 QRを読み取る」で読んでもらってね。読んでから<b>15分</b>、あなたのお店に遊びに来られます</div>${lv>1?`<div class="xw" style="margin-top:6px">お店の飾りが多いので、${lv>2?"置物と壁アイテム":"壁アイテム"}は省いています</div>`:""}`;q.prepend(c);q.style.margin="6px 0"}
function visScan(){const d=visPan(`<div class="xh">📷 QRを読み取る</div><div class="xs">相手の「自分のQRを見せる」画面を枠の中に映してね</div><div style="position:relative;background:#000;border-radius:12px;overflow:hidden;aspect-ratio:1;width:100%;max-width:340px;margin:6px auto"><video id="visv" playsinline muted autoplay style="width:100%;height:100%;object-fit:cover"></video><div style="position:absolute;inset:8%;border:3px solid rgba(255,255,255,.85);border-radius:14px"></div></div><div id="vism" class="xs" style="text-align:center;min-height:20px">カメラを起動中…</div><div class="xb"><button data-vp="b" style="flex:1">戻る</button></div>`);
let st=null,done=0,tm=0;const v=d.querySelector("#visv"),m=d.querySelector("#vism"),cv2=document.createElement("canvas"),g2=cv2.getContext("2d",{willReadFrequently:true});
const stop=()=>{done=1;clearTimeout(tm);try{st&&st.getTracks().forEach(t=>t.stop())}catch(e){}};d._stop=stop;d.onclick=e=>{if(e.target.closest("[data-vp=b]")){stop();visPanel()}};
const loop=()=>{if(done||!d.isConnected){stop();return}try{if(v.readyState>=2&&v.videoWidth){const sc=Math.min(1,1280/Math.max(v.videoWidth,v.videoHeight)),w=Math.round(v.videoWidth*sc),h=Math.round(v.videoHeight*sc);cv2.width=w;cv2.height=h;g2.drawImage(v,0,0,w,h);const r=jsQR(g2.getImageData(0,0,w,h).data,w,h,{inversionAttempts:"dontInvert"});if(r&&r.binaryData&&r.binaryData.length){stop();visGot(Uint8Array.from(r.binaryData));return}}}catch(e){}tm=setTimeout(loop,180)};
if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){m.textContent="この端末ではカメラが使えません";return}
navigator.mediaDevices.getUserMedia({video:{facingMode:"environment",width:{ideal:1920},height:{ideal:1080}},audio:false}).then(s=>{if(done||!d.isConnected){s.getTracks().forEach(t=>t.stop());return}st=s;v.srcObject=s;const p=v.play();if(p&&p.catch)p.catch(()=>{});m.textContent="QRを探しています…";loop()}).catch(()=>{m.innerHTML="カメラを使えませんでした。<br>設定でカメラの使用を許可してください"})}
async function visGot(u8){let o;try{o=await visDec(u8)}catch(e){const d=visPan(`<div class="xh">📷 読み取れませんでした</div><div class="xw">${esc(e.message)}</div><div class="xb"><button data-vp="b" style="flex:1">戻る</button><button data-vp="r" class="on" style="flex:1">もう一度</button></div>`);d.onclick=ev=>{const b=ev.target.closest("[data-vp]");if(!b)return;b.dataset.vp==="r"?visScan():visPanel()};return}
if(o.u===visId()){toast("これは自分のお店のQRです");visScan();return}
G.vsh=G.vsh||[];let e=G.vsh.find(x=>x.u===o.u);if(!e){e={u:o.u,vn:0,lk:0};G.vsh.push(e)}Object.assign(e,{n:String(o.n||"お店").slice(0,30),on:String(o.on||"店長").slice(0,20),at:Date.now(),d:o});G.vsh.sort((a,b)=>b.at-a.at);G.vsh=G.vsh.slice(0,20);G.vmet=(G.vmet||0)+1;save();
const run=R.phase!=="prep",d=visPan(`<div class="xh">🎉 読み取りました！</div><div style="text-align:center;margin:10px 0;font-size:16px"><b>🏪 ${esc(e.n)}</b><br><small style="color:var(--mut)">店主：${esc(e.on)}</small></div><div class="xs" style="text-align:center">今から<b>15分</b>、このお店に遊びに行けます</div>${run?`<div class="xw">営業中は行けません。営業前・閉店後に「お店めぐり」から行けます</div>`:""}<div class="xb" style="gap:6px"><button data-vp="b" style="flex:1">あとで</button><button data-vp="go" class="on" style="flex:2" ${run?"disabled":""}>遊びに行く</button></div>`);
d.onclick=ev=>{const b=ev.target.closest("[data-vp]");if(!b)return;if(b.dataset.vp==="b"){visPanel();return}if(visOk(e)){d.remove();visEnter(e)}}}
function visEnter(e){if(R.vis||R.phase!=="prep"||!G.setup||G.over||R.mvOn)return;const x=e.d;if(!x)return;const G0=G;
const v={G0,e,exp:e.at+VIS_MS,sv:{x:OW.x,y:OW.y,dir:OW.dir,sitting:OW.sitting,seat:OW.seat,hd:OW.hd,idleSmk:OW.idleSmk,eat:OW.eat,ph:OW.ph,mode:OW.mode,bt:OW.bt,bub:OW.bub},look:Object.assign({},OW.c),cat:R.cat,pp:R.people,tool:R.tool,cam:JSON.parse(JSON.stringify(R.cam)),smk:0,lt:""};
const me=Object.assign({i:99,hp:10,up:0,met:1,vt:2,nick:(G0.ow&&G0.ow.name)||"店長"},visLook(G0.ow));v.me=me;
const g=JSON.parse(JSON.stringify(G0));Object.assign(g,{fl:x.fl,furn:x.furn,decor:x.decor||[],wall:x.wall||[],inv:[],ckD:-1,wcl:x.wcl||0});if(x.fcl!=null)g.fcl=x.fcl;if(x.loc!=null)g.loc=x.loc;g.ow=Object.assign({},g.ow||{},x.ow||{},{name:x.on,shop:x.n});
try{R.vis=v;G=g;R.cat=null;R.people=[];R.tool=null;e.vn=(e.vn||0)+1;G0.vtot=(G0.vtot||0)+1;
syncFl();furnRebuild();build();Object.assign(OW,{x:3,y:8,dir:1,sitting:0,seat:null,hd:0,idleSmk:0,eat:null,ph:0,mode:null,bt:0,bub:""});applyOwLook();OW._pc=null;
const p={c:me,x:-4,y:15,st:"vw",dir:1,seat:NOSEAT,seed:Math.random()*5,path:[[4,15]],bt:0,orders:0,tp:0,rem:0,nd:0,dl:0,dt:0,nohk:1,rest:1,vis:1};R.people.push(p);v.p=p;
document.body.classList.add("vis");visBar();setTimeout(()=>{if(R.vis===v)say(OW,"遊びに来てくれてありがとう〜！")},900)}catch(err){try{G=G0;R.vis=null}catch(_){}visBack(v);throw err}}
function visBack(v){G=v.G0;R.vis=null;R.people=v.pp||[];R.cat=v.cat;R.tool=v.tool;if(v.cam)R.cam=v.cam;syncFl();furnRebuild();build();Object.assign(OW,v.sv,{sitting:0,seat:null,_pc:null});Object.assign(OW.c,v.look);applyOwLook();OW._pc=null;
document.body.classList.remove("vis");["#visbar","#vishd","#ckp","#visp"].forEach(q=>{const el=$(q);if(el)el.remove()});save();try{hud();ratm();xrow()}catch(e){}}
function visLeave(msg){const v=R.vis;if(!v)return;visBack(v);if(msg)toast(msg)}
function visBar(){["#visbar","#vishd"].forEach(q=>{const el=$(q);if(el)el.remove()});const v=R.vis;if(!v)return;
const h=document.createElement("div");h.id="vishd";h.innerHTML=`🏪 ${esc(v.e.n)} に訪問中<b id="visrem"></b>`;document.body.appendChild(h);
const b=document.createElement("div");b.id="visbar";const p=v.p,sit=p.st==="sit"||p.st==="vin";
b.innerHTML=`<button data-va="talk">💬 店主と話す</button><button data-va="sit">🪑 ${sit?"席を移る":"席に座る"}</button><button data-va="smk" ${v.smk?"disabled":""}>💨 ${v.smk?"吸っています":"シーシャを吸う"}</button><button data-va="like" ${v.e.lkAt===v.e.at?"disabled":""}>👍 いいね</button><button data-va="stp">🗯 スタンプ</button><button data-va="ck">📸 チェキ</button>${v.stp?`<div id="visstp">${VSTP.map((t,i)=>`<button data-vs="${i}">${t}</button>`).join("")}</div>`:""}<button data-va="out" class="wide">🚪 自分のお店に帰る</button>`;
document.body.appendChild(b);b.onclick=e=>{const t=e.target.closest("[data-va],[data-vs]");if(!t||t.disabled||!R.vis)return;e.stopPropagation();if(t.dataset.vs!=null){visStamp(VSTP[+t.dataset.vs]);return}const a=t.dataset.va;
if(a==="talk")visTalk();else if(a==="sit")visSit();else if(a==="smk")visSmoke();else if(a==="like")visLike();else if(a==="stp"){v.stp=!v.stp;visBar()}else if(a==="ck")visCheki();else if(a==="out")visLeave("🏠 自分のお店に戻りました")}}
function visTalk(){const v=R.vis;if(!v)return;const L=VISL.any.concat(v.smk?VISL.smk:VISL.pre,v.exp-Date.now()<3*60*1000?VISL.end:[]);let t=rnd(L);for(let i=0;i<6&&t===v.lt;i++)t=rnd(L);v.lt=t;say(OW,t)}
function visSit(){const v=R.vis,p=v.p,fr=SEATS.filter(s=>!s.p&&s!==p.seat);if(!fr.length){toast("ほかに空いている席がありません");return}const s=rnd(fr);if(p.seat&&p.seat.p===p)p.seat.p=null;
const sx=p.st==="sit"?p.seat.px+2:p.x,sy=p.st==="sit"?p.seat.Y0+3:p.y;p.x=sx;p.y=sy;s.p=p;p.seat=s;p.st="vin";p.nohk=1;p.rest=1;p._pc=null;const px=s.px+2;p.path=[[sx,15],[px,15],[px,s.Y0+3]];visBar()}
function visSmoke(){const v=R.vis,p=v.p;if(p.st!=="sit"){toast(p.st==="vin"?"席に着くまで待ってね":"先に席に座ってね");return}v.smk=1;p.nohk=0;p.rest=0;p._pc=null;visBar();setTimeout(()=>{if(R.vis===v)say(OW,rnd(["はい、どうぞ〜！","自信作だよ〜"]))},500)}
function visLike(){const v=R.vis,e=v.e;if(e.lkAt===e.at)return;e.lkAt=e.at;e.lk=(e.lk||0)+1;say(v.p,"👍");setTimeout(()=>{if(R.vis===v)say(OW,"ありがとう！うれしい〜")},700);visBar()}
function visStamp(t){const v=R.vis;v.stp=0;say(v.p,t);v.e.sn=(v.e.sn||0)+1;setTimeout(()=>{if(R.vis===v)say(OW,rnd(["ありがとう〜！","うれしい！","でしょ〜！"]))},900);visBar()}
function visCheki(){const v=R.vis;G.ckD=-1;const o=$("#ckp");if(o)o.remove();const d=document.createElement("div");d.id="ckp";d.className="xpan";d.innerHTML=`<div class="xin"></div>`;document.body.appendChild(d);try{ckShoot(d,v.me)}catch(e){d.remove();throw e}}
/* 訪問中のチェキで「戻る」→ そのまま閉じる */
{const _cp=chekiPanel;chekiPanel=function(){if(R.vis){const o=$("#ckp");if(o)o.remove();return}return _cp.apply(this,arguments)}}
/* 訪問中は店主をタップで会話、ほかの操作はしない */
{const _ot=onTap;onTap=function(clx,cly){if(!R.vis)return _ot.apply(this,arguments);const r=cv.getBoundingClientRect(),X=(clx-r.left)*W/r.width,Y=(cly-r.top)*CH/r.height,k=R.cv;if(!k)return;const q=P(OW.x,OW.y,7);if(Math.hypot(q[0]-X,q[1]-Y)<Math.max(30,k.s*6.5))visTalk()}}
/* 訪問中の毎フレーム：残り時間・席に着いたら座る・時間切れで帰る（普段の画面更新はしない） */
{const _hv=hud;hud=function(){if(!R.vis)return _hv.apply(this,arguments);const v=R.vis,p=v.p,now=Date.now();if(p.st==="vin"&&!p.path.length){p.st="sit";p._pc=null;visBar()}
if(now<v.e.at||now>=v.exp){visLeave("⏰ 15分たったので自分のお店に戻りました。また会った時にQRを読んでね");return}const el=document.getElementById("visrem");if(el){const t="あと"+visRem(v.e);if(el.textContent!==t)el.textContent=t}}}
/* 訪問中はクラウド保存しない */
{const _cs=cloudSave;cloudSave=async function(){if(R.vis)return false;return _cs.apply(this,arguments)}}
{const _cp2=cpack;cpack=async function(){if(R.vis)throw new Error("お店めぐり中は保存できません");return _cp2.apply(this,arguments)}}
/* ボタン列に「お店めぐり」 */
{const _xr=xrow;xrow=function(){_xr();const r=$("#xrow");if(!r)return;let b=$("#visb");if(!b){b=document.createElement("button");b.id="visb";b.textContent="🏪 お店めぐり";r.appendChild(b);b.onclick=e=>{e.stopPropagation();visPanel()}}b.disabled=R.phase==="run";b.style.opacity=R.phase==="run"?".45":""}}
try{xrow()}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
