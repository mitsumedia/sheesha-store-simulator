import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== お客さんは歩道を歩いて来店・帰る。外を歩く姿は通行人と同じ仕組み（同じ速さの範囲）で描く ===== */
const WK_X=-10.5,WK_D=85;
const MBG={id:"cust",k:"ped",r:0,sp:12,n:"お客さん"};
function wkV(){return 9+Math.random()*6}
function mbSpd(){return R.phase==="run"?(R.speed||0):0}
/* 来店予定の少し前から、入口に着く時刻に合わせて歩き始める */
function wkGhosts(){if(!mbOn())return;const v0=12;for(const e of R.sched){const dtm=e.at-R.t;if(dtm>WK_D/(v0/6)+2)break;if(e._g||!e.m||!e.m.length)continue;e._g=1;const side=Math.random()<.5?1:-1;
  e.m.forEach((c,i)=>{const v=wkV(),d=Math.min(WK_D,Math.max(0,dtm)*(v/6))+i*4;MB.L.push({T:MBG,gh:{e,c},c,s:side,x:WK_X-(i%2)*1.6,y:15-side*d,a:Math.random()*9,t:0,sp:v,tag:1,seen:1})})}}
/* 店を出たお客さんは、そのまま通行人として歩いて帰る */
{const _mv=move;move=function(p,dt){try{if(p.st==="out"&&!p.path.length&&p.x<-3&&!p.vis&&!p.mob&&p.c&&mbOn()){const side=Math.random()<.5?1:-1;MB.L.push({T:MBG,c:p.c,s:side,x:WK_X,y:p.y,a:Math.random()*9,t:0,sp:wkV(),tag:1,seen:1,ex:1});p.gone=1;return}}catch(e){}return _mv.apply(this,arguments)}}
/* ===== 通行人のお知らせ：店の前を通りすぎた後に、ボタンの上の帯で出す ===== */
const MBQ=[];let mbBusy=0;
function mbBand(t){MBQ.push(t);if(MBQ.length>4)MBQ.shift();if(!mbBusy)mbBandNext()}
function mbBandNext(){const t=MBQ.shift();if(!t){mbBusy=0;return}mbBusy=1;let b=$("#mbband");if(!b){b=document.createElement("div");b.id="mbband";document.body.appendChild(b)}const g=$("#bar");const top=g?g.getBoundingClientRect().top:innerHeight-90;b.style.top=(top-50)+"px";b.textContent=t;b.classList.remove("on");void b.offsetWidth;b.classList.add("on");setTimeout(()=>{b.classList.remove("on");setTimeout(mbBandNext,450)},3600)}
mbSeen=function(t,m){G.mbS=G.mbS||{};const first=!G.mbS[t.id];G.mbS[t.id]=(G.mbS[t.id]||0)+1;if(first&&t.r>=3){const lb=(["","","","★3","★4 レア！","★5 激レア！"][t.r]);try{mbBand("👀 "+lb+" "+t.n+"が通った！");log("👀 "+lb+" "+t.n+" が通った！（街で見たものに記録）")}catch(e){}}};
(function(){const st=document.createElement("style");st.textContent=`#mbband{position:fixed;left:50%;transform:translate(-50%,8px);width:min(92vw,520px);z-index:60;background:rgba(28,22,44,.86);color:#fff;font-weight:900;font-size:13.5px;text-align:center;padding:9px 14px;border-radius:999px;box-shadow:0 4px 14px rgba(0,0,0,.25);opacity:0;pointer-events:none;transition:opacity .35s,transform .35s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#mbband.on{opacity:1;transform:translate(-50%,0)}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
