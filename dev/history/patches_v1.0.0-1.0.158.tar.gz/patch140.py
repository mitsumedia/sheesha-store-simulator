import sys,re
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ---- 新しい装飾品12種（ガチャ限定・店長用） ----
rep('"フルフェイスヘルメット","猫耳カチューシャ","四角メガネ"]','"フルフェイスヘルメット","猫耳カチューシャ","四角メガネ","とがったサングラス","丸メガネ（細ぶち）","ハーフリム","色つきレンズ","片メガネ","ゴーグル","ハンチング帽","バケットハット","ターバン","ハチマキ","ベレー帽","王冠"]')
# メガネを重ねて描く判定を、新しい目元アイテムにも
s,n=re.subn(r'(\b[\w.]+)\.acc===1\|\|\1\.acc===7\|\|\1\.acc===10',r'isGl(\1.acc)',s);assert n==8,n
# 頭のアイテム（ブロックで描く）
rep('H(0,2,7,8,1,1,ak)}\nif(c.sp&&typeof SPF!=="undefined"',
 'H(0,2,7,8,1,1,ak)}'
 'else if(ac===17){const dk=dkHex(ak,.8);H(-1,-1,6,10,8,1,ak);H(0,0,7,8,7,1,ak);H(1,7,6,6,1,1,dk)}'
 'else if(ac===18){const dk=dkHex(ak,.82);H(0,0,6,8,6,1,dk);H(0,0,7,8,6,2,ak);H(-2,-2,5,12,10,1,ak)}'
 'else if(ac===19){const lt=dkHex(ak,1.18);H(-1,-1,5,10,8,2,ak);H(0,0,7,8,6,1,lt);H(1,1,8,6,4,1,ak);H(3,7,5,2,1,1,"#f1c40f")}'
 'else if(ac===20){H(-1,-1,4,10,8,1,"#ffffff");H(3,6,4,2,1,1,ak);H(3,-2,4,2,1,1,"#ffffff");H(3,-2,2,1,1,2,"#ffffff");H(4,-2,1,1,1,2,"#ffffff")}'
 'else if(ac===21){H(-1,-1,6,10,8,1,ak);H(-2,0,7,10,6,1,ak);H(3,2,8,1,1,1,ak)}'
 'else if(ac===22){const g="#f1c40f",g2="#f5d34a";H(1,1,7,6,1,1,g);H(1,4,7,6,1,1,g);H(1,1,7,1,4,1,g);H(6,1,7,1,4,1,g);[[1,1],[6,1],[1,4],[6,4],[3,4],[4,1]].forEach(([x,y])=>H(x,y,8,1,1,1,g2));H(3,4,7,2,1,1,ak)}'
 '\nif(c.sp&&typeof SPF!=="undefined"')
rep('GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25],["deco",8],["ow",6]]','GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25],["deco",8],["ow",10]]')
# メニューの回るキャラの上に描くメガネも新しい目元アイテムに対応
rep('const fr=Math.max(1,sc*(sun?.3:.2));g.save();g.lineJoin="round";','const fr=Math.max(1,sc*(sun?.3:.2));g.save();g.lineJoin="round";if(kind>=11){gEye(g,pt,sc,kind,col);g.restore();return r}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 新しい装飾品：目元6種（線で重ねて描く）・頭6種（ブロック）。ガチャで手に入る店長用 ===== */
function isGl(a){a=+a||0;return a===1||a===7||a===10||(a>=11&&a<=16)}
const OWA=[["とがったサングラス",11],["丸メガネ（細ぶち）",12],["ハーフリム",13],["色つきレンズ",14],["片メガネ",15],["ゴーグル",16],["ハンチング帽",17],["バケットハット",18],["ターバン",19],["ハチマキ",20],["ベレー帽",21],["王冠",22]];
try{OWL.a=OWA;OWA.forEach((x,i)=>{const k="a"+(i+1);if(!OWG.includes(k))OWG.push(k);OWC[k]=["ガチャ"]})}catch(e){}
const accOwn=id=>id<11||owHas("a"+(OWA.findIndex(x=>x[1]===id)+1));
try{[11,12,13,14,15,16].forEach(i=>ACC_E.push(i));ACC_H.splice(ACC_H.indexOf(8),0,17,18,19,20,21,22)}catch(e){}
function gEye(g,pt,s,kind,col){const path=p=>{g.beginPath();p.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath()},line=(a,b,c,w)=>{g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);if(c)g.strokeStyle=c;if(w)g.lineWidth=Math.max(1,w);g.stroke()},circ=(lc,rx,rz,yy)=>{const p=[];for(let i=0;i<24;i++){const t=i/12*Math.PI;p.push(pt(lc+Math.cos(t)*rx,9.6+Math.sin(t)*rz,yy))}return p};
 g.lineJoin="round";col=col||"#333333";
 if(kind===11){const L=[[-1.05,.25],[-.2,.42],[.85,.4],[1.0,.1],[.75,-.4],[-.3,-.45],[-.95,-.15]];for(const[lc,m]of[[1,-1],[3,1]]){const q=L.map(([a,b])=>{const x=m<0?-a:a;return pt(lc+x,9.6+b+(x*m>0?.25:0))});path(q);g.fillStyle="rgba(205,45,110,.88)";g.fill();g.lineWidth=Math.max(1,s*.1);g.strokeStyle=col;g.stroke()}line(pt(1.95,9.95),pt(2.05,9.95),col,s*.12);line(pt(.05,9.95),pt(-.05,9.95,1.6),col,s*.12);line(pt(3.95,9.95),pt(4.05,9.95,1.6),col,s*.12)}
 else if(kind===12){for(const lc of[1,3]){path(circ(lc,.62,.62));g.fillStyle="rgba(210,235,255,.25)";g.fill();g.lineWidth=Math.max(1,s*.12);g.strokeStyle=col;g.stroke()}line(pt(1.62,9.75),pt(2.38,9.75),col,s*.12);line(pt(.38,9.75),pt(-.05,9.75,1.4),col,s*.1);line(pt(3.62,9.75),pt(4.05,9.75,1.4),col,s*.1)}
 else if(kind===13){for(const lc of[1,3]){const p=[[-.85,.55],[.85,.55],[.85,-.45],[-.85,-.45]].map(([a,b])=>pt(lc+a,9.6+b));path(p);g.fillStyle="rgba(210,235,255,.22)";g.fill();line(p[0],p[1],col,s*.28);g.lineWidth=Math.max(1,s*.06);g.strokeStyle="rgba(60,60,60,.5)";g.beginPath();g.moveTo(p[1][0],p[1][1]);g.lineTo(p[2][0],p[2][1]);g.lineTo(p[3][0],p[3][1]);g.lineTo(p[0][0],p[0][1]);g.stroke()}line(pt(1.85,10.1),pt(2.15,10.1),col,s*.2);line(pt(.15,10.1),pt(-.05,10.1,1.3),col,s*.16);line(pt(3.85,10.1),pt(4.05,10.1,1.3),col,s*.16)}
 else if(kind===14){for(const lc of[1,3]){path(circ(lc,.85,.7));g.fillStyle="rgba(255,196,40,.6)";g.fill();g.lineWidth=Math.max(1,s*.16);g.strokeStyle=col;g.stroke()}line(pt(1.85,9.8),pt(2.15,9.8),col,s*.16);line(pt(.15,9.8),pt(-.05,9.8,1.3),col,s*.14);line(pt(3.85,9.8),pt(4.05,9.8,1.3),col,s*.14)}
 else if(kind===15){path(circ(3,.7,.7));g.fillStyle="rgba(210,235,255,.3)";g.fill();g.lineWidth=Math.max(1,s*.18);g.strokeStyle=col;g.stroke();g.setLineDash([s*.15,s*.12]);line(pt(3.6,9.2),pt(3.9,7.6),col,s*.1);g.setLineDash([])}
 else if(kind===16){line(pt(.05,9.6,3.1),pt(-.1,9.6,0),"#4a3a2a",s*.55);line(pt(3.95,9.6,3.1),pt(4.1,9.6,0),"#4a3a2a",s*.55);for(const lc of[1,3]){path(circ(lc,.95,.85,3.2));g.fillStyle="rgba(90,200,220,.55)";g.fill();g.lineWidth=Math.max(1,s*.32);g.strokeStyle=col;g.stroke()}line(pt(1.9,9.6,3.2),pt(2.1,9.6,3.2),col,s*.3)}}
{const _gf=glFx;glFx=function(ox,Y0,f,sit,dr,kind,col,ly,zo){if(!(kind>=11&&kind<=16))return _gf.apply(this,arguments);zo=zo||0;const M=(lx,y)=>sit?[ox+lx,f>0?Y0+y:Y0+6-y]:dr===0?[ox+lx,Y0+y]:dr===2?[ox+4-lx,Y0+3-y]:dr===1?[ox+y,Y0+4-lx]:[ox+3-y,Y0+lx];
 const o=M(0,0),nx=M(0,1),n=[nx[0]-o[0],nx[1]-o[1]],c=M(2,ly),pos=[c[0]+n[0]*.4,c[1]+n[1]*.4,9.5-zo];
 return{pos,fn:k=>{if(n[0]*k.cx+n[1]*k.cy<.04)return;const pt=(lx,z,yy)=>{const m=M(lx,yy===undefined?ly:yy);return P3(m[0],m[1],z-zo,k)};cx.save();gEye(cx,pt,k.s,kind,col);cx.restore()}}}}
'''
rep(TAIL,CODE+TAIL)
rep('${ids.map(i=>`<button data-owp="${k}"','${ids.filter(i=>accOwn(i)).map(i=>`<button data-owp="${k}"')
open(f,'w').write(s)
