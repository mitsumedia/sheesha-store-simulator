import sys,re
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
HB={"雲紅亭珍光":("読書","風●店巡り"),"さんてぃ":("筋トレ","シーシャ屋めぐり"),"野郎シーシャ会":("写真","シーシャ屋めぐり")}
for n,(a,b) in HB.items():
    m=re.search(r'("name":"'+n+r'".{0,600}?"hb":")'+a+'"',s);assert m,n
    s=s[:m.start()]+m.group(1)+b+'"'+s[m.end():]
rep('lv(c)>i||o[0]==="シーシャ歴"||o[0]==="シーシャレベル"?','lv(c)>i||o[0]==="シーシャ歴"||o[0]==="シーシャレベル"||(o[0]==="趣味"&&HBFIX[c.name])?')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 趣味の変更（今のセーブにも反映） ===== */
const HBFIX={"雲紅亭珍光":"風●店巡り","さんてぃ":"シーシャ屋めぐり","野郎シーシャ会":"シーシャ屋めぐり"};
function hbFix(){try{(G.cs||[]).forEach(c=>{const h=HBFIX[c.name];if(h&&c.hb!==h)c.hb=h})}catch(e){}}
hbFix();setTimeout(hbFix,1500);{const _sc11=sched;sched=function(){hbFix();return _sc11.apply(this,arguments)}}{const _rd11=rdex;rdex=function(){hbFix();return _rd11.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
