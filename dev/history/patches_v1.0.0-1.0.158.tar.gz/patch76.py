import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
D=json.load(open('/home/claude/w/maid_dmd.json'))
ADD='''
/* ===== ひめ（No.148）からもらえる非売品：メイド服のトルソー ===== */
DMD.gf_147=%s;{const x={"id":"gf_147","n":"ひめのメイド服","p":4000,"t":{"fantasy":2},"u":["gift",0],"g":147};if(!DEC.some(d=>d.id===x.id))DEC.push(x);GIFT[147]=x}
''' % json.dumps(D)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
