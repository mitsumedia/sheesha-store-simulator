import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== メニュー・各種パネル・模様替え中は「営業開始」を押せなくする ===== */
try{document.head.insertAdjacentHTML("beforeend","<style>body.golk #go{pointer-events:none!important;opacity:.4!important;filter:grayscale(.6)}</style>")}catch(e){}
const goLocked=()=>!!(document.querySelector("#sheet.open")||document.querySelector(".xpan")||document.body.classList.contains("mvmode"));
{const _hg=hud;hud=function(){const r=_hg.apply(this,arguments);try{const l=goLocked();if(document.body.classList.contains("golk")!==l)document.body.classList.toggle("golk",l)}catch(e){}return r}}
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest("#go")&&goLocked()){e.stopPropagation();e.preventDefault()}},true);
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
