import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:80];s=s.replace(a,b)
rep('o.forEach((i,n)=>{m[i]=n+1});return{o,m}}','o.forEach((i,n)=>{m[i]=n+1});[[131,134],[138,149]].forEach(([a,b])=>{const t=m[a];m[a]=m[b];m[b]=t});o.sort((a,b)=>m[a]-m[b]);return{o,m}}')
rep('fs.map(([k,t,l,o])=>{const v=gv(c,k),id="bd-f-"+k;','fs.map(([k,t,l,o])=>{if(c.job==="シーシャ屋"&&["fd","hb","pe","age","fav","hist","sl","tl"].includes(k))return"";const v=gv(c,k),id="bd-f-"+k;')
open(f,'w').write(s);print('ok')
