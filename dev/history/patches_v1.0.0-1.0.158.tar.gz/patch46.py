import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 管理画面：アイテムやその他の贈り物を選べるように
rep('<input id="ga4" ${INP} type="number" inputmode="numeric" placeholder="招待チケット（枚）">',
 '<input id="ga4" ${INP} type="number" inputmode="numeric" placeholder="招待チケット（枚）">'
 '<div style="margin:8px 0 4px;padding:8px;border:1px dashed #d9d0e8;border-radius:8px"><b style="font-size:12px">📦 アイテムを付ける</b>'
 '<select id="gic" ${INP}><option value="d">🪴 置物</option><option value="w">🖼 壁アイテム</option><option value="f">🛋 客席</option><option value="bb">🫘 ビーズクッション</option></select>'
 '<select id="gii" ${INP}>${giOpts("d")}</select><div style="display:flex;gap:6px;align-items:center"><input id="giq" type="number" inputmode="numeric" value="1" style="width:80px;font-size:16px;padding:8px;border:1px solid #d9d0e8;border-radius:8px"><span style="font-size:12px">個</span><button id="gia" style="flex:1">＋ 追加</button></div><div id="gil" style="font-size:12px;margin-top:6px"></div></div>'
 '<div style="margin:4px 0;padding:8px;border:1px dashed #d9d0e8;border-radius:8px;font-size:13px;line-height:2"><b style="font-size:12px">✨ その他</b><br>'
 '<label><input type="checkbox" id="gx1"> 🔥 やる気を全回復</label><br><label><input type="checkbox" id="gx4"> 🎰 今日のガチャをもう1回</label>'
 '<input id="gx2" ${INP} type="number" inputmode="numeric" placeholder="📱 SNSフォロワー＋（人）"><input id="gx3" ${INP} type="number" inputmode="numeric" placeholder="⭐ 知名度＋（最大100）"></div>')
# 受け取り時に中身を反映
rep('G.money+=j.money||0;G.tix=(G.tix||0)+(j.tix||0);','G.money+=j.money||0;G.tix=(G.tix||0)+(j.tix||0);const rx=rwApply(j.rw);')
rep('const t=[j.money?yen(j.money):"",j.tix?"🎟 招待チケット×"+j.tix:""].filter(Boolean).join("・");','const t=[j.money?yen(j.money):"",j.tix?"🎟 招待チケット×"+j.tix:""].concat(rx).filter(Boolean).join("・");')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 不思議な贈り物：アイテム・その他の中身 ===== */
const SEATK=["s","l","t","b","c"];
function giList(c){if(c==="d")return DEC.map(x=>[x.id,x.n]);if(c==="w")return WP.map(x=>[x.id,x.n]);if(c==="bb")return BBS.map(b=>[b.id,"ビーズクッション（"+b.n+"）"]);
const o=[];SSER.forEach(sr=>SEATK.forEach(k=>o.push([k+":"+sr.id,SDEF[k].nm+"（"+sr.n+"）"])));return o}
function giOpts(c){return giList(c).map(([v,n])=>`<option value="${esc(v)}">${esc(n)}</option>`).join("")}
function giName(it){if(it.c==="d"){const x=DEC.find(q=>q.id===it.id);return x?x.n:it.id}if(it.c==="w"){const x=WP.find(q=>q.id===it.id);return x?x.n:it.id}if(it.c==="bb"){const b=BBS.find(q=>q.id===it.id);return"ビーズクッション（"+(b?b.n:it.id)+"）"}const[k,sr]=it.id.split(":"),S=SSER.find(q=>q.id===sr);return(SDEF[k]?SDEF[k].nm:k)+"（"+(S?S.n:sr)+"）"}
let GIL=[];
function giDraw(){const el=document.getElementById("gil");if(!el)return;el.innerHTML=GIL.length?GIL.map((it,i)=>`<span style="display:inline-block;background:#f4effb;border-radius:12px;padding:2px 8px;margin:2px">${esc(giName(it))}×${it.q} <a href="#" data-gid="${i}" style="color:#e5484d;text-decoration:none">✕</a></span>`).join(""):"<span class='m'>（アイテムなし）</span>"}
function rwText(rw){if(!rw)return[];const o=[];(rw.items||[]).forEach(it=>o.push(giName(it)+"×"+it.q));if(rw.mot)o.push("🔥やる気全回復");if(rw.gacha)o.push("🎰ガチャもう1回");if(rw.fol)o.push("📱フォロワー+"+rw.fol);if(rw.fame)o.push("⭐知名度+"+rw.fame);return o}
function rwApply(rw){if(!rw)return[];let pend=0;(rw.items||[]).forEach(it=>{const q=Math.max(1,Math.min(99,+it.q||1));for(let i=0;i<q;i++){let r;if(it.c==="d"||it.c==="w")r=ivAdd({t:it.c,id:it.id});else if(it.c==="bb")r=ivAdd({t:"f",k:"bb",sr:it.id});else{const[k,sr]=it.id.split(":");if(sr==="tg")G.tigerU=1;r=ivAdd({t:"f",k,sr})}if(!r)pend++}});
if(rw.mot)G.mot=100;if(rw.gacha)G.gaD=-1;if(G.ow){if(rw.fol)G.ow.fol=(G.ow.fol||0)+(+rw.fol||0);if(rw.fame)G.ow.fame=Math.min(100,(G.ow.fame||0)+(+rw.fame||0))}
save();try{rdeco();hud()}catch(e){}const t=rwText(rw);if(pend)t.push("（持ち物がいっぱいの分は受け取り待ちへ）");return t}
document.addEventListener("change",e=>{if(e.target.id==="gic"){const s2=document.getElementById("gii");if(s2)s2.innerHTML=giOpts(e.target.value)}});
document.addEventListener("click",async e=>{const a=e.target.closest("[data-gid]");if(a){e.preventDefault();GIL.splice(+a.dataset.gid,1);giDraw();return}
const b=e.target.closest("button");if(!b)return;
if(b.id==="gia"){const c=document.getElementById("gic").value,id=document.getElementById("gii").value,q=Math.max(1,Math.min(99,+document.getElementById("giq").value||1));if(!id)return;const ex=GIL.find(x=>x.c===c&&x.id===id);if(ex)ex.q=Math.min(99,ex.q+q);else GIL.push({c,id,q});giDraw();return}
if(b.id==="gab"){e.stopImmediatePropagation();const v=i=>(document.getElementById("ga"+i).value||"").trim(),xv=i=>document.getElementById("gx"+i);
const rw={items:GIL.slice(),mot:xv(1).checked?1:0,gacha:xv(4).checked?1:0,fol:+xv(2).value||0,fame:+xv(3).value||0};const has=rw.items.length||rw.mot||rw.gacha||rw.fol||rw.fame;
if(!v(1)){sysMsg("gam","あいことばを入れてください",1);return}if(!+v(3)&&!+v(4)&&!has){sysMsg("gam","贈り物の中身を1つ以上選んでください",1);return}
try{await aapi({a:"a_gift_add",pass:v(1),title:v(2),money:+v(3)||0,tix:+v(4)||0,msg:v(5),until:v(6),maxuse:+v(7)||0,rw});sysMsg("gam","✅ 作成しました。あいことば「"+esc(v(1))+"」を告知してください");
[1,2,3,4,5,6,7].forEach(i=>document.getElementById("ga"+i).value="");[2,3].forEach(i=>xv(i).value="");[1,4].forEach(i=>xv(i).checked=false);GIL=[];giDraw();admGifts()}catch(er){sysMsg("gam",esc(er.message),1)}}},true);
admGifts=async function(){const el=document.getElementById("gal");if(!el)return;giDraw();try{const j=await aapi({a:"a_gifts"});el.innerHTML=j.list.length?j.list.map(g=>{let rw=null;try{rw=JSON.parse(g.rw||"null")}catch(e){}const parts=[+g.money?yen(+g.money):"",+g.tix?"🎟×"+g.tix:""].concat(rwText(rw)).filter(Boolean).join("・");
return`<div style="padding:6px 0;border-bottom:1px solid #f0f0f0;${+g.active?"":"opacity:.45"}"><b>${esc(g.pass)}</b>　${esc(g.title||"")}<br>${esc(parts)}<br>受取 ${g.used}${+g.maxuse?"/"+g.maxuse:""}人・${+g.expires?"〜"+fdt(+g.expires).split(" ")[0]:"無期限"} <button data-gt="${g.id}" style="padding:2px 8px;font-size:11px">${+g.active?"停止する":"再開する"}</button></div>`}).join(""):"まだありません"}catch(e){el.textContent=e.message}};
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
