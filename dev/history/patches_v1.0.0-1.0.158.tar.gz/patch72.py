import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# --- クラブ（バトル）を明るく：床・壁を明るめの紫に、背景の赤い光を強く ---
rep('["#2a2030","#31253a","#261b2b"][((x%3)+3)%3]','["#5a4670","#64507c","#523f66"][((x%3)+3)%3]')
rep('(x,y,z)=>z===0?"#ff2d55":"#1c1424");','(x,y,z)=>z===0?"#ff2d55":"#3a2c4e");')
rep('(y%8===0&&z<20)?"#3a2340":"#221828"','(y%8===0&&z<20)?"#5a3a66":"#3a2a4a"')
rep('function clubBg(g,W,H){g.fillStyle="#0b0612";','function clubBg(g,W,H){g.fillStyle="#24163a";')
rep('r.addColorStop(0,"rgba(255,23,68,.35)")','r.addColorStop(0,"rgba(255,80,140,.45)")')
# モブは明るい床でも見えるよう少し明るいグレーに（顔は描かない）
rep('g=["#34343a","#3d3d44","#2e2e34","#45454c"][Math.random()*4|0];t.forEach(v=>{const r=v[2]-z0;v[3]=r<3.5?"#141417":r<8.2?g:"#1a1a1f"})',
    'g=["#6a6a74","#77777f","#5f5f69","#82828a"][Math.random()*4|0];t.forEach(v=>{const r=v[2]-z0;v[3]=r<3.5?"#1e1e22":r<8.2?g:"#2a2a30"})')
# --- 会場の切り替え（venue:"fest" は昼の野外フェス会場） ---
rep('function clubScene({title,col,lead,rivals,lens,ms,result,done,ui}){','function clubScene({title,col,lead,rivals,lens,ms,result,done,ui,venue}){const OUT=venue==="fest";')
rep('st=clubSet(HK);','st=OUT?festSet(HK):clubSet(HK);')
rep('clubBg(g,W,H);g.drawImage(off,0,0,W,H);','(OUT?festBg:clubBg)(g,W,H);g.drawImage(off,0,0,W,H);')
rep('clubBeams(g,k,t);g.textAlign','if(!OUT)clubBeams(g,k,t);else festSun(g,W,H,t);g.textAlign')
rep('d.style.cssText="position:fixed;inset:0;z-index:80;background:#0b0612;','d.style.cssText="position:fixed;inset:0;z-index:80;background:"+(OUT?"#2c4a6e":"#1a1030")+";')
CODE=r'''
/* ===== 野外フェス会場（昼）：芝生・テント・ガーランド ===== */
function festSet(hk){const st=[],B=(...q)=>VB(st,...q),X0=-30,X1=37,Y1=46;
B(X0,-8,-1,X1-X0,Y1+8,1,(x,y)=>(y>=3&&y<=9)?(((x+y)%4)<2?"#e8d9b0":"#dccb9c"):(((Math.floor(x/3)+Math.floor(y/3))%2)?"#7cc46a":"#6db85c"));
/* 奥の植え込み */
B(X0,-9,0,X1-X0,2,4,(x,y,z)=>z<1?"#4a8a3a":((x*7+z*3)%5<2?"#5aa048":"#4f9640"));
/* テント（ブースごとの色の屋根） */
const TC=[["#ff6b6b","#fff4e6"],["#4dabf7","#fff4e6"],["#ffd43b","#fff4e6"],["#69db7c","#fff4e6"],["#b197fc","#fff4e6"]];
CLX.forEach((bx,i)=>{const c=TC[i];B(bx-1,0,0,8,3,5,(x,y)=>y===2?(i===2?"#ffd54a":"#ffffff"):"#f1e7d0");B(bx-1,0,5,8,3,1,"#c9a77a");
for(const [px,py] of[[bx-2,-2],[bx+7,-2],[bx-2,3],[bx+7,3]])B(px,py,0,1,1,15,"#e9ecef");
for(let q=0;q<3;q++)B(bx-3+q,-3+q,15+q,12-q*2,8-q*2,1,(x)=>((x-bx)%4+4)%4<2?c[0]:c[1]);
const h=hk[i]||["#2f6fa8","#3d86c6"];B(bx+4,0,6,2,2,1,h[0]);B(bx+4,0,7,2,2,2,h[1]);B(bx+4,0,9,1,1,3,"#c0c0c0");B(bx+4,0,12,2,2,1,"#ff7043")});
/* ガーランドの柱と旗 */
for(const px of[X0+2,X1-4])B(px,13,0,1,1,22,"#8d6e63");
for(let x=X0+3;x<X1-4;x+=2)B(x,13,20+Math.round(Math.sin((x-X0)/62*Math.PI)*-1.5),1,1,2,["#ff6b6b","#ffd43b","#4dabf7","#69db7c","#f783ac"][((x-X0)/2|0)%5]);
/* 木 */
for(const [px,py] of[[X0+2,24],[X1-6,26],[X0+4,40],[X1-7,40]]){B(px+1,py+1,0,1,1,7,"#7a5230");B(px-1,py-1,7,5,5,4,(x,y,z)=>(x+y+z)%3?"#4caf50":"#3f9a45");B(px,py,11,3,3,2,"#57b85b")}
return st}
function festBg(g,W,H){const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,"#7cc4ff");gr.addColorStop(.6,"#bfe6ff");gr.addColorStop(1,"#e9f7ff");g.fillStyle=gr;g.fillRect(0,0,W,H);
g.fillStyle="rgba(255,255,255,.85)";[[.18,.12,1],[.62,.08,1.3],[.85,.2,.9]].forEach(([x,y,q])=>{const cx0=W*x,cy0=H*y,r=W*.05*q;g.beginPath();g.arc(cx0,cy0,r,0,7);g.arc(cx0+r*1.1,cy0+r*.2,r*.8,0,7);g.arc(cx0-r*1.1,cy0+r*.25,r*.7,0,7);g.fill()})}
function festSun(g,W,H,t){g.save();g.globalCompositeOperation="lighter";const r=g.createRadialGradient(W*.92,H*.02,5,W*.92,H*.02,W*.55);r.addColorStop(0,"rgba(255,240,180,.35)");r.addColorStop(1,"rgba(255,240,180,0)");g.fillStyle=r;g.fillRect(0,0,W,H);g.restore()}
'''
rep(TAIL,CODE+TAIL)
# フェスは野外会場で
rep('clubScene({title:"🎪 シーシャフェス 🎪",col:"#ffd54a",rivals:clubRivals(),lens,ms:9000,done,ui:','clubScene({title:"🎪 シーシャフェス 🎪",col:"#ffd54a",venue:"fest",rivals:clubRivals(),lens,ms:9000,done,ui:')
rep('ef:"会場はクラブ。行列のお客さんにどんどん作ってふるまおう。','ef:"会場は昼の野外フェス。行列のお客さんにどんどん作ってふるまおう。')
rep('evPop({r:5,n:"シーシャフェスにお呼ばれ"','evPop({r:5,n:"シーシャフェスにお呼ばれ"')
open(f,'w').write(s)
