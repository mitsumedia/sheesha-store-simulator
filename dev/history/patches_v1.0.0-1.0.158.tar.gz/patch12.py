import sys,json
f=sys.argv[1];s=open(f).read()
GM=json.load(open('/home/claude/w/gmodels.json'))
a='const DMD={'
assert s.count(a)==1
s=s.replace(a,'const DMD={'+",".join('%s:%s'%(k,json.dumps(v)) for k,v in GM.items())+(',' if GM else ''))
open(f,'w').write(s);print('models',len(GM))
