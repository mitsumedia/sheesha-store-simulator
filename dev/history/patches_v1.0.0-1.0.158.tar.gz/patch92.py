import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 天気アイコンはキャンバスに描かず、店名の行に出す
rep('cx.font="20px sans-serif";cx.fillText(WXI[wk][0],8,24)','')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== UIリニューアル（上部を1行に・店名と口コミ★・右側の丸ボタン・大きな営業開始・営業中は残り時間バー） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
#top{padding:8px 12px 7px!important;border-radius:0 0 18px 18px!important}
#money{font-size:22px!important}
#top .mt{display:flex!important;gap:6px!important;margin-top:6px!important}
#top .mt>div{flex:1;min-width:0;padding:5px 6px!important;border-radius:11px!important;font-size:0!important;display:flex!important;align-items:center;justify-content:center;gap:3px;height:auto!important;min-height:0!important}
#top .mt>div b{font-size:12.5px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#top .mt>div::before{font-size:13px}
#top .mt>div:nth-child(1)::before{content:"👥"}#top .mt>div:nth-child(2)::before{content:"💴"}#top .mt>div:nth-child(3)::before{content:"😊"}#top .mt>div:nth-child(4)::before{content:"💨"}#top .mt>div:nth-child(5)::before{content:"🔥"}
#top .mt i{display:none!important}#top .mt>div:nth-child(2){flex:1.7!important}#top .mt>div:nth-child(1){flex:.9!important}
#shopln{position:fixed;left:10px;top:calc(var(--uit,104px) + 8px);z-index:6;background:rgba(28,20,40,.86);color:#fff;border-radius:14px;padding:5px 12px;font-size:12.5px;font-weight:700;max-width:calc(100vw - 110px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer;-webkit-tap-highlight-color:transparent}
#shopln b{color:#ffd54a;margin-left:4px}#shopln u{font-weight:400;opacity:.85;margin-left:4px}
.fs #atm,#atm{position:fixed!important;left:10px!important;right:auto!important;top:calc(var(--uit,104px) + 44px)!important;bottom:auto!important;display:flex!important;flex-wrap:nowrap!important;gap:4px!important;margin:0!important;z-index:5}
.fs #atm span,#atm span{padding:2px 7px!important;font-size:11px!important;border-radius:9px!important}
#xrow{position:fixed!important;right:12px!important;left:auto!important;top:calc(var(--uit,104px) + 56px)!important;display:flex!important;flex-direction:column!important;flex-wrap:nowrap!important;gap:16px!important;width:auto!important;z-index:6}
#xrow button{width:48px!important;height:48px!important;border-radius:50%!important;padding:0!important;font-size:0!important;box-shadow:0 4px 12px rgba(0,0,0,.25)!important;position:relative;overflow:visible!important}
#xrow button::first-letter{font-size:22px}
#xrow button::after{content:attr(data-l);position:absolute;bottom:-14px;left:50%;transform:translateX(-50%);font-size:9.5px;font-weight:700;color:#3a2f48;white-space:nowrap;text-shadow:0 0 3px #fff,0 0 3px #fff,0 0 3px #fff}
#xrow button[hidden]{display:none!important}
#mvbtn{position:fixed!important;left:auto!important;right:10px!important;top:auto!important;bottom:calc(env(safe-area-inset-bottom,0px) + 78px)!important;border-radius:22px!important;z-index:6}
#bar .in{gap:8px!important;align-items:center}
#go{flex:2.2!important;font-size:18px!important;height:52px!important;border-radius:26px!important;background:linear-gradient(180deg,#ffcf4a,#f0a21b)!important;color:#3a2200!important;box-shadow:0 6px 16px rgba(240,162,27,.4)!important;border:none!important}
#go.rv{background:linear-gradient(90deg,#7c5cff 0,#7c5cff var(--p,0%),#3a2f55 var(--p,0%))!important;color:#fff!important;box-shadow:none!important;opacity:1!important;font-size:13px!important;line-height:1.25}
#go.rv small{font-weight:400;font-size:11px;opacity:.9}
#vent{flex:0 0 52px!important;width:52px!important;height:52px!important;border-radius:50%!important;font-size:10.5px!important;line-height:1.15!important;padding:0!important;white-space:normal!important}
#menu{flex:0 0 52px!important;width:52px!important;height:52px!important;border-radius:50%!important}
#bar .spd{flex:0 0 auto!important;background:transparent!important;padding:0!important}
#bar .spd button:not(.on){display:none!important}
#bar .spd button.on{width:52px!important;height:52px!important;border-radius:50%!important;font-size:15px!important}
.rvl{display:flex;gap:8px;border-bottom:1px solid var(--bd);padding:9px 0}.rvl .st{color:#f0a21b;letter-spacing:1px;white-space:nowrap}.rvl small{color:var(--mut)}
.rvup{background:#7c5cff;color:#fff;border-radius:6px;padding:0 5px;font-size:10px;margin-left:4px}
</style>`)}catch(e){}
/* 上部の高さに合わせて店名・雰囲気・丸ボタンの位置を決める */
function uiTop(){try{const t=$("#top");if(t){const b=Math.round(t.getBoundingClientRect().bottom);document.documentElement.style.setProperty("--uit",b+"px")}}catch(e){}}
window.addEventListener("resize",()=>setTimeout(uiTop,50));
/* 雰囲気タグは短い名前で1行に */
const TLS={luxury:"ゴ",subculture:"サ",asian:"ア",fantasy:"幻",party:"パ"};
ratm=function(){const a=atmo();$("#atm").innerHTML=TAGS.map(k=>`<span title="${TL[k]}">${TLS[k]||TL[k]} ${a[k]}</span>`).join("")};try{ratm()}catch(e){}
/* 丸ボタンの下のラベル */
{const _xu=xrow;xrow=function(){_xu.apply(this,arguments);const L={tixb:"チケット×"+((G.tix|0)),gachab:"ガチャ",chekib:"チェキ",visb:"めぐり"};for(const k in L){const e=document.getElementById(k);if(e)e.dataset.l=L[k]}uiTop()}}
/* 速度は1つのボタンで ×1→×2→×4→⏸ と切り替え */
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("#bar .spd button.on");if(!b||b._cyc)return;const L=[...b.parentNode.querySelectorAll("button")],i=L.indexOf(b),order=[1,2,3,0],nx=L[order[i]!=null?order[i]:1];if(!nx||nx===b)return;e.stopPropagation();e.preventDefault();nx._cyc=1;nx.click();nx._cyc=0},true);
/* ===== 口コミ（全員匿名・1人1件、また来ると書き換わる） ===== */
const RVC={5:["最高のお店！また絶対来ます","煙がきれいで味も最高でした","店主さんの接客がとても良い","居心地がよすぎて長居しちゃう","内装がおしゃれで落ち着く","ここのシーシャが一番好き"],4:["また来たいと思えるお店","シーシャがおいしかった","雰囲気がいいです","ゆっくりできました","ドリンクがあるのがうれしい","店主さんが話しやすい"],3:["普通に良かったです","可もなく不可もなく","また気が向いたら来ます","もう少し話しかけてほしかったかも","悪くはないです"],2:["ちょっと物足りなかった","期待してたほどでは…","少し居心地が悪かったかも","次はもう少し良くなってるといいな"],1:["残念でした","もう来ないかも","居心地が良くなかったです"]};
const RVSMK=["ちょっと煙たかったです","換気してほしかった…"];
function revAdd(c,p){try{G.rev=G.rev||{};let sc;if(spx(c)){sc=Math.random()<.7?5:4}else{const h=(c.hp||0)-(c.up||0),tk=p&&p.tp>=Math.max(1,Math.ceil((c.tl||3)/3))?.4:-.3;sc=Math.round(3.2+h/30+tk+(Math.random()-.5)*1.2)}
const smk=(R.smoke||0)>=60&&sc<=3;sc=Math.max(1,Math.min(5,sc));const t=smk&&Math.random()<.6?rnd(RVSMK):rnd(RVC[sc]),o=G.rev[c.i];G.rev[c.i]={s:sc,t,d:G.day||1,u:o?1:0,n:((o&&o.n)||0)+1};R.revN=(R.revN||0)+1}catch(e){}}
{const _ev=endVisit;endVisit=function(c,p){const r=_ev.apply(this,arguments);if(c&&c.i!==99&&!(p&&p.vis))revAdd(c,p);return r}}
function revAvg(){const L=Object.values(G.rev||{});if(!L.length)return null;return{a:L.reduce((x,o)=>x+o.s,0)/L.length,n:L.length}}
const revStars=n=>"★★★★★".slice(0,n)+"☆☆☆☆☆".slice(0,5-n);
function revPanel(){const o=$("#visp");if(o)o.remove();const L=Object.values(G.rev||{}).sort((a,b)=>b.d-a.d),av=revAvg(),d=document.createElement("div");d.id="visp";d.className="xpan";
d.innerHTML=`<div class="xin"><div class="xh">💬 ${esc(shopNm())} の口コミ</div>${av?`<div style="text-align:center;margin:6px 0 4px"><span style="font-size:26px;font-weight:800;color:#f0a21b">★ ${av.a.toFixed(1)}</span><br><small style="color:var(--mut)">${av.n}件の口コミ（すべて匿名）</small></div>`:""}
<div style="max-height:56vh;overflow:auto">${L.length?L.map(r=>`<div class="rvl"><div style="flex:1"><span class="st">${revStars(r.s)}</span>${r.u?`<span class="rvup">更新</span>`:""}<br>${esc(r.t)}</div><small>匿名さん<br>${r.d}日目</small></div>`).join(""):`<div class="xs" style="text-align:center;margin:16px 0">まだ口コミはありません。<br>お客さんが帰る時に書いてくれます</div>`}</div>
<div class="xb"><button data-rv="x" style="flex:1">閉じる</button></div></div>`;document.body.appendChild(d);d.onclick=e=>{if(e.target.closest("[data-rv]"))d.remove()}}
/* 店名の行（天気・店名・★・口コミ） */
function shopLine(){let e=$("#shopln");if(!e){e=document.createElement("div");e.id="shopln";document.body.appendChild(e);e.onclick=ev=>{ev.stopPropagation();revPanel()}}
const w=(typeof WXI!=="undefined"&&G.wx)?(WXI[G.wx[G.wd]]||[""])[0]:"",av=revAvg(),h=`${w} 🏪 ${esc(shopNm())}<b>${av?"★"+av.a.toFixed(1):"★ —"}</b><u>口コミ${av?"("+av.n+")":""}</u>`;if(e._h!==h){e._h=h;e.innerHTML=h}e.hidden=!G.setup||!!G.over}
/* 営業中は「営業開始」の場所に時刻と残り時間のバー */
const hm=t=>{t=Math.max(0,Math.round(t));return(Math.floor(t/60)%24)+":"+String(t%60).padStart(2,"0")};
function goRun(){const g=$("#go");if(!g)return;if(R.phase==="run"){const o=G.open*60,c=G.close*60,t=Math.min(R.t,c),p=Math.max(0,Math.min(100,(t-o)/Math.max(1,c-o)*100)),rm=Math.max(0,c-t),h=`🕓 ${hm(t)} 営業中<br><small>閉店 ${hm(c)} まで あと${Math.floor(rm/60)}時間${Math.round(rm%60)}分</small>`;
if(!g.classList.contains("rv"))g.classList.add("rv");if(g._h!==h){g._h=h;g.innerHTML=h}g.style.setProperty("--p",p.toFixed(1)+"%")}else if(g.classList.contains("rv")){g.classList.remove("rv");g._h="";g.textContent="▶ 営業開始"}}
{let _lt=0;const _hu2=hud;hud=function(){const r=_hu2.apply(this,arguments);try{goRun();const n=Date.now();if(n-_lt>400){_lt=n;shopLine();uiTop()}}catch(e){}return r}}
try{xrow();shopLine();uiTop()}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
