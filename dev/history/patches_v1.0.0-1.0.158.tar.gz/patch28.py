import sys
f=sys.argv[1];s=open(f).read()
a='["話しかけ適正回数",c=>"1回の来店で"+c.tl+"回まで"]'
assert s.count(a)==1
s=s.replace(a,'["話しかけ適正回数",c=>spx(c)?"何回でもOK":"1回の来店で"+c.tl+"回まで"]')
open(f,'w').write(s)
