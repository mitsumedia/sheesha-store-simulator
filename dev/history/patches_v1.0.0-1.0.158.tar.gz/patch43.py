import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# --- 引き継ぎコードを濃く・見やすく ---
rep('<div style="font-size:30px;font-weight:800;letter-spacing:3px;text-align:center;margin:12px 0;padding:10px;background:#f4effb;border-radius:10px;user-select:all">','<div style="font-size:30px;font-weight:900;letter-spacing:3px;text-align:center;margin:12px 0;padding:12px 8px;background:#2a1f3d;color:#ffffff;-webkit-text-fill-color:#ffffff;border-radius:10px;font-family:ui-monospace,Menlo,monospace">')
rep('m.innerHTML=`<div class="card" style="width:100%;max-width:380px;','m.innerHTML=`<div class="card" style="color:#241a33;-webkit-text-fill-color:currentColor;width:100%;max-width:380px;')
# --- PRESET（新規プレイ）：のりよし・三ツ目のセリフとフレーバー ---
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
UP={139:{"fl":1,"ls":["ダークシガーこそ至高 ","香り系ってなんなん","ミズナーシはやめろ","水が無くなったら、終わり。","水無終は手叩け","ゆっちゃん……"]},
    150:{"fl":48,"ls":["おすおす","マリオゴルフある？","このゲームおもしろい？","よなちるよろしくね！","おす","パパウパウパウ","だれがなんと言おうとシーシャ吸う～","「シーシャ吸う。」applemusicで聞いてね","不思議な贈り物で[とらとらすいえんてん]って入れてみて"]}}
for e in arr:
    if e['slot'] in UP:e.update(UP[e['slot']])
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
LPI=open('lp_item.txt').read().strip()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 遊んでいるデータにも、のりよし・三ツ目のセリフとフレーバーを反映 ===== */
{const UP=%s;if(!G.up1118){G.cs.forEach(c=>{const u=UP[c.i];if(u){c.fl=u.fl;c.ls=u.ls.slice()}});G.up1118=1;try{save()}catch(e){}}}
/* ===== あいことば（ゲーム内だけで受け取れる・1人1回・期限なし） ===== */
const LPASS=%s;
const kata2hira=t=>t.replace(/[ァ-ヶ]/g,c=>String.fromCharCode(c.charCodeAt(0)-0x60));
function lpTry(v){const k=kata2hira(v.replace(/[\s　]/g,""));const id=LPASS[k];if(!id)return null;G.lpu=G.lpu||[];if(G.lpu.includes(k))return{err:"この贈り物はもう受け取っています"};
if(id.startsWith("seat:")){const sr=id.slice(5),S=SSER.find(q=>q.id===sr);if(!S)return{err:"贈り物が見つかりませんでした"};G.tigerU=1;const ok=ivAdd({t:"f",k:"l",sr});G.lpu.push(k);save();try{rdeco()}catch(e){}
log("🐯 不思議な贈り物：「"+S.n+"」の客席シリーズが解禁！2人がけソファを1つもらった"+(ok?"（📦 持ち物へ）":"（持ち物がいっぱい：受け取り待ちへ）"));return{x:{n:S.n+"の客席シリーズ解禁＋2人がけソファ"},ok}}
const w=WP.find(q=>q.id===id),d=DEC.find(q=>q.id===id),x=w||d;if(!x)return{err:"贈り物が見つかりませんでした"};
const ok=ivAdd({t:w?"w":"d",id});G.lpu.push(k);save();try{rdeco()}catch(e){}log("🎁 不思議な贈り物「"+x.n+"」を受け取った！"+(ok?"（📦 持ち物へ）":"（持ち物がいっぱい：受け取り待ちへ）"));return{x,ok}}
document.addEventListener("click",e=>{const b=e.target.closest("#gfok");if(!b)return;const v=(document.getElementById("gfin").value||"").trim();const r=lpTry(v);if(!r)return;e.stopImmediatePropagation();
if(r.err){sysMsg("gfm",r.err,1);return}sysM(`<div style="text-align:center"><div style="font-size:44px">🎁</div><b>不思議な贈り物</b><div style="font-size:18px;font-weight:700;margin:10px 0">${esc(r.x.n)}</div><div class="m" style="font-size:13px">${r.ok?"📦 持ち物に入れました":"持ち物がいっぱいなので、受け取り待ちに入れました"}</div><button data-sx class="on" style="width:100%%;margin-top:12px">受け取った</button></div>`);try{cloudSave()}catch(_){}},true);
''' % (json.dumps({str(k):v for k,v in UP.items()},ensure_ascii=False), '{}' if LPI=='PLACEHOLDER' else json.dumps({'とらとらすいえんてん':LPI},ensure_ascii=False))
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL)
# 贈り物の入力欄は、コード未発行でも出す（あいことばは誰でも受け取れる）
rep('function giftUI(){const c=cl();if(!c){','function giftUI(){const c=cl();if(false){')
rep('if(id==="gfok"){const v=(document.getElementById("gfin").value||"").trim(),c=cl();if(!v)return;','if(id==="gfok"){const v=(document.getElementById("gfin").value||"").trim(),c=cl();if(!v)return;if(!c){sysMsg("gfm","このあいことばは、☰ →「データ・お知らせ」で引き継ぎコードを発行すると受け取れます",1);return}')
open(f,'w').write(s)
