import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 営業中はメニューを開けない ===== */
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("#menu,#tixb,#gachab,#chekib,#visb");if(!b)return;if(R.phase==="run"){e.stopImmediatePropagation();e.preventDefault();try{toast(b.id==="menu"?"営業中はメニューを開けません":"営業中は使えません。閉店後か開店前に使ってください")}catch(_){}}},true);
try{document.head.insertAdjacentHTML("beforeend",`<style>body.bizrun #menu,body.bizrun #tixb,body.bizrun #gachab,body.bizrun #chekib,body.bizrun #visb{opacity:.45}</style>`)}catch(e){}
{const _h12=hud;hud=function(){const r=_h12.apply(this,arguments);try{const on=R.phase==="run";document.body.classList.toggle("bizrun",on);if(on){const sh=$("#sheet");if(sh&&sh.classList.contains("open"))sh.classList.remove("open")}}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
