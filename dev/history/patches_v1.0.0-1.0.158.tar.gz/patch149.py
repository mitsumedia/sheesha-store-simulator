import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# アプリ内ブラウザ（Xなど）が勝手に入れるスクリプトのエラーは出さない
rep('if(/^Script error/.test(m))return;show(m,','if(/^Script error/.test(m))return;if(/_0x[0-9a-f]{4,}/.test(m)||/webkit-masked-url/.test(String(e.filename||"")+String(e.error&&e.error.stack||"")))return;show(m,')
rep('if(/通信できませんでした|サーバーの応答/.test(m))return;show("（非同期）"+m,','if(/通信できませんでした|サーバーの応答/.test(m))return;if(/_0x[0-9a-f]{4,}/.test(m)||/webkit-masked-url/.test(String(r&&r.stack||"")))return;show("（非同期）"+m,')
open(f,'w').write(s)
