import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('R.smoke*(.012+(R.vent>0?.1:0))','R.smoke*(fanD()+(R.vent>0?fanS():0))')
rep('R.vent=30;R.ventE=R.t+30;','R.vent=fanV();R.ventE=R.t+fanV();')
rep('log("🌀 換気中…（30分）")','log("🌀 換気中…（"+fanV()+"分）")')
rep('R.vcd=20}}else if(R.vcd>0)R.vcd','R.vcd=fanC()}}else if(R.vcd>0)R.vcd')
rep('R.vcd=R.phase==="run"?20:0}}}','R.vcd=R.phase==="run"?fanC():0}}}')
rep('genScn();try{if(typeof xsStatic==="function")xsStatic(a)}catch(e){}','genScn();try{if(typeof xsStatic==="function")xsStatic(a)}catch(e){}try{if(typeof fanVox==="function")fanVox(a)}catch(e){}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 換気扇を買い足す（最大4台）：台数で煙の抜け方と換気ボタンが強くなる ===== */
const FANP=[0,0,300000,800000,2000000],FAND=[0,.012,.03,.05,.08],FANS=[0,.1,.12,.14,.16],FANV=[0,30,30,35,40],FANC=[0,20,15,12,10],FANN=[0,4,10,16,26];
function fanN(){const k=G.at2?"fans2":"fans";return Math.max(1,Math.min(4,G[k]||1))}
const fanD=()=>FAND[fanN()],fanS=()=>FANS[fanN()],fanV=()=>FANV[fanN()],fanC=()=>FANC[fanN()];
/* 壁の上の方に換気扇・外観では屋上にダクト */
function fanVox(a){const n=fanN(),xs=FLT.map(t=>t[0]),ys=FLT.map(t=>t[1]),x0=Math.min(...xs)*6,x1=(Math.max(...xs)+1)*6,y0=Math.min(...ys)*6,y1=(Math.max(...ys)+1)*6,P=(x,y,z,c,t)=>a.push([x,y,z,c,t,.5]);
 for(let i=0;i<n;i++){const cxp=x0+(x1-x0)*(i+1)/(n+1);for(let dx=-1.5;dx<1.5;dx+=.5)for(let z=20;z<23;z+=.5){const e=dx<-1||dx>=1||z<20.5||z>=22.5,mid=Math.abs(dx+.25)<.3||Math.abs(z+.25-21.5)<.3;P(cxp+dx,y0,z,e?"#9e9e9e":mid?"#cfd8dc":"#37474f",1)}}
 if(R.ext){for(let i=0;i<n;i++){const xx=x0+4+i*((x1-x0-8)/Math.max(1,n-1||1)),yy=y1-4;box(a,Math.round(xx),yy,25,1,1,3,"#b0bec5");box(a,Math.round(xx),yy-2,28,1,3,1,"#b0bec5");box(a,Math.round(xx),yy-2,26,1,1,2,"#b0bec5");box(a,Math.round(xx)-.5|0,yy-3,25,2,2,1,"#90a4ae")}}}
/* 装飾タブに「換気扇」 */
{const _rd2=rdeco;rdeco=function(){const r=_rd2.apply(this,arguments);try{const gl=document.querySelector('[data-dc="gl"]')||document.querySelector('[data-dc="wl"]');if(gl&&!document.querySelector('[data-dc="fan"]'))gl.insertAdjacentHTML("afterend",'<button data-dc="fan">🌀 換気扇</button>');
 let sec=$("#sec-fan");const card=$("#sec-gl")||$("#sec-clr");if(!sec&&card){sec=document.createElement("div");sec.id="sec-fan";card.parentNode.insertBefore(sec,card.nextSibling)}const c=R.dcat||"obj";if(sec){sec.hidden=c!=="fan";if(c==="fan"){const n=fanN(),nx=n+1;sec.innerHTML=`<div class="m" style="font-size:12px;margin:8px 0 4px">換気扇 <b>${n}台</b>（最大4台）</div><div style="font-size:12.5px;line-height:1.7;background:rgba(123,79,208,.07);border-radius:10px;padding:8px 10px">換気しなくても快適な人数の目安：<b>約${FANN[n]}人</b><br>換気ボタン：<b>${FANV[n]}分</b>効く・次まで<b>${FANC[n]}分</b></div>`+(n<4?`<div style="font-size:12.5px;margin-top:8px">${nx}台にすると → 目安 約${FANN[nx]}人・換気${FANV[nx]}分／待ち${FANC[nx]}分</div><div id="fanbuy" style="display:flex;gap:6px;margin-top:6px"><button id="fanb" class="on" style="flex:1">${nx}台目を付ける（${yen(FANP[nx])}）</button></div>`:`<div style="font-size:12.5px;margin-top:8px">これ以上は付けられません</div>`)+(G.s2?`<div style="font-size:11px;color:var(--mut);margin-top:6px">※2号店の換気扇は2号店で付けます</div>`:"")}}}catch(e){}return r}}
document.addEventListener("click",e=>{if(!e.target.closest)return;const b=e.target.closest("#fanb,#fanok,#fanno");if(!b)return;e.stopPropagation();const box=$("#fanbuy");if(!box)return;const n=fanN(),nx=n+1;
 if(b.id==="fanb"){box.innerHTML=`<button id="fanno" style="flex:1">やめる</button><button id="fanok" class="on" style="flex:1">${yen(FANP[nx])}で付ける</button>`;return}
 if(b.id==="fanno"){rdeco();return}
 if(b.id==="fanok"){if(nx>4)return;if(G.money<FANP[nx]){try{log("お金が足りません");toast("💸 お金が足りません")}catch(_){}return}G.money-=FANP[nx];G[G.at2?"fans2":"fans"]=nx;log("🌀 換気扇を"+nx+"台にした（−"+yen(FANP[nx])+"）");try{toast("🌀 換気扇を"+nx+"台にしました")}catch(_){}save();build();BGK="";hud();rdeco()}},true);
/* 店長の見た目を変えたら吹き出しの顔も作り直す */
{const _ao=applyOwLook;applyOwLook=function(){const r=_ao.apply(this,arguments);try{delete BFC.ow}catch(e){}return r}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
