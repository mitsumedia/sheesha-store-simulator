import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
LS=["名乗れば誰でも野郎シーシャ会","スミレちゃーん","今日下着何色なん？","それラッキースケベ！","最近何かオモロい事あった？","うまー！！","シーシャ結局調整力"]
# 野郎シーシャ会：カナメのセリフ・フレーバー・ゴリラの見た目を引き継ぎ、帰りは「サンキュー！」
YA={"fl":0,"ls":LS,"bye":"サンキュー！","sp":"kaname","hs":98,"hair":"#161616","skin":"#e8c3a0","shirt":"#f4f4f2","top":0,"bot":1,"pants":"#2f3a4a","sl":2,"shoe":"#e9e9e9","acc":0,"eye":1}
# カナメの枠（No.148）はシーシャ屋「ひめ」に
HI={"name":"ひめ","sex":"女性","age":24,"job":"シーシャ屋","sp":"hime","hs":98,"hair":"#5e1830","skin":"#fbe4dc","shirt":"#26242c","pants":"#1e1e24","top":0,"bot":2,"sl":1,"shoe":"#1a1a1a","fat":0,"acc":0,"eye":0,"fl":5,"ls":[],"bye":"ありがとうございました♡","fav":"subculture"}
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot']==142:e.update(YA)
    if e['slot']==147:e.update(HI)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
ADD='''
/* ===== 野郎シーシャ会にカナメの中身を移し、No.148をひめに（遊んでいるデータにも反映） ===== */
{const YA=%s,HI=%s;if(!G.hime1){const a=G.cs[142],b=G.cs[147];if(a&&!a.ed)Object.assign(a,YA);if(b&&!b.ed)Object.assign(b,HI);G.hime1=1;try{save()}catch(e){}}}
''' % (json.dumps(YA,ensure_ascii=False),json.dumps(HI,ensure_ascii=False))
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
