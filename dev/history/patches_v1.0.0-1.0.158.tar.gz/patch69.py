import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 席選び：しばらく座られていない席ほど選ばれやすく（1人客も空いた2人がけに座る）
rep('fr.forEach(s=>{const v=avoid(m[0],s)+kb[s.kind];','fr.forEach(s=>{const v=avoid(m[0],s)+kb[s.kind]+sIdle(s);')
rep('cand.forEach(g=>{const v=avoid(m[0],g[0])+avoid(m[1],g[1]);','cand.forEach(g=>{const v=avoid(m[0],g[0])+avoid(m[1],g[1])+sIdle(g[0])*2;')
rep('function pickSeats(m){','function sIdle(s){const u=(R.sUse||{})[s.fid];return Math.min(18,(R.t-(u!=null?u:G.open*60-90))/8)}\nfunction pickSeats(m){')
rep(TAIL,'''{const _ps=pickSeats;pickSeats=function(m){const r=_ps.apply(this,arguments);try{if(r&&R.phase==="run"){R.sUse=R.sUse||{};r.forEach(s=>{if(s&&s.fid!=null)R.sUse[s.fid]=R.t})}}catch(e){}return r}}
{const _st=start;start=function(){R.sUse={};return _st.apply(this,arguments)}}
/* 起動時：回した席の向きを正しく描くため、全部の仕組みが揃ってから作り直す */
try{furnRebuild();build()}catch(e){}
'''+TAIL)
open(f,'w').write(s)
