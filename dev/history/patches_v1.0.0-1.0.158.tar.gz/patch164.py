import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 外観モード：店の壁（t）は全部見せ、道の向かいの景色（t=2）は隠す
rep('const wallVis=(t,k)=>!t||(t===1?k.cy>0:t===2?k.cx>0:t===3?k.cy<0:k.cx<0);','const wallVis=(t,k)=>!t||(R.ext?t!==2:(t===1?k.cy>0:t===2?k.cx>0:t===3?k.cy<0:k.cx<0));')
rep('genScn();try{if(typeof glassMod==="function")glassMod(a)}catch(e){}','genScn();try{if(typeof glassMod==="function")glassMod(a)}catch(e){}try{if(typeof extMod==="function")extMod(a)}catch(e){}')
rep('if(ptr.size===1){mv+=Math.abs(dx)+Math.abs(dy);if(mv>12){R.cam.yaw+=dx*.008;R.cam.pit=clamp(R.cam.pit+dy*.006,.2,1.45);R.camVer++}}','if(ptr.size===1){mv+=Math.abs(dx)+Math.abs(dy);if(mv>12){R.cam.yaw+=dx*.008;if(R.ext)R.cam.yaw=clamp(R.cam.yaw,EXT_Y-1.1,EXT_Y+1.1);R.cam.pit=clamp(R.cam.pit+dy*.006,R.ext?.08:.2,R.ext?.7:1.45);R.camVer++}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 外観モード（見るだけ・回転だけ） ===== */
const EXT_Y=1.62;R.ext=0;
function extMod(a){if(!R.ext)return;const xs=FLT.map(t=>t[0]),ys=FLT.map(t=>t[1]),EC="#8f857a",EC2="#7a7066";
 for(const v of a){if(v[4]&&v[4]!==2&&!(v[5]&&v[5]<1))v[3]=((v[2]|0)%4===0)?EC2:EC;if(v[4]===2&&(!v[5]||v[5]>=1))v[4]=0}
 FLT.forEach(([tx,ty])=>{box(a,tx*6-1,ty*6-1,24,8,8,1,"#5f5a55")});
 const x0=Math.min(...xs)*6-1,x1=(Math.max(...xs)+1)*6+1,y0=Math.min(...ys)*6-1,y1=(Math.max(...ys)+1)*6+1;
 box(a,x0-1,y0-1,25,x1-x0+2,1,1.5,"#4e4944");box(a,x0-1,y1,25,x1-x0+2,1,1.5,"#4e4944");box(a,x0-1,y0,25,1,y1-y0,1.5,"#4e4944");box(a,x1,y0,25,1,y1-y0,1.5,"#4e4944");
 box(a,x0+8,y0+4,25,5,4,4,"#cfd8dc");box(a,x0+8.3,y0+4.3,29,4.4,3.4,.4,"#b0bec5");box(a,x0+16,y1-9,25,4,4,7,"#90a4ae");box(a,x0+15.7,y1-9.3,32,4.6,4.6,.6,"#78909c");
 }
let EXT_SV=null;
function extSet(on){if(!!R.ext===!!on)return;if(on){EXT_SV={yaw:R.cam.yaw,pit:R.cam.pit,zoom:R.cam.zoom};R.ext=1;R.cam.yaw=EXT_Y;R.cam.pit=.22;R.cam.zoom=Math.max(1.05,R.cam.zoom*1.1)}else{R.ext=0;if(EXT_SV)Object.assign(R.cam,EXT_SV)}build();R.camVer++;BGK="";try{xrow()}catch(e){}document.body.classList.toggle("extv",!!R.ext)}
{const _ot=onTap;onTap=function(){if(R.ext)return;return _ot.apply(this,arguments)}}
{const _bd=build;build=function(){const r=_bd.apply(this,arguments);try{if(R.ext){TX-=7;TY+=0}}catch(e){}return r}}
{const _xe=xrow;xrow=function(){const r=_xe.apply(this,arguments);try{const x=$("#xrow");if(x){let b=$("#extb");if(!b){b=document.createElement("button");b.id="extb";b.onclick=e=>{e.stopPropagation();extSet(!R.ext)}}const ck=$("#chekib");if(ck&&ck.nextSibling!==b)ck.after(b);else if(!b.parentNode)x.appendChild(b);b.textContent=R.ext?"🏪 店内":"🏠 外観";b.dataset.l=R.ext?"店内":"外観";b.classList.toggle("on",!!R.ext)}}catch(e){}return r}}
try{xrow()}catch(e){}
(function(){const st=document.createElement("style");st.textContent=`body.extv #mvbtn,body.extv .cvw .hint{display:none!important}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
