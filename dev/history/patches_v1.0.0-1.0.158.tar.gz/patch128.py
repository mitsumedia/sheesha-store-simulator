import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 三ツ目（専用モデル）に四角メガネを描く（顔の前の面、髪より先に描いて前髪が上に重なる）
rep('return L})().forEach(([x,z,col])=>fc(x,z,col));',
 'return L})().forEach(([x,z,col])=>fc(x,z,col));\n'
 'if(c.acc===10){const GC=dkHex(c.accC||"#d9c79a",.72),gp=(cx,cz)=>P(cx*q,3,8+cz*q,q,GC);'
 'for(const m of[0,1]){const X=v=>m?15-v:v;for(let cx=2;cx<=7;cx++){gp(X(cx),3);gp(X(cx),7)}for(let cz=4;cz<=6;cz++){gp(X(2),cz);gp(X(7),cz)}}'
 'gp(8,6);gp(7,6);for(let y=1.5;y<3;y+=q){P(-.25,y,8+6*q,q,GC);P(4,y,8+6*q,q,GC)}}')
open(f,'w').write(s)
