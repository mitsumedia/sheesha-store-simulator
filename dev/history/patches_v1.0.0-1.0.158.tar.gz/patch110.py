import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 上のステータスに項目名を戻す（客・売上・満足度・煙たさ・やる気） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
html body #top .mt>div{font-size:10px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important;gap:1px!important;padding:4px 7px 5px!important;line-height:1.25!important;white-space:nowrap;overflow:hidden}
html body #top .mt>div::before{content:none!important;display:none!important}
html body #top .mt>div b{font-size:13px!important;line-height:1.2!important}
html body #top .mt>div i{display:block!important;width:100%!important;height:3px!important;border-radius:2px!important;background:rgba(255,255,255,.12)!important;overflow:hidden;margin-top:2px!important;position:static!important}
html body #top .mt>div i u{display:block!important;height:100%!important}
</style>`)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
s=open(f).read()
s=s.replace(TAIL,r'''
/* 換気中は項目名を「🌀 換気中」にして、値は煙たさだけ（はみ出し防止） */
{const _hv2=hud;hud=function(){const r=_hv2.apply(this,arguments);try{const b=document.getElementById("mtk");if(b){const d=b.parentNode,t=d.firstChild,v=R.phase==="run"&&R.vent>0,lb=v?"🌀 換気中":"💨 煙たさ";if(t&&t.nodeType===3&&t.textContent!==lb)t.textContent=lb;if(v)b.textContent=b.textContent.replace("換気中 ","")}}catch(e){}return r}}
'''+TAIL,1)
open(f,'w').write(s)
s=open(f).read()
s=s.replace(TAIL,r'''
/* 満足度の枠を「🚶 来店数」（今日来たお客さんの人数）に */
{const _hv3=hud;hud=function(){const r=_hv3.apply(this,arguments);try{const b=document.getElementById("mth");if(b){const d=b.parentNode,t=d.firstChild;if(t&&t.nodeType===3&&t.textContent!=="🚶 来店数")t.textContent="🚶 来店数";const run=R.phase==="run",v=run&&R.st?(R.st.visits||0)+"人":(((G.week||[])[G.wd-1]||{}).visits!=null?"前回 "+G.week[G.wd-1].visits+"人":"—");if(b.textContent!==v)b.textContent=v;const bar=document.getElementById("mthb");if(bar&&bar.parentNode)bar.parentNode.style.visibility="hidden"}}catch(e){}return r}}
'''+TAIL,1)
open(f,'w').write(s)
