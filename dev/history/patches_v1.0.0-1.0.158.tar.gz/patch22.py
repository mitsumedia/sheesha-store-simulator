import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 廃業防止（図鑑30人以降は救済）
rep('if(G.money<0)G.over=true;save();showResult()}','if(G.money<0&&!(typeof s2Rescue==="function"&&s2Rescue()))G.over=true;save();showResult()}')
# 精算画面：2号店と救済の行
rep('-(r.brk?r.brk.cost:0)-r.pay;\nov(','-(r.brk?r.brk.cost:0)-r.pay+(r.s2?r.s2.net:0);\nov(')
rep('${row("今回の収支",','${typeof s2Rows==="function"?s2Rows(r,row):""}${row("今回の収支",')
# 解禁条件は1号店の増築で判定
rep('k==="bb"||(G.exN||0)>=','k==="bb"||s1v("exN")>=')
rep('u[0]==="extra"?(G.extra||0)>=u[1]:u[0]==="exn"?(G.exN||0)>=u[1]:','u[0]==="extra"?s1v("extra")>=u[1]:u[0]==="exn"?s1v("exN")>=u[1]:')
# 店長は1号店に客として来ない
rep('const pr=k=>!k.act||','const pr=k=>!k.act||(G.s2&&G.s2.mgr===k.i)||')
ADD=r'''
/* ===== 2号店 ===== */
function s1v(k){return(G.at2&&G.s1st?G.s1st[k]:G[k])||0}
const S2K=["fl","furn","decor","wall","fcl","wcl","extra","exN","plm","pln","spm","spn","loc"],S2COST=10000000,S2ASK=15000000,S2DEX=100;
const s2Pick=()=>{const o={};S2K.forEach(k=>{if(G[k]!==undefined)o[k]=G[k]});return o};
function s2Swap(to2,nob){if(!G.s2||!!G.at2===!!to2)return;if(to2){G.s1st=s2Pick();S2K.forEach(k=>delete G[k]);Object.assign(G,G.s2.st||{});delete G.s2.st;G.at2=1}else{G.s2.st=s2Pick();S2K.forEach(k=>delete G[k]);Object.assign(G,G.s1st||{});delete G.s1st;G.at2=0}
if(!G.fl)G.fl=DEFFL();G.furn=G.furn||[];G.decor=G.decor||[];G.wall=G.wall||[];G.extra=G.extra||0;syncFl();if(!nob){furnRebuild();build();R.camVer++;try{rdeco()}catch(e){}hud()}}
const s2Ok=()=>!G.s2&&dexN()>=S2DEX;
const mgType=c=>c.pe%3;const MGT=[["接客型","売上は月によって少し上下（×0.85〜1.05）"],["職人型","売上が安定（×0.9）"],["ムードメーカー型","売上の波が大きい（×0.6〜1.4）"]];
const mgMul=c=>{if(!c)return .5;const t=mgType(c);return t===1?.9:t===0?.85+Math.random()*.2:.6+Math.random()*.8};
const s2Mg=()=>G.s2&&G.s2.mgr!=null?G.cs[G.s2.mgr]:null;
function s2Open(){if(!s2Ok()||G.money<S2COST)return;G.money-=S2COST;const l=G.loc||{a:1,t:1,v:0};
G.s2={st:{fl:DEFFL(),furn:[],decor:[],wall:[],fcl:0,wcl:0,extra:0,exN:0,loc:{a:l.a,t:l.t,v:((l.v|0)+7)%NVAR}},free:1,m0:G.month,mgr:null,red:0};
log("🏪 2号店を開業しました！（-"+yen(S2COST)+"）");save();hud();rfin()}
function s2Ask(){ov(`<div class="card"><b>🏪 2号店を開業しますか？</b><div class="m" style="font-size:13px;margin:8px 0;line-height:1.6">開業費 <b>${yen(S2COST)}</b>（客席・置物の代金は別）<br>2号店は毎月、月末精算の前に1日営業します。<br>最初は床と壁だけの空っぽのお店です。最初に2号店で営業するまでは、客席と置物を制限なく置けます。<br>新しい壁紙6種と床材6種も解禁されます。</div>
<button id="s2y" class="on" style="width:100%" ${G.money>=S2COST?"":"disabled"}>開業する</button><button id="s2n" style="width:100%;margin-top:6px">しない（あとで開業できます）</button></div>`)}
function s2Card(){const s2=G.s2,mg=s2Mg(),bt=(id,ic,t,d,ok)=>`<button id="${id}" ${ok?"":"disabled"} style="width:100%;text-align:left;margin-top:6px"><b>${ic} ${t}</b><small style="display:block;color:var(--mut)">${d}</small></button>`;
if(s2.ask&&mg){ov(`<div class="card"><b>🏪 2号店の日</b><div style="font-size:13px;margin:8px 0;line-height:1.6">店長の${esc(nm(mg))}さんから相談です。<br>「3か月続けて赤字です…。しばらく2号店を休業しますか？」</div>${bt("s2rest","💤","休業する","家賃や光熱費がかからなくなります。いつでも再開できます",1)}${bt("s2keep","💪","続ける","このまま営業を続けます",1)}</div>`);return}
if(s2.rest){ov(`<div class="card"><b>🏪 2号店は休業中です</b><div class="m" style="font-size:12px;margin:6px 0">休業中は家賃や光熱費がかかりません</div>${bt("s2re","🔑","営業を再開する","今日から2号店を営業できます",1)}${bt("s2skip","📋","休業のまま月末精算へ","",1)}</div>`);return}
const lsv=s2.lsv||0,first=s2.free;
ov(`<div class="card"><b>🏪 2号店の日（月末精算の前）</b>
<div class="m" style="font-size:12px;margin:6px 0">${mg?`店長：<b>${esc(nm(mg))}</b>（${MGT[mgType(mg)][0]}）`:"店長はいません。店長がいない日はアルバイトに任せます（売上×0.5）"}</div>
${mg&&lsv?`<div style="font-size:12px;background:var(--bg);border-radius:10px;padding:6px 8px;margin-bottom:4px">店長より：「今月もお店は回しておきました。前回の見回りの日は ${yen(lsv)} でしたよ」</div>`:""}
${bt("s2go","🚶","見回り営業（2号店で1日営業）",first?"最初の営業です。客席と置物を制限なく置けます":"今日の売上 × 店長の力 × 残りの日数分が、2号店の月の売上になります",1)}
${bt("s2auto","🧑‍💼","店長に任せる",!mg?"店長がいないと任せられません":!lsv?"一度見回り営業をすると任せられます":"前回の見回りの売上の80%で計算します（"+yen(lsv)+"）",!!mg&&lsv>0)}
${bt("s2off","💤","今月は2号店を開けない","売上は0。家賃や光熱費はかかります",1)}
${bt("s2mg","👔",mg?"店長を交代する":"店長をスカウトする","親密度100の常連さんから選べます",1)}</div>`)}
function s2MgPanel(){const L=G.cs.filter(c=>!c.ex&&c.met&&lv(c)>=NL&&c.job!=="シーシャ屋"&&!spx(c)),mg=s2Mg();
ov(`<div class="card"><b>👔 店長を選ぶ</b><div class="m" style="font-size:12px;margin:4px 0 8px">親密度100の常連さんから選べます。店長になった人は1号店には来なくなります。交代するといつものお客さんに戻ります。</div>
${MGT.map(t=>`<div class="m" style="font-size:11px">・${t[0]}：${t[1]}</div>`).join("")}
<div style="max-height:50vh;overflow:auto;margin-top:8px">${L.length?L.map(c=>`<button data-s2m="${c.i}" class="${mg===c?"on":""}" style="width:100%;text-align:left;margin-top:4px;display:flex;gap:8px;align-items:center">${FACEC[c.i]?`<img src="${FACEC[c.i]}" style="width:34px;height:34px;border-radius:8px">`:""}<span><b>${esc(nm(c))}</b><small style="display:block;color:var(--mut)">${esc(c.job||"")}・${MGT[mgType(c)][0]}${mg===c?"（いまの店長）":""}</small></span></button>`).join(""):`<div class="m">まだ親密度100の常連さんがいません</div>`}</div>
${mg?`<button data-s2m="-1" style="width:100%;margin-top:8px">店長をやめてもらう</button>`:""}<button id="s2back" style="width:100%;margin-top:6px">もどる</button></div>`)}
function s2Enter(){G.s2p=0;s2Swap(true);if(G.ow)G.ow.acted=1;if(G.wx[G.wd]==="typhoon")G.wx[G.wd]="sun";ovOff();save();hud();rown&&rown();
const mg=s2Mg();log("🏪 2号店にやってきた。準備ができたら「営業開始」！");
ov(`<div class="card"><b>🏪 2号店に来ました</b><div style="font-size:13px;margin:8px 0;line-height:1.6">${G.s2.free?"最初の営業です。客席と置物は、2号店で最初に営業するまで制限なく置けます。<br>客席を置かないと営業できません。":"内装を整えて「営業開始」を押そう。"}${mg?"<br>店長の"+esc(nm(mg))+"さんが待っていました。":""}</div><button id="s2ok" class="on" style="width:100%">OK</button></div>`)}
function s2Finish(mode,en){const s2=G.s2;G.s2r={mode,sales:en?en.sales:0,vis:en?en.visits:0};if(mode==="visit"&&en&&!en.closed){s2.lsv=en.sales;s2.free=0}G.s2m=G.month;G.s2p=0}
function s2Acc(){const s2=G.s2,r=G.s2r||{mode:"off"},days=MDAYS[G.month%12],st=s2.st||{},mg=s2Mg();if(s2.rest&&r.mode!=="visit")return{rest:1,net:0,mode:"rest"};
const m=mgMul(mg);let sales=0,auto=0;if(r.mode==="visit"){sales=r.sales;auto=Math.round(sales*m*(days-1))}else if(r.mode==="auto")auto=Math.round((s2.lsv||0)*.8*m*days);
const e2=st.extra||0,seats=(st.furn||[]).reduce((a,F)=>a+((SDEF[F.k]||{n:0}).n),0),tot=sales+auto,
rent=G.month===s2.m0?0:Math.round((RENT0+RENT_BLK*e2)*locM().r/1000)*1000,util=Math.round((UTIL0+UTIL_BLK*e2)*Math.max(.4,1+.1*(hrsNow()-10)))+SEATU*seats,flv=Math.round(tot*FLV),coal=Math.round(tot*.03),
net=auto-rent-util-flv-coal,pf=tot-rent-util-flv-coal;
if(mg){s2.red=pf<0?(s2.red||0)+1:0;if(s2.red>=3)s2.ask=1}else s2.red=0;
return{mode:r.mode,mg:mg?nm(mg):"",ty:mg?MGT[mgType(mg)][0]:"アルバイト",m:Math.round(m*100)/100,sales,auto,rent,util,flv,coal,net,pf,vis:r.vis||0}}
function s2Rows(r,row){let h="";const x=r.s2;if(x){h+=`<div style="height:6px"></div><div class="m" style="font-size:12px;font-weight:700">🏪 2号店</div>`;
if(x.rest)h+=row("休業中","¥0");else{h+=row(x.mode==="visit"?"見回りの日の売上（来店"+x.vis+"人）":x.mode==="auto"?"店長に任せた":"今月は開けなかった",x.mode==="visit"?yen(x.sales):"—");
h+=row((x.mg?"店長 "+esc(x.mg)+"（"+x.ty+"×"+x.m+"）":"アルバイト（×0.5）")+"の営業",x.mode==="off"?"¥0":"+"+yen(x.auto),"pos");
h+=row(x.rent?"家賃":"家賃（初月フリーレント）","-"+yen(x.rent),"neg")+row("水道光熱費","-"+yen(x.util),"neg")+row("フレーバー代・炭代","-"+yen(x.flv+x.coal),"neg")+row("2号店の収支",(x.pf>=0?"+":"")+yen(x.pf),x.pf<0?"neg":"pos")}}
if(r.resc)h+=`<div style="height:6px"></div>`+row("🤝 常連さんのカンパ（救済融資）","+"+yen(r.resc),"pos")+`<div class="m" style="font-size:11px">お店は続けられます。返済が終わるまで、置物は月3個までになります</div>`;
if(G.s2&&!G.over)h+=`<div id="expc2" style="margin-top:6px"></div>`;return h}
function s2Rescue(){if(dexN()<30)return false;const amt=Math.ceil((-G.money+200000)/100000)*100000;G.loan.bal+=amt;G.money+=amt;G.loan.pay=Math.max(G.loan.pay||0,50000);G.resc=1;if(G.ow)G.ow.fame=Math.max(10,G.ow.fame-5);
if(G.last){G.last.resc=amt;G.last.after=G.money;G.last.bal=G.loan.bal}log("🤝 常連さんたちのカンパで、お店を続けられることになった（救済融資 "+yen(amt)+"）");return true}
function rexp2(){const c=$("#expc2");if(!c||!G.s2)return;if(G.loan.bal>0||(G.last&&G.last.ex)){c.innerHTML="";return}if(G.s2.exm===G.month){c.innerHTML=`<div class="m" style="font-size:12px">今月は2号店を増築済みです</div>`;return}
s2Swap(true,1);const{o}=exOpts();s2Swap(false,1);syncFl();
c.innerHTML=o.length?`<div class="m" style="font-size:12px;margin-bottom:2px">🏗 2号店を増築する（増築ローン）</div>`+o.map(x=>`<button data-ex2="${x.k}" style="width:100%;margin-top:4px">2号店：${x.n}（+${x.t.length}マス・${yen(x.cost)}）</button>`).join(""):`<div class="m" style="font-size:12px">2号店はこれ以上広げられません</div>`}
function s2Expand(k){if(G.loan.bal>0||!G.s2||G.s2.exm===G.month)return;s2Swap(true,1);const x=exOpts().o.find(q=>q.k===k);if(x){x.t.forEach(t=>{if(!G.fl.includes(t))G.fl.push(t)});G.extra+=x.t.length;G.exN=(G.exN||0)+1}s2Swap(false,1);syncFl();if(!x)return;
G.loan.bal+=G.lotto?0:x.cost;G.loan.pay=Math.ceil(x.cost/6.3/10000)*10000;G.s2.exm=G.month;if(G.last)G.last.bal=G.loan.bal;save();hud();rfin();log("🏗 2号店を"+x.n+"増築しました（+"+x.t.length+"マス・増築ローン "+yen(x.cost)+"）");showResult()}
{const _st=settle;settle=function(){if(G.s2&&!G.at2&&G.s2m!==G.month){G.s2p=1;save();return}let x=null;if(G.s2){x=s2Acc();G.money+=x.net;G.s2r=null}_st();if(x&&G.last){G.last.s2=x;G.last.before-=x.net;save();showResult()}}}
{const _dd=dayDone;dayDone=function(en){if(!G.at2)return _dd(en);s2Finish("visit",en);s2Swap(false);if(G.ow)G.ow.acted=0;R.phase="prep";$("#go").disabled=false;$("#go").textContent="営業開始";$("#op").disabled=$("#cl").disabled=false;try{halloOff()}catch(e){}settle();rdex();rfr();rfin()}}
{const _sm=showMorning;showMorning=function(){const pre=R.phase==="prep"&&G.setup&&G.ow&&!G.over&&!(G.last&&!G.last.seen);
if(pre&&G.s2p&&!G.at2){s2Card();return}if(pre&&!G.at2&&s2Ok()&&!G.s2no&&G.money>=S2ASK&&!G.ow.acted){s2Ask();return}
_sm();if(s2Ok()&&G.s2no){const cd=$("#ov .card");if(cd&&!$("#s2open"))cd.insertAdjacentHTML("beforeend",`<button id="s2open" style="width:100%;margin-top:6px" ${G.money>=S2COST?"":"disabled"}><b>🏪 2号店を開業する（${yen(S2COST)}）</b></button>`)}}}
{const _s=start;start=function(){if(R.phase==="prep"&&G.setup&&!G.over&&(G.furn||[]).length===0){ov(`<div class="card"><b>⚠️ 客席を置かないと営業できません</b><div class="m" style="font-size:12px;margin:6px 0">「模様替え」から客席を置いてください</div><button id="s2ok" class="on" style="width:100%">OK</button></div>`);return}_s()};$("#go").onclick=start}
{const _h=hud;hud=function(){_h();if(G.at2){const d=$("#day");if(d&&!/2号店/.test(d.textContent))d.textContent+=" 🏪2号店"}}}
{const _pl=plLeft;plLeft=function(){if(G.at2&&G.s2&&G.s2.free)return 99;if(G.resc&&G.loan.bal<=0)G.resc=0;const v=_pl();return G.resc&&!G.at2?Math.min(v,3-(G.plm===G.month?G.pln||0:0)):v}}
{const _sl=splLeft;splLeft=function(){if(G.at2&&G.s2&&G.s2.free)return 99;return _sl()}}
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const id=b.id;
if(id==="s2y"){s2Open();ovOff();ov(`<div class="card"><b>🏪 2号店を開業しました！</b><div style="font-size:13px;margin:8px 0;line-height:1.6">今月の月末精算の前に、2号店で1日営業します。<br>新しい壁紙と床材が解禁されました。</div><button id="s2ok2" class="on" style="width:100%">OK</button></div>`)}
else if(id==="s2n"){G.s2no=1;save();ovOff();showMorning()}
else if(id==="s2open")s2Ask();
else if(id==="s2ok2"){ovOff();showMorning()}
else if(id==="s2ok")ovOff();
else if(id==="s2go")s2Enter();
else if(id==="s2auto"){s2Finish("auto");ovOff();settle()}
else if(id==="s2off"){s2Finish("off");ovOff();settle()}
else if(id==="s2skip"){s2Finish("rest");ovOff();settle()}
else if(id==="s2mg")s2MgPanel();
else if(id==="s2back")s2Card();
else if(id==="s2rest"){G.s2.rest=1;G.s2.ask=0;G.s2.red=0;save();s2Card()}
else if(id==="s2keep"){G.s2.ask=0;G.s2.red=0;save();s2Card()}
else if(id==="s2re"){G.s2.rest=0;save();s2Card()}
if(b.dataset&&b.dataset.s2m){const v=+b.dataset.s2m;G.s2.mgr=v<0?null:v;G.s2.red=0;save();if(v>=0)log("👔 "+nm(G.cs[v])+"さんが2号店の店長になった");s2Card()}
if(b.dataset&&b.dataset.ex2)s2Expand(b.dataset.ex2)});
{const _sr=showResult;showResult=function(){_sr();try{rexp2()}catch(e){}}}

/* ===== 新しい壁紙・床材（各12種） ===== */
{const F2=[["古いフローリング","oldfl",["#9c7a55","#5e4630"],["s2"]],["黒いステージ床","stage",["#151515","#2a2a2a"],["s2"]],["畳（縁あり）","tatami2",["#cdbf7c","#2c3e2a"],["s2"]],["モザイク絨毯","mosaic2",["#0f4c5c","#c99a2e"],["s2"]],["砂浜","sand",["#e8d5a3","#d9c38a"],["s2"]],["ウッドデッキ","deck",["#9a6b45","#4a3524"],["s2"]],
["船の甲板","shipdk",["#b0804e","#1e1a16"],["exg",0]],["月面","moon",["#9e9e9e","#7d7d7d"],["exg",1]],["氷の床","ice",["#cfeefc","#ffffff"],["exg",2]],["檜の床","hinoki",["#ecd3a3","#c9a874"],["exg",3]],["銭湯のタイル","sento",["#f4f8fb","#4fa3d9"],["exg",4]],["サーカスのリング","circus",["#d62828","#f4f1de"],["exg",5]]];
const W2=[["ステッカーだらけの壁","sticker","#8f8f8f",["s2"]],["フライヤー貼り","flyer","#3a3a3a",["s2"]],["障子","shoji","#f5f1e6",["s2"]],["アーチ模様のタイル","arch","#1f6f78",["s2"]],["白い漆喰","shikkui","#f7f3ea",["s2"]],["夜景の窓","yakei","#1b2347",["s2"]],
["丸太小屋","logw","#a0703f",["exg",6]],["レトロ喫茶の板壁","kissa","#5a3a22",["exg",7]],["歯車の壁","gear","#b08d57",["exg",8]],["夜空の花火","hanabi","#0c1030",["exg",9]],["ホテルのダマスク柄","damask","#efe6d0",["exg",10]],["本棚の壁","books","#6b4423",["exg",11]]];
F2.forEach(([n,pt,c,u])=>FLC.push({n,pt,c,u,p:20000}));W2.forEach(([n,pt,c,u])=>WLC.push({n,pt,c,u,p:20000}))}
{const _co=clrOpen;clrOpen=function(o){if(o&&o.u&&o.u[0]==="s2")return!!G.s2;if(o&&o.u&&o.u[0]==="exg")return(G.exg||[]).includes(o.u[1]);return _co(o)}}
{const _cc=clrCond;clrCond=function(o){if(o&&o.u&&o.u[0]==="s2")return"2号店の開業で解禁";if(o&&o.u&&o.u[0]==="exg")return"EXのお客さんからのプレゼント";return _cc(o)}}
{const _fp=flPat;flPat=function(pt,tx,ty){const r=n=>hsh(tx,ty,n),o=[],A=(p,c)=>o.push([p,c]),ev=(tx+ty)%2,pk=(a,n)=>a[(r(n)*a.length)|0];
switch(pt){
case"oldfl":for(let i=0;i<3;i++){A(RC(0,i*2,6,i*2+2),"#5e4630");A(RC(0,i*2+.1,6,i*2+1.9),pk(["#9c7a55","#8f6e4a","#a8865e","#86643f"],i));if(r(i+9)<.5)A(RC(r(i+3)*4,i*2+.7,r(i+3)*4+1.4,i*2+.85),"#7a5c3c");A(RC((r(i+5)*5)|0,i*2,((r(i+5)*5)|0)+.1,i*2+2),"#5e4630")}break;
case"stage":A(RC(0,0,6,6),"#151515");for(let i=1;i<6;i++)A(RC(0,i-.04,6,i+.04),"#232323");if(r(1)<.12){const x=.8+r(2)*3.4,y=.8+r(3)*3.4;A(RC(x,y,x+1.2,y+.25),pk(["#ffd54f","#ffffff","#ff4f8b"],4));A(RC(x+.48,y-.48,x+.72,y+.73),pk(["#ffd54f","#ffffff","#ff4f8b"],4))}break;
case"tatami2":{const o2=(Math.floor(tx/2)+Math.floor(ty/2))%2;A(RC(0,0,6,6),"#c9bb78");
if(!o2){for(let i=1;i<8;i++)A(RC(0,.4+i*.65,6,.4+i*.65+.05),"#c2b471");A(RC(0,0,6,.4),"#2f3d2a");A(RC(0,5.6,6,6),"#2f3d2a");A(tx%2?RC(5.95,0,6,6):RC(0,0,.05,6),"#a99a5c")}
else{for(let i=1;i<8;i++)A(RC(.4+i*.65,0,.4+i*.65+.05,6),"#c2b471");A(RC(0,0,.4,6),"#2f3d2a");A(RC(5.6,0,6,6),"#2f3d2a");A(ty%2?RC(0,5.95,6,6):RC(0,0,6,.05),"#a99a5c")}}break;
case"mosaic2":A(RC(0,0,6,6),"#e9d8a6");for(let a=0;a<6;a++)for(let b=0;b<6;b++){const c=["#0f6b6b","#c99a2e","#b23a48","#1f3a6b","#0f4c5c"][(Math.abs(a-2.5)+Math.abs(b-2.5)+((tx+ty)&1))%5|0];A(RC(a+.08,b+.08,a+.92,b+.92),c)}break;
case"sand":A(RC(0,0,6,6),"#e8d5a3");for(let i=0;i<10;i++){const x=r(i)*5.7,y=r(i+20)*5.7;A(RC(x,y,x+.25,y+.25),i%2?"#d9c38a":"#f3e4bd")}if(r(40)<.15){const x=1+r(41)*3.5,y=1+r(42)*3.5;A([[x,y],[x+.6,y-.3],[x+1.2,y],[x+.6,y+.5]],"#f7c6c7")}break;
case"deck":A(RC(0,0,6,6),"#4a3524");for(let i=0;i<6;i++){A(RC(i+.07,0,i+.93,6),pk(["#9a6b45","#8d6040","#a6764d"],i));A(RC(i+.4,.4,i+.6,.6),"#5e4630");A(RC(i+.4,5.4,i+.6,5.6),"#5e4630")}break;
case"shipdk":A(RC(0,0,6,6),"#1e1a16");for(let i=0;i<4;i++)A(RC(0,i*1.5+.08,6,i*1.5+1.42),pk(["#b0804e","#a67445","#bb8a56"],i));A(RC((r(9)*5)|0,0,((r(9)*5)|0)+.08,6),"#1e1a16");break;
case"moon":A(RC(0,0,6,6),pk(["#9e9e9e","#a5a5a5","#979797"],1));for(let i=0;i<2;i++)if(r(i+5)<.6){const x=1.2+r(i+7)*3.6,y=1.2+r(i+11)*3.6,s=.5+r(i+13)*.7,P=n=>{const p=[];for(let k=0;k<10;k++){const a=k/10*Math.PI*2;p.push([x+Math.cos(a)*n,y+Math.sin(a)*n])}return clip6(p)};A(P(s),"#b8b8b8");A(P(s*.75),"#7d7d7d")}for(let i=0;i<5;i++){const x=r(i+20)*5.7,y=r(i+30)*5.7;A(RC(x,y,x+.2,y+.2),"#8a8a8a")}break;
case"ice":A(RC(0,0,6,6),ev?"#cfeefc":"#c3e8f9");{let x=r(1)*6,y=0;while(y<6){const nx=x+(r(y*3+2)-.5)*3,ny=y+1.5;A(clip6([[x,y],[nx,ny],[nx+.12,ny],[x+.12,y]]),"#ffffff");x=nx;y=ny}}A(RC(.6,.6,1.2,.8),"#f2fbff");break;
case"hinoki":for(let i=0;i<3;i++){A(RC(0,i*2,6,i*2+2),"#c9a874");A(RC(0,i*2+.06,6,i*2+1.94),pk(["#ecd3a3","#e8cc98","#f0daae"],i));A(RC(r(i+4)*4,i*2+.9,r(i+4)*4+1.6,i*2+1),"#dcbf8c")}break;
case"sento":A(RC(0,0,6,6),"#c6d3dc");for(let a=0;a<4;a++)for(let b=0;b<4;b++)A(RC(a*1.5+.08,b*1.5+.08,a*1.5+1.42,b*1.5+1.42),r(a*4+b)<.12?"#4fa3d9":"#f4f8fb");break;
case"circus":A([[0,0],[6,0],[3,3]],ev?"#d62828":"#f4f1de");A([[6,0],[6,6],[3,3]],ev?"#f4f1de":"#d62828");A([[6,6],[0,6],[3,3]],ev?"#d62828":"#f4f1de");A([[0,6],[0,0],[3,3]],ev?"#f4f1de":"#d62828");A([[3,2.3],[3.7,3],[3,3.7],[2.3,3]],"#f2c14e");break;
default:return _fp(pt,tx,ty)}return o}}
{const _wc=wlCol;wlCol=function(o,x,y,z,t){const h=((t===1||t===3)?x:y)+40,r=n=>hsh(x+y*7,z,n),hs=hsh;
switch(o.pt){
case"sticker":{const cx=Math.floor(h/3),cz=Math.floor(z/3),p=hs(cx,cz,7);if(p<.42&&h%3!==2&&z%3!==2)return["#ff5f8f","#ffd23f","#3bb2f6","#7cdf64","#ffffff","#b388ff","#ff8a3d"][(p*16.6)|0];return r(1)<.2?"#858585":"#8f8f8f"}
case"flyer":{const u=h%5,v=z%6,p=hs(Math.floor(h/5),Math.floor(z/6),3);if(u===4||v===5)return"#3a3a3a";const c=["#f2e9d8","#ffd23f","#ff6b6b","#7cc6fe","#c7f464","#f7a8c4"][(p*6)|0];if(v===1&&u<3)return"#222222";if(v===3&&u===1)return"#555555";return c}
case"shoji":if(z<5)return z===4?"#5a3e24":"#7a5a38";if(z===23)return"#5a3e24";return(h%4===0||(z-5)%4===0)?"#9c7650":"#f5f1e6";
case"arch":{const u=h%6,v=z%12;if(v===0||v===11)return"#c99a2e";const inA=u>=1&&u<=4&&v>=2&&(v<=8||(v===9&&u>=2&&u<=3));if(inA){if(v===2||u===1||u===4||(v===8&&(u===1||u===4))||v===9)return"#c99a2e";return(u+v)%2?"#1f6f78":"#175a62"}return(u+v)%2?"#e8dcc4":"#efe4cf"}
case"shikkui":if(z<2)return"#cfc6b4";return r(1)<.18?"#efe9dc":r(2)<.06?"#e6dece":"#f7f3ea";
case"yakei":{if(h%8===0||z<3||z>20)return"#2b2b33";const col=Math.floor(h/2),bh=4+hs(col,1,9)*10;if(z-3<bh)return hs(h,z,4)<.16?"#ffd36e":"#11131c";return r(5)<.03?"#ffffff":z>15?"#141b3a":"#1b2347"}
case"logw":if(z%3===2)return"#5b3a1e";if(r(6)<.03)return"#6d4625";return["#a0703f","#94653a","#ab7a47"][Math.floor(z/3)%3];
case"kissa":if(z<10)return(h%3===0)?"#4a2f1b":"#5a3a22";if(z===10)return"#3b2414";if(z===23)return"#3b2414";return r(2)<.08?"#e5d5b2":"#efe2c4";
case"gear":{const ci=Math.floor(h/12),gx=ci*12+6,gz=12,dx=h+.5-gx,dz=(z+.5-gz)*.5,d=Math.hypot(dx,dz),a=Math.atan2(dz,dx)+ci;if(d<1.4)return"#2a2724";if(d<2.4)return"#d8b878";if(d<4.4)return(Math.floor((a+20)/(Math.PI/3))%2&&d>2.8&&d<3.9)?"#2a2724":"#b08d57";if(d<5.6&&Math.floor((a+20)/(Math.PI/5))%2===0)return"#9c7a47";return r(3)<.1?"#46423d":"#3d3a36"}
case"hanabi":{const ci=Math.floor(h/13),gx=ci*13+6.5,gz=ci%2?11:14,dx=h+.5-gx,dz=(z+.5-gz)*.5,d=Math.hypot(dx,dz),a=Math.atan2(dz,dx),k=hs(ci,3,2),pal=[["#ff5f8f","#ffd23f"],["#7cdf64","#3bb2f6"],["#ffd23f","#ff8a3d"],["#b388ff","#ffffff"]][(k*4)|0],ray=Math.abs(((a+Math.PI)*6/Math.PI)%1-.5)>.28;if(d<1.2)return"#fff6c8";if(d<6.4&&d>1.6&&ray)return d<4.2?pal[0]:pal[1];return r(4)<.025?"#ffffff":"#0c1030"}
case"damask":{const u=h%6,v=z%8,dd=Math.abs(u-2.5)+Math.abs(v-3.5);if(z<3)return"#7a1f2b";if(z===3)return"#c8a96a";if(dd<1.2||(dd>2.4&&dd<3.2))return"#c8a96a";return"#efe6d0"}
case"books":{const v=z%6;if(v===0||z===23)return"#6b4423";const p=hs(h,Math.floor(z/6),8),bh=3+((p*3)|0);if(v<=bh&&p>.08)return["#7b2d3a","#2f5d50","#34495e","#c49a6c","#8e6c3a","#5d4037","#b5653f"][(hs(h,Math.floor(z/6),9)*7)|0];return"#3a2414"}
default:return _wc(o,x,y,z,t)}}}
'''
rep(TAIL,ADD+TAIL)
open(f,'w').write(s)
