import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 店主タブ：着せ替えもカタログ形式（選ぶと見本の店主に着せて回る→「着がえる」で決定） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
#owcat{display:flex;gap:6px;margin:0 0 8px;overflow-x:auto;scrollbar-width:none}#owcat::-webkit-scrollbar{display:none}
html body #sheet.open #owcat button{flex:none;padding:6px 14px!important;border-radius:18px!important;font-size:12.5px!important;font-weight:900;background:#fff!important;border:1.5px solid #cfd8d4!important;color:#123a33!important}
html body #sheet.open #owcat button.on{background:#6658a6!important;border-color:#6658a6!important;color:#fff!important}
#owlist{background:#fff;border-radius:12px;padding:2px 10px;margin-bottom:10px}
html body #sheet.open #owlist button{display:flex!important;align-items:center;gap:10px;width:100%;min-height:42px;padding:6px 4px!important;border:none!important;border-bottom:1px solid #ecebe4!important;border-radius:0!important;background:transparent!important;color:#123a33!important;font-weight:900!important;font-size:14px!important;text-align:left!important}
html body #sheet.open #owlist button .ic{width:26px;height:26px;border-radius:7px;background:#e3efec;display:flex;align-items:center;justify-content:center;font-size:13px;flex:none}
html body #sheet.open #owlist button .n{flex:1}
html body #sheet.open #owlist button .p{font-size:11.5px;color:#005d4d}
html body #sheet.open #owlist button.sel{background:#6658a6!important;color:#fff!important;border-radius:10px!important;border-bottom-color:transparent!important}html body #sheet.open #owlist button.sel .p{color:#fff}html body #sheet.open #owlist button.sel .ic{background:#fff3}
html body #sheet.open #owlist .sh{font-size:11.5px;font-weight:900;color:#6658a6;padding:10px 2px 4px;border-bottom:1px solid #ecebe4}
html body #sheet #fms .hint{top:auto!important;bottom:32px!important;left:auto!important;right:12px!important;transform:none!important;font-size:9.5px!important;opacity:.8}
#owmore{font-size:11.5px;color:#7f9690;text-align:center;padding:10px 4px}
</style>`)}catch(e){}
const OWCAT={hs:["髪型","h","h2",()=>HSN,"💇"],top:["服","t","t2",()=>TOPN,"👕"],bot:["ズボン","b","b2",()=>BOTN,"👖"]};
let OWK="top",OWPV=null;
const owCur=k=>{const o=G.ow||{},m=OWCAT[k][2];return o[m]?99+o[m]:(o[k]!=null?o[k]:(OW.c[k]||0))};
function owLook(k,v){const L=Object.assign({},OW.c),m=OWCAT[k][2];if(v>=100){L[m]=v-99}else{L[m]=0;L[k]=v}return L}
function owRender(){const po=$("#p-own2");if(!po)return;const o=G.ow||{},cat=OWCAT[OWK],base=cat[3](),cur=owCur(OWK),ty=cat[1];
const rows=base.map((n,i)=>[i,n,0]).concat(OWL[ty].map((x,i)=>[100+i,x[0],1]).filter(r=>owHas(ty+(r[0]-99))));const hidden=OWL[ty].length-rows.filter(r=>r[2]).length;
po.innerHTML=`<div id="owcat">${Object.entries(OWCAT).map(([k,c])=>`<button data-owk="${k}" class="${k===OWK?"on":""}">${c[4]} ${c[0]}</button>`).join("")}<button data-owk="edit">🎨 色・名前</button></div>
<div id="owlist">${rows.map(([v,n,x])=>`<button data-owv="${v}" class="${OWPV===v?"sel":""}"><span class="ic">${cat[4]}</span><span class="n">${esc(n)}</span><span class="p">${v===cur?"着用中":x?"限定":""}</span></button>`).join("")}${hidden>0?`<div id="owmore">いろいろなことを達成すると、着せ替えが増えていきます</div>`:""}</div>
<div class="fmcard"><b>${esc(o.name||"店長")}</b> <span class="m">${o.age?o.age+"歳":""}${o.sex?"・"+esc(o.sex):""}</span><div class="m" style="font-size:12px;margin-top:4px">SNSフォロワー ${(o.fol||0).toLocaleString()}人</div></div>`;
po.onclick=e=>{const k=e.target.closest("[data-owk]");if(k){e.stopPropagation();if(k.dataset.owk==="edit"){try{showOwEdit()}catch(_){const b=document.querySelector("[data-owedit]");if(b)b.click()}return}OWK=k.dataset.owk;OWPV=null;owRender();owStage();fmBtn(null);return}
const r=e.target.closest("[data-owv]");if(r){e.stopPropagation();const v=+r.dataset.owv;if(v===owCur(OWK)){OWPV=null;owRender();owStage();fmBtn(null);return}OWPV=v;owRender();owStage();fmBtn("着がえる ▶")}}}
function owStage(){const o=G.ow||{},st=Math.round(typeof starOf==="function"?starOf(o):0),fm=Math.round(o.fame||0),sk=(o.skill||0),look=OWPV!=null?owLook(OWK,OWPV):OW.c;
const keep=FMS.ang;fmsSet("p",look,`<div class="tl" style="background:none;padding:0;font-size:15px">${esc(o.name||"店長")}<div style="font-size:10.5px;color:#8fc9bc;font-weight:700">${OWPV!=null?"試着中…":esc(shopNm())+" の店主"}</div></div><div class="tr" style="width:128px;color:#fff">${[["👀 知名度",fm,fm],["⭐ スター性",st,st],["💨 技術",sk.toFixed(1),Math.min(100,sk)]].map(([l,v,p])=>`<div style="display:flex;justify-content:space-between;font-size:11px"><span>${l}</span><b>${v}</b></div><div class="ga" style="margin:2px 0 6px"><i style="width:${p}%"></i></div>`).join("")}</div>`);if(OWPV!=null)FMS.ang=keep}
function owApply(){if(OWPV==null)return;const o=G.ow;if(!o)return;const k=OWK,m=OWCAT[k][2],v=OWPV;if(v>=100){o[m]=v-99}else{o[m]=0;o[k]=v}applyOwLook();save();OWPV=null;owRender();owStage();fmBtn(null);try{toast("👕 着がえました")}catch(e){}}
fmOwner=function(){owRender();owStage();fmBtn(OWPV!=null?"着がえる ▶":null)};
{const _fg2=fmGo;fmGo=function(){if(FMTAB==="owner"){owApply();return}return _fg2.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
