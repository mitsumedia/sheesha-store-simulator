import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 管理者モード：置物無制限（1ヶ月の設置数の上限をなくす。置物・壁アイテム・客席） ===== */
{const _pl=plLeft;plLeft=function(){return G.admNL?999:_pl.apply(this,arguments)}}
{const _sl=splLeft;splLeft=function(){return G.admNL?999:_sl.apply(this,arguments)}}
{const _rd=rdeco;rdeco=function(){const r=_rd.apply(this,arguments);try{if(G.admNL){const e=$("#plc");if(e)e.innerHTML="今月の設置：<b>無制限</b>（管理者モード）";const p=$("#spc");if(p)p.innerHTML="今月の客席の設置：<b>無制限</b>（管理者モード）"}}catch(e){}return r}}
{const _ap=admPanel;admPanel=function(){const r=_ap.apply(this,arguments);const d=$("#adm");if(!d)return r;
const put=()=>{if(d.querySelector("[data-adnl]"))return;const call=d.querySelector('[data-ad="call"]');if(!call)return;const b=document.createElement("button");b.dataset.adnl="1";b.style.cssText="display:block;width:100%;margin:0 0 8px;padding:9px 10px;border-radius:10px;font-weight:700;font-size:14px;border:1.5px solid #7b4fd6;"+(G.admNL?"background:#efe6ff;color:#4a2a99":"background:#fff;color:#4a2a99");b.textContent=(G.admNL?"✅ ":"")+"🪴 置物無制限（1ヶ月の設置数の上限なし）";call.after(b)};put();
d.addEventListener("click",e=>{const b=e.target.closest("[data-adnl]");if(b){e.stopPropagation();G.admNL=G.admNL?0:1;save();b.remove();put();try{rdeco();rseat&&rseat()}catch(_){}log("🛠 管理者モード：置物無制限 "+(G.admNL?"ON":"OFF"));return}setTimeout(put,0)},true);return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
