import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# セリフの表示時間を0.4秒短く
rep('p.bub=t;p.bt=3.2;','p.bub=t;p.bt=2.8;')
# 電車は手前の建物や駅舎に隠さず、高架の上を走る姿をいつも見せる
rep('const L2=items.slice(),used=new Set();items.forEach(it=>{const m=it.m,','const L2=items.slice(),used=new Set();items.forEach(it=>{if(it.m.tr)return;const m=it.m,')
open(f,'w').write(s)
