import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 停電：画面全体ではなく、店の中（建物の形）だけ暗くする
rep('function darkDraw(s,T){if(!R.dark)return;cx.fillStyle="rgba(3,3,8,.94)";cx.fillRect(0,0,W,CH);','function darkDraw(s,T){if(!R.dark)return;if(R.dark._fr!==R.frN)darkHull(R.cv);')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* 停電の暗さ：店の建物の形だけ */
function darkHull(k){if(!R.dark||!k)return;R.dark._fr=R.frN;cx.save();cx.fillStyle="rgba(3,3,8,.94)";cx.beginPath();FLT.forEach(([tx,ty])=>{const pts=[];for(const x of[tx*6-1,tx*6+7])for(const y of[ty*6-1,ty*6+7])for(const z of[0,24.5])pts.push(P3(x,y,z,k));const h=mbHull(pts);h.forEach((p,i)=>i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]));cx.closePath()});cx.fill("nonzero");cx.restore()}
{const _dr=draw;draw=function(){R.frN=(R.frN||0)+1;return _dr.apply(this,arguments)}}
/* 道の側から見る時は、外を歩く人より先に暗くする（外の人は暗くならない） */
{const _au7=auraDraw;auraDraw=function(k,fg){if(fg&&R.dark)try{darkHull(k)}catch(e){}return _au7.apply(this,arguments)}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
