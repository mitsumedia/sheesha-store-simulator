import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('genScn();R.stat=cull(a);R.stV++}','genScn();try{if(typeof glassMod==="function")glassMod(a)}catch(e){}R.stat=cull(a);R.stV++}')
rep('if(!h(-1,0)&&!(tx===0&&ty===2))WB.push({x:X-1,y:Y,z:0,w:1,d:6,h:24,t:2});','if(!h(-1,0)&&!(tx===0&&ty===2)&&!glassOn())WB.push({x:X-1,y:Y,z:0,w:1,d:6,h:24,t:2});')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 道に面した壁をガラス張りに（見本） ===== */
function glassOn(){return 1}
const GFC=[{n:"ブラック（初期）",c:"#2b2b2f"},{n:"ホワイト",c:"#f2f2f2"},{n:"ナチュラルウッド",c:"#b68a5a"},{n:"ダークウッド",c:"#5d4030"},{n:"シルバー",c:"#b8bec4"},{n:"ゴールド",c:"#c9a227"},{n:"ネイビー",c:"#2c3e66"},{n:"レッド",c:"#b3262e"},{n:"ミント",c:"#7fc8a9"},{n:"ピンク",c:"#e889ad"}],GFP=5000;
function gfcCur(){return GFC[R.pvG!=null?R.pvG:(G.gfc||0)]||GFC[0]}
function gfcPrev(i){R.pvG=null;const bar=$("#clrbar");if(bar)bar.remove();if(i!=null){R.pvG=i;const sh=$("#sheet");if(sh)sh.classList.remove("open");const d=document.createElement("div");d.id="clrbar";d.innerHTML=`<div class="tc"><div>窓枠を「<b>${esc(GFC[i].n)}</b>」にしますか？　¥${GFP.toLocaleString()}</div><div class="row" style="justify-content:flex-end;margin-top:8px"><button id="gfcno">やめる</button><button id="gfcok" class="on">購入する</button></div></div>`;document.body.appendChild(d)}build();BGK="";try{rdeco()}catch(e){}}
document.addEventListener("click",e=>{if(!e.target.closest)return;const g=e.target.closest("[data-gfc]");if(g){e.stopPropagation();const i=+g.dataset.gfc;if(i===(G.gfc||0))return;gfcPrev(i);return}const b=e.target.closest("#gfcok,#gfcno");if(!b)return;e.stopPropagation();const i=R.pvG;if(b.id==="gfcok"&&i!=null){if(G.money<GFP){log("お金が足りません")}else{G.money-=GFP;G.gfc=i;log("🪟 窓枠を「"+GFC[i].n+"」に変更（-¥"+GFP.toLocaleString()+"）");save();hud()}}gfcPrev(null)},true);
{const _rd=rdeco;rdeco=function(){const r=_rd.apply(this,arguments);try{const wl0=document.querySelector('[data-dc="wl"]'),cat=wl0&&wl0.parentNode;if(cat&&!cat.querySelector('[data-dc="gl"]'))wl0.insertAdjacentHTML("afterend",'<button data-dc="gl">🪟 ガラス窓</button>');
 let sec=$("#sec-gl");const card=$("#sec-clr");if(!sec&&card){sec=document.createElement("div");sec.id="sec-gl";card.parentNode.insertBefore(sec,card.nextSibling)}const c=R.dcat||"obj";if(sec){sec.hidden=c!=="gl";if(c==="gl"){const cur=G.gfc||0;const cs=G.gls||0;sec.innerHTML=`<div class="m" style="font-size:12px;margin:8px 0 4px">ガラスのデザイン</div><div class="grid">${GSTY.map((f,i)=>`<button class="it ${cs===i?"on":""}" data-gls="${i}">${f.n}<small>${cs===i?"使用中":"¥"+f.p.toLocaleString()}</small></button>`).join("")}</div><div class="m" style="font-size:12px;margin:12px 0 4px">ガラスの窓枠</div><div class="grid">${GFC.map((f,i)=>`<button class="it ${cur===i?"on":""}" data-gfc="${i}"><span class="sw" style="background:${f.c};border:1px solid #888"></span>${f.n}<small>${cur===i?"使用中":"¥"+GFP.toLocaleString()}</small></button>`).join("")}</div>`}}
 cat&&cat.querySelectorAll("[data-dc]").forEach(x=>x.classList.toggle("on",x.dataset.dc===c&&R.tool!=="mv"))}catch(e){}return r}}
function glassMod(a){if(!glassOn())return;const fc=gfcCur().c,GX=new Set();if(glsCur()===10){FLT.forEach(([tx,ty])=>{if(FLS.has((tx-1)+","+ty)||(tx===0&&ty===2))return;const X=tx*6,Y=ty*6;for(const yy of[Y+1.5,Y+4]){box(a,X,yy,0,1.5,1.5,1.5,"#a1887f");box(a,X-.25+.25,yy-.25,1.5,2,2,1.5,"#43a047");box(a,X+.25,yy+.25,3,1,1,1,"#66bb6a")}})}FLT.forEach(([tx,ty])=>{if(!FLS.has((tx-1)+","+ty)&&!(tx===0&&ty===2))GX.add(tx*6-1)});for(let i=a.length-1;i>=0;i--){const v=a[i];if(v[4]!==2||!GX.has(v[0])||(v[5]&&v[5]<1))continue;const yy=((v[1]%6)+6)%6;if(yy===0||v[2]>=22||v[2]<1)v[3]=fc;else a.splice(i,1)}}
const GSTY=[{n:"ふつうのガラス（初期）",p:0},{n:"すりガラス",p:300000},{n:"スモークガラス",p:300000},{n:"ステンドグラス",p:600000},{n:"格子窓",p:300000},{n:"アーチ窓",p:450000},{n:"障子窓",p:450000},{n:"ネオンサイン（店名）",p:600000},{n:"カフェカーテン",p:300000},{n:"ガラスブロック",p:450000},{n:"植物の窓辺",p:300000}];
function glsCur(){return R.pvS!=null?R.pvS:(G.gls||0)}
function glsPrev(i){R.pvS=null;const bar=$("#clrbar");if(bar)bar.remove();if(i!=null){R.pvS=i;const sh=$("#sheet");if(sh)sh.classList.remove("open");const d=document.createElement("div");d.id="clrbar";d.innerHTML=`<div class="tc"><div>ガラスを「<b>${esc(GSTY[i].n)}</b>」にしますか？　¥${GSTY[i].p.toLocaleString()}</div><div class="row" style="justify-content:flex-end;margin-top:8px"><button id="glsno">やめる</button><button id="glsok" class="on">購入する</button></div></div>`;document.body.appendChild(d)}build();BGK="";try{rdeco()}catch(e){}}
document.addEventListener("click",e=>{if(!e.target.closest)return;const g=e.target.closest("[data-gls]");if(g){e.stopPropagation();const i=+g.dataset.gls;if(i===(G.gls||0))return;glsPrev(i);return}const b=e.target.closest("#glsok,#glsno");if(!b)return;e.stopPropagation();const i=R.pvS;if(b.id==="glsok"&&i!=null){const pr=GSTY[i].p;if(G.money<pr){log("お金が足りません")}else{G.money-=pr;G.gls=i;log("🪟 ガラスを「"+GSTY[i].n+"」に変更（-¥"+pr.toLocaleString()+"）");save();hud()}}glsPrev(null)},true);
function glassDraw(k){if(!glassOn()||(!R.ext&&!wallVis(2,k)))return;const segs=[];FLT.forEach(([tx,ty])=>{if(FLS.has((tx-1)+","+ty)||(tx===0&&ty===2))return;segs.push([tx*6-.5,ty*6])});
 const night=LTN&&LTN.glow>.2,st=glsCur(),fc=gfcCur().c;cx.save();
 segs.forEach(([X0,y0],si)=>{const Q=(u,v)=>P3(X0,y0+1+u*5,1+v*21,k),poly=(pts,fill,stroke,lw)=>{cx.beginPath();pts.forEach(([u,v],i)=>{const p=Q(u,v);i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1])});cx.closePath();if(fill){cx.fillStyle=fill;cx.fill()}if(stroke){cx.strokeStyle=stroke;cx.lineWidth=lw||1;cx.stroke()}},rect=(u0,v0,u1,v1,f,s2,lw)=>poly([[u0,v0],[u1,v0],[u1,v1],[u0,v1]],f,s2,lw),line=(u0,v0,u1,v1,c,lw)=>{const a=Q(u0,v0),b=Q(u1,v1);cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.strokeStyle=c;cx.lineWidth=lw||1;cx.stroke()};
  const plane=fn=>{const o=R.ext?Q(0,1):Q(1,1),ex=R.ext?Q(1,1):Q(0,1),ey=R.ext?Q(0,0):Q(1,0);cx.save();cx.transform(ex[0]-o[0],ex[1]-o[1],ey[0]-o[0],ey[1]-o[1],o[0],o[1]);fn();cx.restore()};
  const base=()=>rect(0,0,1,1,night?"rgba(255,226,170,.16)":"rgba(170,215,240,.22)"),streak=()=>{for(const[f0,f1]of[[.15,.45],[.3,.55]])line(f0,.9,f1,.15,"rgba(255,255,255,.35)",1.2)};
  if(st===0){base();streak()}
  else if(st===1){rect(0,0,1,1,night?"rgba(255,240,215,.62)":"rgba(240,244,246,.68)");streak()}
  else if(st===2){rect(0,0,1,1,"rgba(25,25,35,.55)");streak()}
  else if(st===3){const C=["#e53935","#1e88e5","#fdd835","#43a047","#8e24aa","#fb8c00"];for(let i=0;i<3;i++)for(let j=0;j<7;j++){const u0=i/3,v0=j/7;rect(u0,v0,u0+1/3,v0+1/7,C[(i*5+j*3+si)%C.length]+(night?"cc":"88"),fc,1.4)}}
  else if(st===4){base();for(let i=1;i<4;i++)line(i/4,0,i/4,1,fc,1.3);for(let j=1;j<8;j++)line(0,j/8,1,j/8,fc,1.3)}
  else if(st===5){base();streak();const pts=[[0,1],[0,.78]];for(let t=0;t<=16;t++){const a=Math.PI*t/16;pts.push([.5-.5*Math.cos(a),.78+.2*Math.sin(a)])}pts.push([1,.78],[1,1]);const wall=(WLC[G.wcl||0]||WLC[0]).c;poly([[0,1],[1,1],[1,.78]].concat(pts.slice(2).reverse()).concat([[0,.78]]),wall);const arc=[];for(let t=0;t<=16;t++){const a=Math.PI*t/16;arc.push([.5-.5*Math.cos(a),.78+.2*Math.sin(a)])}for(let i=0;i<arc.length-1;i++)line(arc[i][0],arc[i][1],arc[i+1][0],arc[i+1][1],fc,2.2)}
  else if(st===6){base();rect(0,.42,1,1,night?"rgba(255,236,190,.95)":"rgba(246,238,218,.95)");for(let i=1;i<4;i++)line(i/4,.42,i/4,1,"#7a5a3a",1.2);for(let j=1;j<6;j++)line(0,.42+j*.58/6,1,.42+j*.58/6,"#7a5a3a",1.2);line(0,.42,1,.42,"#7a5a3a",2)}
  else if(st===7){base();streak();if(si%2===0)plane(()=>{cx.save();cx.scale(1/100,1/100);const t=String((G.ow&&G.ow.shop)||"SHEESHA");cx.textAlign="center";cx.textBaseline="middle";let fs=22;cx.font="900 "+fs+"px sans-serif";const tw=cx.measureText(t).width;if(tw>78){fs=Math.max(8,fs*78/tw);cx.font="900 "+fs+"px sans-serif"}cx.shadowColor="#ff4fa3";cx.shadowBlur=night?14:4;cx.strokeStyle="#ff4fa3";cx.lineWidth=3;cx.strokeRect(8,28,84,28);cx.fillStyle=night?"#ffd1ec":"#ff4fa3";cx.fillText(t,50,43);cx.font="900 11px sans-serif";cx.shadowColor="#40c4ff";cx.fillStyle=night?"#d6f5ff":"#29b6f6";cx.fillText("OPEN",50,66);cx.restore()})}
  else if(st===8){base();streak();const cc="#c0392b";rect(0,0,1,.38,cc+"ee");for(let i=1;i<10;i++)line(i/10,0,i/10,.38,"rgba(0,0,0,.18)",1);line(0,.39,1,.39,"#8d6e63",2.4)}
  else if(st===9){for(let i=0;i<4;i++)for(let j=0;j<12;j++){const u0=i/4,v0=j/12,du=1/4,dv=1/12;rect(u0,v0,u0+du,v0+dv,night?"rgba(255,232,190,.55)":"rgba(200,230,240,.6)","rgba(255,255,255,.75)",1.2);rect(u0+du*.25,v0+dv*.25,u0+du*.75,v0+dv*.75,"rgba(255,255,255,.18)")}}
  else if(st===10){base();streak()}
 });cx.restore()}
{const _md=mbDraw;mbDraw=function(k,fg){const r=_md.apply(this,arguments);try{if(R.ext?fg:!fg)glassDraw(k)}catch(e){}return r}}
/* 営業中以外（通行人がいない時）もガラスは描く */
{const _db2=drawBG;drawBG=function(k){const r=_db2.apply(this,arguments);try{if(!mbOn()&&!R.ext)glassDraw(k)}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
# 読み込み直後の build はガラスの設定が準備される前に走るので、準備ができてから作り直す
s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(TAIL)==1
s=s.replace(TAIL,'\nsetTimeout(()=>{try{build();BGK=""}catch(e){}},0);\n'+TAIL)
open(f,'w').write(s)
