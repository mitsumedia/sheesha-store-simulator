import sys,json
f=sys.argv[1];s=open(f).read()
M=json.load(open('/home/claude/w/rename.json'))
i=s.find('const PRESET=');j=s.find('];',i);seg=s[i:j]
for o,n in M:
    assert seg.count('"name":"%s"'%o)==1,o
    seg=seg.replace('"name":"%s"'%o,'"name":"%s"'%n)
s=s[:i]+seg+s[j:]
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD='''
/* ===== レア3・4の名前の変更（保存データも置きかえ） ===== */
{const RN=%s;const m=new Map(RN);(G.cs||[]).forEach(c=>{if(!c.ex&&m.has(c.name))c.name=m.get(c.name)});}
'''%json.dumps(M,ensure_ascii=False)
assert s.count(TAIL)==1
s=s.replace(TAIL,ADD+TAIL)
open(f,'w').write(s)
