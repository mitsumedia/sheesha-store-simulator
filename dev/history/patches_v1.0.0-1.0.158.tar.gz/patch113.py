import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# お店めぐり：自分が着ているロゴTは自分の店名のまま（相手の店名にならない）
rep('visLook(G0.ow));v.me=me;','visLook(G0.ow));if(me.prT==null)me.prT=(G0.ow&&G0.ow.shop)||"SHISHA";v.me=me;')
# リフレッシュをなくす
rep('お店に集中以外ではやる気も上がります。','')
rep('<br>🧖 リフレッシュ：温泉・サウナ・スパのどれかにランダムで行き、やる気が回復（¥1,000〜5,000）','<br>🧹 掃除：床をなぞって汚れを落とす。きれいだと口コミが良くなる')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== リフレッシュを行動から外す（掃除を練習の次に並べ、5つ目は横いっぱい） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>#ov .mnc .mg>[data-mo="refresh"],[data-o="refresh"]{display:none!important}#ov .mnc .mg>button:last-child:nth-child(odd){grid-column:1/-1}</style>`)}catch(e){}
{const _sm3=showMorning;showMorning=function(){const r=_sm3.apply(this,arguments);try{const g=document.querySelector("#ov .mnc .mg");if(g){const rf=g.querySelector('[data-mo="refresh"]'),cl=g.querySelector('[data-mo="clean"]');if(rf){if(cl)g.insertBefore(cl,rf);rf.remove()}}}catch(e){}return r}}
{const _ac3=act;act=function(k){if(k==="refresh")return;return _ac3.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
