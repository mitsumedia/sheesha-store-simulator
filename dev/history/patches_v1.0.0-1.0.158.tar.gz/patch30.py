import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* 営業中は招待チケット・ガチャ・チェキを押せなくする */
{const runNG=()=>R.phase==="run";
const lockX=()=>{const ng=runNG();["#tixb","#gachab","#chekib"].forEach(id=>{const b=document.querySelector(id);if(b){b.disabled=ng;b.style.opacity=ng?".45":"";b.style.pointerEvents=ng?"none":""}})};
{const _x=xrow;xrow=function(){const r=_x.apply(this,arguments);try{lockX()}catch(e){}return r}}
for(const nm of["tixPanel","gachaPanel","chekiPanel"]){const o=window[nm];if(typeof o!=="function")continue;window[nm]=function(){if(runNG()){try{toast("営業中は使えません")}catch(e){}return}return o.apply(this,arguments)}}
{const _s=start;start=function(){const r=_s.apply(this,arguments);try{["#tixp","#gap","#ckp"].forEach(id=>{const e=document.querySelector(id);if(e)e.remove()});lockX()}catch(e){}return r};$("#go").onclick=start}
setInterval(()=>{try{lockX()}catch(e){}},500)}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
