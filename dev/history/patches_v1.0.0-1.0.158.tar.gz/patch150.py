import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 英語表記を SHEESHA に
rep('>SHISHA GACHA</span>','>SHEESHA GACHA</span>')
rep('(G.ow&&G.ow.shop)||"SHISHA")','(G.ow&&G.ow.shop)||"SHEESHA")')
rep('t=String(t||"").trim()||"SHISHA";','t=String(t||"").trim()||"SHEESHA";')
rep('「Excuse me, shisha OK?」','「Excuse me, sheesha OK?」')
# ガチャのカード：絵を白い枠の真ん中に
rep('g.font=`${Math.round(70*s0)}px sans-serif`;g.textAlign="center";g.textBaseline="middle";g.fillText(res[0],cx-4*s0,cy-62*s0);','g.font=`${Math.round(84*s0)}px sans-serif`;g.textAlign="center";g.textBaseline="middle";g.fillText(res[0],cx-2*s0,cy-4*s0);')
open(f,'w').write(s)
