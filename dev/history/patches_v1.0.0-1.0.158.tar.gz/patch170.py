import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('!OW.mode&&R.evSp==null){R.cat=null;R.dark=null;R.away=null;owReset();endDay()}','!OW.mode&&R.evSp==null&&!R.clA&&!R.cine){R.cat=null;R.dark=null;R.away=null;owReset();endDay()}')
rep('if(R.phase!=="run"||R.away!=null||OW.sitting||R.clA)return;const out=OW.x<0','if(R.phase!=="run"||R.away!=null||OW.sitting||R.clA||R.cine)return;const out=OW.x<0')
# 閉店：画面全体のシャッターをやめて、店長が外からシャッターを閉める
rep('{const _ed=endDay;endDay=function(){if(R.clA)return;R.clA=1;R.clT=R.t;R.clL=rnd(CLL);try{say(OW,R.clL)}catch(e){}setTimeout(()=>shutterDown(()=>{R.clA=0;_ed()}),2300)}}',
    '{const _ed=endDay;endDay=function(){if(R.clA)return;R.clA=1;R.clT=R.t;R.clL=rnd(CLL);try{say(OW,R.clL)}catch(e){}cineClose(()=>{R.clA=0;_ed()})}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(TAIL)==1
CODE=r'''
/* ===== 店のシャッター：閉店で店長が外から閉め、営業開始で店長が来て開ける ===== */
const CINE_Y=1.3,CINE_P=.5;
function shutLv(){if(R.cine)return R.cine.lv;if(R.tab==="deco"||R.pvS!=null||R.pvG!=null)return 0;return R.phase==="run"?0:1}
function shutDraw(k){const lv=shutLv();if(lv<=.001)return;const L=typeof LTN!=="undefined"&&LTN||{oa:0},tn=c=>L.oa>.05&&typeof mixc==="function"?mixc(c,L.ov,Math.min(.6,L.oa*.65)):c,ZT=24,z0=ZT-(ZT-.5)*lv;
 FLT.forEach(([tx,ty])=>{if(FLS.has((tx-1)+","+ty))return;const X=tx*6-1.05,Y=ty*6,q=(y,z)=>P3(X,y,z,k),pl=(pts,c)=>{cx.beginPath();pts.forEach((p,i)=>i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]));cx.closePath();cx.fillStyle=c;cx.fill()};
  pl([q(Y,z0),q(Y+6,z0),q(Y+6,ZT),q(Y,ZT)],tn("#a7adb3"));
  cx.lineWidth=Math.max(1,k.s*.06);for(let z=ZT-.75;z>z0+.3;z-=.75){const a=q(Y,z),b=q(Y+6,z);cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.strokeStyle=tn("#7d848b");cx.stroke()}
  pl([q(Y,z0),q(Y+6,z0),q(Y+6,z0+.6),q(Y,z0+.6)],tn("#5f666c"));
  pl([q(Y,ZT-1.4),q(Y+6,ZT-1.4),q(Y+6,ZT),q(Y,ZT)],tn("#8a9097"));
  const a=q(Y+3,z0+.3),b=q(Y+3.6,z0+.3);cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.strokeStyle=tn("#3d4246");cx.lineWidth=Math.max(1.5,k.s*.15);cx.stroke()})}
/* 店の中から見る時：ガラスの奥に描く */
{const _gd=glassDraw;glassDraw=function(k){try{if(wallVis(2,k))shutDraw(k)}catch(e){}return _gd.apply(this,arguments)}}
/* 道の側から見る時：店の中の人より手前、外を歩く人より奥に描く */
{const _au3=auraDraw;auraDraw=function(k,fg){if(fg)try{if(!wallVis(2,k))shutDraw(k)}catch(e){}return _au3.apply(this,arguments)}}
/* 店の中のシャッターが閉まっている時（営業中以外）、通行人がいないのでガラスの奥に描く処理が呼ばれない場合の保険 */
{const _db3=drawBG;drawBG=function(k){const r=_db3.apply(this,arguments);try{if(R.cine&&!mbOn()&&wallVis(2,k))shutDraw(k)}catch(e){}return r}}
/* 店長を外に出す（外では通行人と同じ描き方） */
function cineOut(on,x,y,face,s){if(on){let m=MB.L.find(q=>q.own);if(!m){m={T:MBG,c:OW.c,s:1,x,y,a:1,t:0,sp:0,tag:1,seen:1,own:1};MB.L.push(m)}m.x=x;m.y=y;m.face=face?1:0;m.s=s||1;if(OW.x>-500){R.cine.ox=OW.x;R.cine.oy=OW.y}OW.x=-999;OW.y=-999}else{MB.L=MB.L.filter(q=>!q.own)}}
function cineCam(t){const c=R.cine;if(!c.cam0)return;const e=t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;let dy=c.ty-c.cam0.yaw;dy=((dy+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;R.cam.yaw=c.cam0.yaw+dy*e;R.cam.pit=c.cam0.pit+(c.tp-c.cam0.pit)*e;R.camVer++}
function cineBack(){const c=R.cine;if(c&&c.cam0){R.cam.yaw=c.cam0.yaw;R.cam.pit=c.cam0.pit;R.camVer++}}
function walkTo(o,pts,v,dt){let st=v*dt;while(st>0&&pts.length){const t=pts[0],dx=t[0]-o.x,dy=t[1]-o.y,d=Math.hypot(dx,dy);if(d>.01)o.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?1:3):(dy>0?0:2);if(d<=st){o.x=t[0];o.y=t[1];pts.shift();st-=d}else{o.x+=dx/d*st;o.y+=dy/d*st;st=0}}return!pts.length}
function cineSkipOn(){const f=e=>{if(!R.cine)return;e.stopPropagation();e.preventDefault();R.cine.skip=1};R.cine.sk=f;setTimeout(()=>{if(R.cine&&R.cine.sk===f)document.addEventListener("pointerdown",f,true)},300)}
function cineEnd(){const c=R.cine;if(!c)return;if(c.k==="close"){OW.x=-999;OW.y=-999;OW.mode="";OW.path=[]}if(c.sk)document.removeEventListener("pointerdown",c.sk,true);cineOut(0);cineBack();R.cine=null;BGK=""}
function cineClose(done){if(!mbOn()){done();return}const ip=(()=>{try{return drPath(OW.x,OW.y,2,15)}catch(e){return null}})()||[[OW.x,15],[2,15]];
 R.cine={k:"close",lv:0,t:0,ph:0,cam0:{yaw:R.cam.yaw,pit:R.cam.pit},ty:CINE_Y,tp:CINE_P,path:ip.concat([[-1,15],[-4.5,15]]),done,pos:{x:OW.x,y:OW.y,dir:OW.dir}};OW.sitting=0;OW.seat=null;OW.idleSmk=0;OW.mode="";OW.path=[];cineSkipOn()}
{const _st=start;start=function(){const r=_st.apply(this,arguments);try{if(R.phase==="run"&&mbOn()&&!R.cine){const hx=OW.x,hy=OW.y;R.cine={k:"open",lv:1,t:0,ph:0,cam0:{yaw:R.cam.yaw,pit:R.cam.pit},ty:CINE_Y,tp:CINE_P,hx,hy,p:{x:-6,y:15-30},t0:R.t};cineOut(1,-6,-15,0,1);cineSkipOn()}}catch(e){R.cine=null}return r};$("#go").onclick=start}
function cineTick(dt){const c=R.cine;if(!c)return;c.t+=dt;if(c.k==="open")R.t=c.t0;
 if(c.k==="close"){
  if(c.skip){c.lv=1;const d=c.done;cineEnd();d();return}
  cineCam(Math.min(1,c.t/1.4));
  if(c.ph===0){const o=c.pos;const fin=walkTo(o,c.path,13,dt);if(o.x<0){cineOut(1,o.x,o.y,0,1)}else{OW.x=o.x;OW.y=o.y;OW.dir=o.dir}if(fin){c.ph=1;c.pt=c.t;cineOut(1,-4.5,15,1,1)}}
  else if(c.ph===1){if(c.t-c.pt>.35){c.ph=2;c.pt=c.t}}
  else if(c.ph===2){c.lv=Math.min(1,(c.t-c.pt)/1.8);if(c.lv>=1){c.ph=3;c.pt=c.t}}
  else if(c.ph===3){const m=MB.L.find(q=>q.own);if(m){m.face=0;m.s=-1;m.y-=11*dt;m.x+=(-6-m.x)*Math.min(1,dt*3)}if(c.t-c.pt>2.4){const d=c.done;c.lv=1;cineEnd();d()}}
  if(c.t>14&&R.cine===c){const d=c.done;cineEnd();d()}}
 else{
  if(c.skip){c.lv=0;OW.x=c.hx;OW.y=c.hy;OW.dir=1;cineEnd();return}
  cineCam(Math.min(1,c.t/1.3));
  if(c.ph===0){const fin=walkTo(c.p,[[-4.5,15]],12,dt);cineOut(1,c.p.x,c.p.y,0,1);if(fin){c.ph=1;c.pt=c.t;cineOut(1,-4.5,15,1,1)}}
  else if(c.ph===1){if(c.t-c.pt>.35){c.ph=2;c.pt=c.t}}
  else if(c.ph===2){c.lv=Math.max(0,1-(c.t-c.pt)/1.6);if(c.lv<=0){c.ph=3;c.pt=c.t;c.k2=1;cineOut(0);const ip=(()=>{try{return drPath(2,15,c.hx,c.hy)}catch(e){return null}})()||[[c.hx,15],[c.hx,c.hy]];c.wp=[[-1,15],[2,15]].concat(ip);OW.x=-3.5;OW.y=15;R.cine.t0=null}}
  if(c.ph>=3){c.k="openw";}
  if(c.t>14&&R.cine===c){OW.x=c.hx;OW.y=c.hy;cineEnd()}}
 if(c.k==="openw"){const o={x:OW.x,y:OW.y,dir:OW.dir};const fin=walkTo(o,c.wp,13,dt);OW.x=o.x;OW.y=o.y;OW.dir=o.dir;if(fin||c.skip){OW.x=c.hx;OW.y=c.hy;OW.dir=1;const back=c.t-c.pt;cineEnd()}}}
/* 開店の演出中は時計を止める（シャッターが開いたらスタート）・店長はこちらで動かす */
{const _tk=tick;tick=function(now){const c=R.cine,fr=c&&c.k==="open",t0=R.t;try{if(c){const n=performance.now(),dt=Math.min(.1,(n-(c.lastN||n))/1000);c.lastN=n;cineTick(dt)}}catch(e){try{cineEnd()}catch(_){}}const r=_tk.apply(this,arguments);if(fr&&R.cine&&R.cine.k==="open")R.t=t0;return r}}
/* 朝（営業前）は店主はまだ来ていない */
{const _hu=hud;hud=function(){const r=_hu.apply(this,arguments);try{if(R.phase==='prep'&&G.setup&&!R.cine&&!R.vis&&!R.clA&&OW.x>-100){OW.x=-999;OW.y=-999;OW.path=[];OW.mode=''}}catch(e){}return r}}
{const _ot=owTick;owTick=function(){if(R.cine)return;return _ot.apply(this,arguments)}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
