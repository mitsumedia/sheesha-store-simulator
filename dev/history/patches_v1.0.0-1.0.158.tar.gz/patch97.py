import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 上部の高さ合わせで丸ボタン等が1px単位で上下にプルプルするのを防ぐ（整数の高さを使い、3px以上変わった時だけ動かす）
rep('function uiTop(){try{const t=$("#top");if(t){const b=Math.round(t.getBoundingClientRect().bottom);document.documentElement.style.setProperty("--uit",b+"px")}}catch(e){}}',
    'let _uitV=0;function uiTop(){try{const t=$("#top");if(t){const b=t.offsetTop+t.offsetHeight;if(b>0&&Math.abs(b-_uitV)>=3){_uitV=b;document.documentElement.style.setProperty("--uit",b+"px")}}}catch(e){}}')
open(f,'w').write(s)
