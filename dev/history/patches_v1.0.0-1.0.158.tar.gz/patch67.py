import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 換気：終わる時刻を覚えておき、時計がそこを過ぎたら必ず止める（長く続くのを防ぐ）
rep('R.vent=30;log("🌀 換気中…（30分）")','R.vent=30;R.ventE=R.t+30;R.ventR=performance.now();log("🌀 換気中…（30分）")')
rep(TAIL,'''{const _hv=hud;hud=function(){try{if(R.vent>0){const over=R.phase!=="run"||(R.ventE!=null&&R.t>=R.ventE)||(R.ventR&&performance.now()-R.ventR>45000&&R.speed);if(over){R.vent=0;R.ventE=null;R.vcd=R.phase==="run"?20:0}}}catch(e){}_hv.apply(this,arguments)}}
'''+TAIL)
# 表示に残り時間
rep('(R.vent>0?"　換気中…":','(R.vent>0?"　換気中…（あと"+Math.max(1,Math.ceil(R.ventE!=null?R.ventE-R.t:R.vent))+"分）":')
open(f,'w').write(s)
