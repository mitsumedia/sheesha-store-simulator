import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 虎の客席シリーズ（あいことばで解禁）
rep('{id:"bg",n:"ブラック×ゴールド"','{id:"tg",n:"虎（タイガー）",m:1.6,u:99,tiger:1,fr:"#f28a1e",cu:"#fff6e8",bk:"#f28a1e",arm:"rd",back:"round",leg:"#17120f",pip:"#17120f",tb:"#fff6e8",tl:"#17120f",cbd:"#f28a1e",ctop:"#fff6e8",ctrim:"#17120f",cst:"back",csl:"#17120f",css:"#f28a1e"},\n{id:"bg",n:"ブラック×ゴールド"')
rep('const seatOpen=(k,sr)=>!!G.seatU&&(k==="bb"||','const seatOpen=(k,sr)=>!!G.seatU&&(sr==="tg"?!!G.tigerU:k==="bb"||')
rep('const seatCond=sr=>{const u=','const seatCond=sr=>{if(sr==="tg")return"あいことばで解禁";const u=')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 虎シリーズは黒い縞模様 ===== */
{const _fv=furnVox;furnVox=function(F,ox,oy){const L=_fv.apply(this,arguments);try{const v=seatSer(F);if(!v||!v.tiger)return L;
return L.map(q=>{if(q[3]!==v.fr||q[2]<1)return q;const t=((q[0]*2+q[1]+Math.floor(q[2]*1.5))%%8+8)%%8;return t<2?[q[0],q[1],q[2],"#17120f"]:q})}catch(e){return L}}}
'''.replace('%%','%')
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
