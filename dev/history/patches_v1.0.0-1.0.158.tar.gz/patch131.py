import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 壁アイテム：2マス・4マスのアイテムは使っている区画の数で数える
rep('$("#wc").textContent=`貼っている枚数 ${(G.wall||[]).length}／貼れる場所 ${WS.length}`;',
    '$("#wc").textContent=`使っている場所 ${(G.wall||[]).reduce((n,w)=>n+1+(w.k2!=null)+(w.k3!=null)+(w.k4!=null),0)}／貼れる場所 ${WS.length}`;')
open(f,'w').write(s)
