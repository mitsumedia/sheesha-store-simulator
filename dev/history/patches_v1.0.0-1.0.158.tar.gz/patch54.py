import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ボックス席：2人・3人のグループも座れるように。4人以上は同じボックスを優先
rep('if(!cand.length)return null;let best=null,bv=-1e9;cand.forEach(g=>{const v=avoid(m[0],g[0])+avoid(m[1],g[1]);if(v>bv){bv=v;best=g}});return best}',
    'if(!cand.length)G.furn.forEach((F,fid)=>{if(F.k!=="b")return;const g=SEATS.filter(s=>s.fid===fid&&!s.p&&!s.x);if(g.length>=2)cand.push(g.slice(0,2))});if(!cand.length)return null;let best=null,bv=-1e9;cand.forEach(g=>{const v=avoid(m[0],g[0])+avoid(m[1],g[1]);if(v>bv){bv=v;best=g}});return best}')
rep('if(n===3){const g=G.furn.map((f,fid)=>(f.k==="t"||f.k==="c")?SEATS.filter(s=>s.fid===fid&&s.kind===f.k):null).filter(g=>g&&g.length===3&&g.every(s=>!s.p&&!s.x));return g.length?g[0]:null}',
    'if(n===3){const g=G.furn.map((f,fid)=>(f.k==="t"||f.k==="c")?SEATS.filter(s=>s.fid===fid&&s.kind===f.k):null).filter(g=>g&&g.length===3&&g.every(s=>!s.p&&!s.x));if(g.length)return g[0];const bxg=G.furn.map((f,fid)=>f.k==="b"?SEATS.filter(s=>s.fid===fid&&!s.p&&!s.x):null).filter(g=>g&&g.length>=3);return bxg.length?bxg[0].slice(0,3):null}')
rep('const bx=fr.filter(s=>s.kind==="b");if(bx.length>=n)return bx.slice(0,n);',
    'for(let fid=0;fid<G.furn.length;fid++){if(G.furn[fid].k!=="b")continue;const g=fr.filter(s=>s.fid===fid);if(g.length>=n)return g.slice(0,n)}const bx=fr.filter(s=>s.kind==="b");if(bx.length>=n)return bx.slice(0,n);')
open(f,'w').write(s)
