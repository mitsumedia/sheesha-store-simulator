import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 雪の日は街が白くなる（大雪イベントの日はさらに） ===== */
function snowLv(){if(R.snowF!=null)return R.snowF;try{if(R.vis)return 0;const w=(G.wx&&G.wx[G.wd])||"";const big=(td().evs||[]).includes(32);if(big)return 1;return w==="snow"?.78:0}catch(e){return 0}}
const SNW="#f3f6fa";
{const _dv=dvb;dvb=function(b,k){const r=_dv.apply(this,arguments);try{const lv=snowLv();if(lv>0&&b.h>.3&&b.z+b.h>.5){const o=P3(b.x,b.y,b.z,k),EX=[k.exx*b.w,k.exy*b.w],EY=[k.eyx*b.d,k.eyy*b.d],EZ=[0,k.ezy*b.h],p=[o[0]+EZ[0],o[1]+EZ[1]];cx.save();cx.globalAlpha=Math.min(1,.55+lv*.45);poly([[p[0],p[1]],[p[0]+EX[0],p[1]+EX[1]],[p[0]+EX[0]+EY[0],p[1]+EX[1]+EY[1]],[p[0]+EY[0],p[1]+EY[1]]],SNW);cx.restore()}}catch(e){}return r}}
{const _d0=drawScn0;drawScn0=function(k){const lv=snowLv();if(!lv)return _d0.apply(this,arguments);const sv=GRD.map(g=>g.c),sb=GRD.base;try{const road=c=>{const n=parseInt(String(c).slice(1),16);if(isNaN(n))return false;return((n>>16)+(n>>8&255)+(n&255))/3<110};GRD.forEach(g=>{g.c=mixc(g.c,SNW,road(g.c)?(lv>=1?.82:.5):(lv>=1?.95:.85))});GRD.base=mixc(GRD.base||"#8d8d8d",SNW,lv>=1?.95:.85);
 const r=_d0.apply(this,arguments);
 /* タイヤの跡 */const gg=mbGeo();cx.save();cx.globalAlpha=lv>=1?.35:.55;[gg.L-28,gg.L-20].forEach(xc=>[-2.4,1.6].forEach(dx=>{poly([P3(xc+dx,gg.Y0-200,0,k),P3(xc+dx+.9,gg.Y0-200,0,k),P3(xc+dx+.9,gg.Y1+200,0,k),P3(xc+dx,gg.Y1+200,0,k)],"#6b7078")}));cx.restore();return r}finally{GRD.forEach((g,i)=>{g.c=sv[i]});GRD.base=sb}}}
/* 外観モードの屋上も白く・大雪の日は歩道のふちに雪の山 */
{const _xm=extMod;extMod=function(a){const r=_xm.apply(this,arguments);try{if(R.ext&&snowLv()>0)a.forEach(v=>{if(v[2]>=24&&!v[4])v[3]=SNW})}catch(e){}return r}}
{const _xst=xsStatic;xsStatic=function(a){const r=_xst.apply(this,arguments);try{if(snowLv()>=1){const g=mbGeo(),P=(x,y,z,s)=>a.push([x,y,z,SNW,undefined,s]);for(const xc of[g.L-16,g.L-34.5])for(let y=Math.floor(g.Y0/2)*2;y<g.Y1;y+=2){const hh=(Math.sin(y*.9+xc)+1)/2;P(xc,y,0,2);if(hh>.45)P(xc+.5,y+.5,1,1);if(hh>.8)P(xc+.75,y+.75,2,.5)}}}catch(e){}return r}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
