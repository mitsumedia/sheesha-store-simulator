import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('📸 チェキの限定エフェクト・スタンプ（3種）／👕 着せ替え（4種）</div>','📸 チェキの限定エフェクト・スタンプ（${CKD.filter(d=>d[3]&&d[3].g).length}種）／👕 着せ替え（${OWG.length}種）</div>')
open(f,'w').write(s)
