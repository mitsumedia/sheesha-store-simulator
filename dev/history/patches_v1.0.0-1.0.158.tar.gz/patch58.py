import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# チェキ（ソファ）：2人の手前にある家具は写さない
rep('sp2=SP2.length?SP2[(((R.ckSp||0)%SP2.length)+SP2.length)%SP2.length]:null;','sp2=SP2.length?SP2[(((R.ckSp||0)%SP2.length)+SP2.length)%SP2.length]:null;var ckFS=null;if(sp2){const[a1,b1]=sp2,fy=a1.f>0?1:-1,cxT=(a1.px+b1.px)/12,cyT=a1.Y0/6,keep=G.furn.filter((F,fid)=>{if(fid===a1.fid)return true;return!furnFoot(F).some(k=>{const[x,y]=k.split(",").map(Number);return (y-cyT)*fy>0.5&&Math.abs(x-cxT)<3.5})});if(keep.length<G.furn.length){ckFS=G.furn;G.furn=keep;furnRebuild();build()}}')
rep('R.cam=sv.cam;TX=sv.TX;TY=sv.TY;BASE=sv.BASE;OW.x=sv.ox;OW.y=sv.oy;R.people=sv.pp;R.tool=sv.tool}','R.cam=sv.cam;TX=sv.TX;TY=sv.TY;BASE=sv.BASE;OW.x=sv.ox;OW.y=sv.oy;R.people=sv.pp;R.tool=sv.tool;try{if(typeof ckFS!=="undefined"&&ckFS){G.furn=ckFS;furnRebuild();build()}}catch(e){}}')
open(f,'w').write(s)
