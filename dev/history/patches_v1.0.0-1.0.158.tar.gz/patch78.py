import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
PX=json.load(open('/home/claude/w/yaro_px.json'))
# 店主の着せ替え（追加の髪型 c.h2／服 c.t2／ズボン c.b2）。体の向き・座りにも合わせて描く
HOOK=r'''if(!c.pump&&(c.h2||c.t2||c.b2||c.pr)&&typeof OWXD!=="undefined"){const Q4=(x,y,z,col,sz)=>{sz=sz||.25;const[X,Y]=map(x,y,sz,sz);a.push([ox+X,Y0+Y,z,col,undefined,sz])};try{OWXD(c,{H,B,Qv,Q4,hr,sk,sh,pa,sit,top,back,sides,bangs})}catch(e){console.log(e)}}'''
rep('if(!SPF[c.sp].ownEye&&!c.pump)EYE()}','if(!SPF[c.sp].ownEye&&!c.pump)EYE()}\n'+HOOK)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 店主の着せ替え（追加10種ずつ） ===== */
const PRN={yaro:__PX__};
const OWH=[["センター分け"],["オールバック"],["ゆるふわパーマ"],["ツンツンヘア"],["縦ロール"],["ちょんまげ"],["編み込み"],["ハーフアップ"],["刈り上げベリーショート"],["ロングウェーブ"]];
const OWT=[["パーカー"],["ニット"],["タイダイT"],["ポロシャツ"],["甚平"],["レザージャケット"],["ベスト＋シャツ"],["ミリタリーシャツ"],["野郎シーシャ会T"],["店名入りT"]];
const OWB=[["デニム"],["ワイドパンツ"],["カーゴパンツ"],["迷彩ハーフパンツ"],["ジャージパンツ"],["ロングスカート"],["プリーツスカート"],["サルエルパンツ"],["タキシードパンツ"],["スウェット"]];
const NBC={};function nameBmp(t){t=String(t||"").trim()||"SHISHA";if(NBC[t])return NBC[t];const W=32,F='bold 13px "Hiragino Kaku Gothic ProN","Hiragino Sans","Noto Sans JP","Yu Gothic",sans-serif',m=document.createElement("canvas").getContext("2d");m.font=F;const one=m.measureText(t).width;let L=[t];if(one>W*1.5&&t.length>=4){let h=Math.ceil(t.length/2);const sp=[...t].map((ch,i)=>/[\s　・]/.test(ch)?i:-1).filter(i=>i>0);if(sp.length){h=sp.sort((a,b)=>Math.abs(a-t.length/2)-Math.abs(b-t.length/2))[0];L=[t.slice(0,h).trim(),t.slice(h+1).trim()]}else L=[t.slice(0,h),t.slice(h)]}const LH=13,Hh=LH*L.length,cv=document.createElement("canvas");cv.width=W;cv.height=Hh;const g=cv.getContext("2d");g.font=F;g.textBaseline="middle";g.fillStyle="#000";L.forEach((s2,i)=>{const w=g.measureText(s2).width||1,k=Math.min(1,(W-1)/w);g.setTransform(k,0,0,1,(W-w*k)/2,0);g.fillText(s2,0,LH*i+LH/2+.5)});const im=g.getImageData(0,0,W,Hh).data,d=[];for(let i=0;i<W*Hh;i++)d.push(im[i*4+3]>110?1:0);return NBC[t]={w:W,h:Hh,d}}
function OWXD(c,o){const{H,B,Qv,Q4,hr,sk,sh,pa,sit,top,back,sides,bangs}=o,dk=dkHex(hr,.72),lt=dkHex(hr,1.3),shd=dkHex(sh,.72),shl=dkHex(sh,1.3),pad=dkHex(pa,.72),pal=dkHex(pa,1.3),FY=3.04;
const front=(x0,x1,z0,z1,fn,y)=>{for(let x=x0;x<x1-1e-6;x+=.25)for(let z=z0;z<z1-1e-6;z+=.25){const col=fn(x,z);if(col)Q4(x,y||FY,z,col)}};
const sleeve=fn=>{if(sit&&false)return;for(const ax of[0,3]){let k=ax;for(let x=ax;x<ax+1-1e-6;x+=.25)for(let z=6;z<8-1e-6;z+=.25){Q4(x,FY+.01,z,fn(x,z,k++))}for(let y=1;y<3-1e-6;y+=.25)for(let z=6;z<8-1e-6;z+=.25){Q4(ax===0?-.24:3.99,y,z,fn(y,z,k++));}for(let x=ax;x<ax+1-1e-6;x+=.25)for(let y=1;y<3-1e-6;y+=.25)Q4(x,y,8,fn(x,y,k++))}};
/* ---- 髪型 ---- */
const h=c.h2|0;
if(h===1){top();back(0,6);H(-1,1,2,1,4,4,hr);H(8,1,2,1,4,4,hr);H(0,5,4,3,1,2,hr);H(5,5,4,3,1,2,hr);H(0,5,3,2,1,1,hr);H(6,5,3,2,1,1,hr);H(3,5,5,2,1,1,dk)}
else if(h===2){top();H(0,-1,1,8,1,6,hr);H(-1,0,3,1,5,3,hr);H(8,0,3,1,5,3,hr);H(0,5,5,8,1,1,hr);H(1,1,7,6,5,1,hr);H(1,2,8,6,3,1,lt)}
else if(h===3){top();H(-1,0,0,1,6,6,hr);H(8,0,0,1,6,6,hr);H(0,-1,0,8,1,7,hr);for(let x=-1;x<9;x+=2)for(let y=0;y<6;y+=2)H(x,y,7+((x+y)/2&1),2,2,1,(x+y)%4?hr:lt);H(0,5,4,8,1,2,hr);for(let x=0;x<8;x+=2)H(x,5,3,1,1,1,(x/2&1)?hr:lt)}
else if(h===4){top();back(0,6);sides(3,3);for(const[x,y,t]of[[0,0,3],[2,1,4],[4,0,3],[6,1,4],[1,3,4],[5,3,4],[3,2,5],[-1,2,2],[8,2,2],[3,4,3]])H(x,y,8,1,1,t,t>3?hr:lt);H(0,5,4,8,1,2,hr);H(2,5,3,1,1,1,hr);H(5,5,3,1,1,1,hr)}
else if(h===5){top();back(-2,8);H(-1,1,-1,1,5,7,hr);H(8,1,-1,1,5,7,hr);H(0,5,4,8,1,2,hr);for(const sx of[-3,9]){for(let z=2;z>-13;z--){const o2=((z%%2)+2)%%2;H(sx-(sx<0?o2:0),1+o2,z,2,2,1,z%%3?hr:lt)}}}
else if(h===6){H(0,0,6,8,6,1,sk);H(0,0,0,8,1,6,hr);H(-1,0,1,1,5,4,hr);H(8,0,1,1,5,4,hr);H(2,1,7,4,4,1,hr);H(3,1,8,2,1,1,hr);H(3,0,8,2,3,2,dk);H(3,3,9,2,2,1,hr)}
else if(h===7){top();back(0,6);sides(2,4);H(0,5,4,8,1,2,hr);for(let z=3;z>-9;z--){const o2=(z&1);H(-2-o2,3,z,2,2,1,z%%2?hr:dk)}H(-2,3,-9,2,2,1,"#ff9ab0")}
else if(h===8){top();H(0,0,-4,8,2,10,hr);H(-1,1,-4,1,4,10,hr);H(8,1,-4,1,4,10,hr);bangs();H(3,0,7,2,2,2,hr);H(2,-1,7,4,1,1,"#f5b8d0")}
else if(h===9){top();H(0,0,3,8,1,3,dk);H(0,0,4,1,5,2,dk);H(7,0,4,1,5,2,dk);H(0,4,5,8,2,1,hr)}
else if(h===10){top();H(0,0,-8,8,2,14,hr);for(let z=-8;z<5;z++){const w=((z+20)%%4<2)?1:0;H(-1-w,1,z,1,4,1,hr);H(8+w,1,z,1,4,1,hr);if(z%%4===0){H(-1,1,z,1,4,1,lt);H(8,1,z,1,4,1,lt)}}bangs();H(0,5,3,1,1,1,hr);H(7,5,3,1,1,1,hr)}
/* ---- 服 ---- */
const t=c.t2|0;
if(t===1){front(1.5,2.5,4.25,5.25,()=>shd);for(const x of[1.5,2.25])for(let z=6.75;z>5.9;z-=.25)Q4(x+.0625,FY+.02,z,"#f4f4f4",.125);for(let x=1;x<3;x+=.25){Q4(x,.75,7.75,shd);Q4(x,.75,7.5,shd)}Q4(1,1,8,shd);Q4(2.75,1,8,shd)}
else if(t===2){front(1,3,4,8,(x,z)=>z<4.5?shd:((Math.round(x*4)%%3===1)?((Math.round(z*4)%%2)?shl:shd):null));}
else if(t===3){const C0=["#ff5c8a","#ffd84a","#5ac8fa","#7bd389","#b28bff","#ff9f43"];sleeve((x,z,k)=>C0[Math.floor(k*1.7+z*3)%6]);const C=["#ff5c8a","#ffd84a","#5ac8fa","#7bd389","#b28bff","#ff9f43"];front(1,3,4,8,(x,z)=>{const d=Math.hypot(x-2,z-6);return C[Math.floor(d*3.2+Math.atan2(z-6,x-2)*.6+6)%%6]})}
else if(t===4){front(1.5,2.5,7.5,8,()=>shd);Q4(1.25,FY,7.75,shd);Q4(2.5,FY,7.75,shd);for(const z of[7.25,6.75])Q4(1.94,FY+.02,z,"#f4f4f4",.125);front(1,1.25,4,8,()=>null)}
else if(t===5){for(let z=4.25;z<8;z+=.25){const x=1+(8-z)*.4;Q4(Math.min(2.75,x),FY+.02,z,shd)}front(1,3,4,4.25,()=>shd);Q4(2.75,FY+.02,5.5,shd);Q4(2.75,FY+.02,5.25,"#f4f4f4");for(let x=1;x<3;x+=.5)for(let z=4.5;z<7.5;z+=1)Q4(x+.125,FY+.01,z,shl,.125)}
else if(t===6){const LJ="#1d1b1f",LH="#3a363d";sleeve(()=>LJ);front(1,3,4,8,(x,z)=>(x>=1.75&&x<2.25&&z<7.5)?null:(x<1.25||x>=2.75?LH:LJ));front(1.5,2.5,7.25,8,(x,z)=>(Math.abs(x-2)>.25)?LH:null,FY+.03);for(let z=4.25;z<7.4;z+=.25)Q4(2.25,FY+.02,z,"#c0c0c8",.125);for(let x=1;x<3;x+=.25)for(let z=4;z<8;z+=.25){Q4(x,.75,z,LJ)}for(const xx of[.75,3])for(let z=4;z<8;z+=.25)for(let y=1;y<3;y+=.25)Q4(xx,y,z,LJ)}
else if(t===7){sleeve(()=>"#f4f4f4");front(1,3,4,8,(x,z)=>(x>=1.75&&x<2.25&&z>5.5)?(x>=1.875&&x<2.125&&z<7.6?"#c0392b":"#f4f4f4"):null);for(const z of[4.75,5.25])Q4(1.94,FY+.02,z,"#d4a017",.125);for(const xx of[.75,3])for(let z=4.25;z<7.5;z+=.25)for(let y=1;y<3;y+=.25)Q4(xx,y,z,"#f4f4f4")}
else if(t===8){front(1.25,1.75,5.75,6.5,()=>shd);front(2.25,2.75,5.75,6.5,()=>shd);for(const z of[7,6.25,5.5,4.75])Q4(1.94,FY+.02,z,"#3b3420",.125);let r=11;const rn=()=>(r=(r*9301+49297)%%233280)/233280;for(let i=0;i<14;i++)Q4(1+Math.floor(rn()*8)*.25,FY+.01,4+Math.floor(rn()*16)*.25,i%%2?shd:shl)}
else if(t===9){const P=PRN.yaro,sz=.125;for(let r=0;r<16;r++)for(let q=0;q<16;q++)Q4(1+q*sz,FY,7-r*sz,"#"+P[r*16+q],sz)}
else if(t===10){const bm=nameBmp(c.prT||((G.ow&&G.ow.shop)||"SHISHA")),S=.05;for(let r=0;r<bm.h;r++)for(let q=0;q<bm.w;q++)if(bm.d[r*bm.w+q])Q4(1.2+q*S,FY+.02,(bm.h>14?7.35:7)-r*S,"#ffffff",S);front(1,3,6.1,6.2,()=>null)}
/* ---- ズボン ---- */
const b=c.b2|0;if(sit){if(b===6||b===7){for(let x=.75;x<3.3;x+=.25)for(let y=1;y<4.5;y+=.25)Q4(x,y,3.75,pa)}return}
const legs=(fn)=>{for(const lx of[1,2])for(let x=lx;x<lx+1-1e-6;x+=.25)for(let z=1;z<4-1e-6;z+=.25){const col=fn(x,z,lx);if(col)Q4(x,FY,z,col)}};
if(b===1){legs((x,z)=>(Math.abs(x-1.5)<.13||Math.abs(x-2.5)<.13)?pal:(z>3.5&&(x<1.25||x>=2.75))?pad:null);for(const lx of[1,2])Q4(lx+.375,FY+.01,1.25,pal,.125)}
else if(b===2){for(let z=1;z<3.6;z+=.25)for(const[xx,yy]of[[.75,1],[.75,1.5],[.75,2],[.75,2.5],[3,1],[3,1.5],[3,2],[3,2.5]])Q4(xx,yy,z,pa);for(let z=1;z<3.6;z+=.25)for(let x=.75;x<3.3;x+=.25){Q4(x,.75,z,pa);Q4(x,FY,z,x>1.9&&x<2.1?pad:pa)}}
else if(b===3){for(const xx of[.75,3])for(let z=2;z<3;z+=.25)for(let y=1.5;y<2.6;y+=.25)Q4(xx,y,z,pad);for(const xx of[.75,3])Q4(xx,2,2.75,dkHex(pa,.5),.125)}
else if(b===4){const C=["#4b5320","#7a6a3a","#2f3a22","#8a8a5a"];let r=7;const rn=()=>(r=(r*9301+49297)%%233280)/233280;legs((x,z)=>z<2?sk:C[Math.floor(rn()*4)]);for(const xx of[.75,3])for(let z=2;z<4;z+=.25)for(let y=1;y<3;y+=.25)Q4(xx,y,z,C[Math.floor(rn()*4)])}
else if(b===5){for(let z=1;z<4;z+=.25){Q4(1,FY+.01,z,"#ffffff");Q4(2.75,FY+.01,z,"#ffffff")}legs((x,z)=>z<1.25?pad:null)}
else if(b===6){for(let z=.75;z<4;z+=.25){const w=.25+(4-z)*.12;for(let x=1-w;x<3+w;x+=.25){Q4(x,FY+w*.3,z,pa);Q4(x,.75-w*.3,z,pa)}for(let y=.75;y<3.2;y+=.25){Q4(1-w,y,z,pa);Q4(2.75+w,y,z,pa)}}}
else if(b===7){for(let z=2.5;z<4;z+=.25){const w=.25+(4-z)*.2;for(let x=1-w;x<3+w;x+=.25){Q4(x,FY+w*.4,z,(Math.round(x*4)%%2)?pa:pad);Q4(x,.75-w*.3,z,pa)}for(let y=.75;y<3.2;y+=.25){Q4(1-w,y,z,pa);Q4(2.75+w,y,z,pa)}}legs((x,z)=>z<2.5?sk:null)}
else if(b===8){for(let z=2;z<3.5;z+=.25)for(let x=.75;x<3.3;x+=.25){Q4(x,FY+.2,z,pa)}for(const xx of[.75,3])for(let z=2;z<3.75;z+=.25)for(let y=1;y<3;y+=.25)Q4(xx,y,z,pa);legs((x,z)=>z<1.5?pad:null)}
else if(b===9){for(let z=1;z<4;z+=.25){Q4(1,FY+.01,z,"#3a3a3a",.125);Q4(2.875,FY+.01,z,"#3a3a3a",.125)}legs((x,z)=>(z>3.6&&Math.abs(x-2)<.6)?pad:null)}
else if(b===10){legs((x,z)=>z<1.5?pad:(z>3.6?pad:null));Q4(1.875,FY+.02,3.75,"#f4f4f4",.125);Q4(2.0,FY+.02,3.75,"#f4f4f4",.125);Q4(1.875,FY+.02,3.5,"#f4f4f4",.125);Q4(2.0,FY+.02,3.5,"#f4f4f4",.125)}
}
'''.replace('%%','%').replace('__PX__',json.dumps(PX))
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
