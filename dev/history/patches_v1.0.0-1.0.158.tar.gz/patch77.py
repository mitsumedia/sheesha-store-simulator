import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
D=json.load(open('/home/claude/w/yaro_dmd.json'))
ADD='''
/* ===== 図鑑の並び：芸能人の次にレジェンド2人→シーシャ屋（おぢサンとのどかは連番、ノムはNo.150） ===== */
{const ORD2=[141,142,130,134,132,133,131,135,143,136,137,149,139,140,144,145,146,147,148,138,150],_dx=dxN;dxN=function(c){const r=_dx(c);if(DXC&&!DXC.ord2){ORD2.forEach((i,k)=>{DXC.m[i]=131+k});DXC.ord2=1}return DXC.m[c.i]||r}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
