import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 新しい腕の形：ばんざい・内側に上げる（ハート）・手を振る
rep('if(kind==="hug"){','''if(kind==="up"){const ux=x+out*1;CKB(a,x+out*.5,1.5,7.5,1,1,1,sl);CKB(a,ux,1.5,8.5,1,1,2.5,sl);CKB(a,ux,1.5,11,1,1,1,sk);CKQ(a,ux+(out>0?.5:0),1.5,12,sk);return}
if(kind==="in"){CKB(a,x,2,7,1,1,1,sl);CKB(a,x+out*.5,2.5,8,1,1,1,sl);CKB(a,x+out*.75,3,9,1,.5,1,sk);if(hold)hold(a,x,3,9,out);return}
if(kind==="wave"){CKB(a,x+out*.5,1.5,7.5,1,1,1,sl);CKB(a,x+out*1,1.5,8.5,1,1,1,sl);const hx=x+out*1.5;CKB(a,hx,1.5,9.5,1,1,1,sk);[0,.5].forEach(q=>{CKQ(a,hx+q,1.5,10.5,sk)});CKQ(a,hx+(out>0?1:-.5),1.5,10,sk);CKQ(a,hx+(out>0?-.5:1),1.5,9.5,sk);return}
if(kind==="hug"){''')
rep('["🍔 もぐもぐ",{arms:[["L","down"],["R","mouth",ckBurger]],arms2:[["L","mouth",ckBurger],["R","down"]]}]];',
 '["🍔 もぐもぐ",{arms:[["L","down"],["R","mouth",ckBurger]],arms2:[["L","mouth",ckBurger],["R","down"]]}],["🙌 ばんざい",{arms:[["L","up"],["R","up"]],arms2:[["L","up"],["R","up"]]}],["💕 ハート",{arms:[["L","down"],["R","in",ckHeart]],arms2:[["L","in"],["R","down"]]}],["👋 手を振る",{arms:[["L","wave"],["R","down"]],arms2:[["L","down"],["R","wave"]]}]];')
rep('const ckBurger=(a,x,y,z)=>{','''const ckHeart=(a,x,y,z,out)=>{const cx0=x+out*1.25,P="#ff5c8a",L="#ff9bb8";[[-1,1],[-.5,1.5],[0,1],[.5,1],[1,1.5],[1.5,1],[-1,.5],[-.5,1],[-.5,.5],[0,.5],[.5,.5],[1,1],[1,.5],[1.5,.5],[-.5,0],[0,0],[.5,0],[1,0],[0,-.5],[.5,-.5],[.25,-1]].forEach(([dx,dz],i)=>CKQ(a,cx0+dx,y+.5,z+.75+dz,i===1||i===4?L:P))};
const ckBurger=(a,x,y,z)=>{''')
open(f,'w').write(s)
