import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 雰囲気タグは省略せず正式名で（1行に収まるよう小さめ） ===== */
ratm=function(){const a=atmo();$("#atm").innerHTML=TAGS.map(k=>`<span>${TL[k]} ${a[k]}</span>`).join("")};try{ratm()}catch(e){}
try{document.head.insertAdjacentHTML("beforeend",`<style>.fs #atm span,#atm span{padding:2px 6px!important;font-size:10.5px!important;white-space:nowrap}.fs #atm,#atm{gap:3px!important;max-width:calc(100vw - 20px)}</style>`)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
