import sys
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=1):
    global s
    c=s.count(old)
    assert c==n,(c,old[:80])
    s=s.replace(old,new)

# ---- A. フリーレントは1か月、B. 立地差、C. 客席の光熱費 ----
rep('const rentNow=()=>(G.month||0)<3?0:RENT0+RENT_BLK*G.extra;',
 'const LOCM=[[{r:1.2,d:1.15},{r:1.5,d:1.35,f:1.2}],[{r:.8,d:.85,rp:1.1},{r:1,d:1}]],locM=()=>{const l=G.loc||{a:1,t:1};return(LOCM[l.a===1?1:0]||LOCM[0])[l.t===0?0:1]},rentAt=m=>m<1?0:Math.round((RENT0+RENT_BLK*G.extra)*locM().r/1000)*1000,rentNow=()=>rentAt(G.month||0),SEATU=1000,seatN=()=>(G.furn||[]).reduce((a,F)=>a+((SDEF[F.k]||{n:0}).n),0),COAL=150;')
rep('utilNow=()=>Math.round((UTIL0+UTIL_BLK*G.extra)*Math.max(.4,1+.1*(hrsNow()-10)))',
    'utilNow=()=>Math.round((UTIL0+UTIL_BLK*G.extra)*Math.max(.4,1+.1*(hrsNow()-10)))+SEATU*(typeof seatN==="function"?seatN():0)')
rep('const nr=(r.month+1)<3?0:RENT0+RENT_BLK*G.extra,fx=nr+UTIL0+UTIL_BLK*G.extra+(r.bal>0?G.loan.pay:0)',
    'const nr=rentAt(r.month+1),fx=nr+utilNow()+(r.bal>0?G.loan.pay:0)')
rep('家賃12万円（<b>最初の3ヶ月はフリーレントで0円</b>）・水道光熱費4万円・フレーバー代（売上の30%）・ドリンク原価（飲まれた分）も毎月かかります。',
    '家賃12万円×立地（<b>最初の1ヶ月はフリーレントで0円</b>）・水道光熱費4万円＋客席1席あたり1,000円・フレーバー代（売上の30%）・炭代（お客さん1人150円）・ドリンク原価（飲まれた分）も毎月かかります。たまに設備の故障で修理代もかかります。')
# 立地の効果を選択画面に表示
rep('function locForm(){const l=G.loc||{a:0,t:1};return`<div class="row">出店地域',
    'function locFx(a,t){return[["家賃×1.2・客足×1.15","家賃×1.5・客足×1.35（新規のお客さんが多い）"],["家賃×0.8・客足×0.85（リピートしやすい）","家賃×1.0・客足×1.0"]][a===1?1:0][t===0?0:1]}\nfunction locForm(){const l=G.loc||{a:0,t:1};return`<div class="row">出店地域')
rep('</select></div>`}\nfunction locRead()',
    '</select></div><div class="m" id="locfx" style="font-size:12px;margin:-2px 0 6px">📍 ${locFx(l.a,l.t)}</div>`}\nfunction locRead()')
rep('document.addEventListener("change",e=>{if((e.target.id==="la"||e.target.id==="lt")&&$("#la")&&$("#lt")){G.loc=locRead();build()}});',
    'document.addEventListener("change",e=>{if((e.target.id==="la"||e.target.id==="lt")&&$("#la")&&$("#lt")){G.loc=locRead();build();const fx=$("#locfx");if(fx)fx.textContent="📍 "+locFx(G.loc.a,G.loc.t)}});')
# 客足（立地）
rep('(k.met?(k.ret?k.freq/7:.12):k.first*.5)*mult(k)*DEMAND',
    '(k.met?(k.ret?k.freq/7:.12):k.first*.5*(locM().f||1))*mult(k)*DEMAND*locM().d')
rep('c.ret=Math.random()<Math.min(.97,c.repeat*mult(c)*(1+m))?1:0;',
    'c.ret=Math.random()<Math.min(.97,c.repeat*mult(c)*(1+m)*(locM().rp||1))?1:0;')

# ---- 客席の効果 ----
# ボックス席：3人以上のグループの来店率+20%
rep('Math.random()<ks.reduce((s,k)=>s+pr(k),0)/ks.length*tmul(w))R.sched.push',
    'Math.random()<ks.reduce((s,k)=>s+pr(k),0)/ks.length*tmul(w)*(ks.length>=3&&G.furn.some(F=>F.k==="b")?1.2:1))R.sched.push')
# カウンター席：一人客が優先して座る
rep('const kb={s:12,l:4,t:2,b:0,c:7,bb:10};','const kb={s:12,l:4,t:2,b:0,c:22,bb:10};')
# 話しかけ：カウンター1.5倍・お店に集中1.5倍（端数はためて整数で足す）
rep('c.fp++;G.talkN=(G.talkN||0)+1;c.hp=Math.min(100,c.hp+1);if(p.seat&&p.seat.kind==="c"){c.hp=Math.min(100,c.hp+1);if(Math.random()<.5)c.fp++}',
    '{const tm=(p.seat&&p.seat.kind==="c"?1.5:1)*(G.focusD===G.day?1.5:1);c.fpx=(c.fpx||0)+tm;const w=Math.floor(c.fpx+1e-9);c.fp+=w;c.fpx-=w}G.talkN=(G.talkN||0)+1;c.hp=Math.min(100,c.hp+1);if(p.seat&&p.seat.kind==="c"){c.hp=Math.min(100,c.hp+1)}')
# ビーズクッション：滞在+20%、おかわり+3%
rep('(p.seat&&p.seat.kind==="bb"?1.15:1)','(p.seat&&p.seat.kind==="bb"?1.2:1)')
rep('p.orders<3&&Math.random()<refP(c,p.orders,fr)){',
    'p.orders<3&&Math.random()<refP(c,p.orders,fr)+(p.seat&&p.seat.kind==="bb"&&p.orders<2?.03:0)){')
# シリーズ：座った客の満足度が上がる。炭代は来店1人150円
rep('function order(p,refill){if(R.coalOut){p.rem=1;p.done=1;say(p,"炭切れ…？また来ます");return}',
    'const SBON={br:0,cr:1,rr:1,dn:1,gv:2,bg:3};function seatBon(p){const s=p.seat;if(!s||s.fid==null||!G.furn[s.fid]||G.furn[s.fid].k==="bb")return 0;return SBON[G.furn[s.fid].sr]||0}\nfunction order(p,refill){if(R.coalOut){p.rem=1;p.done=1;say(p,"炭切れ…？また来ます");return}if(!refill&&!p._coal){p._coal=1;R.st.coal=(R.st.coal||0)+COAL;const sb=seatBon(p);if(sb&&p.c&&!spx(p.c))p.c.hp=Math.min(100,p.c.hp+sb*3)}')

# ---- 炭代・設備故障を月末精算に ----
rep('dayDone({sales:s.sales,visits:s.visits,drinks:s.drinks,miss:s.miss,dc:s.dc||0,closed:false});',
    'dayDone({sales:s.sales,visits:s.visits,drinks:s.drinks,miss:s.miss,dc:s.dc||0,coal:s.coal||0,closed:false});')
rep('dc=Math.round((n?dsum/n:0)*days),L=G.loan,',
    'dc=Math.round((n?dsum/n:0)*days),coal=Math.round((n?wk.reduce((a,d)=>a+(d.coal||0),0)/n:0)*days),brk=Math.random()<.6?(()=>{const B=[["シーシャ台のホースが破れた"],["ヒーターが壊れた"],["冷蔵庫の修理"],["換気扇の修理"],["ボトルが割れた"],["炭コンロの故障"]];return{n:B[Math.random()*B.length|0][0],cost:(10+Math.floor(Math.random()*21))*1000}})():null,L=G.loan,')
rep('G.money+=extra-rent-util-flv-dc-pay;','G.money+=extra-rent-util-flv-dc-coal-(brk?brk.cost:0)-pay;')
rep('rent,util,flv,dc,intr,prin,pay,before,after:G.money','rent,util,flv,dc,coal,brk,intr,prin,pay,before,after:G.money')
rep('net=r.extra-r.rent-r.util-r.flv-(r.dc||0)-r.pay;','net=r.extra-r.rent-r.util-r.flv-(r.dc||0)-(r.coal||0)-(r.brk?r.brk.cost:0)-r.pay;')
rep('${row("ドリンク原価（飲まれた分の推定月額）","-"+yen(r.dc||0),"neg")}',
    '${row("ドリンク原価（飲まれた分の推定月額）","-"+yen(r.dc||0),"neg")}${row("炭代（1人150円・推定月額）","-"+yen(r.coal||0),"neg")}${r.brk?row("🔧 修理代（"+r.brk.n+"）","-"+yen(r.brk.cost),"neg"):""}')

# ---- D. SNSを更新しない日は知名度が下がる ----
rep('if(!o.sns)o.fol=Math.floor(o.fol*.98);','if(!o.sns){o.fol=Math.floor(o.fol*.98);if(o.fame>10)o.fame=Math.max(10,o.fame-.3)}')

# ---- 「今日は何もしない」→「お店に集中」 ----
rep('<button id="mnskip" style="width:100%">今日は何もしない</button></div>`);R.mOpen=1}','</div>`);R.mOpen=1}')
rep('<div class="m" style="font-size:12px;margin:8px 0 4px">行動は1日1回だけ。', '${bt("focus","🤝","お店に集中（無料）","今日は接客に集中。話しかけで上がる親密度が1.5倍。SNSは更新しないので、フォロワーと知名度は少し減ります",true)}\n<div class="m" style="font-size:12px;margin:8px 0 4px">行動は1日1回だけ。')
rep('else if(k==="visit"){if(G.money<3500',
    'else if(k==="focus"){o.acted=1;G.focusD=G.day;rs("good","🤝","今日はお店に集中！","目の前のお客さんを大事にしよう。話しかけで上がる親密度が1.5倍");log("🤝 今日はお店に集中（話しかけの親密度1.5倍）")}\nelse if(k==="visit"){if(G.money<3500')
rep('<button data-o="visit" ${can&&G.money>=3500&&!ty&&G.vm!==G.month?"":"disabled"}>🚶 他店舗へ ¥3,500${G.vm===G.month?"（今月済）":""}</button>',
    '<button data-o="visit" ${can&&G.money>=3500&&!ty&&G.vm!==G.month?"":"disabled"}>🚶 他店舗へ ¥3,500${G.vm===G.month?"（今月済）":""}</button><button data-o="focus" ${can?"":"disabled"}>🤝 お店に集中</button>')
rep("行動は1日1回だけ。行動するとやる気も上がります。","行動は1日1回だけ。お店に集中以外の行動では、やる気も上がります。")

open(f,'w').write(s)
print('ok')
s=open(f).read()
s=s.replace("""o.innerHTML.includes('id="mnskip"')""","""o.innerHTML.includes('今日の行動を選ぼう')""")
open(f,'w').write(s)
s=open(f).read()
s=s.replace('function locForm(){const l=G.loc||{a:0,t:1};','function locForm(){const l=G.loc||{a:1,t:1};')
open(f,'w').write(s)
