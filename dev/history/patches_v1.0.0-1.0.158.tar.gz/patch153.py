import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 口元（ヒゲ・マスク）の色を反映（店主が色を選んだ時だけ。選んでいなければ今までの色）
rep('if(ac===4){H(2,5,1,4,1,1,"#2b1d14");H(0,5,0,2,1,1,"#2b1d14");H(6,5,0,2,1,1,"#2b1d14");H(1,4,-1,6,2,1,"#2b1d14")}','if(ac===4){const bc=c.akU&&c.accC?c.accC:"#2b1d14";H(2,5,1,4,1,1,bc);H(0,5,0,2,1,1,bc);H(6,5,0,2,1,1,bc);H(1,4,-1,6,2,1,bc)}')
rep('if(ac===6){H(0,5,0,8,1,3,"#eeeeee");H(-1,3,1,1,2,1,"#eeeeee");H(8,3,1,1,2,1,"#eeeeee")}','if(ac===6){const mc=c.akU&&c.accC?c.accC:"#eeeeee";H(0,5,0,8,1,3,mc);H(-1,3,1,1,2,1,mc);H(8,3,1,1,2,1,mc)}')
rep('Object.assign({},c,{acc:V[0][0],accC:V[0][1],accV:null})','Object.assign({},c,{acc:V[0][0],accC:V[0][1],accV:null,akU:1})')
rep('Object.assign({},c,{acc:ac,accC:col,accV:null})','Object.assign({},c,{acc:ac,accC:col,accV:null,akU:1})')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* 口元の色：選んだことがある時だけ使う（今までの人はヒゲ焦げ茶・マスク白のまま） */
{const _al5=owAccLook;owAccLook=function(o){const L=_al5.apply(this,arguments);try{if(L.accV&&!(o&&o.accCMv)){const m=+o.accM||0;L.accV=L.accV.map(v=>v[0]===m&&(m===4||m===6)?[v[0],""]:v)}}catch(e){}return L}}
{const _es5=owEdSave;owEdSave=function(){try{if(OWD&&G.ow&&OWD.accCM&&OWD.accCM!==G.ow.accCM)G.ow.accCMv=1}catch(e){}return _es5.apply(this,arguments)}}
/* 着せ替えの見本：右上の数値は下のカードへ。かわりに今のタブの色を見本の横で選べる */
hcRow=function(){return""};
function stgCols(){const o=G.ow||{},h=OWPV!=null&&OWK==="hs"?(OWPV>=100?OWPV-99:0):(o.h2|0);
 if(OWK==="hs")return[["hair","髪の色",OWPAL.hair]].concat(HC2.includes(h)?[["hc2","2色目",OWPAL.hc2]]:[]);if(OWK==="top")return[["shirt","服の色",OWPAL.shirt]];if(OWK==="bot")return[["pants","ズボンの色",OWPAL.pants]];return[]}
function stgPanel(){const o=G.ow||{};return stgCols().map(([k,l,P])=>{const v=String(o[k]||OW.c[k]||(k==="hc2"?"#ff5c8a":"")).toLowerCase();return`<div class="scg"><div class="scl">${l}</div><div class="scp">${P.map(c=>`<span data-scs="${k}" data-v="${c}" class="scs ${c.toLowerCase()===v?"on":""}" style="background:${c}"></span>`).join("")}</div></div>`}).join("")}
{const _os=owStage;owStage=function(){const r=_os.apply(this,arguments);try{const tr=document.querySelector("#fms .info .tr");const fm=$("#fms");if(tr&&$("#p-own2")&&!OWD){const h=stgPanel();tr.innerHTML=h;tr.classList.add("stgc");if(fm)fm.classList.toggle("hasc",!!h)}else if(fm)fm.classList.remove("hasc")}catch(e){}return r}}
function fmStats(){const h=$("#fmh");if(!h)return;let el=$("#fmst");if(!el){el=document.createElement("div");el.id="fmst";h.appendChild(el)}if(FMTAB!=="owner"){el.hidden=true;return}const o=G.ow||{},st=Math.round(typeof starOf==="function"?starOf(o):0),fm=Math.round(o.fame||0),sk=(o.skill||0);el.hidden=false;el.innerHTML=`<div>👀 知名度 <b>${fm}</b></div><div>⭐ スター性 <b>${st}</b></div><div>💨 技術 <b>${sk.toFixed(1)}</b></div>`}
{const _or6=owRender;owRender=function(){const r=_or6.apply(this,arguments);try{fmStats()}catch(e){}return r}}
{const _ft6=fmTab;fmTab=function(){const r=_ft6.apply(this,arguments);try{fmStats()}catch(e){}return r}}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-scs]");if(!b)return;e.stopPropagation();e.preventDefault();if(!G.ow)return;G.ow[b.dataset.scs]=b.dataset.v;try{applyOwLook();owAccSync()}catch(_){}OW._pc=null;save();const keep=FMS.ang;owStage();FMS.ang=keep},true);
(function(){const st=document.createElement("style");st.textContent=`
#fms .tr.stgc{width:auto!important;pointer-events:auto;z-index:3;text-align:left;top:8px!important;right:10px!important}#fms.hasc canvas{transform:translateX(-26px)}#fms.hasc .hint{display:none}
.scg{margin-bottom:6px}.scl{font-size:10.5px;font-weight:900;color:#cfe9e2;margin-bottom:4px}
.scp{display:grid;grid-template-columns:repeat(4,19px);gap:5px}
.scs{display:block;width:19px;height:19px;border-radius:50%;border:1.5px solid rgba(255,255,255,.35);box-sizing:border-box;cursor:pointer}
.scs.on{outline:2.5px solid #ffd84a;outline-offset:1px}
#fmst{position:absolute;left:138px;top:calc(env(safe-area-inset-top,0px) + 13px);font-size:10.5px;line-height:1.45;font-weight:700;color:#8fc9bc}#fmst b{color:#fff;margin-left:3px}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
