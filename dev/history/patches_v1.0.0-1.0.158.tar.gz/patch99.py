import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 見本ステージ：自動回転をやめて、ドラッグでだけ回す ===== */
try{Object.defineProperty(FMS,"auto",{get:()=>0,set:()=>{},configurable:true})}catch(e){}
{const _fs=fmsSet;fmsSet=function(){const keep=FMS.vox&&arguments[0]==="p"&&FMTAB==="owner"?FMS.ang:null;const r=_fs.apply(this,arguments);if(keep!=null)FMS.ang=keep;try{const h=document.querySelector("#fms .hint");if(h)h.textContent="← ドラッグで回転 →"}catch(e){}return r}}
/* ===== 店主タブ「色・名前」をその場で編集（見本にすぐ反映→保存） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
#owed{background:#fff;border-radius:12px;padding:4px 12px 8px;margin-bottom:10px}
#owed .owr{padding:9px 0;border-bottom:1px solid #ecebe4}#owed .owr:last-child{border-bottom:none}
#owed .owl{display:flex;justify-content:space-between;align-items:center;font-size:13px;font-weight:900;color:#123a33;margin-bottom:6px}
html body #sheet.open #owed .owsw{display:flex!important;flex-direction:row!important;gap:7px!important;flex-wrap:wrap!important;align-items:center}
html body #sheet.open #owed .owl{display:flex!important;flex-direction:row!important}html body #sheet.open #owed .owr{display:block!important;width:100%!important}html body #sheet.open #owed .owsw,html body #sheet.open #owed .owpl{width:100%!important}
html body #sheet.open #owed .owsw button{flex:none!important;display:inline-block!important;margin:0!important;max-width:28px!important;min-height:0!important;width:28px!important;height:28px!important;min-width:0!important;padding:0!important;border-radius:50%!important;border:2px solid #fff!important;box-shadow:0 0 0 1.5px #cfd8d4!important}
html body #sheet.open #owed .owsw button.on{box-shadow:0 0 0 2.5px #6658a6!important}
html body #sheet.open #owed input[type=color]{width:34px!important;height:30px!important;padding:0!important;border:none!important;background:none!important}
html body #sheet.open #owed input[type=text],html body #sheet.open #owed input[type=number],html body #sheet.open #owed select{width:100%;padding:8px 10px!important;border-radius:10px!important;font-size:15px!important}
html body #sheet.open #owed .owpl{display:flex;gap:6px;flex-wrap:wrap}
html body #sheet.open #owed .owpl button{padding:5px 12px!important;border-radius:16px!important;font-size:12.5px!important;font-weight:900;background:#fff!important;border:1.5px solid #cfd8d4!important;color:#123a33!important}
html body #sheet.open #owed .owpl button.on{background:#6658a6!important;border-color:#6658a6!important;color:#fff!important}
</style>`)}catch(e){}
const OWPAL={hair:["#161616","#3b2a1e","#6b4a2b","#a8743c","#e0c068","#c9c9c9","#ffffff","#b03a3a","#e86aa6","#7a4fd0","#2f6fd6","#2a9a7c"],skin:["#ffe0c4","#f1c7a0","#e0aa7e","#c58a5c","#9b6440","#6b4129"],shirt:["#2b2b3a","#ffffff","#c0392b","#e67e22","#f1c40f","#27ae60","#2980b9","#8e44ad","#e86aa6","#7f8c8d","#005d4d","#6658a6"],pants:["#3b3b4a","#1e1e1e","#2c3e66","#5b4a33","#7f8c8d","#c8b38a","#ffffff","#8e2c2c"],accC:["#333333","#ffffff","#c0392b","#f1c40f","#2980b9","#e86aa6","#27ae60","#8e44ad"]};
let OWD=null;
function owDraft(){const o=G.ow||{};return{name:o.name||"",shop:o.shop||"",age:o.age||28,sex:o.sex||"男性",hair:OW.c.hair,skin:OW.c.skin,shirt:OW.c.shirt,pants:OW.c.pants||"#3b3b4a",eye:OW.c.eye||0,acc:OW.c.acc||0,accC:OW.c.accC||"#333333"}}
const owDirty=()=>{if(!OWD)return false;const b=owDraft();return Object.keys(OWD).some(k=>String(OWD[k])!==String(b[k]))};
function owEdRender(){const po=$("#p-own2");if(!po)return;if(!OWD)OWD=owDraft();const d=OWD;
const sw=(k,l)=>`<div class="owr"><div class="owl">${l}<input type="color" data-owc="${k}" value="${d[k]}"></div><div class="owsw">${OWPAL[k].map(c=>`<button data-ows="${k}" data-v="${c}" class="${String(d[k]).toLowerCase()===c?"on":""}" style="background:${c}" aria-label="${c}"></button>`).join("")}</div></div>`;
const pl=(k,l,arr)=>`<div class="owr"><div class="owl">${l}</div><div class="owpl">${arr.map((n,i)=>`<button data-owp="${k}" data-v="${i}" class="${+d[k]===i?"on":""}">${esc(n)}</button>`).join("")}</div></div>`;
po.innerHTML=`<div id="owcat">${Object.entries(OWCAT).map(([k,c])=>`<button data-owk="${k}">${c[4]} ${c[0]}</button>`).join("")}<button data-owk="edit" class="on">🎨 色・名前</button></div>
<div id="owed"><div class="owr"><div class="owl">名前</div><input type="text" data-owt="name" maxlength="8" value="${esc(d.name)}" placeholder="店長"></div>
<div class="owr"><div class="owl">店名</div><input type="text" data-owt="shop" maxlength="14" value="${esc(d.shop)}" placeholder="シーシャ屋さん"></div>
<div class="owr"><div class="owl">年齢</div><input type="number" data-owt="age" min="18" max="80" value="${d.age}"></div>
<div class="owr"><div class="owl">性別</div><div class="owpl">${["男性","女性"].map(x=>`<button data-owsx="${x}" class="${d.sex===x?"on":""}">${x}</button>`).join("")}</div>${sw("hair","髪の色")}${sw("skin","肌の色")}${sw("shirt","服の色")}${sw("pants","ズボンの色")}${pl("eye","目",EYN)}${pl("acc","装飾品",ACCN)}${sw("accC","装飾品の色")}
</div></div>`;
po.onclick=e=>{const k=e.target.closest("[data-owk]");if(k){e.stopPropagation();if(k.dataset.owk!=="edit"){OWD=null;OWK=k.dataset.owk;OWPV=null;owRender();owStage();fmBtn(null)}return}
const s2=e.target.closest("[data-ows]");if(s2){e.stopPropagation();OWD[s2.dataset.ows]=s2.dataset.v;owEdRender();owEdStage();return}
const p2=e.target.closest("[data-owp]");if(p2){e.stopPropagation();OWD[p2.dataset.owp]=+p2.dataset.v;owEdRender();owEdStage();return}
const x2=e.target.closest("[data-owsx]");if(x2){e.stopPropagation();OWD.sex=x2.dataset.owsx;owEdRender();owEdStage();return}};
po.oninput=e=>{const t=e.target;if(t.dataset.owc){OWD[t.dataset.owc]=t.value;owEdStage();po.querySelectorAll(`[data-ows="${t.dataset.owc}"]`).forEach(b=>b.classList.remove("on"))}else if(t.dataset.owt){OWD[t.dataset.owt]=t.dataset.owt==="age"?(+t.value||28):t.value;owEdStage(1)}}}
function owEdStage(noStage){if(!noStage){const L=Object.assign({},OW.c,{hair:OWD.hair,skin:OWD.skin,shirt:OWD.shirt,pants:OWD.pants,eye:OWD.eye,acc:OWD.acc,accC:OWD.accC});const keep=FMS.ang;fmsSet("p",L,`<div class="tl" style="background:none;padding:0;font-size:15px">${esc(OWD.name||"店長")}<div style="font-size:10.5px;color:#8fc9bc;font-weight:700">${owDirty()?"変更中…（まだ保存していません）":esc(OWD.shop||shopNm())+" の店主"}</div></div>`);FMS.ang=keep}fmBtn(owDirty()?"保存する ▶":null)}
function owEdSave(){const o=G.ow;if(!o||!OWD)return;const d=OWD;o.name=(d.name||"").trim()||o.name||"店長";o.shop=(d.shop||"").trim();o.age=Math.max(18,Math.min(80,+d.age||28));o.sex=d.sex;Object.assign(o,{hair:d.hair,skin:d.skin,shirt:d.shirt,pants:d.pants,eye:+d.eye,acc:+d.acc,accC:d.accC});applyOwLook();save();OWD=null;owEdRender();owEdStage();try{shopLine();hud()}catch(e){}try{toast("🎨 店主の見た目を保存しました")}catch(e){}}
/* 「色・名前」タブを開いたら前の画面ではなく、この場の編集を出す */
{const _or=owRender;owRender=function(){const r=_or.apply(this,arguments);const po=$("#p-own2");if(po){const old=po.onclick;po.onclick=e=>{const k=e.target.closest("[data-owk]");if(k&&k.dataset.owk==="edit"){e.stopPropagation();OWD=owDraft();OWPV=null;owEdRender();owEdStage();return}return old&&old(e)}}return r}}
{const _fg3=fmGo;fmGo=function(){if(FMTAB==="owner"&&OWD){owEdSave();return}return _fg3.apply(this,arguments)}}
{const _ft3=fmTab;fmTab=function(k){if(k!=="owner")OWD=null;return _ft3.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
