import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 服を10種追加（アロハ〜ジャージ） ===== */
OWT.push(["アロハシャツ"],["ボーダーT"],["スーツ"],["スカジャン"],["エプロン"],["白衣"],["チェックシャツ"],["法被（はっぴ）"],["ダウンジャケット"],["ジャージ"]);
Object.assign(OWC,{t11:["ガチャ"],t12:["営業14日",()=>(G.day||0)>=14],t13:["所持金300万円",()=>(G.money||0)>=3000000],t14:["ガチャ"],t15:["のべ来店500人",()=>(G.tvis||0)>=500],
 t16:["フレーバー30種",()=>(G.flu||[]).length>=30],t17:["ガチャ"],t18:["フェスに3回出店",()=>(G.festN||0)>=3],t19:["ガチャ"],t20:["ガチャ"]});
OWG.push("t11","t14","t17","t19","t20");
{const _ot=OWXD;OWXD=function(c,o){const t=c.t2|0;if(t<11)return _ot.apply(this,arguments);_ot.call(this,Object.assign({},c,{t2:0}),o);
const{Q4,sh,sit}=o,shd=dkHex(sh,.72),shl=dkHex(sh,1.3),FY=3.04,W="#f4f4f4";
const front=(x0,x1,z0,z1,fn,y)=>{for(let x=x0;x<x1-1e-6;x+=.25)for(let z=z0;z<z1-1e-6;z+=.25){const col=fn(x,z);if(col)Q4(x,y||FY,z,col)}};
const backf=(fn)=>{for(let x=1;x<3-1e-6;x+=.25)for(let z=4;z<8-1e-6;z+=.25){const col=fn(x,z);if(col)Q4(x,.74,z,col)}};
const sidef=(fn)=>{for(const xx of[.74,3.01])for(let y=1;y<3-1e-6;y+=.25)for(let z=4;z<8-1e-6;z+=.25){const col=fn(y,z,xx);if(col)Q4(xx,y,z,col)}};
const sleeve=fn=>{for(const ax of[0,3]){let k=ax;for(let x=ax;x<ax+1-1e-6;x+=.25)for(let z=6;z<8-1e-6;z+=.25){Q4(x,FY+.01,z,fn(x,z,k++))}for(let y=1;y<3-1e-6;y+=.25)for(let z=6;z<8-1e-6;z+=.25){Q4(ax===0?-.24:3.99,y,z,fn(y,z,k++))}for(let x=ax;x<ax+1-1e-6;x+=.25)for(let y=1;y<3-1e-6;y+=.25)Q4(x,y,8,fn(x,y,k++))}};
const all=fn=>{front(1,3,4,8,fn);backf(fn);sidef(fn)};
if(t===11){const F=(x,z)=>{const i=Math.floor(x*4)+Math.floor(z*4)*7;return i%11===0?"#ffd84a":i%11===5?"#ff5c8a":i%13===3?"#ffffff":i%7===2?"#2a9a5c":null};all(F);sleeve((x,z)=>F(x+3,z)||sh);front(1.5,2.5,7.5,8,()=>shd);for(const z of[7,6,5])Q4(1.94,FY+.02,z,W,.125)}
else if(t===12){const F=(x,z)=>Math.floor(z*4)%4<2?W:null;all(F);sleeve((x,z)=>Math.floor(z*4)%4<2?W:sh)}
else if(t===13){const J="#2b2f3a",JL="#3a4050";sleeve(()=>J);all((x,z)=>J);front(1,3,4,8,(x,z)=>{const v=Math.abs(x-2)<(z-5.6)*.45;return v?(Math.abs(x-2)<.13&&z<7.6?"#b03a3a":W):(Math.abs(x-2)<.13&&z<5.6?JL:null)},FY+.01);for(const z of[5.25,4.75])Q4(1.94,FY+.02,z,"#111",.125)}
else if(t===14){const S2="#c9a227";sleeve((x,z)=>z<6.5?(Math.floor(z*4)%2?"#1d1b1f":S2):S2);all((x,z)=>z<4.5?(Math.floor(x*4)%2?"#1d1b1f":S2):null);front(1.94,2.06,4.5,8,()=>"#c0c0c8",FY+.02);backf((x,z)=>{const d=Math.hypot(x-2,z-6.2);return d<.8?(d<.4?"#e8714a":S2):null})}
else if(t===15){const A="#3b3b3b";front(1.25,2.75,4,7.25,(x,z)=>(z>=5&&z<5.75&&x>=1.5&&x<2.5)?"#555":A,FY+.02);front(1.25,1.5,7.25,8,()=>A,FY+.02);front(2.5,2.75,7.25,8,()=>A,FY+.02);for(let x=1;x<3;x+=.25)Q4(x,.73,5.5,A)}
else if(t===16){sleeve(()=>W);all((x,z)=>W);front(1,3,4,8,(x,z)=>Math.abs(x-2)<(z-6)*.4?sh:null,FY+.01);front(2.4,2.8,5,5.5,()=>"#dcdcdc",FY+.02);Q4(2.5,FY+.03,5.4,"#2f6fd6",.125);if(!sit){for(let x=1;x<3;x+=.25)for(let z=2.5;z<4;z+=.25){Q4(x,FY+.02,z,W);Q4(x,.73,z,W)}for(const xx of[.73,3.02])for(let y=1;y<3;y+=.25)for(let z=2.5;z<4;z+=.25)Q4(xx,y,z,W)}}
else if(t===17){const F=(x,z)=>{const a=Math.floor(x*4)%4<2,b=Math.floor(z*4)%4<2;return a&&b?shd:(a||b)?dkHex(sh,.86):null};all(F);sleeve((x,z)=>F(x,z)||sh);front(1.5,2.5,7.5,8,()=>shd);for(const z of[7,6,5])Q4(1.94,FY+.02,z,W,.125)}
else if(t===18){sleeve((x,z)=>z<6.5?W:sh);front(1,3,4,8,(x,z)=>(Math.abs(x-2+ (8-z)*.0)<.5&&Math.abs(x-2)>=.25)?W:null,FY+.01);const bm=nameBmp("祭"),S=.06;for(let r=0;r<bm.h;r++)for(let q=0;q<bm.w;q++)if(bm.d[r*bm.w+q])Q4(2.9-q*S,.72,7.4-r*S,W,S);for(let x=1;x<3;x+=.25)Q4(x,.73,4,W)}
else if(t===19){const F=(x,z)=>((z*4)%4===0)?shd:null;all(F);sleeve((x,z)=>((z*4)%4===0)?shd:sh);for(let x=1;x<3;x+=.25)for(let z=4;z<8;z+=.25)if((z*4)%4===2)Q4(x,FY+.06,z,shl);front(1.94,2.06,4,8,()=>"#c0c0c8",FY+.08);front(1.25,2.75,7.75,8.25,()=>sh,FY+.1)}
else if(t===20){sleeve((x,z,k)=>(Math.floor(k)%4===1)?W:sh);front(1.94,2.06,4,8,()=>W,FY+.02);front(1.5,2.5,7.5,8,()=>shd);sidef((y,z)=>(y>=1.75&&y<2.25)?W:null)}
}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
