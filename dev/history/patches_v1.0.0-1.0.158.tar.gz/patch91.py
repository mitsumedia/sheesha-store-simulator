import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# Google AdSense（サイト確認＋H5ゲーム広告の準備）。今後の更新でも必ず入る
ADS='<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5065977714064066" crossorigin="anonymous"></script>\n<script>window.adsbygoogle=window.adsbygoogle||[];var adBreak=adConfig=function(o){adsbygoogle.push(o);};</script>\n'
rep('<head><meta charset=utf8>\n','<head><meta charset=utf8>\n'+ADS)
open(f,'w').write(s)
