import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
D=json.load(open('/home/claude/w/chun_dmd.json'))
ADD='''
/* ===== さんてぃ（No.131）からもらえる非売品：でっかい「中」の麻雀牌 ===== */
DMD.gf_141=%s;{const x={"id":"gf_141","n":"でっかい中の牌","p":4000,"t":{"asian":2},"u":["gift",0],"g":141};if(!DEC.some(d=>d.id===x.id))DEC.push(x);GIFT[141]=x}
''' % json.dumps(D)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
