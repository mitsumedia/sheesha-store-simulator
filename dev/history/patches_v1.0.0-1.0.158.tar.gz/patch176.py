import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 外観モードでも、ポスターは「中から見える壁」のものだけ出す（壁を貫通して見えないように）
rep('R.stat.filter(v=>wallVis(v[4],k))','R.stat.filter(v=>(R.ext&&v[4]&&v[5]&&v[5]<1)?wallVis0(v[4],k):wallVis(v[4],k))')
rep('if(!x||!x.img||!!x.fl!==!!fl)return;const[tx,ty,s]=d.k.split(",").map(Number);if(!wallVis(s,k))return;','if(!x||!x.img||!!x.fl!==!!fl)return;const[tx,ty,s]=d.k.split(",").map(Number);if(!wallVis0(s,k))return;')
rep('let WS=[];const wallVis=','const wallVis0=(t,k)=>!t||(t===1?k.cy>0:t===2?k.cx>0:t===3?k.cy<0:k.cx<0);let WS=[];const wallVis=')
rep('p.x<-3&&!p.vis&&!p.mob&&p.c&&mbOn()','p.x<-3&&!p.vis&&(!p.mob||p.c.mobC)&&p.c&&mbOn()')
rep('statList(k).forEach(o=>{if(o.v[4])dv(o.v,k)})','statList(k).forEach(o=>{if(o.v[4]&&(!R.ext||wallVis0(o.v[4],k)))dv(o.v,k)})')
rep('SC.fg=L.filter(o=>!o.v[4]);','SC.fg=L.filter(o=>!o.v[4]||(R.ext&&!wallVis0(o.v[4],k)));')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 訪ねてくるイベントの人は、歩道を歩いて（車で）やってくる。元恋人だけは灰色のまま ===== */
const MOBLK={6:{shirt:"#ffeb3b",top:7,pants:"#c8b38a",acc:18,pp:["cam"]},29:{shirt:"#1a237e",top:2,pants:"#1a237e",acc:2,sex:"男性",car:"police"},30:{shirt:"#212121",top:5,pants:"#212121",acc:1,hair:"#e0c068",hs:10,sex:"男性"},
 43:{shirt:"#ffd54f",top:2,pants:"#ffd54f",acc:11,car:"lux"},48:{shirt:"#f48fb1",top:8,pants:"#fafafa",acc:1,pp:["selfie"]},49:{shirt:"#e53935",top:0,pants:"#212121",acc:2,pp:["box2"]}};
{const _mv=mobVisit;mobVisit=function(e){if(R.closed||R.away!=null)return false;if(!mbOn()||R.cine)return _mv.apply(this,arguments);
 const L=MOBLK[e.id],c=mobChar();if(L){Object.assign(c,{skin:MB_SK[Math.floor(Math.random()*MB_SK.length)],hair:L.hair||MB_HR[Math.floor(Math.random()*MB_HR.length)],shirt:L.shirt,pants:L.pants,top:L.top,acc:L.acc||0,accC:"#333333"});if(L.sex)c.sex=L.sex;c.hs=L.hs!=null?L.hs:(c.sex==="女性"?MB_HSF:MB_HSM)[Math.floor(Math.random()*6)];c.bot=c.sex==="女性"?c.bot:0;c.mobC=1}
 const g=mbGeo(),side=Math.random()<.5?1:-1,T=Object.assign({},XEVT.per,{pp:L&&L.pp});
 if(L&&L.car){const base=xvT(L.car);if(base){const CT=L.car==="police"?xFlash(base):base;const car={T:CT,s:-1,lane:-1,x:g.L-20,y:g.Y1+30,a:2,t:0,sp:20,tag:1,seen:1,ev:1,evc:{e,c,T,stopY:15+(base.l||18)/2}};MB.L.push(car);MB.evw=(MB.evw||[]).concat([car]);return true}}
 const m={T,c,s:side,x:WK_X,y:15-side*55,a:1,t:0,sp:10,tag:1,seen:1,ev:1,evw:e};MB.L.push(m);MB.evw=(MB.evw||[]).concat([m]);return true}}
function mobEnter(e,c,x,y){const p={c,mob:1,ev:e,x,y,st:"peek",dir:1,seat:NOSEAT,seed:Math.random()*5,path:[[3,15]],bt:0,orders:0,tp:0,rem:0,nd:0,dl:0,dt:0,wt:0,nl:["……"]};R.people.push(p)}
function mobWalkTick(dt){const W=MB.evw;if(!W||!W.length)return;MB.evw=W.filter(m=>{
 if(R.closed||R.phase!=="run"){MB.L=MB.L.filter(o=>o!==m);return false}
 if(m.evw){if(!MB.L.includes(m))MB.L.push(m);const at=m.s>0?m.y>=15:m.y<=15;if(at){MB.L=MB.L.filter(o=>o!==m);mobEnter(m.evw,m.c,WK_X,15);return false}return true}
 if(m.evc){const v=m.evc;if(!v.done){if(m.y<=v.stopY){m.y=v.stopY;m.sp=0;v.done=1;v.t=0;mobEnter(v.e,v.c,mbGeo().L-14,15)}return true}
  v.t+=dt;if(v.t>25){m.sp=22;m.ev=0;m.T=Object.assign({},m.T,{sp0:1});return false}return true}
 return false})}
{const _tk6=tick;tick=function(now){try{const n=performance.now(),dt=Math.min(.1,(n-(MB.evwN||n))/1000);MB.evwN=n;mobWalkTick(dt)}catch(e){}return _tk6.apply(this,arguments)}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
