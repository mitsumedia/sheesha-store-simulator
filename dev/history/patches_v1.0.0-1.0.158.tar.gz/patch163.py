import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('try{if(typeof glassMod==="function")glassMod(a)}catch(e){}','try{if(typeof glassMod==="function")glassMod(a)}catch(e){}try{if(typeof signMod==="function")signMod(a)}catch(e){}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 外の看板（見本） ===== */
const SIGNS=[null,{n:"黒板の立て看板",p:100000,b:.02},{n:"木製の看板",p:250000,b:.03},{n:"電飾スタンド看板",p:500000,b:.04,lit:1},{n:"ネオンの縦看板",p:800000,b:.05,lit:1}];
function signCur(){return R.pvSg!=null?R.pvSg:(G.sign||0)}
function signText(a,txt,x0,y0,z0,S,col,maxW,axis){const bm=nameBmp(txt);let sc=S;if(bm.w*sc>maxW)sc=maxW/bm.w;for(let r=0;r<bm.h;r++)for(let q=0;q<bm.w;q++)if(bm.d[r*bm.w+q]){if(axis==="y")a.push([x0,y0+(bm.w-1-q)*sc,z0-r*sc,col,"sg",sc]);else a.push([x0+q*sc,y0,z0-r*sc,col,"sg",sc])}}
function signMod(a){const k=signCur();if(!k)return;const nm=String((G.ow&&G.ow.shop)||"SHEESHA"),X=-6,Y=6.5;
 if(k===1){/* 黒板のA型看板 */box(a,X,Y,0,.5,.5,11,"#6d4c41");box(a,X,Y+5.5,0,.5,.5,11,"#6d4c41");box(a,X,Y,10.5,.5,6,.5,"#6d4c41");box(a,X,Y+.5,2,.5,5,8.5,"#2f4f3a");box(a,X+1.5,Y+.5,0,.5,5,.5,"#6d4c41");
  signText(a,nm,X-.22,Y+.8,10,.14,"#ffffff",4.4,"y");for(const[yy,zz,c]of[[1.2,6.6,"#ffd54f"],[2.4,6.6,"#ffd54f"],[3.6,6.6,"#ffd54f"],[1.2,5,"#f48fb1"],[2.4,5,"#f48fb1"],[1.2,3.4,"#81d4fa"],[2.4,3.4,"#81d4fa"],[3.6,3.4,"#81d4fa"]])box(a,X-.22,Y+yy,zz,.1,.9,.3,c)}
 else if(k===2){/* 木製の看板 */box(a,X+.2,Y+.7,0,.6,.6,7,"#5d4030");box(a,X+.2,Y+5.2,0,.6,.6,7,"#5d4030");box(a,X,Y,7,.8,6.5,5,"#c4955f");box(a,X-.1,Y-.3,12,1,7.1,.6,"#5d4030");box(a,X-.1,Y-.3,6.5,1,7.1,.5,"#5d4030");signText(a,nm,X-.22,Y+.4,11.3,.17,"#3e2723",5.7,"y")}
 else if(k===3){/* 電飾スタンド看板 */box(a,X-.5,Y+.5,0,2.5,5,.8,"#424242");box(a,X,Y+1,0,1.5,4,14,"#f5f5f5");box(a,X-.1,Y+.9,14,1.7,4.2,.5,"#424242");for(let z=1;z<14;z+=1.4)a.push([X-.22,Y+1,z,"#ffeb3b","sg",.3],[X-.22,Y+4.7,z,"#ffeb3b","sg",.3]);signText(a,nm,X-.22,Y+1.4,13,.13,"#c62828",3.2,"y")}
 else if(k===4){/* ネオンの縦看板 */box(a,X-.5,Y,0,2.5,6,.8,"#212121");box(a,X+.5,Y+2.6,.8,.8,.8,3,"#616161");box(a,X,Y,3.8,1,6,12,"#1b1530");for(let y=Y;y<Y+6;y+=.3)a.push([X-.22,y,15.6,"#ff4fa3","sg",.3],[X-.22,y,3.9,"#ff4fa3","sg",.3]);for(let z=3.9;z<15.8;z+=.3)a.push([X-.22,Y,z,"#ff4fa3","sg",.3],[X-.22,Y+5.7,z,"#ff4fa3","sg",.3]);signText(a,nm,X-.24,Y+.5,14.6,.16,"#40c4ff",5,"y");signText(a,"OPEN",X-.24,Y+1.2,8,.14,"#ffd1ec",3.6,"y")}}
{const _sm=signMod;signMod=function(a){const n0=a.length;_sm.apply(this,arguments);const k=signCur();if(!k)return;const th={1:.5,2:.8,3:1.5,4:1}[k],X=-6,add=[];for(let i=n0;i<a.length;i++){const v=a[i];if(v[4]==="sg"&&v[0]<X+.01){add.push([X+th+.06,v[1],v[2],v[3],"sb",v[5]])}}
 /* 裏面は文字が鏡にならないよう左右を反転 */let y0=1e9,y1=-1e9;add.forEach(v=>{y0=Math.min(y0,v[1]);y1=Math.max(y1,v[1]+v[5])});add.forEach(v=>{a.push(v)});for(let i=n0;i<a.length;i++){if(a[i][4]==="sg"||a[i][4]==="sb")a[i][4]=undefined}}}
/* 夜に光る部分を明るく */
{const _gd=glassDraw;glassDraw=function(k){const r=_gd.apply(this,arguments);try{const sg=SIGNS[signCur()];if(sg&&sg.lit&&LTN&&LTN.glow>.2){const p=P3(-6.2,9.5,9,k),rr=20;const g=cx.createRadialGradient(p[0],p[1],1,p[0],p[1],rr*(R.cv?R.cv.s:1)*.6);g.addColorStop(0,signCur()===4?"rgba(255,79,163,.35)":"rgba(255,235,59,.3)");g.addColorStop(1,"rgba(0,0,0,0)");cx.save();cx.fillStyle=g;cx.beginPath();cx.arc(p[0],p[1],rr*(R.cv?R.cv.s:1)*.6,0,7);cx.fill();cx.restore()}}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
