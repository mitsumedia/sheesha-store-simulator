import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('<span id="smk"></span>','<details class="cd" id="d-sys"><summary>🔑 データ・お知らせ</summary><div class="card"><button id="cdb" style="width:100%;margin-bottom:6px">🔑 引き継ぎコード</button><button id="giftb2" style="width:100%;margin-bottom:6px">🎁 不思議な贈り物</button><button id="polb" style="width:100%">📄 規約・プライバシー・お問い合わせ</button><div id="verl" class="m" style="text-align:center;font-size:11px;margin-top:10px;user-select:none">Ver 1.0.0</div></div></details>\n<span id="smk"></span>')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 引き継ぎコード・不思議な贈り物・管理（サーバー：api.php） ===== */
const CLOUD_API="api.php";
const cl=()=>{try{return JSON.parse(localStorage.getItem("shisha_cloud")||"null")}catch(e){return null}},clSet=o=>{try{localStorage.setItem("shisha_cloud",JSON.stringify(o))}catch(e){}};
async function api(o){let r;try{r=await fetch(CLOUD_API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)})}catch(e){throw new Error("通信できませんでした。電波のいい所でもう一度試してください")}let j=null;try{j=await r.json()}catch(e){}if(!j)throw new Error("サーバーの応答が読めませんでした（"+r.status+"）");if(!j.ok){const e=new Error(j.error||"エラーが起きました");e.st=r.status;throw e}return j}
const b64=u8=>{let s="";for(let i=0;i<u8.length;i+=32768)s+=String.fromCharCode.apply(null,u8.subarray(i,i+32768));return btoa(s)},ub64=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
async function cpack(){const js=JSON.stringify(G);if(typeof CompressionStream==="function"){try{const st=new Blob([js]).stream().pipeThrough(new CompressionStream("gzip"));return{z:1,data:b64(new Uint8Array(await new Response(st).arrayBuffer()))}}catch(e){}}return{z:0,data:js}}
async function cunpack(z,d){if(!z)return d;const st=new Blob([ub64(d)]).stream().pipeThrough(new DecompressionStream("gzip"));return await new Response(st).text()}
const monLbl=()=>(Math.floor((G.month||0)/12)+1)+"年目"+MN[(G.month||0)%12]+"月",cmeta=()=>({shop:G.ow?G.ow.shop||"":"",owner:G.ow?G.ow.name||"":"",mon:monLbl(),money:Math.round(G.money||0)});
const fdt=t=>{if(!t)return"—";const d=new Date(t*1000);return d.getFullYear()+"/"+(d.getMonth()+1)+"/"+d.getDate()+" "+d.getHours()+":"+String(d.getMinutes()).padStart(2,"0")};
let cSaving=0;
async function cloudSave(){const c=cl();if(!c||cSaving||!G.setup)return false;cSaving=1;try{const j=await api({a:"save",uid:c.uid,token:c.token,...cmeta(),...(await cpack())});c.at=j.at;c.err=0;clSet(c);return true}catch(e){c.err=e.st===403?2:1;clSet(c);return false}finally{cSaving=0}}
function sysM(h){let m=document.getElementById("sysm");if(!m){m=document.createElement("div");m.id="sysm";m.style.cssText="position:fixed;inset:0;z-index:9999;background:rgba(20,10,40,.55);display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box";m.addEventListener("click",e=>{if(e.target===m||e.target.closest("[data-sx]"))m.remove()});document.body.appendChild(m)}
m.innerHTML=`<div class="card" style="width:100%;max-width:380px;max-height:86vh;overflow:auto;position:relative;background:#fff;border-radius:14px;padding:16px;box-sizing:border-box"><button data-sx style="position:absolute;right:8px;top:8px;padding:2px 10px">✕</button>${h}</div>`;return m}
const sysOff=()=>{const m=document.getElementById("sysm");if(m)m.remove()},sysMsg=(id,t,bad)=>{const e=document.getElementById(id);if(e){e.innerHTML=t;e.style.color=bad?"#e5484d":"#22a06b"}};
const INP='style="width:100%;box-sizing:border-box;font-size:16px;padding:8px;margin:4px 0;border:1px solid #d9d0e8;border-radius:8px"';
function loadBox(){return`<div style="margin-top:14px;padding-top:10px;border-top:1px solid #eee"><b style="font-size:13px">📲 引き継ぎコードで続きから</b><div class="m" style="font-size:11px">別の端末のデータをこの端末に読み込みます</div><input id="cdin" ${INP} placeholder="例：AB12-CD34" autocapitalize="characters" autocomplete="off"><button id="cdld" style="width:100%">読み込む</button><div id="cdlm" style="font-size:12px;margin-top:4px"></div></div>`}
function codeUI(first){const c=cl();
if(!c){sysM(`<b>🔑 引き継ぎコード</b><div style="font-size:13px;line-height:1.7;margin:8px 0">コードを発行すると、<b>毎月の精算のたびに自動でセーブ</b>がサーバーに保存されます。<br>機種変更やデータが消えたときは、このコードで続きから遊べます。</div><button id="cdis" class="on" style="width:100%">コードを発行する</button><div id="cdim" style="font-size:12px;margin-top:4px"></div>${loadBox()}`);return}
sysM(`<b>🔑 引き継ぎコード</b>${first?`<div style="font-size:14px;margin:8px 0;padding:8px;border-radius:8px;background:#fff6e5;line-height:1.6"><b>📸 この画面をスクショしてね！</b><br>あなた専用の<b>引き継ぎコード</b>です。機種変更やデータが消えたときに、このコードで続きから遊べます。<br>これからは毎月の精算で自動セーブされます。</div>`:""}<div style="font-size:30px;font-weight:800;letter-spacing:3px;text-align:center;margin:12px 0;padding:10px;background:#f4effb;border-radius:10px;user-select:all">${esc(c.code)}</div><button id="cdcp" style="width:100%;margin-bottom:6px">📋 コピーする</button><div class="m" style="font-size:12px;line-height:1.6">毎月の精算のたびに自動でセーブされます<br>最後のセーブ：${fdt(c.at)}${c.err===2?`<br><span style="color:#e5484d">⚠️ この端末の登録が無効になっています（別の端末で読み込まれた可能性）。コードで読み込み直してください</span>`:c.err?`<br><span style="color:#e5484d">⚠️ 前回のセーブに失敗しました</span>`:""}</div><button id="cdsv" style="width:100%;margin-top:8px">☁️ 今すぐセーブ</button><div id="cdsm" style="font-size:12px;margin-top:4px"></div>${loadBox()}`)}
let cdArm=0;
document.addEventListener("click",async e=>{const b=e.target.closest("button,#verl");if(!b)return;const id=b.id;
if(id==="cdb"){codeUI();return}
if(id==="cdis"){b.disabled=true;sysMsg("cdim","発行中…");try{const j=await api({a:"issue",...cmeta(),...(await cpack())});clSet({uid:j.uid,token:j.token,code:j.code,at:j.at});log("🔑 引き継ぎコードを発行しました（"+j.code+"）");codeUI(true)}catch(er){b.disabled=false;sysMsg("cdim",esc(er.message),1)}return}
if(id==="cdcp"){const c=cl();try{await navigator.clipboard.writeText(c.code);b.textContent="✅ コピーしました"}catch(er){b.textContent="長押しでコードを選んでコピーしてください"}return}
if(id==="cdsv"){b.disabled=true;sysMsg("cdsm","セーブ中…");const ok=await cloudSave();b.disabled=false;if(ok)codeUI();else{const c=cl();sysMsg("cdsm",c&&c.err===2?"この端末の登録が無効です。コードで読み込み直してください":"セーブできませんでした。通信を確認してください",1)}return}
if(id==="cdld"){const v=(document.getElementById("cdin").value||"").trim();if(!v){sysMsg("cdlm","コードを入れてください",1);return}
if(!(cdArm>Date.now())){cdArm=Date.now()+6000;b.textContent="⚠️ 今のこの端末のデータは上書きされます。もう一度押すと読み込み";return}cdArm=0;b.disabled=true;sysMsg("cdlm","読み込み中…");
try{const j=await api({a:"load",code:v});const js=await cunpack(j.z,j.data);const g=JSON.parse(js);if(!g||!g.cs)throw new Error("セーブデータが壊れています");
const _set=Storage.prototype.setItem;_set.call(localStorage,"shisha_v2",js);_set.call(localStorage,"shisha_cloud",JSON.stringify({uid:j.uid,token:j.token,code:j.code,at:j.at}));Storage.prototype.setItem=function(k,v){if(k==="shisha_v2")return;return _set.call(this,k,v)};
sysM(`<b>✅ 読み込みました</b><div style="font-size:13px;margin:8px 0">「${esc(j.shop||"")}」${esc(j.mon||"")}のデータです。再読み込みします…</div>`);setTimeout(()=>location.reload(),900)}catch(er){b.disabled=false;b.textContent="読み込む";sysMsg("cdlm",esc(er.message),1)}return}
if(id==="giftb2"){giftUI();return}
if(id==="gfok"){const v=(document.getElementById("gfin").value||"").trim(),c=cl();if(!v)return;b.disabled=true;sysMsg("gfm","確認中…");
try{const j=await api({a:"gift",uid:c.uid,token:c.token,pass:v});G.money+=j.money||0;G.tix=(G.tix||0)+(j.tix||0);save();hud();try{rfin()}catch(_){}
const t=[j.money?yen(j.money):"",j.tix?"🎟 招待チケット×"+j.tix:""].filter(Boolean).join("・");log("🎁 不思議な贈り物「"+(j.title||"")+"」を受け取った！ "+t);
sysM(`<div style="text-align:center"><div style="font-size:44px">🎁</div><b>${esc(j.title||"不思議な贈り物")}</b><div style="font-size:18px;font-weight:700;margin:10px 0">${esc(t)}</div>${j.msg?`<div class="m" style="font-size:13px;line-height:1.6">${esc(j.msg)}</div>`:""}<button data-sx class="on" style="width:100%;margin-top:12px">受け取った</button></div>`);cloudSave()}catch(er){b.disabled=false;sysMsg("gfm",esc(er.message),1)}return}
if(id==="polb"){sysM(`<b>📄 規約・プライバシー・お問い合わせ</b><div style="display:flex;flex-direction:column;gap:6px;margin-top:10px"><a href="privacy.html" target="_blank" rel="noopener"><button style="width:100%">🔒 プライバシーポリシー</button></a><a href="terms.html" target="_blank" rel="noopener"><button style="width:100%">📜 利用規約</button></a><a href="about.html" target="_blank" rel="noopener"><button style="width:100%">🏢 運営者情報・お問い合わせ</button></a></div><div class="m" style="font-size:11px;margin-top:10px;text-align:center">運営：ミツメディア／info@mitsumedia.xyz</div>`);return}
if(id==="verl"){R.vtap=(R.vtap||[]).filter(t=>t>Date.now()-3000);R.vtap.push(Date.now());if(R.vtap.length>=5){R.vtap=[];admUI()}return}
});
function giftUI(){const c=cl();if(!c){sysM(`<b>🎁 不思議な贈り物</b><div style="font-size:13px;line-height:1.7;margin:8px 0">贈り物を受け取るには、先に<b>引き継ぎコード</b>の発行が必要です（1人1回ずつ受け取れるようにするため）。</div><button id="cdb" class="on" style="width:100%">🔑 引き継ぎコードを発行する</button>`);return}
sysM(`<b>🎁 不思議な贈り物</b><div class="m" style="font-size:12px;margin:6px 0">運営からのお知らせなどで届いた「あいことば」を入れてください</div><input id="gfin" ${INP} placeholder="あいことば" autocomplete="off"><button id="gfok" class="on" style="width:100%">受け取る</button><div id="gfm" style="font-size:12px;margin-top:4px"></div>`)}
/* 毎月の精算後に自動セーブ。未発行なら最初の精算後に1回だけ案内 */
{const _st=settle;settle=function(){const r=_st.apply(this,arguments);try{if(cl())setTimeout(cloudSave,50)}catch(e){}return r}}
/* 最初の精算が終わって翌月へ進んだら、自動でコードを発行して表示 */
{const _nm=nextMonth;nextMonth=function(){const r=_nm.apply(this,arguments);try{if(G.setup&&!G.cdAsk2&&!cl()&&!G.over&&/^https?:/.test(location.protocol)){G.cdAsk2=1;save();setTimeout(async()=>{try{const j=await api({a:"issue",...cmeta(),...(await cpack())});clSet({uid:j.uid,token:j.token,code:j.code,at:j.at});log("🔑 引き継ぎコードを発行しました（"+j.code+"）");codeUI(true)}catch(e){toast("🔑 データが消えたときのために、☰ →「データ・お知らせ」から<b>引き継ぎコード</b>を発行しておこう",6000)}},600)}}catch(e){}return r}}
/* ===== 管理ページ（バージョン表記を5回タップ） ===== */
let AP="";
const aapi=o=>api({...o,apass:AP});
function admUI(){sysM(`<b>🛠 管理ページ</b><input id="apin" type="password" ${INP} placeholder="管理パスワード" autocomplete="current-password"><button id="apok" class="on" style="width:100%">ログイン</button><div id="apm" style="font-size:12px;margin-top:4px"></div>`)}
function admHome(st){sysM(`<b>🛠 管理ページ</b><div class="m" style="font-size:12px;margin:4px 0">登録 ${st.players}人・直近7日にセーブ ${st.week}人</div>
<div style="margin-top:10px"><b style="font-size:13px">👤 ユーザーを探す</b><input id="aq" ${INP} placeholder="店名・店主名・コード"><button id="aqb" style="width:100%">検索</button><div id="aql" style="font-size:12px;margin-top:6px"></div></div>
<div style="margin-top:14px;padding-top:10px;border-top:1px solid #eee"><b style="font-size:13px">🎁 不思議な贈り物を作る</b>
<input id="ga1" ${INP} placeholder="あいことば（例：おわび1118）"><input id="ga2" ${INP} placeholder="タイトル（例：メンテナンスのお詫び）"><input id="ga3" ${INP} type="number" inputmode="numeric" placeholder="お金（円）"><input id="ga4" ${INP} type="number" inputmode="numeric" placeholder="招待チケット（枚）"><input id="ga5" ${INP} placeholder="ひとことメッセージ（任意）">
<div class="m" style="font-size:11px">受け取り期限（空欄なら無期限）</div><input id="ga6" ${INP} type="date"><input id="ga7" ${INP} type="number" inputmode="numeric" placeholder="先着人数（空欄か0なら無制限）"><button id="gab" class="on" style="width:100%">作成する</button><div id="gam" style="font-size:12px;margin-top:4px"></div><div id="gal" style="font-size:12px;margin-top:8px"></div></div>`);admGifts()}
async function admGifts(){const el=document.getElementById("gal");if(!el)return;try{const j=await aapi({a:"a_gifts"});el.innerHTML=j.list.length?j.list.map(g=>`<div style="padding:6px 0;border-bottom:1px solid #f0f0f0;${g.active?"":"opacity:.45"}"><b>${esc(g.pass)}</b>　${esc(g.title||"")}<br>${g.money?yen(+g.money)+" ":""}${g.tix?"🎟×"+g.tix+" ":""}受取 ${g.used}${+g.maxuse?"/"+g.maxuse:""}人・${+g.expires?"〜"+fdt(+g.expires).split(" ")[0]:"無期限"} <button data-gt="${g.id}" style="padding:2px 8px;font-size:11px">${g.active?"停止する":"再開する"}</button></div>`).join(""):"まだありません"}catch(e){el.textContent=e.message}}
document.addEventListener("click",async e=>{const b=e.target.closest("button");if(!b)return;
if(b.id==="apok"){AP=document.getElementById("apin").value;sysMsg("apm","確認中…");try{admHome(await aapi({a:"a_login"}))}catch(er){AP="";sysMsg("apm",esc(er.message),1)}return}
if(b.id==="aqb"){const el=document.getElementById("aql");el.textContent="検索中…";try{const j=await aapi({a:"a_search",q:document.getElementById("aq").value});
el.innerHTML=j.list.length?j.list.map(p=>`<div style="padding:6px 0;border-bottom:1px solid #f0f0f0"><b>${esc(p.shop||"（店名なし）")}</b>　店主 ${esc(p.owner||"")}<br>コード <b>${esc(p.code)}</b>・${esc(p.mon||"")}・所持金 ${yen(+p.money||0)}<br>開始 ${fdt(+p.created)}・最終 ${fdt(+p.updated)}<br><button data-ah="${p.id}" style="padding:2px 8px;font-size:11px">セーブ履歴（${p.ns}）</button> <button data-ar="${p.id}" style="padding:2px 8px;font-size:11px">コード再発行</button><div id="ah${p.id}"></div></div>`).join(""):"見つかりません"}catch(er){el.textContent=er.message}return}
if(b.dataset.ah){const pid=b.dataset.ah,el=document.getElementById("ah"+pid);try{const j=await aapi({a:"a_saves",pid});el.innerHTML=j.list.map((s,i)=>`<div style="margin:4px 0 0 8px">${i===0?"最新":i+"つ前"}：${fdt(+s.created)}（${Math.round(s.size/1024)}KB）${i?` <button data-rs="${s.id}" data-rp="${pid}" style="padding:2px 8px;font-size:11px">この時点に戻す</button>`:""}</div>`).join("")}catch(er){el.textContent=er.message}return}
if(b.dataset.rs){if(b.dataset.arm!=="1"){b.dataset.arm="1";b.textContent="もう一度押すと戻します";return}try{await aapi({a:"a_restore",pid:b.dataset.rp,sid:b.dataset.rs});b.textContent="✅ 戻しました（本人がコードで読み込むと反映）";b.disabled=true}catch(er){b.textContent=er.message}return}
if(b.dataset.ar){if(b.dataset.arm!=="1"){b.dataset.arm="1";b.textContent="古いコードは使えなくなります。もう一度押すと再発行";return}try{const j=await aapi({a:"a_recode",pid:b.dataset.ar});b.textContent="新しいコード："+j.code;b.disabled=true}catch(er){b.textContent=er.message}return}
if(b.id==="gab"){const v=i=>(document.getElementById("ga"+i).value||"").trim();if(!v(1)){sysMsg("gam","あいことばを入れてください",1);return}if(!+v(3)&&!+v(4)){sysMsg("gam","お金かチケットのどちらかを入れてください",1);return}
try{await aapi({a:"a_gift_add",pass:v(1),title:v(2),money:+v(3)||0,tix:+v(4)||0,msg:v(5),until:v(6),maxuse:+v(7)||0});sysMsg("gam","✅ 作成しました。あいことば「"+esc(v(1))+"」を告知してください");[1,2,3,4,5,6,7].forEach(i=>document.getElementById("ga"+i).value="");admGifts()}catch(er){sysMsg("gam",esc(er.message),1)}return}
if(b.dataset.gt){try{await aapi({a:"a_gift_toggle",id:b.dataset.gt});admGifts()}catch(er){}return}
});
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
