import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# カウンターの台を1ブロック奥へ（壁にぴったり付くように）
rep('for(let x=0;x<18;x++){for(let y=7;y<11;y++)for(let z=0;z<6;z++)B(x,y,z,z===5&&v.ctrim&&y===7?v.ctrim:v.cbd);for(let y=6;y<11;y++)B(x,y,6,v.ctop)}','for(let x=0;x<18;x++){for(let y=8;y<12;y++)for(let z=0;z<6;z++)B(x,y,z,z===5&&v.ctrim&&y===8?v.ctrim:v.cbd);for(let y=7;y<12;y++)B(x,y,6,v.ctop)}')
open(f,'w').write(s)
