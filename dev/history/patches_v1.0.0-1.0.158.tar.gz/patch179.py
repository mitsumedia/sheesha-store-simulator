import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== イベントは良いもの7割・悪いもの3割 ===== */
{const _ep=evPick;evPick=function(tp){try{const L=EV.filter(e=>e.t===tp&&e.id!==31&&!(e.once&&(G.evDex||{})[e.id])&&(!e.ok||e.ok()));if(!L.length)return null;const good=L.filter(e=>GA_GOOD.includes(e.id)),bad=L.filter(e=>!GA_GOOD.includes(e.id));let P=Math.random()<.7?good:bad;if(!P.length)P=good.length?good:bad;let s=P.reduce((a,e)=>a+EVW[e.r],0)*Math.random();for(const e of P){s-=EVW[e.r];if(s<=0)return e}return P[P.length-1]}catch(e){return _ep.apply(this,arguments)}}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
