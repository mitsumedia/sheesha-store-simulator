import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('genScn();try{if(typeof glassMod==="function")glassMod(a)}catch(e){}','genScn();try{if(typeof xsStatic==="function")xsStatic(a)}catch(e){}try{if(typeof glassMod==="function")glassMod(a)}catch(e){}')
rep('c=rnd(U.length?U:L);c.act=1;arrive([c]);return"（"+nm(c)+"が来店）"','c=rnd(U.length?U:L);c.act=1;if(typeof mbOn==="function"&&mbOn()){R.sched.push({at:R.t+5,m:[c],force:1});R.sched.sort((a,b)=>a.at-b.at)}else arrive([c]);return"（"+nm(c)+"が来店）"')
# ガチャのイベント確定：★4に限らず、良いイベントだけ
rep('function gaEvList(){return EV.filter(e=>![31,40,42,50].includes(e.id)&&(e.t==="pre"||e.t==="run")&&!(e.once&&(G.evDex||{})[e.id]))}',
    'const GA_GOOD=[2,6,8,10,13,14,20,22,27,34,36,38,41,43,45,46,48,49];function gaEvList(){return EV.filter(e=>GA_GOOD.includes(e.id)&&(e.t==="pre"||e.t==="run")&&!(e.once&&(G.evDex||{})[e.id])&&(!e.ok||e.t==="run"||(()=>{try{return e.ok()}catch(_){return true}})()))}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
s=s.replace(TAIL,open('/home/claude/w/p178.js').read()+'\n'+TAIL)
open(f,'w').write(s)
