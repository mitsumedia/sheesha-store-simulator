set -e
cd /home/claude/w
cp game.v137.html game.html
for p in 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119 120 121 122 123 124 125 126 127 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157 158 159 160 161 162 166 167 168 169 170 171 172 173 164 174 175 176 177 178 179 180 181 182 183; do python3 patch$p.py game.html >/dev/null; done
python3 - <<'P'
import re
G=open('game.html').read();Go=open('game.orig.html').read();B=open('builder.orig.html').read()
big=lambda h:max(re.findall(r'<script>(.*?)</script>',h,re.S),key=len)
gs,go,bs=big(G),big(Go),big(B);tail=go[len(bs)-1:];assert gs.endswith(tail)
open('builder.html','w').write(B.replace(bs,gs[:len(gs)-len(tail)]+"\n",1))
P
python3 patchB.py builder.html >/dev/null && python3 patchB2.py builder.html >/dev/null
timeout 200 python3 t0.py game.html
