import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('"変わってないね、そういうところ"];','"変わってないね、そういうところ","…その髪型、似合ってるじゃん","今の人とは、うまくいってるの？","自分のこと、お客さんとして扱ってね","…あの時は、ごめんね","また来るかは、わからないけど"];')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 💔 元恋人：図鑑は名前と見た目だけ。来店は月1回20%の抽選 ===== */
const motoC=()=>G.cs.find(c=>c.moto);
function motoFix(){const c=motoC();if(!c)return;c.act=0;c.ls=MOTOL.slice();if(G.motoM!==G.month){G.motoM=G.month;G.motoD=Math.random()<.2?G.day+Math.floor(Math.random()*Math.max(1,7-(G.wd||0))):-1}}
{const _sc=sched;sched=function(fc){try{motoFix()}catch(e){}const r=_sc.apply(this,arguments);try{const c=motoC();if(c&&!fc&&G.motoD===G.day&&!c.quit){const o=G.open*60+(R.late||0),e=G.close*60-60;if(e>o){R.sched.push({at:o+Math.floor(Math.random()*(e-o)),m:[c]});R.sched.sort((a,b)=>a.at-b.at);G.motoD=-1}}}catch(e){}return r}}
{const _fd=fmDex;fmDex=function(i,el){const r=_fd.apply(this,arguments);try{const c=G.cs[i];if(c&&c.moto){const n=document.querySelector("#fms .nm");if(n)n.innerHTML=`<div><b>💔 ${esc(c.name)}</b><small>元恋人。たまにやってくる</small></div>`;const tl=document.querySelector("#fms .tl");if(tl)tl.textContent="💔";fmBtn(null)}}catch(e){}return r}}
{const _rd2=rdex;rdex=function(){if(R.sel>=0&&G.cs[R.sel]&&G.cs[R.sel].moto)R.sel=-1;const r=_rd2.apply(this,arguments);try{document.querySelectorAll(".dxt[data-c]").forEach(el=>{const c=G.cs[+el.dataset.c];if(c&&c.moto){el.querySelectorAll(".dxl,.dxp").forEach(x=>x.style.visibility="hidden");const no=el.querySelector(".dxno");if(no&&no.textContent!=="💔")no.textContent="💔"}})}catch(e){}return r}}
try{setTimeout(()=>{try{motoFix()}catch(e){}},0)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
