import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* 大雪の日は吹雪っぽく：粒を増やして斜めに、うっすら白くかすむ */
{const _dr3=draw;draw=function(){const r=_dr3.apply(this,arguments);try{if(R.vis)return r;const t=td();if(!(t.snow||(t.evs||[]).includes(32)))return r;const T=performance.now()/1000;cx.save();cx.setTransform(dpr,0,0,dpr,0,0);cx.fillStyle="rgba(240,244,250,.16)";cx.fillRect(0,0,W,CH);cx.fillStyle="rgba(255,255,255,.9)";for(let i=0;i<140;i++){const sz=.9+(i%5)*.55,sp=40+(i%7)*9,x=((i*53+T*(60+(i%4)*15))%(W+60))-30,y=(i*97+T*sp)%(CH+20)-10;cx.beginPath();cx.arc(x,y,sz,0,7);cx.fill()}cx.restore()}catch(e){}return r}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
