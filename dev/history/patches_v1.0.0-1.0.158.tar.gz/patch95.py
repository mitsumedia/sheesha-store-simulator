import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 急な用事で外出中の店主は、店の外に立たせず画面から消す（戻る時は入口から入ってくる）
rep('OW._pc=null;OW.x=-8;OW.y=15}}','OW._pc=null;OW.x=-999;OW.y=-999}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 図鑑：ステージも「解禁度」でカードと同じ色・色の説明を表示 ===== */
const DXCL=[[0,"#8a8494","0〜9%"],[10,"#5c9cff","10〜29%"],[30,"#f2d04a","30〜49%"],[50,"#4fd18a","50〜69%"],[70,"#ff6a5a","70〜99%"],[100,"#ffcf5a","100%（コンプリート）"]];
const dxColL=p=>{let c=DXCL[0][1];for(const d of DXCL)if(p>=d[0])c=d[1];return c};
try{document.head.insertAdjacentHTML("beforeend",`<style>#dxlg{display:flex;flex-wrap:wrap;gap:4px 10px;margin-top:6px;font-size:10.5px;font-weight:700;color:#5c7a73}#dxlg span{display:inline-flex;align-items:center;gap:3px}#dxlg i{display:inline-block;width:14px;height:5px;border-radius:3px}</style>`)}catch(e){}
function dxLegend(){const dc=$("#dc");if(!dc||R.dxm==="f"||R.dxm==="e"||dc.querySelector("#dxlg"))return;const d=document.createElement("div");d.id="dxlg";d.innerHTML=`<b style="color:#123a33">解禁度の色：</b>`+DXCL.map(x=>`<span><i style="background:${x[1]}"></i>${x[2]}</span>`).join("");dc.appendChild(d)}
{const _rd=rdex;rdex=function(){const r=_rd.apply(this,arguments);try{dxLegend()}catch(e){}return r}}
{const _fd=fmDex;fmDex=function(i,el){const r=_fd.apply(this,arguments);try{const c=G.cs[i];if(c&&c.met){const L=lv(c),p=L>=NL?100:Math.floor(L/NL*100),col=dxColL(p),nm2=document.querySelector("#fms .nm>div:last-child");if(nm2)nm2.innerHTML=`解禁度 ${p}%<div class="ga" style="width:90px"><i style="width:${p}%;background:${col}"></i></div>`}}catch(e){}return r}}
try{dxLegend()}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
