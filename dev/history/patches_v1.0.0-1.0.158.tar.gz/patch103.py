import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('${ownForm()}','${ownForm2()}',3)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 起動時・登録時の店主プロフィール設定を新デザインに（名前・店名が一番上） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
#ov .card:has(.owf2){background:#f3f1ea!important;color:#123a33!important;border:none!important;border-radius:16px!important}
#ov .card:has(.owf2)>b{font-size:17px;font-weight:900;color:#005d4d}
#ov .card:has(.owf2) .m{color:#5c7a73!important}
#ov .card:has(.owf2) select,#ov .card:has(.owf2) input[type=text],#ov .card:has(.owf2) input[type=number]{background:#fff!important;color:#123a33!important;border:1.5px solid #cfd8d4!important;border-radius:10px!important;padding:8px 10px!important;font-size:15px!important;width:100%!important;box-sizing:border-box!important}
#ov .card:has(.owf2) #own0,#ov .card:has(.owf2) #start0,#ov .card:has(.owf2) #owok{width:100%;margin-top:10px;background:#6658a6!important;color:#fff!important;border:none!important;border-radius:14px!important;padding:12px 0!important;font-weight:900!important;font-size:16px!important}
.owf2 .ofstg{position:sticky;top:-2px;z-index:5;background:#005d4d;border-radius:12px;height:170px;margin:8px 0 10px;box-shadow:0 6px 10px -6px rgba(0,40,30,.4);display:flex;align-items:center;justify-content:center}
.owf2 .ofstg canvas{width:150px!important;height:160px!important}
#ov .card:has(.owf2){overflow:visible!important}
#ov .owf2 .ofstg button{position:absolute;top:50%;transform:translateY(-50%);width:36px!important;height:36px!important;border-radius:50%!important;background:#6658a6!important;color:#fff!important;border:none!important;padding:0!important;font-size:14px!important}
#ov .owf2 .ofstg button[data-ow=L]{left:10px}#ov .owf2 .ofstg button[data-ow=R]{right:10px}
.owf2 .ofsec{background:#fff;border-radius:12px;padding:2px 12px;margin-bottom:10px}
.owf2 .ofrw{padding:9px 0;border-bottom:1px solid #ecebe4}.owf2 .ofrw:last-child{border-bottom:none}
.owf2 .oflb{display:flex;justify-content:space-between;align-items:center;font-size:13px;font-weight:900;margin-bottom:6px}
.owf2 .ofsw{display:flex;flex-wrap:wrap;gap:7px}
#ov .owf2 .ofsw button{width:28px!important;height:28px!important;min-width:0!important;padding:0!important;border-radius:50%!important;border:2px solid #fff!important;box-shadow:0 0 0 1.5px #cfd8d4!important;margin:0!important;flex:none}
#ov .owf2 .ofsw button.on{box-shadow:0 0 0 2.5px #6658a6!important}
#ov .owf2 input[type=color]{width:34px!important;height:30px!important;padding:0!important;border:none!important;background:none!important}
.owf2 .ofpl{display:flex;flex-wrap:wrap;gap:6px}
#ov .owf2 .ofpl button{padding:5px 12px!important;border-radius:16px!important;font-size:12.5px!important;font-weight:900!important;background:#fff!important;border:1.5px solid #cfd8d4!important;color:#123a33!important;margin:0!important}
#ov .owf2 .ofpl button.on{background:#6658a6!important;border-color:#6658a6!important;color:#fff!important}
.owf2 label{display:block}.owf2 label>span{display:block;font-size:13px;font-weight:900;margin-bottom:6px}
</style>`)}catch(e){}
function ownForm2(){R.od=R.od||OWD0();const c=R.od;
const sw=(k,l)=>`<div class="ofrw"><div class="oflb">${l}<input type="color" data-ok="${k}" value="${c[k]||"#333333"}"></div><div class="ofsw">${(OWPAL[k]||[]).map(x=>`<button type="button" data-oksw="${k}" data-v="${x}" class="${String(c[k]||"").toLowerCase()===x?"on":""}" style="background:${x}"></button>`).join("")}</div></div>`;
const pl=(k,l,arr,cur)=>`<div class="ofrw"><div class="oflb">${l}</div><input type="hidden" data-ok="${k}" value="${cur}"><div class="ofpl">${arr.map((n,i)=>`<button type="button" data-okp="${k}" data-v="${i}" class="${+cur===i?"on":""}">${esc(n)}</button>`).join("")}</div></div>`;
return`<div class="owf2"><div class="ofstg"><canvas id="owcv" width="160" height="170"></canvas><button type="button" data-ow="L">◀</button><button type="button" data-ow="R">▶</button></div>
<div class="ofsec"><div class="ofrw"><div class="oflb">店名</div><input type="text" data-ok="shop" maxlength="14" placeholder="シーシャ屋さん" value="${esc(c.shop||"")}"></div>
<div class="ofrw"><div class="oflb">名前</div><input type="text" data-ok="name" maxlength="8" placeholder="店長" value="${esc(c.name||"")}"></div>
<div class="ofrw"><div class="oflb">年齢</div><input type="number" data-ok="age" min="18" max="80" value="${c.age}"></div>
${pl("sex","性別",["男性","女性"],c.sex==="女性"?1:0)}</div>
<div class="ofsec"><div class="ofrw">${owSel("hs","髪型",HSN,c)}</div><div class="ofrw">${owSel("top","服の種類",TOPN,c)}</div><div class="ofrw">${owSel("bot","ズボンの種類",BOTN,c)}</div></div>
<div class="ofsec">${sw("hair","髪の色")}${sw("skin","肌の色")}${sw("shirt","服の色")}${sw("pants","ズボンの色")}${pl("eye","目",EYN,c.eye||0)}${pl("acc","装飾品",ACCN,c.acc||0)}${sw("accC","装飾品の色")}</div></div>`};
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-oksw],[data-okp]");if(!b||!R.od)return;const box=b.closest(".ofrw");if(!box)return;
const k=b.dataset.oksw||b.dataset.okp,inp=box.querySelector(`[data-ok="${k}"]`);if(!inp)return;inp.value=b.dataset.v;inp.dispatchEvent(new Event("input",{bubbles:true}));box.querySelectorAll("button").forEach(x=>x.classList.toggle("on",x===b))});
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
