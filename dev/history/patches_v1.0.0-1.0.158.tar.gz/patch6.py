import sys,json,re
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=None):
    global s
    c=s.count(old)
    assert c>=1 and (n is None or c==n),(c,old[:90])
    s=s.replace(old,new)
# ===== 図鑑番号：レア順（1→5、レア未定は最後）。中の番号（c.i）は変えず、表示だけ =====
rep('String(c.i+1).padStart(3,"0")','dxNo(c)')
rep('String(x.i+1).padStart(3,"0")','dxNo(x)',1)
rep('log("✎ No."+(t.i+1)+" を更新しました")','log("✎ No."+dxNo(t)+" を更新しました")',1)
rep('$("#dg").innerHTML=A.map(c=>{const L=lv(c)','$("#dg").innerHTML=A.slice().sort((a,b)=>dxN(a)-dxN(b)).map(c=>{const L=lv(c)',1)
rep('const lv=c=>c.met?','var DXC=null;function dxN(c){const k=G.cs.map(x=>x.rar||0).join("");if(!DXC||DXC.k!==k){const o=G.cs.map(x=>x.i).sort((a,b)=>{const ra=G.cs[a].rar||9,rb=G.cs[b].rar||9;return a>=151||b>=151?a-b:(ra-rb)||(a-b)});DXC={k,m:{}};o.forEach((i,n)=>{DXC.m[i]=n+1})}return DXC.m[c.i]||c.i+1}\nfunction dxNo(c){return String(dxN(c)).padStart(3,"0")}\nconst lv=c=>c.met?',1)
# ===== 34人の帰りのセリフ：いったん「ありがとうございました」 =====
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1]);n=0
for e in arr:
    if e['slot']!=83 and (e.get('job') in ('人外','芸能人','シーシャ屋') or e.get('gobi') or e.get('vx')) and not (e.get('bye') or '').strip():
        e['bye']='ありがとうございました';n+=1
print('bye',n)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
rep('if(!G.shop12){','if(!G.bye1){G.cs.forEach(c=>{if(c.i!==83&&spx(c)&&!(c.bye&&String(c.bye).trim()))c.bye="ありがとうございました"});G.bye1=1}\nif(!G.shop12){',1)
open(f,'w').write(s);print('ok')
