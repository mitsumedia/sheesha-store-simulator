import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('"name":"K-Sick"','"name":"K-SicK"')
rep('/* K-Sick：','/* K-SicK：')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 名前の修正：K-Sick → K-SicK（今のセーブにも反映） ===== */
function nmFix(){try{(G.cs||[]).forEach(c=>{if(c.name==="K-Sick")c.name="K-SicK";if(c.nick==="K-Sick")c.nick="K-SicK"})}catch(e){}}
nmFix();setTimeout(nmFix,1500);{const _sc9=sched;sched=function(){nmFix();return _sc9.apply(this,arguments)}}{const _rd9=rdex;rdex=function(){nmFix();return _rd9.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
