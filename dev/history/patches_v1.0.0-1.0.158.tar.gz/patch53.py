import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('G.wall=G.wall||[];{const ok=new Set(WS.map(w=>w.k));G.wall=G.wall.filter(d=>{if([d.k,d.k2,d.k3,d.k4].filter(Boolean).every(q=>ok.has(q)))return true;const x=WP.find(q=>q.id===d.id);if(x){',
'''G.wall=G.wall||[];{const ok=new Set(WS.map(w=>w.k)),KS=d=>["k","k2","k3","k4"].filter(f=>d[f]),fit=d=>KS(d).every(f=>ok.has(d[f])),used=new Set();G.wall.forEach(d=>{if(fit(d))KS(d).forEach(f=>used.add(d[f]))});
const DV={1:[0,-1],2:[-1,0],3:[0,1],4:[1,0]},mv=(k,n)=>{const p=k.split(","),sd=+p[2],v=DV[sd];if(!v)return null;p[0]=String(+p[0]+v[0]*n);p[1]=String(+p[1]+v[1]*n);return p.join(",")};
G.wall=G.wall.filter(d=>{if(fit(d))return true;
/* 貼る壁がなくなった壁アイテムは持ち物へ（数を数えて、あとでお知らせ） */
R.wbk=(R.wbk||0)+1;
const x=WP.find(q=>q.id===d.id);if(x){''')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* 壁アイテムが持ち物に戻ったら、はっきりお知らせ */
{const _b=build;build=function(){R.wbk=0;const r=_b.apply(this,arguments);if(R.wbk){const n=R.wbk;R.wbk=0;try{save()}catch(e){}setTimeout(()=>{try{toast("📦 貼る壁がなくなった壁アイテム "+n+"個を持ち物に戻しました（☰ → 装飾 → 📦 持ち物 → 🖼 壁アイテム）",6000)}catch(e){}},300)}return r}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL)
open(f,'w').write(s)
