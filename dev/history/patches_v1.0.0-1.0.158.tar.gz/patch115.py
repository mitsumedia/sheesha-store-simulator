import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 掃除ミニゲームを難しく：1回なぞって落ちる量 34→12
rep('dirtSet(key,v-34)','dirtSet(key,v-12)')
rep('if(v-34<25)','if(v-12<25)')
rep('if(key===last&&n-lastT<160)return','if(key===last&&n-lastT<220)return')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 掃除ミニゲーム中は営業開始を押せない ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>body:has(#clov) #go,body:has(#ov:not([hidden]) .clc) #go{pointer-events:none!important;opacity:.45!important}</style>`)}catch(e){}
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest("#go")&&($("#clov")||(!$("#ov").hidden&&document.querySelector("#ov .clc")))){e.stopImmediatePropagation();e.preventDefault()}},true);
/* ===== 閉店後のバトル・フェス告知：今日のまとめを閉じてから出す。終わるまで次の日の行動は出さない ===== */
function d8Hide(){const p=$("#evp");if(p&&$("#dlok")&&!$("#ov").hidden){p.style.display="none";R.evHid=1}}
{const _ep=evPop;evPop=function(){const r=_ep.apply(this,arguments);try{d8Hide()}catch(e){}return r}}
{const _sd=showDayLog;showDayLog=function(){const r=_sd.apply(this,arguments);try{d8Hide()}catch(e){}return r}}
document.addEventListener("click",e=>{if(!(e.target.closest&&e.target.closest("#dlok")))return;const p=$("#evp");if(R.evHid&&p){e.stopImmediatePropagation();R.evHid=0;R.d8Def=1;ovOff();p.style.display=""}else R.evHid=0},true);
{const _d8=day8;day8=function(cb,fo){return _d8.call(this,function(){try{cb&&cb()}finally{if(R.d8Def){R.d8Def=0;if(!(G.last&&!G.last.seen))setTimeout(()=>showMorning(),50)}}},fo)}}
{const _sm5=showMorning;showMorning=function(){const p=$("#evp");if(R.evHid&&(!p||$("#ov").hidden)){R.evHid=0;if(p)p.style.display=""}if(R.d8Def||R.evHid)return;return _sm5.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
