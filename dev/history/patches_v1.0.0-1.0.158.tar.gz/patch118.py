import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 朝の行動画面：iPhoneで下のボタンが隠れないように。中身はスクロール、ボタンは下に固定 ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>html body #ov .card.mnc{max-height:calc(100dvh - 20px)!important;overflow-y:auto!important;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;display:block}
html body #ov .mnc .mb{position:sticky;bottom:0;background:#f3f1ea;z-index:2;padding-bottom:max(12px,env(safe-area-inset-bottom));box-shadow:0 -6px 12px -6px rgba(0,0,0,.12)}
html body #ov .mnc .mg button{min-height:0!important;padding:8px 11px!important}
html body #ov .mnc .mg button .e{font-size:18px}</style>`)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
