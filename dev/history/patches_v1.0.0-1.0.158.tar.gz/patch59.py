import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== チェキのエフェクト・スタンプ（解禁制） ===== */
try{document.head.insertAdjacentHTML("beforeend",'<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">')}catch(e){}
const CKFONT='"Dela Gothic One","Hiragino Sans",sans-serif';
function ckFx(k,pts,cols,n,sz,sh,seed,zr){let r=seed||7;const rn=()=>(r=(r*9301+49297)%233280)/233280;zr=zr||[2,15];for(let i=0;i<n;i++){const p=pts[i%pts.length],dx=(rn()-.5)*14,dz=zr[0]+rn()*(zr[1]-zr[0]),dy=(rn()-.5)*3,rot=rn()*6,ci=i%cols.length,wx=p[0]+dx,rs=.7+rn()*.6;
if(dz>6&&dz<12.8&&pts.some(q=>Math.abs(wx-q[0])<2.9))continue;
const o=P3(wx,p[1]+dy,dz,k),w=k.s*sz*rs;cx.save();cx.translate(o[0],o[1]);cx.fillStyle=cols[ci];cx.strokeStyle=cols[ci];
if(sh==="star"||sh==="maple"){cx.rotate(rot*.2);cx.beginPath();for(let j=0;j<10;j++){const rr=j%2?w*(sh==="maple"?.5:.42):w,t=j*Math.PI/5;cx.lineTo(Math.sin(t)*rr,-Math.cos(t)*rr)}cx.fill();if(sh==="maple"){cx.fillRect(-w*.06,0,w*.12,w*1.1)}}
else if(sh==="heart"){cx.rotate((rot-3)*.08);cx.beginPath();cx.moveTo(0,w*.9);cx.bezierCurveTo(-w*1.5,-w*.1,-w*.7,-w*1.2,0,-w*.35);cx.bezierCurveTo(w*.7,-w*1.2,w*1.5,-w*.1,0,w*.9);cx.fill()}
else if(sh==="note"){cx.rotate((rot-3)*.08);cx.font="bold "+Math.round(w*2.4)+"px sans-serif";cx.textAlign="center";cx.lineWidth=w*.35;cx.strokeStyle="#fff";const t=i%3?"♪":"♫";cx.strokeText(t,0,0);cx.fillText(t,0,0)}
else if(sh==="money"){cx.rotate(rot);if(i%3===0){cx.fillStyle="#f2c230";cx.beginPath();cx.arc(0,0,w*.7,0,7);cx.fill();cx.fillStyle="#d79a12";cx.beginPath();cx.arc(0,0,w*.42,0,7);cx.fill()}else{cx.fillRect(-w*1.2,-w*.55,w*2.4,w*1.1);cx.fillStyle="rgba(255,255,255,.55)";cx.fillRect(-w*.35,-w*.3,w*.7,w*.6)}}
else if(sh==="bubble"){cx.fillStyle="rgba(190,230,255,.25)";cx.beginPath();cx.arc(0,0,w,0,7);cx.fill();cx.lineWidth=w*.12;cx.strokeStyle="rgba(140,200,255,.85)";cx.stroke();cx.fillStyle="rgba(255,255,255,.9)";cx.beginPath();cx.ellipse(-w*.35,-w*.4,w*.25,w*.15,-.6,0,7);cx.fill()}
else if(sh==="smoke"){cx.globalAlpha=.42;[[0,0,1],[w*.8,-w*.3,.75],[-w*.75,-w*.2,.7],[w*.2,-w*.75,.7]].forEach(([x,y,q])=>{cx.beginPath();cx.arc(x,y,w*q,0,7);cx.fill()})}
else if(sh==="ring"){cx.rotate((rot-3)*.1);cx.lineWidth=w*.42;cx.strokeStyle="rgba(255,255,255,.8)";cx.beginPath();cx.ellipse(0,0,w*1.2,w*.55,0,0,7);cx.stroke();cx.lineWidth=w*.2;cx.strokeStyle=cols[ci];cx.stroke()}
else if(sh==="petal"){cx.rotate(rot);cx.beginPath();cx.ellipse(0,0,w*.75,w*.42,0,0,7);cx.fill();cx.fillStyle="rgba(255,255,255,.5)";cx.beginPath();cx.ellipse(-w*.2,0,w*.3,w*.15,0,0,7);cx.fill()}
else if(sh==="snow"){cx.globalAlpha=.95;cx.beginPath();cx.arc(0,0,w*.45,0,7);cx.fill();if(i%4===0){cx.lineWidth=w*.12;for(let j=0;j<3;j++){cx.rotate(Math.PI/3);cx.beginPath();cx.moveTo(-w*.9,0);cx.lineTo(w*.9,0);cx.stroke()}}}
else if(sh==="leaf"){cx.rotate(rot);cx.beginPath();cx.ellipse(0,0,w*.9,w*.42,0,0,7);cx.fill();cx.strokeStyle="rgba(255,255,255,.55)";cx.lineWidth=w*.1;cx.beginPath();cx.moveTo(-w*.8,0);cx.lineTo(w*.8,0);cx.stroke()}
else if(sh==="paw"){cx.rotate((rot-3)*.15);cx.beginPath();cx.ellipse(0,w*.2,w*.55,w*.45,0,0,7);cx.fill();[[-w*.6,-w*.4],[-w*.2,-w*.75],[w*.2,-w*.75],[w*.6,-w*.4]].forEach(([x,y])=>{cx.beginPath();cx.arc(x,y,w*.22,0,7);cx.fill()})}
else if(sh==="gem"){cx.rotate((rot-3)*.1);cx.beginPath();cx.moveTo(-w*.8,-w*.3);cx.lineTo(-w*.4,-w*.75);cx.lineTo(w*.4,-w*.75);cx.lineTo(w*.8,-w*.3);cx.lineTo(0,w*.85);cx.closePath();cx.fill();cx.fillStyle="rgba(255,255,255,.6)";cx.beginPath();cx.moveTo(-w*.4,-w*.75);cx.lineTo(0,-w*.3);cx.lineTo(w*.4,-w*.75);cx.closePath();cx.fill()}
else if(sh==="dot"){cx.beginPath();cx.arc(0,0,w*.3,0,7);cx.fill();if(i%5===0){cx.globalAlpha=.6;cx.fillRect(-w*.9,-w*.06,w*1.8,w*.12);cx.fillRect(-w*.06,-w*.9,w*.12,w*1.8)}}
else{cx.rotate(rot);cx.fillRect(-w*.7,-w*.3,w*1.4,w*.6)}cx.restore()}}
const ckMid=h=>[(h[0][0]+h[1][0])/2,(h[0][1]+h[1][1])/2];
function ckFire(k,h){const m=ckMid(h);let r=3;const rn=()=>(r=(r*9301+49297)%233280)/233280;for(let i=0;i<26;i++){const x=m[0]+(rn()-.5)*16,o=P3(x,m[1]+1+rn()*2,0,k),hh=k.s*(1.6+rn()*2.4),w=hh*.45;[["#ff6a1a",1],["#ffc23a",.6],["#fff2b0",.3]].forEach(([c,q])=>{cx.fillStyle=c;cx.beginPath();cx.moveTo(o[0],o[1]-hh*q*1.2);cx.quadraticCurveTo(o[0]+w*q,o[1]-hh*q*.2,o[0],o[1]);cx.quadraticCurveTo(o[0]-w*q,o[1]-hh*q*.2,o[0],o[1]-hh*q*1.2);cx.fill()})}}
function ckBolt(k,h){const m=ckMid(h);[[-6.5,15,1],[6.8,14,-1]].forEach(([dx,z0,f])=>{const pts=[[0,0],[1*f,-2.5],[-.2*f,-3],[1.3*f,-6]].map(([x,z])=>P3(m[0]+dx+x,m[1],z0+z,k));cx.lineJoin="round";[["#fff",k.s*1.3],["#ffd83a",k.s*.7]].forEach(([c,lw])=>{cx.strokeStyle=c;cx.lineWidth=lw;cx.beginPath();pts.forEach((p,i)=>i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]));cx.stroke()})})}
function ckRainbow(k,h){const m=ckMid(h),o=P3(m[0],m[1],8,k);["#ff5a5a","#ff9f3a","#ffe14a","#6fd36a","#4ab4ff","#9b6bff"].forEach((c,i)=>{cx.strokeStyle=c;cx.globalAlpha=.75;cx.lineWidth=k.s*.55;cx.beginPath();cx.arc(o[0],o[1],k.s*(9.5-i*.55),Math.PI*1.08,Math.PI*1.92);cx.stroke()});cx.globalAlpha=1}
function ckShoot2(k,h){const m=ckMid(h);[[-6.5,13.8,1.1],[7,14.3,.9],[7.3,8.5,.8],[-7,7,.7]].forEach(([dx,z,q])=>{const o=P3(m[0]+dx,m[1],z,k),w=k.s*q,g=cx.createLinearGradient(o[0],o[1],o[0]-w*7,o[1]-w*3.5);g.addColorStop(0,"rgba(255,240,150,.9)");g.addColorStop(1,"rgba(255,240,150,0)");cx.strokeStyle=g;cx.lineWidth=w*.7;cx.lineCap="round";cx.beginPath();cx.moveTo(o[0],o[1]);cx.lineTo(o[0]-w*7,o[1]-w*3.5);cx.stroke();cx.fillStyle="#ffe14a";cx.beginPath();for(let j=0;j<10;j++){const rr=j%2?w*.45:w*1.1,t=j*Math.PI/5;cx.lineTo(o[0]+Math.sin(t)*rr,o[1]-Math.cos(t)*rr)}cx.fill()})}
function ckHanabi(k,h){const m=ckMid(h);[[-6.8,13,"#ff5c8a"],[7,13.6,"#ffd84a"],[6.8,7,"#5ac8fa"],[-7,6.5,"#7bd389"]].forEach(([dx,z,c])=>{const o=P3(m[0]+dx,m[1],z,k);for(let j=0;j<16;j++){const t=j*Math.PI/8,r1=k.s*.6,r2=k.s*2.1;cx.strokeStyle=c;cx.lineWidth=k.s*.28;cx.lineCap="round";cx.beginPath();cx.moveTo(o[0]+Math.cos(t)*r1,o[1]+Math.sin(t)*r1);cx.lineTo(o[0]+Math.cos(t)*r2,o[1]+Math.sin(t)*r2);cx.stroke();cx.fillStyle="#fff";cx.beginPath();cx.arc(o[0]+Math.cos(t)*r2,o[1]+Math.sin(t)*r2,k.s*.18,0,7);cx.fill()}})}
function ckNight(k,h){ckFx(k,h,["#fff8c8","#ffffff","#ffe680"],34,.7,"dot",41,[8,15]);const m=ckMid(h),o=P3(m[0]+6.8,m[1],13.5,k),r=k.s*1.5;cx.fillStyle="#ffe680";cx.beginPath();cx.arc(o[0],o[1],r,0,7);cx.fill();cx.globalCompositeOperation="destination-out";cx.beginPath();cx.arc(o[0]+r*.5,o[1]-r*.3,r*.85,0,7);cx.fill();cx.globalCompositeOperation="source-over"}
function ckCrown(k,h){h.forEach(p=>{const o=P3(p[0],p[1]-.5,13.2,k),w=k.s*1.5;cx.fillStyle="#f2c230";cx.strokeStyle="#a8770a";cx.lineWidth=k.s*.15;cx.beginPath();cx.moveTo(o[0]-w,o[1]);cx.lineTo(o[0]-w,o[1]-w*.9);cx.lineTo(o[0]-w*.5,o[1]-w*.4);cx.lineTo(o[0],o[1]-w*1.1);cx.lineTo(o[0]+w*.5,o[1]-w*.4);cx.lineTo(o[0]+w,o[1]-w*.9);cx.lineTo(o[0]+w,o[1]);cx.closePath();cx.fill();cx.stroke();["#e0352b","#4ab4ff","#6fd36a"].forEach((c,i)=>{cx.fillStyle=c;cx.beginPath();cx.arc(o[0]+(i-1)*w*.6,o[1]-w*.25,k.s*.2,0,7);cx.fill()})})}
const SEAS=a=>()=>a.includes(MN[(G.month||0)%12]);
/* [id, 種類(e:エフェクト s:スタンプ), 名前, 解禁, 描画 or [文字,色]] ※idは1.0.28のポーズ解禁を引き継ぐ */
const CKD=[
["bub","e","🫧 シャボン玉",null,(k,h)=>ckFx(k,h,["#bfe6ff"],22,1.1,"bubble",13)],
["smk","e","💨 煙もくもく",null,(k,h)=>ckFx(k,h,["#c9ccd6","#b5b9c6","#dfe1e8"],30,1.4,"smoke",31,[2,15])],
["ring","e","⭕ 煙の輪っか",{t:"チェキを3回撮る",f:()=>(G.ckN||0)>=3},(k,h)=>ckFx(k,h,["#b5b9c6","#c9ccd6"],18,1.1,"ring",19,[5,15])],
["csmk","e","🌈 カラフル煙",{t:"フレーバーを15種解禁",f:()=>(G.flu||[]).length>=15},(k,h)=>ckFx(k,h,["#ffb3d1","#b9a6ff","#9fe0ff","#b8f0c0","#ffe0a0"],30,1.4,"smoke",37,[2,15])],
["kira","e","✨ キラキラ",{g:1},(k,h)=>ckFx(k,h,["#ffd84a","#fff3a0","#ffb3e0","#ffffff"],30,.95,"star",11)],
["gtr","e","🎵 音符",{g:1},(k,h)=>ckFx(k,h,["#7b4fd0","#ff5c8a","#2f9be0","#f28a1e"],18,.8,"note",23)],
["bolt","e","⚡ 稲妻",{g:1},ckBolt],
["rbw","e","🌈 虹",{g:1},ckRainbow],
["sstar","e","🌠 流れ星",{g:1},ckShoot2],
["skr","e","🌸 桜",{t:"3〜4月に営業する",f:SEAS([3,4])},(k,h)=>ckFx(k,h,["#ffc4d6","#ffaec8","#ffe0ea"],36,.75,"petal",43)],
["hnb","e","🎆 花火",{t:"7〜8月に営業する",f:SEAS([7,8])},ckHanabi],
["mmj","e","🍁 紅葉",{t:"9〜11月に営業する",f:SEAS([9,10,11])},(k,h)=>ckFx(k,h,["#e0452b","#f28a1e","#d9a320"],26,.85,"maple",47)],
["snow","e","❄️ 雪",{t:"12〜2月に営業する",f:SEAS([12,1,2])},(k,h)=>ckFx(k,h,["#ffffff","#eef6ff"],48,.6,"snow",53)],
["cash","e","💸 お金",{t:"所持金1000万円",f:()=>(G.money||0)>=10000000},(k,h)=>ckFx(k,h,["#7fb069","#9fcf86","#5e9447"],40,1,"money",5)],
["heart2","e","💕 ハート",{t:"図鑑100%のお客さん5人",f:()=>G.cs.filter(c=>c.met&&ckPct(c)>=100).length>=5},(k,h)=>ckFx(k,h,["#ff5c8a","#ff9bb8","#ff2e6d"],26,.85,"heart",17)],
["party","e","🎉 紙吹雪",{t:"フェスに出演 か 2号店を開く",f:()=>!!(G.festN||G.s2)},(k,h)=>ckFx(k,h,["#ff5c8a","#ffd84a","#5ac8fa","#7bd389","#b28bff"],46,.6,"rect",29)],
["fire","e","🔥 炎",{t:"1日の売上10万円",f:()=>(G.bestS||0)>=100000},ckFire],
["leaf","e","🍃 葉っぱ",{t:"フレーバーを20種解禁",f:()=>(G.flu||[]).length>=20},(k,h)=>ckFx(k,h,["#5fb85a","#8fd36a","#3f9a4a"],28,.85,"leaf",59)],
["paw","e","🐾 足あと",{t:"人外のお客さんを図鑑に登録",f:()=>G.cs.some(c=>c.met&&c.job==="人外")},(k,h)=>ckFx(k,h,["#6b4a35","#8a6248"],24,1,"paw",61)],
["night","e","🌙 星空",{t:"営業100日",f:()=>(G.day||0)>=100},ckNight],
["gem","e","💎 宝石",{t:"借金を完済",f:()=>!!G.loan&&G.loan.bal<=0&&(G.month||0)>0},(k,h)=>ckFx(k,h,["#5ad0f0","#b48cff","#ff7ab0","#7be0b0"],24,.8,"gem",67)],
["crown","e","👑 王冠",{t:"フォロワー1万人",f:()=>((G.ow||{}).fol||0)>=10000},ckCrown],
["thx","s","ありがとう！",null,["ありがとう！","#ff5c8a"]],
["again","s","また来てね",null,["また来てね","#2f9be0"]],
["open","s","祝開店",null,["祝開店","#e0352b"]],
["chill","s","チル⭐︎",null,["チル⭐︎","#3fb6a8"]],
["moku","s","もくもく〜",{t:"のべ来店数100人",f:()=>(G.tvis||0)>=100},["もくもく〜","#8a8fa3"]],
["nochill","s","チルっていうな💢",{g:1},["チルっていうな💢","#e0352b"]],
["gao","s","がおー！",{g:1},["がおー！","#f28a1e"]],
["win","s","優勝",{g:1},["優勝","#d4a017"]],
["emo","s","エモい",{g:1},["エモい","#9b59d0"]],
["totono","s","ととのった",{g:1},["ととのった","#2f9be0"]],
["kanpai","s","かんぱーい！",{t:"のべ来店数500人",f:()=>(G.tvis||0)>=500},["かんぱーい！","#e0901e"]],
["selfie","s","#映え",{t:"フォロワー3000人",f:()=>((G.ow||{}).fol||0)>=3000},["#映え","#9b59d0"]],
["pray","s","祝1周年",{t:"営業1年",f:()=>(G.month||0)>=12},["祝1周年","#e0352b"]],
["flex","s","最強",{t:"増築3回",f:()=>(G.exN||0)>=3},["最強","#1d1a26"]],
["joren","s","常連さん",{t:"チェキを5回撮る",f:()=>(G.ckN||0)>=5},["常連さん","#6b4a35"]],
["itsumo","s","いつもありがとう",{t:"チェキを10回撮る",f:()=>(G.ckN||0)>=10},["いつもありがとう","#ff5c8a"]],
["zutto","s","ズッ友",{t:"図鑑100%のお客さん1人",f:()=>G.cs.some(c=>c.met&&ckPct(c)>=100)},["ズッ友","#ff2e6d"]],
["umai","s","煙がうまい",{t:"フレーバーを10種解禁",f:()=>(G.flu||[]).length>=20},["煙がうまい","#5e9447"]],
["hanjo","s","大繁盛",{t:"のべ来店数1000人",f:()=>(G.tvis||0)>=1000},["大繁盛","#e0452b"]],
["manin","s","満員御礼",{t:"増築を全部終える",f:()=>(G.exN||0)>=6},["満員御礼","#c0392b"]],
["oku","s","億り人",{t:"所持金1億円",f:()=>(G.money||0)>=100000000},["億り人","#d4a017"]],
["s2","s","祝2号店",{t:"2号店を開く",f:()=>!!G.s2},["祝2号店","#e0352b"]],
["legend","s","伝説",{t:"レジェンドの3人と出会う",f:()=>G.cs.filter(c=>c.met&&c.job==="レジェンド").length>=3},["伝説","#1d1a26"]]];
const ckDOk=d=>!d[3]||(G.ckU||[]).includes(d[0]);
function ckUnlock(id,why){G.ckU=G.ckU||[];if(G.ckU.includes(id))return null;G.ckU.push(id);const d=CKD.find(q=>q[0]===id);if(d){const t=(d[1]==="e"?"エフェクト":"スタンプ")+"「"+d[2]+"」";log("📸 チェキの"+t+"が解禁"+(why?"（"+why+"）":""));if(!why)try{toast("📸 チェキに新しい"+t+"が追加！")}catch(e){}}save();return d}
function ckChk(){if(!G.setup)return;CKD.forEach(d=>{const L=d[3];if(L&&L.f&&!(G.ckU||[]).includes(d[0])){try{if(L.f())ckUnlock(d[0])}catch(e){}}})}
function ckDBtns(t){const cur=t==="e"?R.ckEf:R.ckSt;return`<button class="xr ${cur?"":"on"}" data-dk="${t}:">なし</button>`+CKD.filter(d=>d[1]===t).map(d=>ckDOk(d)?`<button class="xr ${cur===d[0]?"on":""}" data-dk="${t}:${d[0]}"${t==="s"?` style="font-family:${CKFONT.replace(/"/g,"'")}"`:""}>${esc(d[2])}</button>`:`<button class="xr" data-dkl="${d[0]}" style="opacity:.45">🔒 ${d[1]==="e"?esc(d[2].split(" ")[0]):"？？？"}</button>`).join("")}
function ckStamp(cv,redo){const d=CKD.find(q=>q[0]===R.ckSt&&q[1]==="s");if(!d||!ckDOk(d))return;const[t,col]=d[4],g=cv.getContext("2d"),W2=cv.width,H2=cv.height;let fs=Math.round(W2*.13);const F=()=>fs+"px "+CKFONT;
try{const ff='48px "Dela Gothic One"';if(document.fonts&&!document.fonts.check(ff,t)&&!ckStamp._w){ckStamp._w=1;document.fonts.load(ff,t).then(()=>{ckStamp._w=0;if(document.fonts.check(ff,t)&&cv.isConnected&&redo)redo()}).catch(()=>{ckStamp._w=0})}}catch(e){}
g.save();g.font=F();while(g.measureText(t).width>W2*.82&&fs>20){fs-=2;g.font=F()}g.translate(W2/2,H2*.87);g.rotate(-.07);g.textAlign="center";g.textBaseline="middle";g.lineJoin="round";
g.lineWidth=fs*.34;g.strokeStyle="rgba(0,0,0,.25)";g.strokeText(t,3,4);g.lineWidth=fs*.3;g.strokeStyle="#fff";g.strokeText(t,0,0);g.fillStyle=col;g.fillText(t,0,0);g.restore()}
{const _cd=chekiDraw;chekiDraw=function(cv,c,pi){const r=_cd.apply(this,arguments);try{ckStamp(cv,()=>chekiDraw(cv,c,pi))}catch(e){}return r}}
{const _h59=hud;hud=function(){_h59();try{ckChk()}catch(e){}}}
'''
rep('if(pose.smoke){const T0=.75','try{const fd=CKD.find(q=>q[0]===R.ckEf&&q[1]==="e");if(fd&&ckDOk(fd))fd[4](k,sp2?sp2.map(q=>[q.px+2,q.Y0+2,q.f]):[[X0+2,Y0+2,1],[X0+gap+2,Y0+2,1]])}catch(e){console.log(e)}if(pose.smoke){const T0=.75')
rep('G.ckD=G.day;save();','G.ckD=G.day;G.ckN=(G.ckN||0)+1;save();')
rep('<div class="xs">場所</div>','<div class="xs">エフェクト</div><div class="ckps" id="ckde">${ckDBtns("e")}</div><div class="xs">スタンプ</div><div class="ckps" id="ckds">${ckDBtns("s")}</div><div class="xs" style="font-size:11px">🔒はタップで解禁条件が見られます</div><div class="xs">場所</div>')
rep('const z=e.target.closest("[data-pz]");if(z){pi=+z.dataset.pz;','''const dl=e.target.closest("[data-dkl]");if(dl){const q=CKD.find(x=>x[0]===dl.dataset.dkl);toast("🔒 "+(q[3].g?"ガチャで出る":q[3].t+"で解禁"));return}const dk=e.target.closest("[data-dk]");if(dk){const[t,id]=dk.dataset.dk.split(":");if(t==="e")R.ckEf=id;else R.ckSt=id;$(t==="e"?"#ckde":"#ckds").innerHTML=ckDBtns(t);chekiDraw(cv,c,pi);return}const z=e.target.closest("[data-pz]");if(z){pi=+z.dataset.pz;''')
rep('const GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25]];','const GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25],["deco",8]];')
rep('function gachaOk(k){','function gachaOk(k){if(k==="deco")return CKD.some(d=>d[3]&&d[3].g&&!ckDOk(d));')
rep('function gachaGive(k){const o=G.ow;','function gachaGive(k){const o=G.ow;if(k==="deco"){const L=CKD.filter(d=>d[3]&&d[3].g&&!ckDOk(d)),d=L[Math.random()*L.length|0];ckUnlock(d[0],"ガチャ");return["📸","チェキの"+(d[1]==="e"?"エフェクト":"スタンプ"),"「"+d[2]+"」がチェキで使えるようになった！"]}')
rep('📱 フォロワー+100</div>','📱 フォロワー+100／📸 チェキの限定エフェクト・スタンプ（3種）</div>')
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
