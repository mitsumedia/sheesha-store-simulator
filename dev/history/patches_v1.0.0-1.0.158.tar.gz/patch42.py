import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
B64=open('minashu.b64').read().strip()
# プレゼント限定の壁アイテムはショップに出さない・買えない・解禁通知を出さない
rep('$("#wl").innerHTML=WP.map(wpIt).join("")','$("#wl").innerHTML=WP.filter(x=>!(x.u&&x.u[0]==="gift")).map(wpIt).join("")')
rep('if(k==="year")return(G.month||0)>=n*12;return true}','if(k==="year")return(G.month||0)>=n*12;if(k==="gift")return false;return true}')
rep('.find(q=>q.id===t);if(w)return{t:"w",id:t,n:w.n,p:w.p}','.find(q=>q.id===t);if(w&&!(w.u&&w.u[0]==="gift"))return{t:"w",id:t,n:w.n,p:w.p}')
rep('ok=ivAdd({t:"d",id:x.id})','ok=ivAdd({t:WP.includes(x)?"w":"d",id:x.id})')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== のりよし（No.140）のプレゼントを「水無終の掛け軸」（横長・壁2区画）に ===== */
{const x={id:"wp_minashu",n:"水無終の掛け軸",p:0,t:{asian:3,luxury:1},img:"data:image/png;base64,%s",iw:84,ih:38,w2:1,u:["gift",0]};if(!WP.some(q=>q.id===x.id))WP.push(x);const c=G.cs.find(q=>q.sp==="noriyoshi");GIFT[c?c.i:139]=x}
''' % B64
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
