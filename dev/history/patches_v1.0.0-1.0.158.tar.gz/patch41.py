import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('const WX=48,WY=36,W=Math.min(600,window.innerWidth||420),CH=','const WX=48,WY=36;let W=Math.min(600,window.innerWidth||420),CH=')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 画面サイズに合わせてキャンバスの解像度を合わせる（PCで横に伸びる・スマホで比率がずれるのを防ぐ） ===== */
function fitCv(){try{const r=cv.getBoundingClientRect(),w=Math.round(r.width),h=Math.round(r.height);if(w<80||h<80)return;
const d=Math.max(1,Math.min(2,window.devicePixelRatio||1,Math.sqrt(2600000/(w*h))));if(w===W&&h===CH&&Math.abs(d-dpr)<.01&&cv.width===Math.round(w*d))return;
W=w;CH=h;dpr=d;cv.width=Math.round(W*dpr);cv.height=Math.round(CH*dpr);cv.style.aspectRatio=W+" / "+CH;if(typeof BGK!=="undefined")BGK="";R.camVer++}catch(e){}}
{let t=0;const go=()=>{clearTimeout(t);t=setTimeout(fitCv,80)};window.addEventListener("resize",go);window.addEventListener("orientationchange",go);if(window.ResizeObserver)new ResizeObserver(go).observe(cv);[0,300,1300].forEach(ms=>setTimeout(fitCv,ms))}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
