import sys
f=sys.argv[1];s=open(f).read()
a='log("お金が足りません")';c=s.count(a);assert c==8,c
s=s.replace(a,'(log("お金が足りません"),toast("💸 お金が足りません"))')
open(f,'w').write(s)
