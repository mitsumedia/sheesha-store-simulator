import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 本当に帰る時も、戻ってくる時と同じ道で外へ出て同じだけ止まる → 止まった後に、そのまま去るか戻るか
rep('if(u.ph==="w"){u.ph="b";p.path=[[-8,15],[UKI,15]];return false}',
    'if(u.ph==="w"){if(u.lv){p.uk=null;p.path=[[-8,UKO-16]];log("🚪 "+nm(p.c)+" は本当に帰った（戻ってきた回数 "+u.n+"回）");return false}u.ph="b";p.path=[[-8,15],[UKI,15]];return false}')
rep('if(u.ph==="r"){if(u.n>=2&&(u.n>=UKMAX||Math.random()<.5)){p.uk=null;p.path=[[-6,15]];log("🚪 "+nm(p.c)+" は本当に帰った（戻ってきた回数 "+u.n+"回）")}else{u.ph="o";p.path=[[2,15],[-8,15],[-8,UKO]]}return false}',
    'if(u.ph==="r"){u.lv=u.n>=2&&(u.n>=UKMAX||Math.random()<.5);u.ph="o";p.path=[[2,15],[-8,15],[-8,UKO]];return false}')
open(f,'w').write(s);print('ok')
