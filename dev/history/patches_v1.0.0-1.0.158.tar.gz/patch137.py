import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 話しかける相手の判定：タップした場所に体（足〜頭）が重なっている人の中で、一番手前の人を選ぶ
rep('let best=null,bd2=1e9;R.people.concat([OW]).forEach(p=>{const q=P(p.x,p.y,7),d=Math.hypot(q[0]-X,q[1]-Y);if(d<bd2){bd2=d;best=p}});',
 'let best=null,bd2=1e9;const hw=Math.max(14,k.s*1.9),cand=[];R.people.concat([OW]).forEach(p=>{if(!(p.x>-100))return;const sit=p.seat&&(p.st==="sit"||p.st==="drink"),f=P(p.x,p.y,0),h=P(p.x,p.y,sit?9.5:11.5),lo=Math.min(f[1],h[1]),hi=Math.max(f[1],h[1]),ty=Math.max(lo,Math.min(hi,Y)),tx=f[0]+(h[0]-f[0])*((ty-f[1])/((h[1]-f[1])||1)),d=Math.hypot(X-tx,Y-ty);if(d<hw)cand.push([f[1],p]);const q=P(p.x,p.y,7),d2=Math.hypot(q[0]-X,q[1]-Y);if(d2<bd2){bd2=d2;best=p}});if(cand.length){cand.sort((a,b)=>b[0]-a[0]);best=cand[0][1];bd2=0}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 図鑑：前に選んだお客さんの黄色い枠が残らないように（メニューでは紫の選択表示だけにする） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>#sheet #dg .dxt.on .dxi{outline:none!important}</style>`)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
