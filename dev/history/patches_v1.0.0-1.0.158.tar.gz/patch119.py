import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 1) ボタン列の位置計算は1秒に1回まで（毎回レイアウトを測り直さない）
rep('try{const a=$("#atm").getBoundingClientRect(),c=$(".cvw").getBoundingClientRect();if(a.height)r.style.top=Math.round(a.bottom-c.top+6)+"px"}catch(_){}',
    'try{const _n=performance.now();if(!r.style.top||_n-(window._xrT||0)>1000){window._xrT=_n;const a=$("#atm").getBoundingClientRect(),c=$(".cvw").getBoundingClientRect();if(a.height){const t=Math.round(a.bottom-c.top+6)+"px";if(r.style.top!==t)r.style.top=t}}}catch(_){}')
# 2) 重い端末だけ自動で軽量モード（30fps・解像度1.5倍）
rep('draw();{const _n=performance.now();if(_n-(window._hudT||0)>=90)','liteDraw(now);{const _n=performance.now();if(_n-(window._hudT||0)>=90)')
rep('const d=Math.max(1,Math.min(2,window.devicePixelRatio||1,Math.sqrt(2600000/(w*h))));','const d=Math.max(1,Math.min(R.lite?1.5:2,window.devicePixelRatio||1,Math.sqrt(2600000/(w*h))));')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 自動の軽量モード：描き直しが重い端末だけ、30fps＋解像度1.5倍にする ===== */
const LITE={t0:performance.now(),fi:16,dw:5,lastD:0,lastF:0,bad:0};
function liteDraw(now){const L=LITE;if(L.lastF){const fi=now-L.lastF;if(fi<100&&document.visibilityState==="visible")L.fi+=(fi-L.fi)*.05}L.lastF=now;
if(R.lite&&now-L.lastD<30)return;L.lastD=now;const a=performance.now();draw();const d=performance.now()-a;L.dw+=(d-L.dw)*.05;
if(!R.lite&&now-L.t0>6000){const st=Math.min(100,now-(L.lastC||now));L.lastC=now;if(L.dw>12||L.fi>24)L.bad+=st;else L.bad=Math.max(0,L.bad-st*2);if(L.bad>3000){R.lite=1;try{fitCv()}catch(e){}}}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
