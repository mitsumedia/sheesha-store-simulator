import sys
f=sys.argv[1];s=open(f).read()
a='<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover">'
assert s.startswith(a),s[:120]
s='<!doctype html><html lang="ja"><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">'+s[len(a):]
open(f,'w').write(s)
