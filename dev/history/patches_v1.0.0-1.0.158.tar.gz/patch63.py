import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 確定申告のお知らせ：文字色を濃くしてはっきり見えるように
rep('<div style="margin:8px 0 2px;padding:8px;border-radius:8px;background:#fff6e5;font-size:12px;line-height:1.6"><b>🧾 確定申告のお知らせ</b>',
    '<div class="taxn" style="margin:8px 0 2px;padding:10px;border-radius:8px;background:#fff3d6;border:2px solid #f0b23a;color:#3b2a12;font-size:13px;line-height:1.7"><b style="font-size:14px;color:#b5520e">🧾 確定申告のお知らせ</b>')
rep(';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";','try{document.head.insertAdjacentHTML("beforeend","<style>.taxn,.taxn *{color:#3b2a12!important;opacity:1!important}.taxn>b:first-child{color:#b5520e!important}</style>")}catch(e){}\n;(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";')
open(f,'w').write(s)
