import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 最初の1ヶ月（7日目まで）は速度ボタンの上に「タップで倍速」 ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>#spdtip{position:absolute;bottom:calc(100% + 6px);right:0;background:#6658a6;color:#fff;font-size:11px;font-weight:900;white-space:nowrap;padding:3px 9px;border-radius:10px;pointer-events:none;z-index:8}#spdtip:after{content:"";position:absolute;top:100%;right:20px;border:5px solid transparent;border-top-color:#6658a6}</style>`)}catch(e){}
{let _st=0;const _hs=hud;hud=function(){const r=_hs.apply(this,arguments);try{const n=Date.now();if(n-_st>500){_st=n;const sp=document.querySelector("#bar .spd");if(sp){sp.style.position="relative";let t=document.getElementById("spdtip");const on=G.setup&&!G.over&&R.phase==="run"&&(G.day||1)<=7&&!document.body.classList.contains("mvmode");if(on&&!t){t=document.createElement("div");t.id="spdtip";t.textContent="タップで倍速";sp.appendChild(t)}else if(!on&&t)t.remove()}}}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
