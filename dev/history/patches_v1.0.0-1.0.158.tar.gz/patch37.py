import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 増築などで貼る壁がなくなった壁アイテムは、売却ではなく持ち物へ
rep('if(x){G.money+=x.p;log("🖼 "+x.n+" は貼る壁がなくなったので外しました（+¥"+x.p.toLocaleString()+"）")}','if(x){(G.inv=G.inv||[]).push({t:"w",id:d.id});log("🖼 "+x.n+" は貼る壁がなくなったので持ち物に戻しました")}')
# 模様替え：全部しまう
rep('動かしたい家具・置物（<b style="color:#3a8ee6">青く光っているもの</b>）や壁アイテムをタップしてください</div></div>`','動かしたい家具・置物（<b style="color:#3a8ee6">青く光っているもの</b>）や壁アイテムをタップしてください</div><button id="mvall" style="margin-top:6px;width:100%">${R.mvAll&&R.mvAll>Date.now()?"⚠️ もう一度タップで全部しまう":(G.seatU?"📦 全部持ち物に戻す":"📦 置物と壁アイテムを全部しまう")}</button></div>`')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 模様替え：全部しまう ===== */
document.addEventListener("click",e=>{const b=e.target.closest("#mvall");if(!b)return;e.stopPropagation();
if(!(R.mvAll&&R.mvAll>Date.now())){R.mvAll=Date.now()+4000;mvBar();setTimeout(()=>{if(R.mvAll&&R.mvAll<=Date.now()){R.mvAll=0;try{mvBar()}catch(_){}}},4100);return}
R.mvAll=0;const pre=mvSnap(),keepS=!G.seatU;G.inv=G.inv||[];let n=0;if(!keepS)(G.furn||[]).forEach(F=>{G.inv.push({t:"f",k:F.k,sr:F.sr});n++});(G.decor||[]).forEach(d=>{G.inv.push({t:"d",id:d.id});n++});(G.wall||[]).forEach(d=>{G.inv.push({t:"w",id:d.id});n++});
if(!keepS)G.furn=[];G.decor=[];G.wall=[];R.mvs=null;log(keepS?"📦 置物・壁アイテム "+n+"個を持ち物に戻しました（客席は解禁前なのでそのまま）":"📦 客席・置物・壁アイテム "+n+"個を全部持ち物に戻しました（客席を置かないと営業できません）");mvDone();mvPushU(pre);mvBar()},true);
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
