import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 画面上部のプレイ日数を「○年○日目」に（1年＝12か月×7日＝84日）
rep("""プレイ'+(G.day||1)+'日目</small>'""","""プレイ'+ydLbl()+'</small>'""")
rep("d.textContent.replace(/\\s*プレイ\\d+日目$/,\"\")","d.textContent.replace(/\\s*プレイ(\\d+年)?\\d+日目$/,\"\")")
rep('/* ===== 画面上部にプレイ日数 ===== */','/* ===== 画面上部にプレイ日数 ===== */\nconst ydLbl=()=>{const n=Math.max(1,G.day||1),y=Math.floor((n-1)/84),d=(n-1)%84+1;return(y?y+"年":"")+d+"日目"};')
open(f,'w').write(s)
