import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 雲紅亭：画面の外まで出て見えなくなってから、戻るか決める（外で立ち止まらない）
rep('const UKO=-14,','const UKO=-46,')
rep('u.ph="w";u.w=1.1;','u.ph="w";u.w=.5;')
# ひめのセリフ・帰りのセリフ・好きなフレーバー
HL=["このロット、良すぎ……！？","シェフを呼んでくださいまし♡","高火力気持ちよすぎですわ〜","作ってもらうシーシャが1番うまい","自律神経が整う音がしますわ！","ここ、シーシャ屋ですわよ？","水が無くなったら、終わりですの？","あら！もうこんな時間！","ご無理のない範囲でお願い致しますわ！","言葉だけ横転致しますわー！"]
HI={"ls":HL,"bye":"最高でしたわ！ごきげんよう！","fl":0}
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot']==147:e.update(HI)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
CODE='''
/* ===== ひめのセリフ（遊んでいるデータにも反映） ===== */
{const HI=%s;if(!G.hime2){const c=G.cs[147];if(c&&c.name==="ひめ"&&!c.ed)Object.assign(c,HI);G.hime2=1;try{save()}catch(e){}}}
/* ===== 来なくなったお客さんは、ゲーム内で3か月（21日）たつと戻ってくる ===== */
function quitBack(){(G.cs||[]).forEach(c=>{if(!c.quit||spx(c))return;if(c.quitD==null){c.quitD=G.day||0;return}if((G.day||0)-c.quitD>=21){c.quit=0;c.quitD=null;c.up=Math.min(c.up||0,20);c.ret=1;c.retMsg=1;log("😌 "+nm(c)+" が、またお店に来てくれそうです")}})}
{const _st=start;start=function(){try{quitBack()}catch(e){}return _st.apply(this,arguments)}}
{const _ar=arrive;arrive=function(m){const r=_ar.apply(this,arguments);try{(m||[]).forEach(c=>{if(c&&c.retMsg){c.retMsg=0;const p=R.people.find(q=>q.c===c&&!q.gone);if(p)setTimeout(()=>{try{say(p,"お久しぶりです…また来ちゃいました")}catch(e){}},1500)}})}catch(e){}return r}}
''' % json.dumps(HI,ensure_ascii=False)
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
