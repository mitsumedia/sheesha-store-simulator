import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ---- 店長の装飾品：目元・頭・口元を1つずつ重ねて付けられる ----
rep('eye:OW.c.eye||0,acc:OW.c.acc||0,accC:OW.c.accC||"#333333"}}',
    'eye:OW.c.eye||0,acc:OW.c.acc||0,accC:OW.c.accC||"#333333",...owAccD()}}')
rep('${pl("eye","目",EYN)}${pl("acc","装飾品",ACCN)}${sw("accC","装飾品の色")}',
    '${pl("eye","目",EYN)}${pa("accE","目元",ACC_E)}${d.accE?sw("accCE","目元の色"):""}${pa("accH","頭",ACC_H)}${d.accH?sw("accCH","頭の色"):""}${pa("accM","口元",ACC_M)}${d.accM?sw("accCM","口元の色"):""}${+d.accH===8?`<div class="owr" style="font-size:11px;color:#8a8a8a">フルフェイスヘルメットの時は目元を付けられません</div>`:""}')
rep('const pl=(k,l,arr)=>`','const pa=(k,l,ids)=>`<div class="owr"><div class="owl">${l}</div><div class="owpl">${ids.map(i=>`<button data-owp="${k}" data-v="${i}" class="${+d[k]===i?"on":""}" ${k==="accE"&&+d.accH===8&&i?"disabled style=\\"opacity:.35\\"":""}>${esc(i?ACCN[i]:"なし")}</button>`).join("")}</div></div>`;\nconst pl=(k,l,arr)=>`')
rep('const L=Object.assign({},OW.c,{hair:OWD.hair,skin:OWD.skin,shirt:OWD.shirt,pants:OWD.pants,eye:OWD.eye,acc:OWD.acc,accC:OWD.accC});',
    'const L=Object.assign({},OW.c,{hair:OWD.hair,skin:OWD.skin,shirt:OWD.shirt,pants:OWD.pants,eye:OWD.eye},owAccLook(OWD));')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
const ACC_E=[0,1,7,10],ACC_H=[0,2,3,5,9,8],ACC_M=[0,4,6];
function owAccInit(o){if(!o||o.accE!==undefined)return;const a=+o.acc||0,c=o.accC||"#333333";o.accE=ACC_E.includes(a)?a:0;o.accH=ACC_H.includes(a)?a:0;o.accM=ACC_M.includes(a)?a:0;o.accCE=o.accCH=o.accCM=c}
/* 描くためのデータ：目元（メガネ）は上から線で重ねるので acc に、頭・口元はブロックで描くので accV に */
function owAccLook(o){const e=+o.accH===8?0:(+o.accE||0),V=[[+o.accH||0,o.accCH||"#333333"],[+o.accM||0,o.accCM||"#333333"]].filter(v=>v[0]);return{acc:e,accC:o.accCE||"#333333",accV:V.length?V:null}}
function owAccD(){const o=G.ow||{};owAccInit(o);return{accE:+o.accE||0,accH:+o.accH||0,accM:+o.accM||0,accCE:o.accCE||"#333333",accCH:o.accCH||"#333333",accCM:o.accCM||"#333333"}}
function owAccSync(){const o=G.ow;if(!o)return;owAccInit(o);const L=owAccLook(o);Object.assign(o,{acc:L.acc,accC:L.accC});o.accV=L.accV;if(typeof OW!=="undefined"&&OW.c){Object.assign(OW.c,L);OW._pc=null}}
try{["accCE","accCH","accCM"].forEach(k=>{OWPAL[k]=OWPAL.accC})}catch(e){}
/* ブロックの装飾品を2つ重ねる：1つ目で描いて、2つ目は「付けた時に増える／消える（帽子で隠れる髪など）」ブロックだけ足し引きする */
{const _pv2=pv;pv=function(a,ox,Y0,f,c){if(!c||!c.accV||!c.accV.length)return _pv2.apply(this,arguments);const rest=[].slice.call(arguments,5),V=c.accV,K=v=>v[0]+","+v[1]+","+v[2]+","+(v[5]||1);
 const base=[],r=_pv2.call(this,base,ox,Y0,f,Object.assign({},c,{acc:V[0][0],accC:V[0][1],accV:null}),...rest);let out=base;
 for(const[ac,col]of V.slice(1)){const A=[],B=[];_pv2.call(this,A,ox,Y0,f,Object.assign({},c,{acc:ac,accC:col,accV:null}),...rest);_pv2.call(this,B,ox,Y0,f,Object.assign({},c,{acc:0,accV:null}),...rest);
  const kb=new Map(B.map(v=>[K(v),v[3]])),ka=new Map(A.map(v=>[K(v),v[3]]));const rm=new Set(B.filter(v=>ka.get(K(v))!==v[3]).map(K)),add=A.filter(v=>kb.get(K(v))!==v[3]);out=out.filter(v=>!rm.has(K(v))).concat(add)}
 out.forEach(v=>a.push(v));return r}}
{const _al=applyOwLook;applyOwLook=function(){const r=_al.apply(this,arguments);try{owAccSync()}catch(e){}return r}}
{const _es=owEdSave;owEdSave=function(){let ex=null;if(OWD){if(+OWD.accH===8)OWD.accE=0;ex={accE:+OWD.accE||0,accH:+OWD.accH||0,accM:+OWD.accM||0,accCE:OWD.accCE,accCH:OWD.accCH,accCM:OWD.accCM};const L=owAccLook(OWD);OWD.acc=L.acc;OWD.accC=L.accC}
 const r=_es.apply(this,arguments);if(ex&&G.ow){Object.assign(G.ow,ex);owAccSync();save();OWD=null;try{owEdRender();owEdStage()}catch(e){}}return r}}
try{owAccSync()}catch(e){}setTimeout(()=>{try{owAccSync()}catch(e){}},1200);
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
