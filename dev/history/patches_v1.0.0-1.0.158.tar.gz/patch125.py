import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 管理画面：「プレイ1年16日目」が「プレイ16日目」になっていたのを修正
rep('monFix=t=>{const m=String(t||"").match(/(\\d+)日目$/);return m?ydOf(+m[1]):String(t||"")}',
    'monFix=t=>{const m=String(t||"").match(/(?:(\\d+)年)?(\\d+)日目$/);return m?ydOf((+(m[1]||0))*84+(+m[2])):String(t||"")}')
open(f,'w').write(s)
