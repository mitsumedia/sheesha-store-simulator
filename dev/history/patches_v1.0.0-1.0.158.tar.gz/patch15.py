import sys
f=sys.argv[1];s=open(f).read()
ADD=r'''
/* ===== ↶ 模様替えの「元に戻す」 ===== */
R.mvU=[];
function mvSnap(){return JSON.stringify({f:G.furn,d:G.decor,w:G.wall||[],i:G.inv||[]})}
function mvPushU(pre){if(pre!==mvSnap()){R.mvU.push(pre);if(R.mvU.length>30)R.mvU.shift();mvBar()}}
{const _t=mvTap;mvTap=function(X,Y,k){const pre=mvSnap();_t(X,Y,k);mvPushU(pre)}}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-mv]");if(!b)return;const pre=mvSnap();setTimeout(()=>mvPushU(pre),0)},true);
function mvUndo(){const pre=R.mvU.pop();if(!pre)return;const o=JSON.parse(pre);G.furn=o.f;G.decor=o.d;G.wall=o.w;G.inv=o.i;R.mvs=null;R.mvT=null;mvDone();mvBar();log("↶ 1つ前に戻しました")}
{const _b=mvBar;mvBar=function(){_b();const b=$("#mvbar");if(!b)return;const tc=b.querySelector(".tc");if(!tc)return;const n=R.mvU.length;const d=document.createElement("div");d.className="row";d.style.marginTop="6px";d.innerHTML=`<button data-mvu="1" ${n?"":"disabled"}>↶ 元に戻す${n?"（"+n+"）":""}</button>`;tc.appendChild(d)}}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-mvu]");if(!b)return;e.stopPropagation();mvUndo()});
{const _mt=mvToggle;mvToggle=function(on){const was=R.mvOn;_mt(on);if(was&&!R.mvOn)R.mvU=[]}}
'''
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T);open(f,'w').write(s);print('ok')
