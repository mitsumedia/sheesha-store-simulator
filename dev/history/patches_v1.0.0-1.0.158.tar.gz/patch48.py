import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('if(pre!==mvSnap()){R.mvU.push(pre);','if(pre!==mvSnap()){R.mvU.push(pre);R.mvR=[];')
rep('function mvUndo(){const pre=R.mvU.pop();if(!pre)return;','function mvUndo(){const pre=R.mvU.pop();if(!pre)return;(R.mvR=R.mvR||[]).push(mvSnap());')
rep('d.innerHTML=`<button data-mvu="1" ${n?"":"disabled"}>↶ 元に戻す${n?"（"+n+"）":""}</button>`','const nr=(R.mvR||[]).length;d.style.gap="6px";d.innerHTML=`<button data-mvu="1" style="flex:1" ${n?"":"disabled"}>↶ 元に戻す${n?"（"+n+"）":""}</button><button data-mvu="r" style="flex:1" ${nr?"":"disabled"}>↷ やり直す${nr?"（"+nr+"）":""}</button>`')
rep('e.stopPropagation();mvUndo()})','e.stopPropagation();if(b.dataset.mvu==="r")mvRedo();else mvUndo()})')
rep('if(was&&!R.mvOn)R.mvU=[]','if(was&&!R.mvOn){R.mvU=[];R.mvR=[]}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== ↷ 模様替えの「やり直す」 ===== */
function mvRedo(){const nx=(R.mvR||[]).pop();if(!nx)return;R.mvU.push(mvSnap());const o=JSON.parse(nx);G.furn=o.f;G.decor=o.d;G.wall=o.w;G.inv=o.i;R.mvs=null;R.mvT=null;mvDone();mvBar();log("↷ やり直しました")}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
