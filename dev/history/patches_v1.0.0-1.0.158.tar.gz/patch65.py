import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# テスト期間中はチェキのX投稿ボタンを隠す（CKX=true で復活）
a=s[s.index('<button data-fin="xp"'):s.index('<button data-fin="sh"')]
rep(a,'${CKX?`'+a+'`:""}')
rep('function chekiDraw(','const CKX=false;\nfunction chekiDraw(')
open(f,'w').write(s)
