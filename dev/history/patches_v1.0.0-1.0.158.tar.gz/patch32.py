import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 急用から戻るとき：入口から入って定位置（入口横）まで歩いて戻る
rep('if(R.away!=null&&R.t>=R.away){R.away=null;owReset();say(OW,"ただいま！お待たせしました");log("🏃 店に戻った")}',
    'if(R.away!=null&&R.t>=R.away){R.away=null;owReset();OW.x=-4;OW.y=15;OW.dir=1;OW.mode="back";OW.path=[[3,15],[3,8]];say(OW,"ただいま！お待たせしました");log("🏃 店に戻った")}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* 店主の定位置は入口横（0,1）に固定。古いセーブでそこに置物があれば持ち物へ */
owHomeXY=function(){return[3,8]};
try{let mv=0;G.decor=(G.decor||[]).filter(d=>{if((d.tx===0&&(d.ty===1||d.ty===2))){try{ivAdd({t:"d",id:d.id});mv++}catch(e){}return false}return true});if(mv){build();log("📦 店主の定位置にあった置物を持ち物にしまいました（"+mv+"個）")}}catch(e){}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
