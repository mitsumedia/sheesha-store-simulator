import sys,json,base64,io
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 1) 白發中を描き直し（256×144）
img="data:image/png;base64,"+base64.b64encode(open('/home/claude/w/mj_px.png','rb').read()).decode()
i=s.find('{"id": "wp_mj"');j=s.find('}',s.find('"u"',i))+1
d=json.loads(s[i:j]);d['img']=img;d['iw']=64;d['ih']=36
s=s[:i]+json.dumps(d,ensure_ascii=False)+s[j:]
# 2) 客席の色を3シリーズ追加
rep('{id:"bg",n:"ブラック×ゴールド",m:2,u:4,','''{id:"lv",n:"ラベンダー",m:1.3,u:2,fr:"#9b86c9",cu:"#c3b3e6",bk:"#7f6bb0",arm:"rd",back:"round",leg:"#f2f2f2",tb:"#ffffff",tl:"#e0d8f0",cbd:"#7f6bb0",ctop:"#f4f0fb",ctrim:"#e0d8f0",cst:"round",csl:"#f2f2f2",csp:"#ffffff",css:"#c3b3e6"},
{id:"tc",n:"テラコッタ",m:1.4,u:3,fr:"#b5562e",cu:"#d6744a",bk:"#93421f",arm:"sq",back:"low",leg:"#3a2a1e",tb:"#e8d6b8",tl:"#3a2a1e",cbd:"#93421f",ctop:"#e8d6b8",ctrim:"#3a2a1e",cst:"back",csl:"#3a2a1e",css:"#b5562e"},
{id:"ns",n:"ネイビー×シルバー",m:1.8,u:4,fr:"#1c2a4a",cu:"#2c3e66",bk:"#152038",arm:"sq",back:"tuft",leg:"#c0c6cf",pip:"#c0c6cf",tb:"#22314f",tl:"#c0c6cf",cbd:"#152038",ctop:"#c0c6cf",ctrim:"#c0c6cf",cst:"back",csl:"#c0c6cf",css:"#2c3e66"},
{id:"bg",n:"ブラック×ゴールド",m:2,u:4,''')
# 3) 柱を5種類（置物）
P=json.load(open('/home/claude/w/gift/gpil.json'))
i=s.find('const DEC=');j=s.find('];',i);arr=json.loads(s[i+10:j+1])
gi=next(n for n,x in enumerate(arr) if x['u'][0]=='gift')
new=[{"id":k,"n":v[0],"p":v[3],"t":v[2],"u":v[4]} for k,v in P.items()]
arr=arr[:gi]+new+arr[gi:]
s=s[:i+10]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))+s[j+1:]
rep('const DMD={','const DMD={'+",".join('%s:%s'%(k,json.dumps(v[1])) for k,v in P.items())+',')
open(f,'w').write(s);print('ok')
