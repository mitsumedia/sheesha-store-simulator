import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 店主の見た目キャッシュに2色目を入れる
rep('+"|"+(OW.c.h2|0)+(OW.c.t2|0)+(OW.c.b2|0);if(!OW._pc','+"|"+(OW.c.h2|0)+(OW.c.t2|0)+(OW.c.b2|0)+(OW.c.hc2||"");if(!OW._pc')
# 色・名前タブに「髪の2色目」（ツートンの髪型の時だけ）
rep('${sw("hair","髪の色")}','${sw("hair","髪の色")}${HC2.includes(OW.c.h2|0)?sw("hc2","髪の2色目"):""}',2)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 髪型：編み込み→七三分け、新しい髪型11種（ツートン6種は2色目を選べる） ===== */
OWH[6][0]="七三分け";
OWH.push(["寝ぐせヘア"],["アシメ"],["角刈り"],["外ハネボブ"],["爆発ヘア"],["メッシュ"],["インナーカラー"],["裾カラー"],["左右ツートン"],["前髪カラー"],["グラデーション"]);
const HC2=[16,17,18,19,20,21];
Object.assign(OWC,{h11:["営業100日",()=>(G.day||0)>=100],h12:["ガチャ"],h13:["図鑑50人",()=>G.cs.filter(c=>c.met).length>=50],h14:["ガチャ"],h15:["のべ来店1,000人",()=>(G.tvis||0)>=1000],
 h16:["ガチャ"],h17:["フォロワー5,000人",()=>((G.ow||{}).fol||0)>=5000],h18:["ガチャ"],h19:["バトルで2回優勝",()=>(G.batW||0)>=2],h20:["ガチャ"],h21:["チェキを30回撮る",()=>(G.ckN||0)>=30]});
OWG.push("h12","h14","h16","h18","h20");
OWPAL.hc2=["#ff5c8a","#ffd84a","#5ac8fa","#7bd389","#b28bff","#ff9f43","#ffffff","#c9c9c9","#e0c068","#2f6fd6","#b03a3a","#161616"];
{const _ox=OWXD;OWXD=function(c,o){const h=c.h2|0;if(h!==7&&h<11)return _ox.apply(this,arguments);
 const c2=Object.assign({},c,{h2:0});try{_ox.call(this,c2,o)}catch(e){}
 const{H,hr,sk,top,back,sides,bangs}=o,dk=dkHex(hr,.72),lt=dkHex(hr,1.3),P=c.hc2||"#ff5c8a";
 const mx=t=>{const a=parseInt(String(hr).slice(1),16),b=parseInt(String(P).slice(1),16),f=s=>Math.round(((a>>s)&255)*(1-t)+((b>>s)&255)*t);return"#"+((1<<24)+(f(16)<<16)+(f(8)<<8)+f(0)).toString(16).slice(1)};
 if(h===7){top();back(0,6);sides(2,4);H(0,5,6,2,1,1,hr);H(2,5,5,6,1,2,hr);H(7,5,4,1,1,1,hr);H(3,0,8,5,6,1,hr);H(4,2,9,3,2,1,lt);H(2,0,7,1,6,1,dkHex(sk,.85))}
 else if(h===11){top();back(0,6);sides(3,3);H(0,5,5,8,1,2,hr);H(1,5,4,1,1,1,hr);H(5,5,4,1,1,1,hr);H(4,2,8,1,1,2,hr);H(5,2,9,1,1,2,hr);H(6,2,10,1,1,1,hr);H(-1,2,5,1,1,1,hr);H(-2,2,6,1,1,1,hr);H(8,3,6,1,1,1,hr);H(9,3,7,1,1,1,hr);H(2,0,8,1,1,1,hr);H(1,-1,8,1,1,1,hr)}
 else if(h===12){top();back(0,6);sides(2,4);H(-1,1,0,1,5,6,hr);H(0,5,2,4,1,5,hr);H(1,5,1,2,1,1,hr);H(4,5,5,4,1,2,hr);H(0,5,7,8,1,1,hr);H(2,5,3,1,1,1,dk)}
 else if(h===13){top();back(0,6);sides(3,3);H(0,0,7,8,6,2,hr);H(0,0,9,8,6,1,lt);H(0,5,5,8,1,2,hr);H(-1,1,4,1,4,3,dk);H(8,1,4,1,4,3,dk)}
 else if(h===14){top();H(-1,0,1,1,6,6,hr);H(8,0,1,1,6,6,hr);H(0,-1,1,8,1,6,hr);H(-2,0,1,1,6,1,hr);H(9,0,1,1,6,1,hr);H(0,-2,1,8,1,1,hr);H(-2,-1,1,1,1,1,hr);H(9,-1,1,1,1,1,hr);bangs();H(-1,0,2,1,6,1,lt);H(8,0,2,1,6,1,lt)}
 else if(h===15){top();back(0,6);sides(3,3);H(0,5,5,8,1,2,hr);for(const[x,y,z]of[[-2,1,6],[-3,3,4],[9,1,6],[10,3,4],[0,-2,6],[6,-2,6],[3,-3,4],[-2,-1,8],[8,-1,8],[0,1,9],[3,0,10],[6,2,9],[2,3,10],[4,3,9],[-2,4,7],[8,4,7],[3,-2,8]])H(x,y,z,2,2,2,(x+y+z)%3?hr:lt)}
 else if(h===16){top();back(0,6);sides(2,4);bangs();H(2,0,7,1,6,1,P);H(2,5,3,1,1,4,P);H(1,5,3,1,1,1,P)}
 else if(h===17){top();H(-1,0,-1,1,6,8,P);H(8,0,-1,1,6,8,P);H(0,-1,-1,8,1,8,P);H(-2,0,2,1,6,5,hr);H(9,0,2,1,6,5,hr);H(0,-2,2,8,1,5,hr);H(-2,-1,2,1,1,5,hr);H(9,-1,2,1,1,5,hr);bangs()}
 else if(h===18){top();for(let z=-6;z<7;z++){const col=z<-2?P:hr;H(-1,0,z,1,6,1,col);H(8,0,z,1,6,1,col);H(0,-1,z,8,1,1,col)}bangs()}
 else if(h===19){top();H(4,0,7,4,6,1,P);H(-1,0,2,1,6,5,hr);H(8,0,2,1,6,5,P);H(0,-1,2,4,1,5,hr);H(4,-1,2,4,1,5,P);H(0,5,5,4,1,2,hr);H(4,5,5,4,1,2,P);H(0,5,4,1,1,1,hr);H(7,5,4,1,1,1,P)}
 else if(h===20){top();back(0,6);sides(2,4);H(0,5,5,8,1,2,P);for(let x=0;x<8;x+=2)H(x,5,4,1,1,1,P)}
 else if(h===21){top();for(let z=-6;z<7;z++){const col=mx(Math.min(1,Math.max(0,(4-z)/9)));H(-1,0,z,1,6,1,col);H(8,0,z,1,6,1,col);H(0,-1,z,8,1,1,col)}bangs()}}}
/* 2色目の保存・反映 */
{const _al3=owAccLook;owAccLook=function(o){const L=_al3.apply(this,arguments);if(o&&o.hc2)L.hc2=o.hc2;return L}}
{const _ad3=owAccD;owAccD=function(){const r=_ad3.apply(this,arguments);r.hc2=(G.ow||{}).hc2||"#ff5c8a";return r}}
{const _es3=owEdSave;owEdSave=function(){const v=OWD&&OWD.hc2;const r=_es3.apply(this,arguments);if(v&&G.ow&&G.ow.hc2!==v){G.ow.hc2=v;OW.c.hc2=v;OW._pc=null;save()}return r}}
{const _ap3=applyOwLook;applyOwLook=function(){const r=_ap3.apply(this,arguments);if(G.ow)OW.c.hc2=G.ow.hc2||"#ff5c8a";return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
