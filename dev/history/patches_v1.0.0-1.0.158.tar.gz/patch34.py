import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('<details class="cd" id="d-frc">','<details class="cd" id="d-grf"><summary>📈 売上グラフ<small id="s-grf"></small></summary><div class="card" id="grf"><div class="dcat" style="margin-bottom:6px"><button data-gm="d" class="on">日別</button><button data-gm="m">月別</button></div><canvas id="grfc" style="width:100%;height:190px;display:block"></canvas><div id="grfs" class="m" style="font-size:12px;margin-top:6px;line-height:1.6"></div></div></details>\n<details class="cd" id="d-frc">')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 売上グラフ ===== */
function histInit(){if(!G.hist)G.hist={d:[],m:[]};if(!G.hist.d.length&&G.week&&G.week.length)G.week.forEach((e,i)=>G.hist.d.push({m:G.month,wd:i,s:e.sales||0,v:e.visits||0,c:e.closed?1:0}))}
histInit();
{const _dd=dayDone;dayDone=function(en){try{if(!G.at2&&en){histInit();G.hist.d.push({m:G.month,wd:G.wd,s:en.sales||0,v:en.visits||0,c:en.closed?1:0});if(G.hist.d.length>84)G.hist.d.splice(0,G.hist.d.length-84)}}catch(e){}return _dd.apply(this,arguments)}}
{const _st=settle;settle=function(){const r=_st.apply(this,arguments);try{const L=G.last;if(L&&!L._h&&L.month===G.month&&L.after!=null){histInit();const x=L.s2||{};const cost=(L.rent||0)+(L.util||0)+(L.flv||0)+(L.dc||0)+(L.coal||0)+(L.brk?L.brk.cost:0);
G.hist.m.push({m:G.month,s:(L.est||0)+((x.sales||0)+(x.auto||0)),c:cost,p:(L.after||0)-(L.before||0),mo:L.after,v:L.vis||0});if(G.hist.m.length>36)G.hist.m.splice(0,G.hist.m.length-36);L._h=1;save()}}catch(e){}if(typeof grfDraw==="function")grfDraw();return r}}
let GRM="d";
function grfDraw(){const cv=document.getElementById("grfc");if(!cv||!cv.offsetWidth)return;histInit();const W2=cv.offsetWidth,H2=190,dp=window.devicePixelRatio||1;cv.width=W2*dp;cv.height=H2*dp;const g=cv.getContext("2d");g.setTransform(dp,0,0,dp,0,0);g.clearRect(0,0,W2,H2);
const yen2=v=>(v<0?"-":"")+(Math.abs(v)>=10000?(Math.abs(v)/10000).toFixed(Math.abs(v)>=1e6?0:1).replace(/\.0$/,"")+"万":Math.round(Math.abs(v)).toLocaleString());
const L=GRM==="d"?G.hist.d.slice(-28):G.hist.m.slice(-12),sm=document.getElementById("grfs");
g.font="11px sans-serif";g.fillStyle="#998fae";
if(!L.length){g.textAlign="left";g.fillText(GRM==="d"?"営業するとここに日ごとの売上が出ます":"月末の精算をするとここに月ごとの売上が出ます",8,H2/2);if(sm)sm.innerHTML="";return}
const pl=44,pr=6,pt=10,pb=22,cw=W2-pl-pr,ch=H2-pt-pb;
const vals=GRM==="d"?L.map(e=>e.s):L.map(e=>e.s),pv=GRM==="m"?L.map(e=>e.p):[],mx=Math.max(1,...vals,...pv),mn=Math.min(0,...pv),rg=mx-mn,Y=v=>pt+ch*(1-(v-mn)/rg);
g.strokeStyle="#ece6f4";g.lineWidth=1;g.textAlign="right";for(let i=0;i<=4;i++){const v=mn+rg*i/4,y=Y(v);g.beginPath();g.moveTo(pl,y);g.lineTo(W2-pr,y);g.stroke();g.fillText(yen2(v),pl-4,y+4)}
if(mn<0){g.strokeStyle="#b9b0c8";g.beginPath();g.moveTo(pl,Y(0));g.lineTo(W2-pr,Y(0));g.stroke()}
const n=L.length,bw=cw/Math.max(n,GRM==="d"?14:6),gap=Math.max(1,bw*.22);
L.forEach((e,i)=>{const x=pl+i*bw+gap/2,w=bw-gap,y=Y(e.s),y0=Y(0);g.fillStyle=GRM==="d"?(e.c?"#cfc8da":(e.wd>=5?"#f0a14a":"#7b4fd0")):"#7b4fd0";g.fillRect(x,Math.min(y,y0),w,Math.max(1,Math.abs(y0-y)));
if(GRM==="d"&&e.wd===0){g.fillStyle="#998fae";g.textAlign="center";g.fillText(MN[e.m%12]+"月",x+w/2,H2-6)}if(GRM==="m"){g.fillStyle="#998fae";g.textAlign="center";g.fillText(MN[e.m%12]+"月",x+w/2,H2-6)}});
if(GRM==="m"){g.strokeStyle="#22a06b";g.lineWidth=2;g.beginPath();L.forEach((e,i)=>{const x=pl+i*bw+bw/2,y=Y(e.p);i?g.lineTo(x,y):g.moveTo(x,y)});g.stroke();L.forEach((e,i)=>{const x=pl+i*bw+bw/2,y=Y(e.p);g.fillStyle=e.p<0?"#e5484d":"#22a06b";g.beginPath();g.arc(x,y,3,0,7);g.fill()})}
if(sm){if(GRM==="d"){const op=L.filter(e=>!e.c),av=op.length?op.reduce((a,e)=>a+e.s,0)/op.length:0,best=op.reduce((b,e)=>e.s>(b?b.s:-1)?e:b,null),wk=op.filter(e=>e.wd>=5),wd=op.filter(e=>e.wd<5),aw=a=>a.length?a.reduce((x,e)=>x+e.s,0)/a.length:0;
sm.innerHTML=`<span style="color:#7b4fd0">■</span>平日　<span style="color:#f0a14a">■</span>週末　<span style="color:#cfc8da">■</span>休業<br>直近${op.length}日の平均 <b>${yen(Math.round(av))}</b>（平日 ${yen(Math.round(aw(wd)))}／週末 ${yen(Math.round(aw(wk)))}）<br>最高 <b>${best?yen(best.s):"—"}</b>（${best?MN[best.m%12]+"月"+WD[best.wd]+"曜":""}）`}
else{const a=L[L.length-1],b=L[L.length-2],dd=b?Math.round((a.s-b.s)/Math.max(1,b.s)*100):null;sm.innerHTML=`<span style="color:#7b4fd0">■</span>月の売上　<span style="color:#22a06b">●</span>月の収支（返済込み）<br>${MN[a.m%12]}月：売上 <b>${yen(Math.round(a.s))}</b>${dd!=null?`（前月比 ${dd>=0?"+":""}${dd}%）`:""}・経費 ${yen(Math.round(a.c))}・収支 <b style="color:${a.p<0?"#e5484d":"#22a06b"}">${a.p>=0?"+":""}${yen(Math.round(a.p))}</b>`}}
const sg=document.getElementById("s-grf");if(sg){const d=G.hist.d.slice(-7).filter(e=>!e.c);sg.textContent=d.length?"　直近7日平均 "+yen(Math.round(d.reduce((a,e)=>a+e.s,0)/d.length)):""}}
document.addEventListener("click",e=>{const b=e.target.closest("[data-gm]");if(!b)return;GRM=b.dataset.gm;document.querySelectorAll("[data-gm]").forEach(x=>x.classList.toggle("on",x===b));grfDraw()});
{const d=document.getElementById("d-grf");if(d)d.addEventListener("toggle",()=>{if(d.open)setTimeout(grfDraw,0)})}
{const _h=hud;let lastN=-1;hud=function(){_h.apply(this,arguments);try{const n=(G.hist?G.hist.d.length+G.hist.m.length*100:0);if(n!==lastN){lastN=n;grfDraw()}}catch(e){}}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
