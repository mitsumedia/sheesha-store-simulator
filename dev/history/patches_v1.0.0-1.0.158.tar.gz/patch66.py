import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
SAN={"hs":0,"hair":"#231c18","shirt":"#323b52","pants":"#26272d","shoe":"#151515","top":0,"bot":0,"sp":"santy"}
ADD=r'''
/* ===== さんてぃ v2：ボサっとした黒髪・細メガネ・デニムジャケット＋赤T ===== */
SPF.santy=({H,Q4,hr})=>{const RD="#c8282b",WT="#f4efe6",BT="#e8e8ea",LP="#262d40",SPK="#55607a";
 /* 赤いTシャツ（前を開けたジャケットの間） */
 for(let z=4;z<7.8;z+=.25)for(let x=1.25;x<2.75;x+=.25)Q4(x,3.04,z,RD);
 /* Tシャツの白い文字（縦書き風） */
 [[1.75,7],[2,7],[2,6.75],[1.75,6.5],[2,6.5],[1.75,6],[2,6],[1.75,5.75],[2,5.5],[1.75,5.25],[2,5],[1.75,4.75]].forEach(([x,z])=>Q4(x,3.06,z,WT));
 /* ジャケットの前立て・ボタン・えり */
 for(let z=4;z<7.6;z+=.25){Q4(1,3.05,z,LP);Q4(2.75,3.05,z,LP)}
 [4.75,5.75,6.75].forEach(z=>{Q4(1,3.08,z,BT);Q4(2.75,3.08,z,BT)});
 for(let z=7.25;z<8;z+=.25){Q4(1.25-(z-7.25)*.33,3.07,z,LP);Q4(2.5+(z-7.25)*.33,3.07,z,LP)}
 /* ボサっとした髪：ボリューム＋前髪をギザギザに */
 H(0,0,6,8,6,1,hr);H(1,2,7,2,3,1,hr);H(4,1,7,3,4,1,hr);H(2,4,7,2,2,1,hr);
 H(-1,1,4,1,6,3,hr);H(8,1,4,1,6,3,hr);H(0,-1,1,8,1,6,hr);
 H(0,7,5,8,1,2,hr);H(0,7,4,2,1,1,hr);H(3,7,4,1,1,1,hr);H(5,7,4,2,1,1,hr);H(-1,6,6,1,2,1,hr);H(8,6,6,1,2,1,hr);H(2,8,6,3,1,1,hr);
 /* 細い長方形のメガネ */
 const G="#3b2f29",s=.125,y=3.03,P=(x,z)=>Q4(x,y,z,G,s),RT=(x0,x1,z0,z1)=>{for(let x=x0;x<=x1+1e-6;x+=s){P(x,z0);P(x,z1)}for(let z=z0;z<=z1+1e-6;z+=s){P(x0,z);P(x1,z)}};
 RT(.375,1.625,9.0,9.625);RT(2.375,3.625,9.0,9.625);for(let x=1.75;x<2.3;x+=s)P(x,9.5);
 for(let yy=1.5;yy<3;yy+=s){Q4(.25,yy,9.5,G,s);Q4(3.625,yy,9.5,G,s)}
};
{const K=%s;if(!G.san2){const c=G.cs[141];if(c&&!c.ed)Object.assign(c,K);G.san2=1;try{save()}catch(e){}}}
''' % json.dumps(SAN,ensure_ascii=False)
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot']==141:e.update(SAN)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
