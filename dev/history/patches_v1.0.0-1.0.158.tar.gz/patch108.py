import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== カメラを回している間は軽く描く（置物の絵は角度を少し刻んで使い回す） ===== */
let LOWC=null,_camS="",_camT=0,CAMMV=0;
function kQ(k){const st=.07,yaw=Math.round(Math.atan2(k.ry,k.rx)/st)*st,pit=Math.round(Math.atan2(k.cz,k.uz)/st)*st,cp=Math.cos(pit),sp=Math.sin(pit),sa=Math.sin(yaw),ca=Math.cos(yaw),s2=k.s;
return Object.assign({},k,{cx:-cp*sa,cy:cp*ca,cz:sp,rx:ca,ry:sa,ux:sa*sp,uy:-ca*sp,uz:cp,exx:s2*ca,exy:-s2*sa*sp,eyx:s2*sa,eyy:s2*ca*sp,ezy:-s2*cp})}
{const _ds=decSprite;decSprite=function(id,s2,k,r){return _ds.call(this,id,s2,CAMMV?kQ(k):k,r)}}
{const _sd=scnDraw;scnDraw=function(k){if(CAMMV)return false;return _sd.apply(this,arguments)}}
{const _dw=draw;draw=function(){const c=R.cam,sg=c.yaw.toFixed(4)+","+c.pit.toFixed(4)+","+c.zoom.toFixed(4)+","+W+","+CH,n=performance.now();if(sg!==_camS){_camS=sg;_camT=n}
CAMMV=!window.LOW_OFF&&n-_camT<200;return _dw.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
