import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# チェキ（店内のソファに座るとき）にもシーシャ台
rep('if(pose.hk&&!sp2){const S=.8;','if(pose.hk&&sp2){sp2.forEach((st,n)=>{const S=.8,hc={x:n?st.px+5.6:st.px-1.9,y:st.f>0?st.Y0+4.2:st.Y0+1.8,rot:st.f>0?0:2,sc:S};HKV[hc.rot].forEach(v=>a.push([v[0]*S+hc.x,v[1]*S+hc.y,v[2]*S+(hc.z||0),v[3],undefined,(v[5]||1)*S]));hosePush(a,{seat:st},hc,n?2:1)})}if(pose.hk&&!sp2){const S=.8;')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* 店主が店の外に取り残されたら、入口から定位置へ戻す（急用のあとなど） */
setInterval(()=>{try{if(R.phase!=="run"||R.away!=null||OW.sitting||R.clA)return;const out=OW.x<0||!FLS.has(Math.floor(OW.x/6)+","+Math.floor(OW.y/6));
if(!out){OW._stk=0;return}if(OW.path&&OW.path.length){OW._stk=(OW._stk||0)+1;if(OW._stk<6)return}
OW._stk=0;const h=owHomeXY();if(OW.x<-1){OW.mode="back";OW.path=[[3,15],[h[0],h[1]]];OW.dir=1}else{OW.mode="";OW.path=[];OW.x=h[0];OW.y=h[1];OW._pc=null}}catch(e){}},2000);
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
