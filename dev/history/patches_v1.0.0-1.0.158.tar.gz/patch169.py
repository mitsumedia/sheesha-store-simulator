import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 傘の色：黒をやめる
rep('mbP(["#1565c0","#e53935","#fafafa","#212121","#fdd835"],Math.random()*9)','mbP(["#1565c0","#e53935","#f5f5f5","#43a047","#fdd835","#8e24aa","#ff7aa8"],Math.random()*9)')
# 傘の形：丸みのある段々のかさ＋骨＋先っぽ
rep('if(m.um){px(1.9,1.4,7,.25,.25,5,"#616161",.25);px(-.6,-1.1,12,5,5,.5,m.um,1)}','if(m.um)umbVox(P,ox,oy,m.um);')
rep('const drawIt=it=>{it.parts.sort((p,q)=>p.d-q.d).forEach(o=>dvb(o.b,k));if(it.vox&&it.vox.length)it.vox.forEach(v=>{try{dv(v,k)}catch(e){}});if(it.spr)it.spr.forEach(q=>{try{q.fn(k)}catch(e){}})};','const drawIt=it=>{it.parts.sort((p,q)=>p.d-q.d).forEach(o=>dvb(o.b,k));if(it.vox&&it.vox.length)it.vox.forEach(v=>{if(v.um)return;try{dv(v,k)}catch(e){}});if(it.spr)it.spr.forEach(q=>{try{q.fn(k)}catch(e){}});if(it.vox)it.vox.forEach(v=>{if(!v.um)return;try{dv(v,k)}catch(e){}})};')
# 窓枠も通行人を隠す
rep('if(!h(-1,0)&&!(tx===0&&ty===2)&&!glassOn())WB.push({x:X-1,y:Y,z:0,w:1,d:6,h:24,t:2});','if(!h(-1,0)&&!(tx===0&&ty===2)){if(!glassOn())WB.push({x:X-1,y:Y,z:0,w:1,d:6,h:24,t:2});else{WB.push({x:X-1,y:Y,z:0,w:1,d:1,h:24,t:2},{x:X-1,y:Y,z:22,w:1,d:6,h:2,t:2},{x:X-1,y:Y,z:0,w:1,d:6,h:1,t:2});if(!FLS.has(tx+","+(ty+1))||(tx===0&&ty+1===2))WB.push({x:X-1,y:Y+5,z:0,w:1,d:1,h:24,t:2})}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(TAIL)==1
CODE=r'''
/* ===== 通行人：性別に合った髪型・服 ===== */
const MB_HSF=[0,1,1,2,3,3,5,5,6,8,11,12,13,15],MB_HSM=[0,0,0,4,7,9,9,10,12,12,14,15,16,17,17];
{const _ml=mbLook;mbLook=function(t,a){const c=_ml.apply(this,arguments);try{const o=MBLK[t.id]||{};c.sex=o.sex||(o.hs?"男性":(Math.random()<.5?"女性":"男性"));const L=c.sex==="女性"?MB_HSF:MB_HSM;if(!o.hs||!o.hs.every(h=>L.includes(h)))c.hs=L[Math.floor(Math.random()*L.length)];c.h2=0;if(c.sex==="男性"&&c.bot===2)c.bot=[0,0,1,3][Math.floor(Math.random()*4)]}catch(e){}return c}}
/* ===== 傘：丸みのある形 ===== */
function umbVox(P,ox,oy,col){const cx0=ox+2,cy0=oy+1.5,dk=dkHex(col,.78),put=(x,y,z,c,s)=>{const v=[x,y,z,c,undefined,s];v.um=1;P.push(v)};
 for(let z=7;z<13.5;z+=.25)put(cx0-.125,cy0-.125,z,"#616161",.25);
 const R=[[13,3],[13.5,2.5],[14,1.75],[14.5,1]];R.forEach(([z,r],li)=>{const rin=li<R.length-1?R[li+1][1]-.5:-1;for(let x=-r;x<r;x+=.5)for(let y=-r;y<r;y+=.5){const d=Math.hypot(x+.25,y+.25);if(d>r||d<rin)continue;const rib=li===0&&(Math.abs(x+.25)<.3||Math.abs(y+.25)<.3);put(cx0+x,cy0+y,z,rib?dk:col,.5)}});
 put(cx0-.125,cy0-.125,15,"#9e9e9e",.25);put(cx0-.125,cy0-.125,15.25,"#9e9e9e",.25)}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
