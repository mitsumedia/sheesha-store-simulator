import sys
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=1):
    global s
    c=s.count(old)
    assert c==n,(c,old[:80])
    s=s.replace(old,new)

# お客様図鑑：4列のタイル。会ったことのある人は顔写真
OLD='''$("#dg").innerHTML=A.map(c=>`<button class="it ${R.sel===c.i?"on":""}" data-c="${c.i}"><span class="sw" style="background:${c.met?c.shirt:"#888"}"></span><span class="m">No.${String(c.i+1).padStart(3,"0")}</span> ${esc(c.met?nm(c):"？？？")}${c.rar?`<span style="color:#d4a017;font-size:11px"> ${"★".repeat(c.rar)}</span>`:""}<small>${c.met?(c.quit?"来なくなった… ":"")+"解禁 "+lv(c)+"/"+NL:(c.act?"まだ会っていない":"未出現")}</small></button>`).join("");'''
NEW='''$("#dg").classList.add("dxg");$("#dg").innerHTML=A.map(c=>{const L=lv(c),mx=L>=NL,no=String(c.i+1).padStart(3,"0"),pc=Math.floor(L/NL*100),tc=mx?"mx":pc<10?"t0":pc<30?"t1":pc<50?"t2":pc<70?"t3":"t4";return`<button class="dxt ${R.sel===c.i?"on":""} ${c.met?"":"lk"} ${mx?"mx":""} ${c.quit?"qt":""} ${c.met?tc:""}" data-c="${c.i}"><span class="dxi"><span class="dxno">${no}</span>${c.rar?`<span class="dxr">${"★".repeat(c.rar)}</span>`:""}${c.met?`<img class="xf" data-fi="${c.i}" ${FACEC[c.i]?`src="${FACEC[c.i]}"`:""} alt="">`:`<b>？</b>`}${c.met?`<span class="dxl">${mx?"100":pc}%</span>`:""}</span><i class="dxp"><u style="width:${c.met?Math.round(L/NL*100):0}%"></u></i><small>${esc(c.met?nm(c):c.act?"まだ会っていない":"未出現")}${c.met&&c.nick&&L>=NL?`<span class="dxs">${esc(c.name)}</span>`:""}</small></button>`}).join("");faceFill($("#dg"));'''
rep(OLD,NEW)
# 顔写真の背景（ベージュ）を透明にして、タイルの色が見えるように
rep('drawFace("#fcache",G.cs[i]);FACEC[i]=cv.toDataURL()','drawFace("#fcache",G.cs[i]);{const g=cv.getContext("2d"),im=g.getImageData(0,0,120,120),a=im.data;for(let q=0;q<a.length;q+=4)if(Math.abs(a[q]-239)<3&&Math.abs(a[q+1]-230)<3&&Math.abs(a[q+2]-218)<3)a[q+3]=0;g.putImageData(im,0,0)}FACEC[i]=cv.toDataURL()')
rep('<b>No.${String(c.i+1).padStart(3,"0")} ${esc(nm(c))}</b>','<b>No.${String(c.i+1).padStart(3,"0")} ${esc(nm(c))}${c.nick&&lv(c)>=NL?`<span style="font-weight:400;font-size:13px">（${esc(c.name)}）</span>`:""}</b>')
# フレーバー・イベントの図鑑はいつもの2列に戻す
rep('function rflv(){','function rflv(){$("#dg").classList.remove("dxg");')
rep('function rev(){','function rev(){$("#dg").classList.remove("dxg");')

CSS=r'''
document.head.insertAdjacentHTML("beforeend",`<style>
#dg.dxg{grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 8px}
#p-dex #dg button.dxt{position:relative;display:flex;flex-direction:column;align-items:center;gap:3px;padding:0;margin:0;border:0;background:none;color:inherit;min-width:0;font:inherit}
#p-dex #dg .dxi{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;width:100%;aspect-ratio:1;border-radius:16px;overflow:hidden;background:linear-gradient(160deg,#4a74c9,#2a4687);box-shadow:inset 0 0 0 3px rgba(255,255,255,.22),inset 0 -6px 0 rgba(0,0,0,.18),0 2px 4px rgba(0,0,0,.25)}
#p-dex #dg .dxi img{width:78%;height:78%;margin-top:2%;object-fit:contain;image-rendering:pixelated}
#p-dex #dg .dxt.lk .dxi{background:linear-gradient(160deg,#3a4256,#262b38);box-shadow:inset 0 0 0 2px rgba(255,255,255,.1),inset 0 -6px 0 rgba(0,0,0,.2)}
#p-dex #dg .dxt.lk .dxi b{font-size:26px;color:rgba(255,255,255,.28);font-weight:900}
#p-dex #dg .dxt.mx .dxi{background:linear-gradient(135deg,#fff6c8 0%,#f0b93a 30%,#b8790f 55%,#f5c74a 75%,#fff0b0 100%);box-shadow:inset 0 0 0 3px rgba(255,255,255,.5),inset 0 -6px 0 rgba(0,0,0,.15),0 2px 6px rgba(224,138,30,.5)}
#p-dex #dg .dxt.mx .dxi::after{content:"";position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.65) 48%,transparent 60%);background-size:250% 100%;animation:dxsh 2.6s linear infinite;pointer-events:none;z-index:1}@keyframes dxsh{0%{background-position:150% 0}100%{background-position:-100% 0}}
#p-dex #dg .dxt.mx .dxl{background:rgba(120,70,0,.45)}
#p-dex #dg .dxt.on .dxi{outline:3px solid #ffb300;outline-offset:2px}
#p-dex #dg .dxt.qt .dxi img{filter:grayscale(1) brightness(.75)}
#p-dex #dg .dxno{position:absolute;left:5px;top:4px;z-index:2;font-size:9px;font-weight:700;color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.6)}
#p-dex #dg .dxr{position:absolute;right:4px;top:3px;z-index:2;font-size:8px;line-height:1;color:#ffd54f;text-shadow:0 1px 1px rgba(0,0,0,.6);letter-spacing:-1px}
#p-dex #dg .dxl{position:absolute;left:0;right:0;bottom:0;height:22%;display:flex;align-items:center;justify-content:center;z-index:2;font-size:12px;font-weight:900;color:#fff;background:rgba(0,0,0,.38);-webkit-text-stroke:3px rgba(0,0,0,.55);paint-order:stroke fill}
#p-dex #dg .dxt.lk .dxi{justify-content:center}
#p-dex #dg .dxt.t0 .dxi{background:linear-gradient(160deg,#4a4550,#1f1c24)}
#p-dex #dg .dxt.t1 .dxi{background:linear-gradient(160deg,#4a74c9,#2a4687)}
#p-dex #dg .dxt.t2 .dxi{background:linear-gradient(160deg,#fff06a,#e8cf1a)}
#p-dex #dg .dxt.t3 .dxi{background:linear-gradient(160deg,#4fb37a,#24734a)}
#p-dex #dg .dxt.t4 .dxi{background:linear-gradient(160deg,#e0574a,#9c2a22)}
#p-dex #dg .dxt.t0 .dxp u{background:#8a8494}#p-dex #dg .dxt.t1 .dxp u{background:#5c9cff}#p-dex #dg .dxt.t2 .dxp u{background:#f2d04a}#p-dex #dg .dxt.t3 .dxp u{background:#4fd18a}#p-dex #dg .dxt.t4 .dxp u{background:#ff6a5a}
#p-dex #dg .dxp{display:block;width:84%;height:5px;border-radius:3px;background:rgba(0,0,0,.35);overflow:hidden}
#p-dex #dg .dxp u{display:block;height:100%;background:#4fd1c5;border-radius:3px}
#p-dex #dg .dxt.mx .dxp u{background:#ffcf5a}
#p-dex #dg .dxt small{display:block;width:100%;font-size:10px;line-height:1.2;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--mut)}
#p-dex #dg .dxt:not(.lk) small{color:inherit}
#p-dex #dg .dxt small .dxs{display:block;font-size:9px;opacity:.7;overflow:hidden;text-overflow:ellipsis}
</style>`);
'''
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
if TAIL in s: rep(TAIL, CSS+TAIL)
else:
    i=s.rfind('</script>'); s=s[:i]+CSS+s[i:]
open(f,'w').write(s)
print('ok')
