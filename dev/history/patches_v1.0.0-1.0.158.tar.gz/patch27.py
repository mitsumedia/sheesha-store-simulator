import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# チェキの文字：はみ出すときは縮める
rep('g.fillText(((G.ow||{}).name||"店長")+" × "+nm(c),PW/2,665)','g.fillText(((G.ow||{}).name||"店長")+" × "+nm(c),PW/2,665,PW-60)')
rep('g.fillText(shop+"　"+ckDate(),PW/2,705)','g.fillText(shop+"　"+ckDate(),PW/2,705,PW-60)')
# iPhoneで中央寄せ（textAlign）が効かずに文字が右にずれる対策：中央・右寄せは自分で幅を測って左寄せで描く
HEAD='''<script>(()=>{try{const P=CanvasRenderingContext2D.prototype;for(const nm of["fillText","strokeText"]){const o=P[nm];P[nm]=function(t,x,y,mw){const a=this.textAlign;if(a!=="center"&&a!=="right"&&a!=="end")return mw===undefined?o.call(this,t,x,y):o.call(this,t,x,y,mw);let w=this.measureText(t).width;if(mw!==undefined&&w>mw)w=mw;this.textAlign="left";try{const X=a==="center"?x-w/2:x-w;return mw===undefined?o.call(this,t,X,y):o.call(this,t,X,y,mw)}finally{this.textAlign=a}}}}catch(e){}})()</script>'''
i=s.find('<script')
s=s[:i]+HEAD+s[i:]
open(f,'w').write(s)
