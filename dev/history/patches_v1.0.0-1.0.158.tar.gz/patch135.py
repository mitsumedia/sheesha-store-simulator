import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 画面サイズが変わってキャンバスを作り直した直後に、すぐ描き直す（一瞬クリーム色になるチラつき対策）
rep('cv.style.aspectRatio=W+" / "+CH;if(typeof BGK!=="undefined")BGK="";R.camVer++}catch(e){}}',
    'cv.style.aspectRatio=W+" / "+CH;if(typeof BGK!=="undefined")BGK="";R.camVer++;try{if(typeof LITE!=="undefined")LITE.lastD=0;draw()}catch(_){}}catch(e){}}')
open(f,'w').write(s)
