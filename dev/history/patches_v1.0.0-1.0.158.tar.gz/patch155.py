import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 出店地域を8種に。すべて路面店（1階）。今の「都内」→都心、「住宅地」→住宅街 ===== */
const AREA=[
 {n:"都心",e:"🏙",b:0,r:1.5,d:1.35,f:1.2,tx:"高層ビルのオフィス街。家賃はとても高い。平日に強く、週末は弱い",wd:[1.1,1.1,1.1,1.1,1.05,.85,.85]},
 {n:"繁華街",e:"🌃",b:0,r:1.4,d:1.3,f:1.15,tx:"ネオンの雑居ビル街。家賃は高い。金・土に強い",wd:[.95,.95,.95,1,1.2,1.2,.9]},
 {n:"駅前",e:"🚉",b:0,r:1.6,d:1.45,f:1.35,rp:.9,tx:"駅と線路の前。家賃はいちばん高い。人通りが多く、一見さんが多い"},
 {n:"商店街",e:"🏮",b:1,r:1,d:1,rp:1.15,tx:"アーケードのある商店街。家賃はふつう。常連が付きやすい"},
 {n:"住宅街",e:"🏡",b:1,r:1,d:1,tx:"一戸建てと公園の街。家賃はふつう。週末に強い",wd:[.95,.95,.95,.95,1,1.15,1.15]},
 {n:"田舎",e:"🌾",b:1,r:.6,d:.7,rp:1.25,tx:"田んぼと山の町。家賃はいちばん安い。お客さんは少ないが、常連になりやすい"},
 {n:"海沿い",e:"🏖",b:1,r:1,d:1,tx:"砂浜の見える海沿いの道。家賃はふつう。夏に強く、冬は弱い",ss:1}];
function areaZ(l){l=l||G.loc||{};if(l.z!=null&&AREA[l.z])return l.z;return l.a===1?4:0}
/* 外の景色を少しはっきり見せる */
function scnA(){return .55}
function areaFix(){if(!G.loc)return;if(G.loc.z==null){G.loc.z=areaZ(G.loc)}G.loc.t=1;G.loc.a=AREA[G.loc.z].b}
const AREAM={get r(){return AREA[areaZ()].r},get f(){return AREA[areaZ()].f||1},get rp(){return AREA[areaZ()].rp||1},
 get d(){const A=AREA[areaZ()];let d=A.d;try{if(A.wd)d*=A.wd[G.wd|0]||1;if(A.ss){const m=MN[(G.month||0)%12];if([7,8].includes(m))d*=1.3;else if(m===6||m===9)d*=1.1;else if([12,1,2].includes(m))d*=.75}}catch(e){}return d}};
LOCM[0][0]=LOCM[0][1]=LOCM[1][0]=LOCM[1][1]=AREAM;
/* 開業・移転の地域えらび */
locFx=function(z){const A=AREA[z]||AREA[0];return`${A.e} ${A.tx}（家賃×${A.r}）`};
locForm=function(){const z=areaZ();return`<div class="row">出店地域 <select id="lz">${AREA.map((A,i)=>`<option value="${i}" ${z===i?"selected":""}>${A.e} ${A.n}</option>`).join("")}</select></div><div class="m" id="locfx" style="font-size:12px;margin:-2px 0 6px">📍 ${locFx(z)}</div>`};
locRead=function(){const z=$("#lz")?+$("#lz").value:areaZ(),v=G.loc&&G.loc.v!==undefined?G.loc.v:Math.random()*NVAR|0;return{a:AREA[z].b,t:1,v,z}};
document.addEventListener("change",e=>{if(e.target.id!=="lz")return;const z=+e.target.value,fx=$("#locfx");if(fx)fx.textContent="📍 "+locFx(z);if(!G.setup||!$("#mvov")){G.loc=locRead();try{build()}catch(_){}}});
/* 景色：地域ごとに向かい側を作りかえる */
{const _gs=genScn;genScn=function(){const l=G.loc;if(l){if(l.z==null)l.z=areaZ(l);l.t=1;l.a=AREA[l.z].b}const r=_gs.apply(this,arguments);try{areaScn(areaZ(l))}catch(e){}return r}}
function areaScn(z){const xs=FLT.map(t=>t[0]),ys=FLT.map(t=>t[1]),L=Math.min(...xs)*6,Rr=(Math.max(...xs)+1)*6,T=Math.min(...ys)*6,B=(Math.max(...ys)+1)*6,Y0=T-70,Y1=B+60,MY=(T+B)/2;
 let sd=17+z*131+((G.loc&&G.loc.v)|0)*7;const rn=()=>{sd=(sd*16807)%2147483647;return sd/2147483647},pick=a=>a[Math.floor(rn()*a.length)];
 const bx=(x,y,z2,w,d,h,c,t,win,ne)=>SCN.push({x,y,z:z2,w,d,h,c,t,win,ne}),gr=(x,y,w,d,c)=>GRD.push({x,y,w,d,c});
 const clr=(sides)=>{for(let i=SCN.length-1;i>=0;i--){const b=SCN[i];if((b.t===2&&b.x<L-34)||(sides&&sides.includes(b.t)))SCN.splice(i,1)}};
 const tree=(x,y,c,t)=>{bx(x,y,0,1,1,4,"#6d4c41",t||2);bx(x-2,y-2,4,5,5,4,c||pick(["#4caf50","#43a047","#66bb6a"]),t||2);bx(x-1,y-1,8,3,3,2,"#81c784",t||2)};
 const arch=(y,c,c2,txt)=>{bx(L-27,y,0,1.2,1.2,12,c,2);bx(L-10.2,y,0,1.2,1.2,12,c,2);bx(L-27.5,y-.2,12,18.4,1.6,2.6,c2,2,0,txt?1:0);bx(L-28,y-.4,14.6,19.4,2,.8,c,2)};
 const road=(c,line)=>{for(let i=GRD.length-1;i>=0;i--){const g=GRD[i];if(g.x>=L-26.5&&g.x<L-10&&g.w<=16.5)GRD.splice(i,1)}gr(L-26,Y0,16,Y1-Y0,c);if(line)for(let y=Y0;y<Y1;y+=8)gr(L-18.5,y,1,4,line)};
 if(z===0){/* 都心：超高層・アンテナ・大型ビジョン */SCN.filter(b=>b.t===2&&b.x<L-34&&b.h>20).forEach((b,i)=>{b.h=Math.round(b.h*1.6);if(i%3===0){bx(b.x+b.w/2-.5,b.y+b.d/2,b.z+b.h,1,1,10,"#b0bec5",2);bx(b.x+b.w/2-.6,b.y+b.d/2-.1,b.z+b.h+10,1.2,1.2,1,"#ff1744",2,0,1)}});
  const t0=SCN.find(b=>b.t===2&&b.x<L-34&&b.y>T-20);if(t0){bx(t0.x+t0.w,t0.y+1,14,.6,Math.min(12,t0.d-2),8,"#263238",2);bx(t0.x+t0.w+.1,t0.y+1.6,14.6,.6,Math.min(10.8,t0.d-3.2),6.8,"#4fc3f7",2,0,1)}
  for(let y=Y0;y<Y1;y+=10)tree(L-31,y+2,"#2e7d32");for(let y=T;y<B;y+=8)gr(L-26,y,16,.3,"#ffffff");GRD.base="#7d8790"}
 else if(z===1){/* 繁華街：ネオンだらけ・アーチ看板・提灯 */SCN.filter(b=>(b.t===2&&b.x<L-34)||b.t===1).forEach(b=>{if(b.h<8)return;b.c=pick(["#3a3346","#43394f","#2f2b3a","#4a3b47"]);const N=()=>pick(["#ff4fa3","#40c4ff","#ffd54f","#69f0ae","#b388ff","#ff7043","#ff1744"]);
   if(b.t===2){for(let k=0;k<3;k++)bx(b.x+b.w,b.y+1+rn()*(b.d-4),3+k*7+rn()*3,.7,2.6,5+rn()*3,N(),2,0,1);bx(b.x+b.w,b.y+.5,2,.8,b.d-1,1.6,N(),2,0,1)}else{bx(b.x+1,b.y+b.d,3+rn()*5,2.4,.7,6,N(),1,0,1)}});
  arch(T+2,"#b71c1c","#ff1744",1);arch(B-6,"#b71c1c","#ffd54f",1);for(let y=Y0;y<Y1;y+=7){bx(L-9.4,y,6,.2,.2,1,"#5d4037",2);bx(L-9.8,y-.3,4.8,1,1,1.4,y%14?"#ff5252":"#ffca28",2,0,1);bx(L-27.6,y,6,.2,.2,1,"#5d4037",2);bx(L-28,y-.3,4.8,1,1,1.4,y%14?"#ffca28":"#ff5252",2,0,1)}
  road("#2b2730","#e040fb");GRD.base="#26222c"}
 else if(z===2){/* 駅前：店の裏に高架の線路（電車が走る）、道の向かいに駅前広場と駅舎 */clr();
  for(let i=SCN.length-1;i>=0;i--){const b=SCN[i];if(b.y+b.d>T-40&&b.y<T-1&&b.t!==2)SCN.splice(i,1)}
  const VY=T-17,VX0=L-160,VX1=Rr+160;for(let x=VX0;x<VX1;x+=14){bx(x,VY+1,0,1.6,6,13,"#b0aaa2",0)}
  for(let x=VX0;x<VX1;x+=14){bx(x,VY,13,14,8,1.4,"#c9c3bb",0);for(const ry of[VY+1.6,VY+3.2,VY+4.8,VY+6.4])bx(x,ry,14.4,14,.3,.25,"#9e9e9e",0);bx(x,VY-.3,14.4,14,.3,1.4,"#d7d2cb",0);bx(x,VY+8,14.4,14,.3,1.4,"#d7d2cb",0)}
  for(let x=VX0;x<VX1;x+=28){bx(x,VY+.2,15.8,.3,.3,5,"#78909c",0);bx(x,VY+.2,20.6,.3,7.6,.3,"#78909c",0)}
  gr(L-58,Y0,23,Y1-Y0,"#d6d2cc");for(let y=Y0;y<Y1;y+=4)gr(L-58,y,23,.3,"#c4bfb8");gr(L-54,MY-14,13,28,"#9e9e9e");gr(L-51,MY-11,7,22,"#81c784");
  bx(L-84,T-12,0,24,36,13,"#efebe9",2,"#9fc3d9");bx(L-85,T-13,13,26,38,1.5,"#37474f",2);bx(L-76,T+2,14.5,4,4,9,"#efebe9",2);bx(L-72.2,T+3,18,.4,2,2,"#ffffff",2);bx(L-72.1,T+3.6,18.4,.4,.8,.8,"#212121",2);bx(L-60.4,T-2,8,.4,16,2.6,"#1565c0",2,0,1);
  for(let y=B;y<B+40;y+=10){bx(L-38,y,0,.5,.5,4.5,"#757575",2);bx(L-38.8,y-.4,4.5,2,1.6,1.4,"#f9a825",2)}GRD.base="#8a8178"}
 else if(z===3){/* 商店街：アーケードの屋根・入口アーチ・のぼり */clr();const C=["#f5e6c8","#e8d5b5","#f0d9c0","#e3e8ec","#fbe9e7","#e8f5e9"],A2=[["#c62828","#ffffff"],["#1565c0","#ffffff"],["#2e7d32","#fff59d"],["#ef6c00","#ffffff"],["#6a1b9a","#f3e5f5"]];
  let y=Y0;while(y<Y1){const d=8+Math.floor(rn()*4),h=7+Math.floor(rn()*4);bx(L-50,y,0,14,d-.4,h,pick(C),2,"#9fc3d9");const a=pick(A2);for(let i=0;i<d-1;i+=1.5)bx(L-36.6,y+.3+i,3.6,1.6,Math.min(1.5,d-1.3-i),.5,(i/1.5)%2?a[1]:a[0],2);bx(L-36.3,y+.8,h-2.4,.3,d-2,1.4,pick(["#3e2723","#1a237e","#b71c1c","#004d40"]),2);
   if(rn()<.6)bx(L-35.6,y+d/2,0,1.4,1.4,1.4,pick(["#ff8f00","#8bc34a","#e53935","#fdd835"]),2);y+=d}
  for(let yy=Y0;yy<Y1;yy+=6){bx(L-29,yy,0,.5,.5,13,"#b0bec5",2);bx(L-8.6,yy,0,.5,.5,13,"#b0bec5",2);bx(L-29,yy,13,21,.5,.5,"#b0bec5",2)}for(let yy=Y0;yy<Y1;yy+=3)bx(L-29.5,yy,13.5,22,.6,.3,"#cfd8dc",2);
  arch(T-4,"#8d6e63","#fff3e0",0);bx(L-25,T-4.2,12.4,14,.3,1.8,"#c62828",2);for(let yy=Y0;yy<Y1;yy+=9){bx(L-9.6,yy,0,.2,.2,5,"#9e9e9e",2);bx(L-9.6,yy+.2,2.5,.2,1.2,2.5,pick(["#e53935","#1e88e5","#fdd835","#43a047"]),2)}
  road("#b39a84",0);for(let y=Y0;y<Y1;y+=3)gr(L-26,y,16,.25,"#a18872");GRD.base="#9a8f84"}
 else if(z===4){/* 住宅街：一戸建て・マンション・小さな公園 */SCN.filter(b=>b.h>=1.4&&b.h<=1.6&&b.c&&b.t).forEach(b=>{b.c=pick(["#d84315","#1565c0","#2e7d32","#6d4c41","#455a64","#ad1457"])});clr();
  const HC=["#fff8e1","#f3e5f5","#e3f2fd","#fbe9e7","#f1f8e9","#fafafa","#ffe0b2"],RC=["#d84315","#1565c0","#2e7d32","#6d4c41","#455a64","#ad1457","#8d6e63"];
  const hs=(x,y,w,d)=>{const c=pick(HC),r=pick(RC),h=7+Math.floor(rn()*3);bx(x,y,0,w,d,h,c,2,"#9fc3d9");bx(x-.6,y-.6,h,w+1.2,d+1.2,1.3,r,2);bx(x+1,y+1,h+1.3,w-2,d-2,1.3,r,2);bx(x+2.5,y+2.5,h+2.6,Math.max(1,w-5),Math.max(1,d-5),1.2,r,2);bx(x+w,y+d/2-1,0,.3,2,4,"#6d4c41",2);gr(x+w,y-1,3.5,d+2,"#9ccc65");bx(x+w+3,y-1,0,.6,d+2,1.4,pick(["#eeeeee","#bcaaa4","#8d6e63"]),2)};
  const mn=(x,y,w,d,fl)=>{const c=pick(["#eceff1","#d7ccc8","#cfd8dc","#f5f5f5","#e0d7c6"]),h=fl*3.2;bx(x,y,0,w,d,h,c,2,"lit2");for(let k=1;k<fl;k++)bx(x+w,y+.5,k*3.2-.3,.8,d-1,.25,"#90a4ae",2);bx(x-.3,y-.3,h,w+.6,d+.6,.6,"#78909c",2);bx(x+w-.2,y+d/2-1.5,0,.6,3,3,"#455a64",2)};
  let y=Y0;let k=0;while(y<Y1){if(k%4===1){mn(L-58,y,18,14,6+Math.floor(rn()*4));y+=16}else if(k%4===3&&Math.abs(y-MY)<30){gr(L-58,y,20,14,"#8bc34a");bx(L-54,y+3,0,.4,.4,6,"#e53935",2);bx(L-48,y+3,0,.4,.4,6,"#e53935",2);bx(L-54,y+3,6,6.4,.4,.4,"#e53935",2);bx(L-44,y+8,0,4,1,3,"#fdd835",2);tree(L-56,y+11);y+=16}else{hs(L-49,y,11,10);hs(L-63,y,11,10);y+=13}k++}
  for(let y=Y0;y<Y1;y+=11)tree(L-37.5,y,pick(["#66bb6a","#81c784","#f48fb1"]));
  for(const[x0,y0,w,d,fl]of[[-110,Y0+10,22,18,10],[-112,MY-6,24,18,12],[-108,B+20,20,16,9]])mn(L+x0,y0,w,d,fl);GRD.base="#8fae74"}
 else if(z===5){/* 田舎：田んぼ・山・かかし・無人販売所・電柱 */clr([1,3,4]);const P0="#8bc34a",P1="#7cb342";for(let y=Y0-40;y<Y1+40;y+=14){gr(L-120,y,82,13,(y/14|0)%2?P0:P1);for(let x=L-118;x<L-40;x+=2.2)gr(x,y+.5,.4,12,"#558b2f");gr(L-120,y+13,82,1,"#8d7a5c")}
  for(let y=T-40;y<B+40;y+=14){gr(Rr+2,y,60,13,(y/14|0)%2?P1:P0);for(let x=Rr+3;x<Rr+60;x+=2.2)gr(x,y+.5,.4,12,"#558b2f")}gr(L-12,T-60,Rr-L+70,52,"#9ccc65");gr(L-12,B+4,Rr-L+70,50,"#9ccc65");
  road("#8d8d86",0);for(let i=GRD.length-1;i>=0;i--){const g=GRD[i];if(g.c==="#cbbfae"||g.c==="#e6e6e6")GRD.splice(i,1)}gr(L-9,Y0,9,Y1-Y0,"#a1a37a");gr(L-35,Y0,9,Y1-Y0,"#a1a37a");
  for(let y=Y0;y<Y1;y+=22){bx(L-31,y,0,.5,.5,12,"#8d6e63",2);bx(L-31.6,y-.4,11,1.6,1.2,.4,"#6d4c41",2)}bx(L-60,T+4,0,.4,.4,5,"#6d4c41",2);bx(L-61.2,T+3.9,4,2.8,.4,.4,"#6d4c41",2);bx(L-60.5,T+3.6,5,1.4,1,1.4,"#ffe0b2",2);bx(L-61,T+3.4,6.2,2.4,1.6,.6,"#ffb300",2);
  bx(L-40,B+2,0,4,3,3,"#a1887f",2);bx(L-40.3,B+1.8,3,4.6,3.4,.5,"#5d4037",2);bx(L-36.2,B+2.5,1,.3,2,.8,"#ff7043",2);
  bx(L-82,T-6,0,16,14,6,"#efe3cf",2);for(let k=0;k<4;k++)bx(L-83+k,T-7+k,6+k*1.2,18-2*k,16-2*k,1.2,"#5d4037",2);bx(Rr+14,T+6,0,10,10,5,"#efe3cf",4);bx(Rr+13,T+5,5,12,12,1.2,"#455a64",4);
  for(const[mx,my,ms]of[[-190,Y0+10,60],[-175,MY,72],[-195,B+40,64],[-120,Y0-60,50]]){let w=ms;for(let k=0;k<8;k++){bx(L+mx+k*4,my-w/2,k*6,w,w,6,k>5?"#1b5e20":k>2?"#2e7d32":"#388e3c",0);w-=8;if(w<4)break}}GRD.base="#7aa35a"}
 else if(z===6){/* 海沿い：砂浜・海・灯台・船・ヤシ */clr([1]);gr(L-62,Y0-40,27,Y1-Y0+80,"#ead9a8");gr(L-260,Y0-80,198,Y1-Y0+160,"#2f8fcf");for(let x=L-260;x<L-62;x+=7)gr(x,Y0-80,1.4,Y1-Y0+160,"#56aee0");gr(L-64,Y0-40,2.5,Y1-Y0+80,"#f5f5f5");gr(L-12,T-60,Rr-L+70,48,"#ead9a8");
  for(let y=Y0+6;y<Y1;y+=14){const x=L-46+rn()*8;bx(x,y,0,1,1,10,"#8d6e63",2);for(const[dx,dy]of[[-3,0],[1,0],[0,-3],[0,1]])bx(x+dx,y+dy,9.5,3,3,.8,"#43a047",2);bx(x-1,y-1,10,3,3,.8,"#66bb6a",2)}
  for(let y=T+18;y<B+30;y+=10){bx(L-55,y,0,.3,.3,4,"#bdbdbd",2);bx(L-57,y-2,4,4,4,.4,pick(["#ff7043","#26c6da","#ffee58","#ec407a"]),2)}
  bx(L-110,T-30,0,6,6,4,"#9e9e9e",2);for(let k=0;k<6;k++)bx(L-109,T-29,4+k*4,4,4,4,k%2?"#e53935":"#ffffff",2);bx(L-109.3,T-29.3,28,4.6,4.6,2.5,"#fff59d",2,0,1);bx(L-109.6,T-29.6,30.5,5.2,5.2,1,"#37474f",2);
  for(const[bx0,by0,c]of[[-130,MY-20,"#ffffff"],[-150,B+20,"#ef5350"]]){bx(L+bx0,by0,0,4,10,1.5,c,2);bx(L+bx0+1,by0+3,1.5,2,4,2,"#eceff1",2)}bx(L-58,T-14,0,4,4,6,"#ffffff",2);bx(L-58.5,T-14.5,6,5,5,1,"#e53935",2);GRD.base="#2f8fcf"}}
/* ネオンは夜に光る */
{const _d0=drawScn0;drawScn0=function(k){const r=_d0.apply(this,arguments);try{if(WG&&LTN&&LTN.glow>.05){const N=SCN.filter(b=>b.ne&&wallVis(b.t,k));if(N.length){const oc=cx,w=WG;cx=w;WG=null;try{N.forEach(b=>dvb(b,k))}finally{WG=w;cx=oc}}}}catch(e){}return r}}
/* 移転（ベータ版は無料） */
function mvPanel(){if(!G.setup||G.over)return;if(R.phase!=="prep"){toast("移転は営業前だけできます");return}const z0=areaZ();
 const d=document.createElement("div");d.id="mvov";d.className="xpan";d.innerHTML=`<div class="xin"><div class="xh">🚚 お店を移転する</div><div class="xs">いまの場所：<b>${AREA[z0].e} ${AREA[z0].n}</b></div>
 <div style="background:#fff3d6;border:2px solid #f0b23a;border-radius:10px;padding:8px 10px;margin:8px 0;font-weight:900;color:#b5520e;font-size:13px">🎉 ベータ版のため、今回は移転費用が無料！</div>
 <div id="mvl">${AREA.map((A,i)=>`<button data-mz="${i}" class="mvb ${i===z0?"cur":""}" ${i===z0?"disabled":""}><b>${A.e} ${A.n}</b>${i===z0?" <small>（いまの場所）</small>":""}<small style="display:block">${A.tx}（家賃×${A.r}）</small></button>`).join("")}</div>
 <div class="xs" style="margin-top:6px">移転しても、内装・お客さん・お金はそのままです。家賃とお客さんの来かたが変わります。</div><div class="xb"><button data-mz="x" style="flex:1">やめる</button></div></div>`;document.body.appendChild(d);
 d.onclick=e=>{const b=e.target.closest("[data-mz]");if(!b)return;if(b.dataset.mz==="x"){d.remove();return}const z=+b.dataset.mz,A=AREA[z];
  if(!b.classList.contains("arm")){d.querySelectorAll(".mvb.arm").forEach(x=>{x.classList.remove("arm");const q=x.querySelector(".cf");if(q)q.remove()});b.classList.add("arm");b.insertAdjacentHTML("beforeend",`<small class="cf">もう一度タップで「${A.n}」に移転します</small>`);return}
  G.loc=Object.assign({},G.loc||{},{z,a:A.b,t:1,v:Math.random()*NVAR|0});G.mvN=(G.mvN||0)+1;try{genScn();build();BGK=""}catch(_){}save();d.remove();try{log("🚚 お店を「"+A.n+"」に移転しました（ベータ版のため無料）");toast(A.e+" "+A.n+"に移転しました！")}catch(_){}try{hud()}catch(_){}}}
function mvCard(){const pe=$("#p-etc");if(!pe)return;let c=$("#mvcard");if(!c){c=document.createElement("div");c.id="mvcard";c.className="fmcard";pe.prepend(c)}const z=areaZ();c.innerHTML=`<div style="display:flex;align-items:center;gap:8px"><div style="flex:1"><b>📍 お店の場所</b><div class="m" style="font-size:12.5px;margin-top:2px">${AREA[z].e} ${AREA[z].n}（路面店）</div></div><button id="mvgo" style="flex:none">🚚 移転する</button></div>`}
{const _ft7=fmTab;fmTab=function(k){const r=_ft7.apply(this,arguments);try{if(k==="etc")mvCard()}catch(e){}return r}}
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest("#mvgo")){e.stopPropagation();mvPanel()}},true);
(function(){const st=document.createElement("style");st.textContent=`#mvl{display:flex;flex-direction:column;gap:6px;max-height:52vh;overflow:auto}.mvb{text-align:left!important;padding:8px 10px!important}.mvb small{color:var(--mut);font-weight:700}.mvb.cur{opacity:.6}.mvb.arm{outline:3px solid #6658a6}.mvb .cf{color:#6658a6!important;margin-top:4px;font-weight:900}`;document.head.appendChild(st)})();
try{areaFix()}catch(e){}
'''
rep(TAIL,CODE+TAIL)
rep('cx.globalAlpha=SCA;cx.drawImage(SCV,0,0)','cx.globalAlpha=(typeof scnA==="function"?scnA():SCA);cx.drawImage(SCV,0,0)')
open(f,'w').write(s)
