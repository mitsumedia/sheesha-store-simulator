import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('"明日はけむりーぐです", "はぁ"], "fl": 41}','"明日はけむりーぐです", "はぁ", "いいですねぇ"], "fl": 41}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== さんてぃのセリフ追加（遊んでいるデータにも） ===== */
function sanLs(){try{(G.cs||[]).forEach(c=>{if(c.name==="さんてぃ"&&Array.isArray(c.ls)&&!c.ls.includes("いいですねぇ"))c.ls.push("いいですねぇ")})}catch(e){}}
sanLs();setTimeout(sanLs,1500);{const _sc12=sched;sched=function(){sanLs();return _sc12.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
