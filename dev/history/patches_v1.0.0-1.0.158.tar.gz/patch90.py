import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 管理ページの経過表示を、ゲーム画面の「プレイ○年○日目」に合わせる（古い記録も日数から直して表示）
rep('const monLbl=()=>(Math.floor((G.month||0)/12)+1)+"年目"+MN[(G.month||0)%12]+"月・"+(G.day||1)+"日目",',
    'const ydOf=n=>{n=Math.max(1,n|0);const y=Math.floor((n-1)/84),d=(n-1)%84+1;return"プレイ"+(y?y+"年":"")+d+"日目"},monFix=t=>{const m=String(t||"").match(/(\\d+)日目$/);return m?ydOf(+m[1]):String(t||"")},monLbl=()=>ydOf(G.day||1),')
rep('・${esc(p.mon||"")}・所持金','・${esc(monFix(p.mon))}・所持金')
open(f,'w').write(s)
