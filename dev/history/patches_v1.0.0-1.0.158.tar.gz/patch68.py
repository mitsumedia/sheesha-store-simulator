import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 選んでいる席そのものをタップしたら「選択解除」にする（移動扱いで向きが変わっていた）
rep('if(m&&m.t!=="w"&&R.mvT&&R.mvT.has(key)){if(m.t==="f"){','if(m&&pk&&mvSame(pk,m)){mvOff();return}\nif(m&&m.t!=="w"&&R.mvT&&R.mvT.has(key)){if(m.t==="f"){')
# 移動で向きが変わるときは知らせる
rep('for(const a of alts)if(furnFits(a,mi))return a;return fFlip(N)}','for(const a of alts)if(furnFits(a,mi))return a;try{toast("↻ その場所は今の向きでは置けないので、向きを変えて置きました")}catch(e){}return fFlip(N)}')
open(f,'w').write(s)
