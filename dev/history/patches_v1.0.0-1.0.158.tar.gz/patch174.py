import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 外観モードとほかの機能の合わせ方 ===== */
/* シャッター演出の間は外観モードを外し、終わったら戻す */
{const _cc=cineClose;cineClose=function(done){const w=!!R.ext;if(w)extSet(0);return _cc.call(this,()=>{try{done()}finally{if(w&&!R.vis)try{extSet(1)}catch(e){}}})}}
{const _st7=start;start=function(){const w=!!R.ext;if(w)extSet(0);const r=_st7.apply(this,arguments);try{if(w){if(R.cine)R.cine.reExt=1;else extSet(1)}}catch(e){}return r};$("#go").onclick=start}
{const _ce=cineEnd;cineEnd=function(){const c=R.cine,re=c&&c.reExt;const r=_ce.apply(this,arguments);if(re)try{extSet(1)}catch(e){}return r}}
/* 友だちの店に遊びに行く時は外観モードを外す */
{const _ve=visEnter;visEnter=function(){if(R.ext)try{extSet(0)}catch(e){}return _ve.apply(this,arguments)}}
/* 模様替え・装飾のタブに行く時も外す */
{const _stb=setTab;setTab=function(t){if(R.ext&&t==="deco")try{extSet(0)}catch(e){}return _stb.apply(this,arguments)}}
try{document.head.insertAdjacentHTML("beforeend","<style>body.vis #extb{display:none!important}</style>")}catch(e){}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
