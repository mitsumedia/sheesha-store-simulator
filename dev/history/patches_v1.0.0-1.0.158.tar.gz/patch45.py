import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('const monLbl=()=>(Math.floor((G.month||0)/12)+1)+"年目"+MN[(G.month||0)%12]+"月"','const monLbl=()=>(Math.floor((G.month||0)/12)+1)+"年目"+MN[(G.month||0)%12]+"月・"+(G.day||1)+"日目"')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 画面上部にプレイ日数 ===== */
{const _h=hud;hud=function(){_h.apply(this,arguments);try{const d=$("#day");if(d&&G.setup){const t=d.textContent.replace(/\s*プレイ\d+日目$/,"");d.innerHTML=esc(t)+'<small style="display:block;font-size:10px;opacity:.8;font-weight:600">プレイ'+(G.day||1)+'日目</small>'}}catch(e){}}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
