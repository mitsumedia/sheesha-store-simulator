import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== iPhoneのSafari対策：全画面メニューの高さを実際に見えている高さに合わせ、外側のページは動かないようにする ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
html body #sheet.open{height:100vh!important;height:100dvh!important;max-height:100dvh!important;bottom:auto!important;overscroll-behavior:contain!important;-webkit-overflow-scrolling:touch}
html.fmopen,html.fmopen body{overflow:hidden!important;overscroll-behavior:none!important;height:100%!important}
html body #sheet.open #fmb{bottom:calc(env(safe-area-inset-bottom,0px) + 12px)!important}
html body #sheet.open>*:last-child{margin-bottom:0}
#fmpad{height:150px}
</style>`)}catch(e){}
setTimeout(()=>{try{const sh=$("#sheet");if(!sh)return;if(!$("#fmpad")){const p=document.createElement("div");p.id="fmpad";sh.appendChild(p)}
const sync=()=>{const on=sh.classList.contains("open");document.documentElement.classList.toggle("fmopen",on);if(on){try{window.scrollTo(0,0)}catch(e){}const p=$("#fmpad");if(p&&p.nextSibling)sh.appendChild(p)}};
new MutationObserver(sync).observe(sh,{attributes:true,attributeFilter:["class"]});sync()}catch(e){}},50);
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
