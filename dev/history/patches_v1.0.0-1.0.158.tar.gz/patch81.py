import sys
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 乗り物で来るお客さん：有馬（No.95）はバイク、亜空間飛助はUFO。店の前に停めて、乗って帰る ===== */
let BKVX=null;
function bkVox(){if(BKVX)return BKVX;const d=DMD.gf_94;if(!d)return[];const pal=d[0].split(",").map(c=>"#"+c),bin=atob(d[1]),L=[];for(let i=0;i+2<bin.length;i+=3){const a=bin.charCodeAt(i);L.push([((a>>4)-2)*.5,((a&15)-2)*.5,bin.charCodeAt(i+1)*.5,pal[bin.charCodeAt(i+2)]])}return BKVX=L}
function ufoVox(t){const L=[],C=["#ff4d6d","#ffd84a","#5ac8fa","#7bd389","#b28bff"],S="#c9d1da",S2="#9aa4b0",GL="#8ee8ff";
const ring=(z,r0,r1,fn)=>{for(let x=-r1;x<=r1;x+=.5)for(let y=-r1;y<=r1;y+=.5){const d=Math.hypot(x+.25,y+.25);if(d<=r1&&d>=r0)L.push([x,y,z,fn(x,y,d)])}};
ring(.5,0,2,()=>"#3a4250");ring(1,0,3.5,()=>S2);ring(1.5,0,5,(x,y,d)=>{if(d>4.4){const a=Math.atan2(y,x),k=Math.floor((a+Math.PI)/(Math.PI*2)*12+t*4)%12;return k%2?C[(k>>1)%5]:"#fff6c0"}return S});
ring(2,0,4,()=>S);ring(2.5,0,2.5,()=>GL);ring(3,0,2,()=>GL);ring(3.5,0,1.25,()=>"#bff4ff");return L}
const VEH={94:{k:"bike",x:-5.5,park:11,far:80,sp:24},52:{k:"ufo",x:-15,park:4,far:0,sp:16}};
function vhRider(a,b){const t=[];try{pv(t,b.x-2,b.y-3,b.dir||1,b.c,1,0,0,0)}catch(e){}t.forEach(v=>{v[2]+=1.6+(b.z||0);a.push(v)})}
function vhOne(a,b){const V=VEH[b.c.i],now=performance.now(),dt=Math.min(.1,(now-(b.t||now))/1000)*(R.speed?Math.min(2,R.speed):0);b.t=now;b.tt=(b.tt||0)+dt;
const me=()=>R.people.find(q=>q.c&&q.c.i===b.c.i&&!q.gone),U=V.k==="ufo",sx=b.x+(U?4:2.5),sy=b.y+(U?4:1);
if(b.ph==="in"){if(U){b.z=Math.max(0,b.z-V.sp*dt);if(b.z<=0){b.ph="dis";b.w=1.6}}else{b.dir=1;b.y=Math.min(V.park,b.y+V.sp*dt);if(b.y>=V.park){b.ph="dis";b.w=1.4}}}
else if(b.ph==="dis"){b.w-=dt;if(b.w<=0){b.ph="park";if(b.m){const m=b.m;b.m=null;arrive0(m);const p=me();if(p){p.x=sx;p.y=sy;p.path=[[-3,15]].concat(p.path||[])}}}}
else if(b.ph==="park"){const p=me();if(p){b.came=1;if(p.st==="out"&&!p.bkP){p.bkP=1;p.path=(p.path||[]).concat([[sx,sy]])}}else if(b.came){b.ph="mnt";b.w=1.4}}
else if(b.ph==="mnt"){b.w-=dt;if(b.w<=0)b.ph="out"}
else if(b.ph==="out"){if(U){b.z+=V.sp*dt*(1+b.z/20);if(b.z>70)return false}else{b.dir=-1;b.y-=V.sp*dt;if(b.y<-V.far)return false}}
if(U){const still=b.ph==="park"||b.ph==="dis"||b.ph==="mnt",hov=still?Math.sin(b.tt*2.2)*.25+.25:0,zz=(b.z||0)+hov;ufoVox(b.tt).forEach(([x,y,z,col])=>a.push([b.x+x,b.y+y,z+zz,col,undefined,.5]));
if(still)for(const[lx,ly]of[[-2.5,-1.5],[2.5,-1.5],[0,2.75]])a.push([b.x+lx,b.y+ly,0,"#9aa4b0",undefined,.5]);
if(b.z>1)for(let q=0;q<5;q++)a.push([b.x-.25,b.y-.25,Math.max(0,b.z-1-q*1.6),"#bff4ff",undefined,.5]);
if(b.ph==="in"||b.ph==="out"||(b.ph==="dis"&&b.w>.8)||(b.ph==="mnt"&&b.w<.6)){const t=[];try{pv(t,b.x-2,b.y-2,1,b.c,1,0,0,0)}catch(e){}t.forEach(v=>{if(v[2]>5){v[2]+=zz-3;a.push(v)}})}}
else{const dr=b.dir||1;bkVox().forEach(([x0,y0,z,col])=>a.push([b.x+dr*(y0-3),b.y+dr*(x0-3)-.25,z,col,undefined,.5]));
if(b.ph==="in"||b.ph==="out"||(b.ph==="dis"&&b.w>.6)||(b.ph==="mnt"&&b.w<.8))vhRider(a,b)}
return true}
{const _dy=dyn;dyn=function(){const a=_dy.apply(this,arguments);try{if(R.vehs&&R.vehs.length)R.vehs=R.vehs.filter(b=>vhOne(a,b))}catch(e){console.log(e)}return a}}
const arrive0=arrive;
arrive=function(m){try{const c=m&&m.length===1&&m[0],V=c&&VEH[c.i];if(V&&R.phase==="run"&&R.away==null&&!(R.vehs||[]).some(b=>b.c===c)){R.vehs=R.vehs||[];R.vehs.push(V.k==="ufo"?{ph:"in",x:V.x,y:V.park,z:45,c,m,t:performance.now()}:{ph:"in",dir:1,x:V.x,y:-V.far,c,m,t:performance.now()});return}}catch(e){}return arrive0.apply(this,arguments)};
{const _st=start;start=function(){R.vehs=[];return _st.apply(this,arguments)}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,CODE+TAIL);open(f,'w').write(s)
