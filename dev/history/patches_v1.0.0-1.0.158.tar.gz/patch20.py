import sys
f=sys.argv[1];s=open(f).read()
a='if(!G.setup)showSetup();else if(!G.loc)showLoc();else if(!G.ow)showOwner();else if(G.last&&!G.last.seen)showResult();else showMorning();'
assert s.count(a)==1,s.count(a)
# 起動時の最初の画面は、全部の読み込みが終わってから出す（朝の画面で閉じて開き直すと固まる不具合の修正）
s=s.replace(a,'setTimeout(()=>{'+a+'},0);')
open(f,'w').write(s);print('ok')
