import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('let spot=SPS.length?SPS[(((R.ckSp||0)%SPS.length)+SPS.length)%SPS.length]:FLT[0];','const spI=SPS.length?(((R.ckSp||0)%SPS.length)+SPS.length)%SPS.length:0;let spot=SPS.length?SPS[spI]:FLT[0];')
rep('R.cam={yaw:.22,pit:.24,zoom:(pose.hk?4.4:4.9)','R.cam={yaw:[.22,-.42][spI%2],pit:.24,zoom:(pose.hk?4.4:4.9)')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== チェキの撮影場所：となり合う場所は1つにまとめ、場所ごとに角度も変える ===== */
ckSpots=function(){const F=FLT.slice().sort((a,b)=>(b[1]-a[1])||(a[0]-b[0])),L=[];for(const[tx,ty]of F){if(occ(tx,ty)||!FLS.has((tx+1)+","+ty)||occ(tx+1,ty))continue;if(L.some(([x,y])=>Math.abs(x-tx)<3&&Math.abs(y-ty)<2))continue;L.push([tx,ty])}
if(!L.length)for(const[tx,ty]of F){if(!occ(tx,ty)&&FLS.has((tx+1)+","+ty)&&!occ(tx+1,ty)){L.push([tx,ty]);break}}return L};
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
