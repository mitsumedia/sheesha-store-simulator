import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
U=json.load(open('/mnt/user-data/uploads/163d16b8-attachment.txt'))
KK=["rar","name","sex","age","pe","job","fav","fl","fd","hist","sl","freq","stay","tl","first","repeat","refill","fr","aw","ap","hb","ls","bye"]
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1]);by={e['slot']:e for e in arr}
for u in U:
    e=by[u['no']-1]
    for k in KK:
        if k in u:e[k]=u[k]
    if e.get('job')=='シーシャ屋':e['rar']=5
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))+s[j+1:]
# 表示番号の入れ替え：ハル(ID135)↔sumire(ID132)、ノム(ID139)↔Ryusei(ID150)
rep('DXC={k,m:{}};o.forEach((i,n)=>{DXC.m[i]=n+1})}','DXC={k,m:{}};o.forEach((i,n)=>{DXC.m[i]=n+1});[[131,134],[138,149]].forEach(([a,b])=>{const t=DXC.m[a];DXC.m[a]=DXC.m[b];DXC.m[b]=t})}')
# シーシャ屋はプロフィールの一部を出さない
rep('+ORD.map((o,i)=>`<div class="f">','+ORD.map((o,i)=>c.job==="シーシャ屋"&&SHX.includes(o[0])?"":`<div class="f">')
rep('const NL=ORD.length;','const NL=ORD.length;\nconst SHX=["好きなドリンク","趣味","性格","年齢","好きな雰囲気","シーシャ歴","シーシャレベル","話しかけ適正回数"];')
# 既存セーブへ反映（編集してない客だけ。シーシャ屋のレア5は全員）
rep('if(!G.bye1){','if(!G.bld5){const KK=%s;G.cs.forEach(c=>{const p=PRESET[c.i];if(!p)return;if(p.job==="シーシャ屋"&&c.job==="シーシャ屋")c.rar=5;if(c.ed||c.i===124)return;KK.forEach(k=>{if(p[k]!==undefined)c[k]=JSON.parse(JSON.stringify(p[k]))})});G.bld5=1;DXC=null}if(!G.bye1){'%json.dumps(KK))
open(f,'w').write(s);print('ok')
