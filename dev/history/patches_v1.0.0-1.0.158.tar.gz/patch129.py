import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# チェキにもメガネ・サングラスを描く（お店の中と同じ描き方）
rep('a.map(v=>({v,d:dep(v,k)})).sort((p,q)=>p.d-q.d).forEach(o=>dv(o.v,k));\ntry{const fd=CKD',
 'a.map(v=>({v,d:dep(v,k)})).sort((p,q)=>p.d-q.d).forEach(o=>dv(o.v,k));\n'
 'try{const hasG=c=>!c.pump&&(c.acc===1||c.acc===7||c.acc===10),gc=c=>c.accC||"#333333";'
 'if(sp2){const[a1,b1]=sp2;[[a1,ow],[b1,cu]].forEach(([st,c])=>{if(hasG(c))glFxS(st,c.acc,gc(c),3.04,seatZo(st)).fn(k)})}'
 'else{[[X0,ow],[X0+gap,cu]].forEach(([x,c])=>{if(hasG(c))glFx(x,Y0,1,pose.sit?1:0,0,c.acc,gc(c),3.04).fn(k)})}}catch(e){console.log(e)}\n'
 'try{const fd=CKD')
open(f,'w').write(s)
