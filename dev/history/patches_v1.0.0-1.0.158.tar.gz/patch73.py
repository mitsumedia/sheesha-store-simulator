import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== フェス会場：バトルとは別のクラブ（青緑のネオン・光るダンスフロア・ミラーボール） ===== */
festSet=function(hk){const st=[],B=(...q)=>VB(st,...q),X0=-30,X1=37,Y1=46;
B(X0,-8,-1,X1-X0,Y1+8,1,(x,y)=>{if(y>=12&&y<=34&&x>=-14&&x<=20){const t=(Math.floor((x+14)/4)+Math.floor((y-12)/4))%4;return["#ff4fd8","#3ee6ff","#ffe14a","#7a5cff"][t]}return((x+y)%2)?"#2a4660":"#244058"});
B(X0,-9,0,X1-X0,1,27,(x,y,z)=>z===0?"#3ee6ff":(x%6===0?"#335a78":"#2b4c68"));B(X0-1,-9,0,1,Y1+9,27,(x,y,z)=>z===0?"#3ee6ff":(y%6===0?"#335a78":"#2b4c68"));
/* 奥のLEDウォール（波模様） */
B(-14,-8,8,34,1,13,(x,y,z)=>{const v=Math.sin((x+3)/3)+Math.cos(z/2.2);return v>1?"#ffe14a":v>.2?"#ff4fd8":v>-.6?"#3ee6ff":"#14243a"});
/* トラスとライト */
for(const y of[-6,0])B(X0+1,y,25,X1-X0-2,1,1,"#9fb3c8");for(let x=X0+3;x<X1-2;x+=5)for(const y of[-6,0]){B(x,y,23,2,1,2,"#222");B(x,y,22,2,1,1,"#3ee6ff")}
/* ミラーボール */
B(-25,12,23,1,1,3,"#cfd8e3");B(-27,10,19,5,5,4,(x,y,z)=>((x+y+z)%2)?"#e8f4ff":"#9fb3c8");
/* ブース */
CLX.forEach((bx,i)=>{B(bx-1,0,0,8,3,5,(x,y)=>y===2&&(x-bx)%2===0?(i===2?"#ffd54a":"#3ee6ff"):"#16283a");B(bx-1,0,5,8,3,1,"#4a6a88");const h=hk[i]||["#2f6fa8","#3d86c6"];
B(bx+4,0,6,2,2,1,h[0]);B(bx+4,0,7,2,2,2,h[1]);B(bx+4,0,9,1,1,3,"#c0c0c0");B(bx+4,0,12,2,2,1,"#ff7043")});
/* スピーカー */
for(const [px,py] of[[X0+2,1],[X1-5,1]])B(px,py,0,3,3,9,(x,y,z)=>z===8?"#222":(z%3===1?"#3ee6ff":"#121a24"));
return st};
festBg=function(g,W,H){g.fillStyle="#123048";g.fillRect(0,0,W,H);const r=g.createRadialGradient(W/2,H*.15,10,W/2,H*.2,W*.8);r.addColorStop(0,"rgba(62,230,255,.4)");r.addColorStop(1,"rgba(62,230,255,0)");g.fillStyle=r;g.fillRect(0,0,W,H)};
festSun=function(g,W,H,t){};
'''
rep(TAIL,CODE+TAIL)
# function宣言を差し替え可能に
rep('function festSet(hk){','let festSet=function(hk){')
rep('function festBg(g,W,H){','let festBg=function(g,W,H){')
rep('function festSun(g,W,H,t){','let festSun=function(g,W,H,t){')
# フェスでもビーム（色違い）
rep('function clubBeams(g,k,t){','function clubBeams(g,k,t,C){')
rep('const col=n%3===0?"120,90,255":"255,30,80";','const col=C?C[n%C.length]:n%3===0?"120,90,255":"255,30,80";')
rep('if(!OUT)clubBeams(g,k,t);else festSun(g,W,H,t);','if(!OUT)clubBeams(g,k,t);else{clubBeams(g,k,t,["62,230,255","255,79,216","255,225,74"]);festSun(g,W,H,t)}')
rep('d.style.cssText="position:fixed;inset:0;z-index:80;background:"+(OUT?"#2c4a6e":"#1a1030")+";','d.style.cssText="position:fixed;inset:0;z-index:80;background:"+(OUT?"#0e2236":"#1a1030")+";')
rep('ef:"会場は昼の野外フェス。行列のお客さんにどんどん作ってふるまおう。','ef:"会場はネオンのクラブ。行列のお客さんにどんどん作ってふるまおう。')
# 「美味しい！」で上がる量：1回のフェスで知名度・スター性それぞれ最大20
rep('const dim=1/(1+(G.festN||0)*.5),capF=3*dim,capS=3*dim,stp=.5*dim;','const capF=20,capS=20,stp=3;')
rep("toFixed(1)}</b>／スター性 <b>+${r.dS.toFixed(1)}","toFixed(0)}</b>／スター性 <b>+${r.dS.toFixed(0)}")
open(f,'w').write(s)
