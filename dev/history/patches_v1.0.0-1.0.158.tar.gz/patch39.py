import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
GVER=open('gver.txt').read().strip()
rep('>Ver 1.0.0</div>','>Ver '+GVER+'</div>')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 更新チェック：起動時・アプリに戻ったとき・30分ごと。新しい版があればお知らせを出して選んでもらう ===== */
const GVER="%s";
let updV=null,updLater=null,updBusy=0;
async function updCheck(){if(updBusy||!/^https?:/.test(location.protocol))return;updBusy=1;try{const r=await fetch("version.txt?"+Date.now(),{cache:"no-store"});if(!r.ok)return;const v=(await r.text()).trim();if(!v||v===GVER)return;updV=v;updShow()}catch(e){}finally{updBusy=0}}
function updShow(){if(!updV||updLater===updV||document.getElementById("updm"))return;if(R.phase==="run"||!$("#ov").hidden||document.getElementById("sysm")){setTimeout(updShow,5000);return}
const m=sysM(`<div style="text-align:center"><div style="font-size:40px">🆕</div><b>新しいバージョンがあります</b><div style="font-size:14px;margin:8px 0">Ver ${esc(GVER)} → <b>Ver ${esc(updV)}</b></div><div class="m" style="font-size:12px;margin-bottom:10px">セーブデータはそのまま引き継がれます</div><button id="updgo" class="on" style="width:100%%;margin-bottom:6px">今すぐ更新</button><button id="updlt" style="width:100%%">あとで</button></div>`);m.id="sysm";m.firstElementChild.id="updm"}
document.addEventListener("click",e=>{const b=e.target.closest("#updgo,#updlt");if(!b)return;if(b.id==="updgo"){try{save()}catch(_){}location.replace(location.pathname+"?v="+encodeURIComponent(updV))}else{updLater=updV;sysOff()}});
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"){updLater=null;setTimeout(updCheck,800)}});
setTimeout(updCheck,1500);setInterval(updCheck,30*60*1000);
''' % GVER
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
