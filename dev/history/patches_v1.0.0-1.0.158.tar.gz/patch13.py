import sys
f=sys.argv[1];s=open(f).read()
ADD=r'''
/* ===== ✨ 発光する置物（でっかいりんご：赤と緑に交互に光る） ===== */
const DGLOW={gf_150:[[255,30,50],[0,255,60]]};
{const _dp=decPush;decPush=function(L,k){_dp(L,k);(G.decor||[]).forEach(dd=>{const gc=DGLOW[dd.id];if(!gc)return;const ox=dd.tx*6,oy=dd.ty*6;
L.push({v:{fn:k=>{const t=performance.now()/1000,w=(Math.sin(t*1.6)+1)/2,c=gc[0].map((v,i)=>Math.round(v*(1-w)+gc[1][i]*w)),P=P3(ox+3,oy+3,5,k),r=k.s*9*(0.9+0.1*Math.sin(t*3.1));
const g=cx.createRadialGradient(P[0],P[1],0,P[0],P[1],r);g.addColorStop(0,`rgba(${c},0.55)`);g.addColorStop(0.5,`rgba(${c},0.22)`);g.addColorStop(1,`rgba(${c},0)`);
cx.save();cx.globalCompositeOperation="lighter";cx.fillStyle=g;cx.beginPath();cx.arc(P[0],P[1],r,0,7);cx.fill();cx.restore()}},d:(ox+6)*k.cx+(oy+6)*k.cy+12*k.cz})})}}
{const _ii=ivInit;ivInit=function(){_ii();G.inv=G.inv.filter(it=>it.t!=="d"||DEC.some(q=>q.id===it.id));G.ivPend=G.ivPend.filter(it=>it.t!=="d"||DEC.some(q=>q.id===it.id))}}
'''
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T);open(f,'w').write(s);print('ok')
