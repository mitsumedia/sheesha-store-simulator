import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 全画面メニュー：見本ステージを上に固定して、一覧をスクロールしても見えるようにする ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
html body #sheet.open #fms.on{position:sticky;top:var(--fmhh,128px);z-index:4;height:196px;margin-top:-10px;border-radius:0 0 12px 12px;box-shadow:0 6px 10px -6px rgba(0,40,30,.35)}
html body #sheet.open .dcat{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto;gap:6px!important;padding-bottom:2px;-webkit-overflow-scrolling:touch;scrollbar-width:none}
html body #sheet.open .dcat::-webkit-scrollbar{display:none}
html body #sheet.open .dcat button{flex:none!important;width:auto!important;padding:6px 12px!important;font-size:12.5px!important;white-space:nowrap;border-radius:18px!important}
html body #sheet.open #sec-obj>.m:first-child,html body #sheet.open [id^=sec-]>.m:first-child{display:none!important}
html body #sheet.open #plc{font-size:11px!important}
</style>`)}catch(e){}
function fmhH(){try{const h=document.getElementById("fmh");if(h&&h.offsetHeight)document.documentElement.style.setProperty("--fmhh",h.offsetHeight+"px")}catch(e){}}
window.addEventListener("resize",()=>setTimeout(fmhH,50));
{const _ft2=fmTab;fmTab=function(){const r=_ft2.apply(this,arguments);fmhH();return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
