import sys,json,re
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=1):
    global s
    c=s.count(old)
    assert c==n,(c,old[:90])
    s=s.replace(old,new)
# 「初めて」系のセリフは初来店のときだけ
rep('const say=(p,t,k)=>{','const say=(p,t,k)=>{if(p&&p.c&&(p.c.vt||2)>1&&typeof t==="string"){if(t.indexOf("初めてなのに常連")>=0)t="また来ちゃいました、えへへ";else if(t.indexOf("初めて来たんですけど")>=0)t="ここ、いいお店ですよね"}')
# おかわりで話しかけ回数をリセット
rep('function order(p,refill){','function order(p,refill){if(refill)p.tp=0;')
# 店長カスタム：服の種類・ズボンの種類・ズボンの色も保存して反映
rep('shirt:c.shirt,acc:c.acc,accC:c.accC})};','shirt:c.shirt,top:c.top|0,bot:c.bot|0,pants:c.pants,acc:c.acc,accC:c.accC})};')
rep('Object.assign(OW.c,{eye:o.eye||0,hs:o.hs,hair:o.hair,skin:o.skin,shirt:o.shirt,acc:o.acc,accC:o.accC});',
    'Object.assign(OW.c,{eye:o.eye||0,hs:o.hs,hair:o.hair,skin:o.skin,shirt:o.shirt,acc:o.acc,accC:o.accC},o.top!=null?{top:o.top}:{},o.bot!=null?{bot:o.bot}:{},o.pants?{pants:o.pants}:{});')
rep('skin:o.skin,shirt:o.shirt,acc:o.acc,accC:o.accC};ov(`<div class="card"><b>店主の見た目</b>',
    'skin:o.skin,shirt:o.shirt,top:o.top!=null?o.top:OW.c.top,bot:o.bot!=null?o.bot:OW.c.bot,pants:o.pants||OW.c.pants,acc:o.acc,accC:o.accC};ov(`<div class="card"><b>店主の見た目</b>')
# 修理代：お客さんが多い月ほど起きやすい（20%〜60%）
rep('brk=Math.random()<.6?','brk=Math.random()<Math.min(.6,.2+wk.reduce((a,d)=>a+(d.visits||0),0)/150)?')
# お腹控えめ（flatB）のキャラ
rep('if(v>=2&&v<=5)for(let x=1;x<3;x+=.5)Qv(x,4,z,TC((x-1)*2,v))','if(v>=2&&v<=5&&!(c.sp&&SPF[c.sp]&&SPF[c.sp].flatB))for(let x=1;x<3;x+=.5)Qv(x,4,z,TC((x-1)*2,v))')
# 新垣（No.133）・のりよし（No.140）のモデル
rep('SPF.oji3.ownEye=1;','SPF.oji3.ownEye=1;\n'+open('/home/claude/w/models5.js').read())
# PRESET に入れる
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
look={132:dict(name="新垣",sex="男性",hs=98,hair="#141416",skin="#e8c3a2",shirt="#b4bba0",top=0,bot=0,pants="#2f3442",shoe="#1d1d1f",eye=5,acc=0,fat=0,sp="arakaki"),
      139:dict(name="のりよし",sex="男性",hs=98,hair="#141416",skin="#ecc4a2",shirt="#f5f5f3",top=0,bot=0,pants="#1e1f24",shoe="#151515",eye=0,acc=0,fat=2,sp="noriyoshi")}
for e in arr:
    if e.get('slot') in look: e.update(look[e['slot']])
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
rep('G.shop11=1}','G.shop11=1}\nif(!G.shop12){[133,140].forEach(n=>{const c=G.cs[n-1],p=PRESET[n-1];if(!c||c.ed)return;["sp","hs","hair","top","shirt","bot","pants","eye","fat","acc","skin","name","sex","shoe"].forEach(k=>{c[k]=p[k]})});G.shop12=1}')
open(f,'w').write(s);print('ok')
