import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 模様替え中は吹き出しを出さない（下の家具が見えて選べるように）
rep('const bs=[];R.people.concat(R.cat?[OW,R.cat]:[OW]).forEach(p=>{','const bs=[];(R.mvOn?[]:R.people.concat(R.cat?[OW,R.cat]:[OW])).forEach(p=>{')
ADD=r'''
/* ===== 🔧 模様替え：見た目どおりに選べるように（画面上の形で当たり判定） ===== */
function mvHull(pts){pts=pts.slice().sort((a,b)=>a[0]-b[0]||a[1]-b[1]);const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]),lo=[],up=[];for(const p of pts){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],p)<=0)lo.pop();lo.push(p)}for(let i=pts.length-1;i>=0;i--){const p=pts[i];while(up.length>=2&&cr(up[up.length-2],up[up.length-1],p)<=0)up.pop();up.push(p)}up.pop();lo.pop();return lo.concat(up)}
function mvIn(h,X,Y){let s=0;for(let i=0;i<h.length;i++){const a=h[i],b=h[(i+1)%h.length],c=(b[0]-a[0])*(Y-a[1])-(b[1]-a[1])*(X-a[0]);if(c!==0){if(s===0)s=Math.sign(c);else if(Math.sign(c)!==s)return false}}return true}
function mvBox(x0,x1,y0,y1,h,k){const P=[];[x0,x1].forEach(x=>[y0,y1].forEach(y=>[0,h].forEach(z=>{const q=P3(x,y,z,k);P.push([q[0],q[1]])})));return mvHull(P)}
function mvPick(X,Y,k){let best=null,bd=-1e9;
G.furn.forEach((F,i)=>{furnFoot(F).forEach(q=>{const[tx,ty]=q.split(",").map(Number),seat=F.k==="b"||ty===F.ty,h=F.k==="b"?5:seat?6.5:1.2,x0=tx*6,y0=ty*6;
 if(mvIn(mvBox(x0+.3,x0+5.7,y0+.3,y0+5.7,h,k),X,Y)){const d=(x0+3)*k.cx+(y0+3)*k.cy+h/2*k.cz;if(d>bd){bd=d;best={t:"f",i}}}})});
G.decor.forEach((d0,i)=>{let h=8,bx=[.5,5.5,.5,5.5];try{const sl=decVox(d0.id,d0.r);if(sl&&sl.length){h=Math.max(...sl.map(s=>s.si))+1;bx=[Math.min(...sl.map(s=>s.bb[0])),Math.max(...sl.map(s=>s.bb[1])),Math.min(...sl.map(s=>s.bb[2])),Math.max(...sl.map(s=>s.bb[3]))]}}catch(e){}const x0=d0.tx*6,y0=d0.ty*6;
 if(mvIn(mvBox(x0+bx[0],x0+bx[1],y0+bx[2],y0+bx[3],h,k),X,Y)){const d=(x0+3)*k.cx+(y0+3)*k.cy+h/2*k.cz;if(d>bd){bd=d;best={t:"d",i}}}});return best}
mvTap=function(X,Y,k){if(R.phase!=="prep"){log("🔧 模様替えは開店前だけできます");mvToggle(false);return}
const m=R.mvs,[tx,ty]=mvKeyAt(X,Y,k),key=tx+","+ty,pk=mvPick(X,Y,k);
/* 壁アイテムを選んでいる時・物がない所をタップした時は壁を先に見る */
const wallHit=()=>{let bw=null,bd=1e9;WS.forEach(w=>{if(!wallVis(w.s,k))return;const q=P3(w.c[0],w.c[1],w.c[2],k),d=Math.hypot(q[0]-X,q[1]-Y);if(d<bd){bd=d;bw=w}});return bw&&bd<Math.max(24,k.s*3.5)?bw:null};
if(m&&m.t==="w"){const bw=wallHit();if(bw){const i=(G.wall||[]).findIndex(d=>[d.k,d.k2,d.k3,d.k4].includes(bw.k));if(i===m.i){mvOff();return}if(i<0){const d=G.wall[m.i],ks=wallSlots(d.id,bw.k,m.i);if(!ks){log("そこには貼れません（緑の丸の区画に移動できます）");return}d.k=ks[0];delete d.k2;delete d.k3;delete d.k4;if(ks[1])d.k2=ks[1];if(ks[2])d.k3=ks[2];if(ks[3])d.k4=ks[3];log("🔧 "+mvName(m)+" を移動");mvDone();mvSel(m);return}mvSel({t:"w",i});return}}
/* 選んでいる家具・置物を緑のマスへ（自分と重なる位置へのずらしもOK） */
if(m&&m.t!=="w"&&R.mvT&&R.mvT.has(key)&&(!pk||mvSame(pk,m))){if(m.t==="f"){const F=G.furn[m.i],N=Object.assign({},F,{tx,ty});if(furnFits(N,m.i))Object.assign(F,N);else Object.assign(F,N,{f:-N.f});log("🔧 "+seatName(F)+" を移動")}else{G.decor[m.i].tx=tx;G.decor[m.i].ty=ty;log("🔧 置物を移動")}mvDone();mvSel(m);return}
if(pk){if(mvSame(pk,m)){mvOff();return}mvSel(pk);return}
{const bw=wallHit();if(bw){const i=(G.wall||[]).findIndex(d=>[d.k,d.k2,d.k3,d.k4].includes(bw.k));if(i>=0){mvSel({t:"w",i});return}}}
const hit=FLS.has(key)?mvObjAt(key):null,o=hit||mvNear(X,Y,k);
if(m&&m.t!=="w"){if(o&&!mvSame(o,m)){mvSel(o);return}if(o)return;log("緑のマスに移動できます");return}
if(o){mvSel(o);return}mvOff()};
'''
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T);open(f,'w').write(s);print('ok')
