import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 話しかけた回数を「その日・そのお客さん」で数える（席を立って戻った時などに0に戻って「あまり話せなかった」と言わないように） ===== */
{const _tk=talk;talk=function(p){const b=p&&p.tp||0;const r=_tk.apply(this,arguments);try{if(p&&p.c&&(p.tp||0)>b){const c=p.c;if(c._tdD!==G.day){c._tdD=G.day;c._tdN=0}c._tdN+=1;p.tp=Math.max(p.tp,c._tdN)}}catch(e){}return r}}
{const _ev=endVisit;endVisit=function(c,p){try{if(p&&c&&c._tdD===G.day)p.tp=Math.max(p.tp||0,c._tdN||0)}catch(e){}return _ev.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
