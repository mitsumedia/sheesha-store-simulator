import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== メニューから掃除を選んだ時：メニューを閉じてから掃除を始める ===== */
{const _cs=cleanStart;cleanStart=function(){try{const sh=$("#sheet");if(sh)sh.classList.remove("open")}catch(e){}return _cs.apply(this,arguments)}}
{const _cp=cleanPlay;cleanPlay=function(){try{const sh=$("#sheet");if(sh)sh.classList.remove("open")}catch(e){}return _cp.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
