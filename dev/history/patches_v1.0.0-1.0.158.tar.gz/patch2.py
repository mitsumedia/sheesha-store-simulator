import sys
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=1):
    global s
    c=s.count(old)
    assert c==n,(c,old[:80])
    s=s.replace(old,new)

# ===== 好きなフレーバー：提供時に❤️、解禁時に告知 =====
rep('if(spx(c)){VXRAW=al?1:0;sayX(p,s);VXRAW=0}else say(p,s)}',
    'if(spx(c)){VXRAW=al?1:0;sayX(p,s);VXRAW=0}else say(p,(fav?"❤️ ":"")+s)}')
rep('+mn+(fav?"（好物入り）":"")+" ¥"+pr)}',
    '+mn+(fav?(spx(c)?"（好物入り）":"（好物入り❤️ 親密度アップ）"):"")+" ¥"+pr)}')
rep('log("🍃 新しいフレーバー「"+f[0]+"」（レア"+f[2]+"）が解禁！"+(src?"（"+src+"）":""));',
    'log("🍃 新しいフレーバー「"+f[0]+"」（レア"+f[2]+"）が解禁！"+(src?"（"+src+"）":""));try{flFavNote(i)}catch(e){}')

# ===== 雲紅亭珍光（No.84）の帰り方 =====
rep('function endVisit(c,p){if(spx(c)){if(p&&c.bye&&String(c.bye).trim())',
    'function endVisit(c,p){if(spx(c)){if(p&&c.i!==83&&c.bye&&String(c.bye).trim())')
rep('p.path=p.x<2?[[-6,15]]:[[p.x,15],[2,15],[-6,15]];if(!wasIn)endVisit(c,p)}',
    'p.path=p.x<2?[[-6,15]]:[[p.x,15],[2,15],[-6,15]];if(!wasIn)endVisit(c,p);if(!wasIn&&c.i===83){p.uk={n:0,ph:"r0",w:0,op:p.x<2?[[-8,15],[-8,UKO]]:[[p.x,15],[2,15],[-8,15],[-8,UKO]]};p.path=[];NOGOBI=1;sayX(p,"アラシタ");NOGOBI=0;log("🚪 "+nm(c)+"：アラシタ")}}')
rep('const t=p.path[0];','if(p.uk&&ukMove(p,dt))return;const t=p.path[0];')
rep('if(R.phase==="run"&&R.speed){const dm=dt*6*R.speed;','if(R.phase==="run"&&R.speed&&!R.people.some(p=>p.uk)){const dm=dt*6*R.speed;')

# ===== 強制来店（管理者・招待チケット）：席が空くまで入口の外で待つ =====
rep('while(R.sched.length&&R.sched[0].at<=R.t)arrive(R.sched.shift().m);',
    'while(R.sched.length&&R.sched[0].at<=R.t){const e=R.sched.shift();if(e.force&&(R.away!=null||!pickSeats(e.m))){e.at=R.t+10;R.sched.push(e);R.sched.sort((a,b)=>a.at-b.at);continue}if(e.force&&e.why)log(e.why);arrive(e.m)}')
rep('sched();evStartSched();','sched();evStartSched();try{fcInject()}catch(e){}')

rep('G.day++;appear();','G.day++;try{gaEvMove()}catch(e){}appear();')
rep('営業開始（来店予定 ${R.sched.reduce((s,e)=>s+e.m.length,0)}人）`','営業開始`')
# ===== 図鑑を開いた日を記録 =====
rep('function setTab(t){R.tab=t;','function setTab(t){R.tab=t;if(t==="dex")G.dexSeen=G.day;')

# ===== 管理者モードに「来店客を選ぶ」 =====
rep('<div style="font-weight:700;margin-top:6px">特別イベント</div>',
    '<button data-ad="call" style="display:block;width:100%;margin:2px 0 8px;padding:9px 10px;border-radius:10px;border:1.5px solid #7b4fd6;background:#7b4fd6;color:#fff;font-weight:700;font-size:14px">👥 来店客を選ぶ</button><div style="font-weight:700;margin-top:6px">特別イベント</div>')
rep('if(k==="x"){d.remove();save();log("🛠 管理者モード：フラグ "+admList());if(R.phase==="prep"&&admPreAny())evMorning();return}',
    'if(k==="x"){d.remove();save();log("🛠 管理者モード：フラグ "+admList());if(R.phase==="prep"&&admPreAny())evMorning();return}if(k==="call"){d.remove();save();callPanel();return}')

# ===== 追加の関数群 =====
ADD = r'''
/* ===== トースト ===== */
function toast(t,ms){let w=$("#toastw");if(!w){w=document.createElement("div");w.id="toastw";document.body.appendChild(w)}const d=document.createElement("div");d.className="toast";d.innerHTML=t;w.appendChild(d);setTimeout(()=>{d.style.opacity="0";d.style.transform="translateY(-8px)"},ms||3200);setTimeout(()=>d.remove(),(ms||3200)+500)}
/* ===== 好きなフレーバーの告知（図鑑で好物が見えている客は名前、見えていなければ伏せる） ===== */
function flFavNote(i){const A=G.cs.filter(c=>c.fl===i&&!spx(c)),kn=A.filter(c=>c.met&&lv(c)>2),f=FL[i];if(!f)return;
if(kn.length){const ns=kn.slice(0,3).map(c=>nm(c)==="？？？"?"No."+String(c.i+1).padStart(3,"0")+"のお客さん":nm(c)+"さん").join("、")+(kn.length>3?" ほか"+(kn.length-3)+"人":"");log("💕 「"+f[0]+"」は "+ns+" の好きなフレーバーです！");toast("🍃 「"+esc(f[0])+"」解禁！<br>💕 "+esc(ns)+" の好きなフレーバーです")}
else if(A.some(c=>c.act)){log("💭 「"+f[0]+"」は誰かの好きなフレーバーみたい…");toast("🍃 「"+esc(f[0])+"」解禁！<br>💭 誰かの好きなフレーバーみたい…")}}
/* ===== 雲紅亭珍光：出て行っては戻ってくる。その間は時間が止まり、新しいお客さんも来ない ===== */
const UKO=-14,UKI=4,UKMAX=10,UKL=["帰ります","本当に帰ります","帰りますね","髪切った？","もう来ないよ？","でさ〜ね〜","ママ…","もうええて！","ジェニファーロペスで〜す","帰るねw"];
function ukMove(p,dt){const u=p.uk;if((u.ph==="r0"||u.ph==="r")&&(p.bt>0||p.bq))return true;if(u.ph==="r0"){u.ph="o";p.path=u.op;return false}
if(u.w>0){u.w-=dt;if(u.w>0)return true;u.w=0;
if(u.ph==="w"){u.ph="b";p.path=[[-8,15],[UKI,15]];return false}
if(u.ph==="r"){if(u.n>=2&&(u.n>=UKMAX||Math.random()<.5)){p.uk=null;p.path=[[-6,15]];log("🚪 "+nm(p.c)+" は本当に帰った（戻ってきた回数 "+u.n+"回）")}else{u.ph="o";p.path=[[2,15],[-8,15],[-8,UKO]]}return false}}
if(p.path.length)return false;
if(u.ph==="o"){u.ph="w";u.w=1.1;p.dir=1;return true}
if(u.ph==="b"){u.n++;NOGOBI=1;sayX(p,UKL[Math.min(UKL.length,u.n)-1]);NOGOBI=0;u.ph="r";u.w=.3;p.dir=1;return true}
return false}
/* ===== 強制来店（管理者の「来店客を選ぶ」・招待チケット） ===== */
function fcGroups(ids){const used=new Set(),out=[];ids.forEach(i=>{if(used.has(i))return;const g=GROUPS.find(m=>m.includes(i))||[i];g.forEach(j=>used.add(j));out.push(g.slice())});return out}
function fcPush(grs,why){const ids=new Set(grs.flat());R.sched=R.sched.map(e=>e.force?e:Object.assign({},e,{m:e.m.filter(c=>!ids.has(c.i))})).filter(e=>e.m.length);let t=Math.ceil(R.t)+2;grs.forEach(g=>{const m=g.map(j=>G.cs[j]).filter(c=>c&&!R.people.some(p=>p.c===c&&p.st!=="out"));if(!m.length)return;m.forEach(c=>{c.act=1});R.sched.push({at:t,m,force:1,why});t+=3});R.sched.sort((a,b)=>a.at-b.at)}
function forceCall(ids,why){const grs=fcGroups(ids);grs.flat().forEach(i=>{G.cs[i].act=1});
if(R.phase==="run"&&!R.closed){fcPush(grs,why);log("👥 "+grs.flat().length+"人がまもなく来店します")}
else{G.fcall=(G.fcall||[]).concat(grs.map(g=>({g,why})));log("👥 "+grs.flat().length+"人が次の営業開始直後に来店します")}save()}
function fcInject(){const L=G.fcall||[];if(!L.length)return;G.fcall=[];L.forEach(x=>fcPush([x.g],x.why));save()}
function callPanel(){const old=$("#admc");if(old)old.remove();const d=document.createElement("div");d.id="admc";d.className="xpan";const sel=new Set();
d.innerHTML=`<div class="xin"><div class="xh">👥 来店客を選ぶ</div><div class="xs">選んだお客さんは必ず来店します（来店頻度・出現条件・満席は無視。満席なら席が空くまで外で待ちます）。営業中ならすぐ、開店前なら開店直後に来ます</div><input id="admq" placeholder="名前・番号・職業で検索" style="width:100%;box-sizing:border-box;margin:6px 0"><div id="admcl" class="xl"></div><div class="xb"><button data-cx="back" style="flex:1">戻る</button><button data-cx="go" class="on" style="flex:2" id="admgo">呼ぶ（0人）</button></div></div>`;document.body.appendChild(d);
const draw=()=>{const q=($("#admq").value||"").trim();$("#admcl").innerHTML=G.cs.filter(c=>!q||(c.name+(c.nick||"")+c.job+String(c.i+1).padStart(3,"0")).includes(q)).map(c=>`<label class="xr ${sel.has(c.i)?"on":""}"><input type="checkbox" data-ci="${c.i}" ${sel.has(c.i)?"checked":""}><span class="sw" style="background:${c.shirt}"></span><b>No.${String(c.i+1).padStart(3,"0")}</b> ${esc(c.name)}<small>${esc(c.job)}${c.rar?" ★"+c.rar:""}${c.met?"":"・未登録"}${GROUPS.some(m=>m.includes(c.i))?"・グループ客":""}</small></label>`).join("");$("#admgo").textContent="呼ぶ（"+sel.size+"人）"};draw();
$("#admq").oninput=draw;d.onchange=e=>{const i=e.target.dataset.ci;if(i==null)return;const n=+i;if(e.target.checked)sel.add(n);else sel.delete(n);e.target.closest("label").classList.toggle("on",e.target.checked);$("#admgo").textContent="呼ぶ（"+sel.size+"人）"};
d.onclick=e=>{const b=e.target.closest("[data-cx]");if(!b)return;if(b.dataset.cx==="back"){d.remove();admPanel();return}if(!sel.size){toast("お客さんを選んでください");return}const ids=[...sel];ids.forEach(i=>{const c=G.cs[i];if(!c.met){c.met=1;c.fp+=2}});forceCall(ids,"🛠 管理者が呼んだお客さんが来店");d.remove();toast("👥 "+ids.length+"人を呼びました"+(R.phase==="run"&&!R.closed?"":"（開店直後に来店）"));try{rdex()}catch(e){}}}
/* 顔アイコン（図鑑と同じ顔をキャッシュして一覧に出す） */
const FACEC={};function faceFill(root){const L=[...root.querySelectorAll("img.xf:not([src])")];let k=0;const step=()=>{if(!root.isConnected)return;let cv=$("#fcache");if(!cv){cv=document.createElement("canvas");cv.id="fcache";cv.width=cv.height=120;cv.style.display="none";document.body.appendChild(cv)}for(let n=0;n<6&&k<L.length;n++,k++){const im=L[k],i=+im.dataset.fi;if(!FACEC[i]){try{drawFace("#fcache",G.cs[i]);FACEC[i]=cv.toDataURL()}catch(e){FACEC[i]=""}}if(FACEC[i])im.src=FACEC[i]}if(k<L.length)setTimeout(step,0)};setTimeout(step,0)}
/* ===== 招待チケット ===== */
const TIXM=[30,60,80,100,120,130,140],tixNm=c=>{const n=nm(c);return n==="？？？"?"No."+String(c.i+1).padStart(3,"0"):n};
function tixChk(){if(!G.setup)return;G.tix=G.tix||0;G.tixAw=G.tixAw||0;const met=G.cs.filter(c=>c.met).length;while(G.tixAw<TIXM.length&&met>=TIXM[G.tixAw]){G.tix++;log("🎟 図鑑が"+TIXM[G.tixAw]+"人に！ご褒美で招待チケットを1枚もらった");toast("🎟 図鑑 "+TIXM[G.tixAw]+"人達成！<br>ご褒美に招待チケットを1枚プレゼント");G.tixAw++;save()}}
function tixPanel(){const old=$("#tixp");if(old)old.remove();G.tix=G.tix||0;const d=document.createElement("div");d.id="tixp";d.className="xpan";let pick=null;
const nx=TIXM.find(m=>m>G.cs.filter(c=>c.met).length),pre=R.phase==="prep"&&G.setup&&!G.over,used=G.invD===G.day,q=G.fcall&&G.fcall.some(x=>x.tix);
const why=!pre?"招待チケットは開店前に使えます":used?"今日はもう招待しました（1日1枚まで）":G.tix<=0?"チケットがありません":"";
d.innerHTML=`<div class="xin"><div class="xh">🎟 招待チケット　<span style="font-size:14px">×${G.tix}</span></div><div class="xs">開店前に使うと、営業開始と同時に選んだお客さんが来てくれます（1日1枚まで・図鑑に登録済みのお客さんだけ）。<br>図鑑の登録数が ${TIXM.join("・")}人 になると1枚もらえます${nx?"（次は"+nx+"人）":""}</div>${why?`<div class="xw">${why}</div>`:""}<input id="tixq" placeholder="名前・番号で検索" style="width:100%;box-sizing:border-box;margin:6px 0" ${why?"disabled":""}><div id="tixl" class="xl"></div><div class="xb"><button data-tx="x" style="flex:1">閉じる</button><button data-tx="go" class="on" style="flex:2" id="tixgo" disabled>招待する</button></div></div>`;document.body.appendChild(d);
const draw=()=>{const qq=($("#tixq").value||"").trim(),L=G.cs.filter(c=>c.met&&(!qq||(nm(c)+(c.nick||"")+String(c.i+1).padStart(3,"0")).includes(qq)));$("#tixl").innerHTML=L.length?L.map(c=>`<button class="xr ${pick===c.i?"on":""}" data-ti="${c.i}" ${why?"disabled":""}><img class="xf" data-fi="${c.i}" ${FACEC[c.i]?`src="${FACEC[c.i]}"`:""} alt=""><b>No.${String(c.i+1).padStart(3,"0")}</b> ${esc(nm(c))}${c.rar?`<small style="color:#d4a017">${"★".repeat(c.rar)}</small>`:""}</button>`).join(""):`<div class="xs">まだ図鑑に登録されたお客さんがいません</div>`;faceFill(d);$("#tixgo").disabled=!!why||pick==null;$("#tixgo").textContent=pick==null?"招待する":"🎟 "+tixNm(G.cs[pick])+" を招待する"};draw();$("#tixq").oninput=draw;
d.onclick=e=>{const t=e.target.closest("[data-ti]");if(t){pick=+t.dataset.ti;draw();return}const b=e.target.closest("[data-tx]");if(!b)return;if(b.dataset.tx==="x"){d.remove();return}
if(why||pick==null)return;const c=G.cs[pick];G.tix--;G.invD=G.day;G.fcall=(G.fcall||[]).concat(fcGroups([pick]).map(g=>({g,why:"🎟 招待した "+tixNm(c)+" が来てくれた！",tix:1})));c.act=1;save();log("🎟 招待チケットを使った："+tixNm(c)+"（営業開始と同時に来店）");toast("🎟 "+esc(tixNm(c))+" を招待しました<br>営業開始と同時に来てくれます");d.remove();xrow()}}
/* ===== 広告ガチャ（今はダミー広告。1営業日1回） ===== */
function gaEvList(){return EV.filter(e=>![31,40,42,50].includes(e.id)&&(e.t==="pre"||e.t==="run")&&!(e.once&&(G.evDex||{})[e.id]))}
function gaEvMove(){const g=G.gaEv;if(!g||G.day<=g.day)return;G.admF=G.admF||{};G.admF[g.t]=g.id;G.gaEv=null;save()}
const GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25]];
function gachaOk(k){if(k==="money")return !G.lotto&&G.money>0;if(k==="dex")return G.cs.some(c=>!c.met);if(k==="flv")return flPick(5)>=0;if(k==="fol")return !!G.ow;if(k==="ev")return !G.gaEv&&gaEvList().length>0;return true}
function gachaRoll(){const L=GACHA.filter(([k])=>gachaOk(k));let r=Math.random()*L.reduce((a,b)=>a+b[1],0);for(const[k,w]of L){r-=w;if(r<=0)return k}return L[0][0]}
function gachaGive(k){const o=G.ow;
if(k==="tix"){G.tix=(G.tix||0)+1;log("🎰 ガチャ：招待チケット+1");return["🎟","招待チケット","招待チケットを1枚ゲット！"]}
if(k==="money"){const g=Math.min(G.money,100000);G.money+=g;log("🎰 ガチャ：所持金2倍（+"+yen(g)+"）");return["💰","所持金2倍！",yen(G.money-g)+" → "+yen(G.money)+(g>=100000?"（上限+10万円）":"")]}
if(k==="dex"){const L=G.cs.filter(c=>!c.met),c=L[Math.random()*L.length|0];c.act=1;c.met=1;c.fp+=2;log("🎰 ガチャ：No."+String(c.i+1).padStart(3,"0")+" が図鑑に登録された");return["📖","図鑑に1人登録","No."+String(c.i+1).padStart(3,"0")+" のお客さんが図鑑に登録されました。お店にも来てくれるかも？"]}
if(k==="ev"){const L=gaEvList();let w=L.reduce((a,e)=>a+EVW[e.r],0)*Math.random(),e=L[L.length-1];for(const q of L){w-=EVW[q.r];if(w<=0){e=q;break}}G.gaEv={id:e.id,t:e.t,day:G.day};log("🎰 ガチャ：次の営業日に★"+e.r+"のイベントが起こる");return["⚡","イベント確定！","次の営業日に "+"★".repeat(e.r)+" のイベントが必ず起こります。何が起こるかはお楽しみ"]}
if(k==="flv"){let t=flPick(Math.min(5,flMax()+1));if(t<0)t=flPick(5);const n=flUnlock(t,"ガチャ");return["🍃","フレーバー解禁","新しいフレーバー「"+n+"」を手に入れた！"]}
if(k==="fol"){o.fol+=100;o.star=starOf(o);log("🎰 ガチャ：フォロワー+100");return["📱","フォロワー+100","フォロワー "+(o.fol-100).toLocaleString()+" → "+o.fol.toLocaleString()+"人"]}}
function gachaPanel(){const old=$("#gap");if(old)old.remove();const d=document.createElement("div");d.id="gap";d.className="xpan";const done=G.gaD===G.day,ok=G.setup&&G.ow&&!G.over;
d.innerHTML=`<div class="xin" style="text-align:center"><div class="xh">🎰 広告ガチャ</div><div class="xs">広告を見ると、ガチャを1回まわせます（1営業日に1回）</div><div class="xs" style="text-align:left;background:rgba(123,79,208,.08);border-radius:10px;padding:6px 10px;margin:6px 0">🎟 招待チケット／💰 所持金2倍（上限+10万円）／📖 図鑑に1人登録／⚡ 次の営業日にイベント確定／🍃 フレーバー1種解禁／📱 フォロワー+100</div><div id="gab" style="min-height:120px;display:flex;align-items:center;justify-content:center;flex-direction:column">${done?`<div class="xw">今日はもう回しました。次の営業日にまた回せます</div>`:`<div style="font-size:56px">🎰</div>`}</div><div class="xb"><button data-gx="x" style="flex:1">閉じる</button><button data-gx="ad" class="on" style="flex:2" ${done||!ok?"disabled":""}>📺 広告を見て回す</button></div></div>`;document.body.appendChild(d);
d.onclick=e=>{const b=e.target.closest("[data-gx]");if(!b||b.disabled)return;if(b.dataset.gx==="x"){if(d.dataset.busy)return;d.remove();return}
if(b.dataset.gx==="ad"&&!d.dataset.busy&&G.gaD!==G.day){d.dataset.busy=1;b.disabled=true;d.querySelector('[data-gx="x"]').disabled=true;G.gaD=G.day;save();const box=$("#gab");let n=5;
const tk=()=>{box.innerHTML=`<div style="width:100%;background:#16121c;color:#cfc6dc;border-radius:12px;padding:22px 10px"><div style="font-size:12px;opacity:.7">広告（テスト用のダミー）</div><div style="font-size:30px;margin:6px 0">📺</div><div style="font-size:13px">あと <b>${n}</b> 秒</div></div>`;if(n--<=0){clearInterval(iv);spin()}};const iv=setInterval(tk,1000);tk();
const spin=()=>{const I=["🎟","💰","📖","⚡","🍃","📱"];let c=0;const sp=setInterval(()=>{box.innerHTML=`<div style="font-size:60px">${I[c++%I.length]}</div>`},90);setTimeout(()=>{clearInterval(sp);const r=gachaGive(gachaRoll());save();hud();xrow();box.innerHTML=`<div style="font-size:60px;animation:pop .6s ease">${r[0]}</div><b style="font-size:18px">${esc(r[1])}</b><div class="xs" style="margin-top:4px">${esc(r[2])}</div>`;delete d.dataset.busy;d.querySelector('[data-gx="x"]').disabled=false},1300)}}}}
/* チケット枚数とガチャボタン（雰囲気タグの下） */
function xrow(){const cv=$(".cvw");if(!cv)return;let r=$("#xrow");if(!r){r=document.createElement("div");r.id="xrow";r.innerHTML=`<button id="tixb"></button><button id="gachab"></button>`;cv.appendChild(r);$("#tixb").onclick=e=>{e.stopPropagation();tixPanel()};$("#gachab").onclick=e=>{e.stopPropagation();gachaPanel()}}
$("#tixb").textContent="🎟 招待チケット ×"+(G.tix||0);const ga=G.gaD!==G.day&&G.setup&&!G.over;$("#gachab").textContent=ga?"🎰 ガチャ":"🎰 ガチャ（済）";$("#gachab").classList.toggle("gon",ga);r.hidden=!G.setup}
/* 図鑑リマインド：初回は7日、2回目からは14日、図鑑を開いていないと出す */
const DXL=["たまにはお客様図鑑を確認しよう！<br>あだ名はつけた？","常連さんのこと、どれくらい知ってる？<br>図鑑でプロフィールを見てみよう。<b>あだ名</b>もつけられるよ","最近来てくれたお客さん、覚えてる？<br>お客様図鑑をのぞいてみよう！あだ名はつけた？"];
function dexRemind(){if(!G.setup)return;if(G.dexSeen==null){G.dexSeen=G.day;return}if(G.over||(G.tut||0)<99||TUT||R.phase!=="prep"||!$("#ov").hidden||document.body.classList.contains("mvmode")||$("#adm")||$("#admc")||$("#tixp")||$("#gap")||$("#evp"))return;
if(G.day-G.dexSeen<(G.dexRem?14:7))return;G.dexRem=1;G.dexSeen=G.day;save();tutCard(rnd(DXL),"図鑑を見る","#menu",()=>{const sh=$("#sheet");if(sh)sh.classList.add("open");R.dxm="c";setTab("dex")},{tt:"📖 お客様図鑑"})}
{const _h9=hud;hud=function(){_h9();try{tixChk();xrow();dexRemind()}catch(e){}}}
document.head.insertAdjacentHTML("beforeend",`<style>
#toastw{position:fixed;left:0;right:0;top:calc(var(--th,64px) + 44px);z-index:95;display:flex;flex-direction:column;align-items:center;gap:6px;pointer-events:none;padding:0 16px}
.toast{background:rgba(32,22,48,.92);color:#f6efe4;border-radius:14px;padding:8px 14px;font-size:13px;line-height:1.5;text-align:center;box-shadow:0 6px 18px rgba(0,0,0,.35);transition:opacity .4s,transform .4s;max-width:360px}
#xrow{position:absolute;left:8px;top:30px;z-index:3;display:flex;gap:4px}
#xrow button{font-size:11px;padding:3px 8px;border-radius:999px;border:0;background:rgba(255,255,255,.88);color:#2a2233;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,.2)}
#xrow #gachab.gon{background:#ffcf5a}
body:not(.fs) #xrow{top:auto;bottom:24px}
body.mvmode #xrow{pointer-events:none;opacity:.35}
.xpan{position:fixed;inset:0;z-index:92;background:rgba(10,6,18,.78);display:flex;align-items:center;justify-content:center;padding:12px}
.xpan .xin{background:#fffdf6;color:#2a2233;border-radius:16px;padding:14px;width:100%;max-width:420px;max-height:86vh;display:flex;flex-direction:column}
.xpan .xh{font-weight:800;font-size:17px}
.xpan .xs{font-size:12px;color:#6f6680;line-height:1.5}
.xpan .xw{font-size:13px;color:#c0392b;background:#ffecea;border-radius:8px;padding:6px 8px;margin-top:6px}
.xpan input{color:#2a2233;background:#fff;border:1px solid #ddd}
.xpan .xl{overflow:auto;flex:1;min-height:120px;display:flex;flex-direction:column;gap:3px}
.xpan .xr{display:flex;align-items:center;gap:6px;text-align:left;padding:6px 8px;border-radius:10px;border:1.5px solid #e5ddd0;background:#fff;color:#2a2233;font-size:13px}
.xpan .xr.on{border-color:#7b4fd6;background:#efe6ff}
.xpan .xr small{margin-left:auto;color:#8a8094;font-size:11px}
.xpan .xr .xf{width:34px;height:34px;border-radius:6px;border:2px solid #5a4632;background:#efe6da;flex:none;image-rendering:pixelated}
.xpan .xr .sw{width:12px;height:12px;border-radius:3px;flex:none;margin:0}
.xpan .xb{display:flex;gap:8px;margin-top:10px}.xpan .xb button{padding:10px;border-radius:10px;color:#2a2233;background:#fff;border:1px solid #ddd}.xpan .xb button.on{background:#7b4fd6;color:#fff;border-color:#7b4fd6}
</style>`);
'''
# 末尾のスマホ用シート処理（ビルダーには無い部分）の前に追加する
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
if TAIL in s:
    rep(TAIL, ADD+TAIL)
else:
    i=s.rfind('</script>')
    s=s[:i]+ADD+s[i:]
open(f,'w').write(s)
print('ok')
