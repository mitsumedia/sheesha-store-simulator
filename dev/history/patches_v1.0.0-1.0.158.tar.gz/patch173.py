import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 訪問先の店主：自分の着ぐるみ・装飾品を引き継がず、相手のものを使う
rep('g.ow=Object.assign({},g.ow||{},x.ow||{},{name:x.on,shop:x.n});',
    'g.ow=Object.assign({},g.ow||{});["kg","accE","accH","accM","accCE","accCH","accCM","accCMv","accV","hc2"].forEach(k=>{delete g.ow[k]});{const xo=x.ow||{};if(xo.accE==null){g.ow.accE=+xo.acc||0;g.ow.accCE=xo.accC||"#333333";g.ow.accH=0;g.ow.accM=0}}g.ow=Object.assign(g.ow,x.ow||{},{name:x.on,shop:x.n});')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 友だちの店に遊びに行く：着ぐるみ・装飾品は自分は自分のまま、相手の店主は相手のもの ===== */
{const _vl=visLook;visLook=function(o){const r=_vl.apply(this,arguments);try{o=o||{};["kg","accE","accH","accM","accCE","accCH","accCM","accCMv","hc2"].forEach(k=>{if(o[k]!=null)r[k]=o[k]});if(!R.vis&&G&&o===G.ow){const L=owAccLook(o);r.acc=L.acc;r.accC=L.accC;r.accV=L.accV||null;r.kg=+L.kg||0}}catch(e){}return r}}
{const _al9=owAccLook;owAccLook=function(o){const L=_al9.apply(this,arguments);try{if(R.vis&&o&&o===G.ow){L.kg=+o.kg||0;if(L.kg)L.accV=null}}catch(e){}return L}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
