import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 新ジャンル「レジェンド」
rep('"配達員","シーシャ屋","芸能人"],JSP=["シーシャ屋","芸能人"]','"配達員","シーシャ屋","芸能人","レジェンド"],JSP=["シーシャ屋","芸能人","レジェンド"]')
rep('function spx(c){return!!c&&(c.job==="人外"||c.job==="芸能人"||c.job==="シーシャ屋"||','function spx(c){return!!c&&(c.job==="人外"||c.job==="芸能人"||c.job==="シーシャ屋"||c.job==="レジェンド"||')
rep('const FAMR={"シーシャ屋":[','const FAMR={"レジェンド":["…そうです、たまに呼ばれます笑","昔ちょっとね","今日はただの一般客です笑"],"シーシャ屋":[')
# 新規プレイ用：No.142・143の枠をレジェンド2人に
LEG={141:{"name":"さんてぃ","sex":"男性","job":"レジェンド"},142:{"name":"野郎シーシャ会","sex":"男性","job":"レジェンド"}}
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot'] in LEG:e.update(LEG[e['slot']])
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== レジェンド枠：遊んでいるデータにも反映（来店・親密度などはそのまま引き継ぐ） ===== */
{const LEG=%s;if(!G.leg1){G.cs.forEach(c=>{const u=LEG[c.i];if(u&&!c.ed)Object.assign(c,u)});G.leg1=1;try{save()}catch(e){}}}
/* 図鑑の並び：レジェンド2人は三ツ目（No.151）の直前 */
{const LEGI=[141,142],_dx=dxN;dxN=function(c){const r=_dx(c);if(DXC&&!DXC.leg){const o=Object.keys(DXC.m).map(Number).sort((a,b)=>DXC.m[a]-DXC.m[b]).filter(i=>!LEGI.includes(i));const p=o.indexOf(150);o.splice(p<0?o.length:p,0,...LEGI.filter(i=>DXC.m[i]!=null));o.forEach((i,n)=>{DXC.m[i]=n+1});DXC.leg=1}return DXC.m[c.i]||c.i+1}}
''' % json.dumps({str(k):v for k,v in LEG.items()},ensure_ascii=False)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
