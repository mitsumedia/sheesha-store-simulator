import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ---- やる気イベントの効果を置き換え ----
rep('ef:"やる気+5",ok:()=>evIn().some(p=>p.c.met),go:()=>{motAdd(5)}','ef:"次の日は行動を2回できる",ok:()=>evIn().some(p=>p.c.met),go:()=>{evAct2("常連さんの差し入れ")}')
rep('ef:"やる気+3",go:()=>{motAdd(3)}','ef:"次の日は行動を2回できる",go:()=>{evAct2("家主さんのおそうざい")}')
rep('ef:"やる気+8、今週は雰囲気アップ（客足+10%）",go:()=>{motAdd(8);evx().atm={mo:G.month,m:1.1}}','ef:"会ったことのあるお客さん全員の友好度+5、今週は雰囲気アップ（客足+10%）",go:()=>{evFp(5);evx().atm={mo:G.month,m:1.1}}')
rep('ef:"席がひとつ今日は使えない、やる気−5"','ef:"席がひとつ今日は使えない、お客さん全員の友好度−5"')
rep('go:()=>{const s=rnd(evFree());s.x=1;motAdd(-5)}','go:()=>{const s=rnd(evFree());s.x=1;evFp(-5)}')
rep('ef:"開店が2時間遅れる、やる気−5",ok:()=>G.close-G.open>=4,go:()=>{td().late=120;motAdd(-5)}','ef:"開店が2時間遅れる、お客さん全員の友好度−5",ok:()=>G.close-G.open>=4,go:()=>{td().late=120;evFp(-5)}')
rep('ef:"やる気−20",go:()=>{motAdd(-20)}','ef:"次の日は行動できない",go:()=>{evNoAct("警察の訪問")}')
rep('ef:"やる気−30（ただし30より下にはならない）",go:()=>{motFloor(30)}','ef:"次の日は行動できない",go:()=>{evNoAct("イキリ客")}')
rep('ef:"所持金の10%を失う、やる気−30",go:()=>{const v=G.money>0?Math.round(G.money*.1):0;if(v)evMoney(-v,"空き巣");motAdd(-30)}','ef:"所持金の10%を失う、次の日は行動できない",go:()=>{const v=G.money>0?Math.round(G.money*.1):0;if(v)evMoney(-v,"空き巣");evNoAct("空き巣")}')
rep('ef:"追徴課税で先月の売上の20%を支払う、やる気−30",ok:()=>G.last&&G.last.est>0,go:()=>{evMoney(-Math.round(G.last.est*.2),"追徴課税");motAdd(-30)}','ef:"追徴課税で先月の売上の20%を支払う、次の日は行動できない",ok:()=>G.last&&G.last.est>0,go:()=>{evMoney(-Math.round(G.last.est*.2),"追徴課税");evNoAct("税務署の手紙")}')
rep('ef:"一気に満席。閉店後、やる気−40（ただし30より下にはならない）"','ef:"一気に満席。次の日は行動できない"')
rep('arrive([c]);n++}R.oneop=1;return','arrive([c]);n++}R.oneop=1;evNoAct("ワンオペ地獄");return')
rep('{id:47,r:5,t:"run",n:"元恋人が来店",tx:"「…久しぶり。こんな店やってたんだ」",ef:"やる気が+30か−30",go:()=>{const u=Math.random()<.5;motAdd(u?30:-30);return u?"（なんだか元気が出た！やる気+30）":"（心がざわつく…やる気−30）"}}',
    '{id:47,r:5,t:"run",n:"元恋人が来店",tx:"「…久しぶり。こんな店やってたんだ」",ef:"元恋人の見た目と名前を決めて、図鑑に登録。ときどき来るようになる",once:1,go:()=>"（どんな人だった？）"}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 次の日の行動：2回できる日／できない日 ===== */
function evAct2(why){G.act2D=G.day+1;G.act2W=why}
function evNoAct(why){G.noActD=G.day+1;G.noActW=why}
function evFp(n){G.cs.forEach(c=>{if(!c.met||c.quit)return;const f=c.fp||0;if(n>0)c.fp=f+n;else{const keep=Math.floor(Math.min(f,(typeof NL!=="undefined"?NL:12)*4)/4)*4;c.fp=Math.max(keep,f+n,0)}})}
const act2On=()=>G.act2D===G.day&&G.noActD!==G.day;
{const _sm4=showMorning;showMorning=function(){const o=G.ow;
if(G.noActD===G.day&&canAct()){if(typeof evMorning==="function"&&evMorning())return;if(!canAct())return;o.acted=1;G.actK="none";save();
ov(`<div class="card" style="text-align:center"><div style="font-size:42px">😣</div><b>今日は行動できません</b><div class="m" style="font-size:13px;margin:8px 0;line-height:1.7">昨日の「${esc(G.noActW||"できごと")}」で、今日は何もする気になれない…<br>このまま開店準備をしよう</div><button id="noactok" class="on" style="width:100%">開店準備へ</button></div>`);
const b=$("#noactok");if(b)b.onclick=e=>{e.stopPropagation();ovOff();try{rown();fmAct()}catch(_){}};return}
const r=_sm4.apply(this,arguments);
try{if(act2On()){const box=document.querySelector("#ov .mnc");if(box&&!box.querySelector(".act2b")){const n=G.act2U===G.day?1:2,d=document.createElement("div");d.className="act2b";d.style.cssText="margin:8px 12px 0;padding:8px 10px;border-radius:10px;background:#6658a6;color:#fff;font-weight:900;font-size:13px;text-align:center";d.textContent="🎁 "+(G.act2W||"昨日のできごと")+"のおかげで、今日は2回行動できる！（あと"+n+"回）";const g=box.querySelector(".mg");if(g)g.parentNode.insertBefore(d,g.previousElementSibling||g)}}}catch(e){}
return r}}
{const _ac4=act;act=function(k){const o=G.ow,b4=o&&o.acted;const r=_ac4.apply(this,arguments);
if(o&&!b4&&o.acted&&act2On()&&G.act2U!==G.day&&k!=="visit"&&R.phase==="prep"){G.act2U=G.day;o.acted=0;save();let n=0;const t=setInterval(()=>{n++;if(n>240||R.phase!=="prep"||o.acted){clearInterval(t);return}
if($("#ov").hidden&&!$("#clov")&&!document.querySelector(".xpan")&&!document.querySelector("#sheet.open")){clearInterval(t);try{toast("🎁 もう1回行動できます")}catch(_){}showMorning()}},500)}
return r}}
/* ===== 💔 元恋人：見た目と名前を決めて図鑑へ ===== */
const MOTOL=["…元気そうだね","このフレーバー、昔一緒に吸ったやつ","別に、会いに来たわけじゃないから","…ここ、居心地いいね","あの頃より、ちょっと大人になった？","…まだあのマグカップ使ってる？","たまたま近くを通っただけ","変わってないね、そういうところ"];
function motoEdit(done){const o=G.ow||{},sex=o.sex==="女性"?"男性":"女性",b=mkC(-1,"",sex,1);
R.od={shop:"",name:"",age:o.age||28,sex,eye:b.eye||0,hs:b.hs,hair:b.hair,skin:b.skin,shirt:b.shirt,top:b.top,bot:b.bot,pants:b.pants,acc:0,accC:"#333333",h2:0,t2:0,b2:0};
ov(`<div class="card motof"><b>💔 元恋人ってどんな人？</b><div class="m" style="font-size:12px;margin:4px 0">見た目と名前を決めると、図鑑に登録されて、ときどきお店に来るようになります</div>${ownForm2()}<button id="motook" class="on" style="width:100%;margin-top:8px">この人にする</button></div>`);
try{const n=document.querySelector('#ov .motof [data-ok="name"]');if(n){n.placeholder="名前";n.maxLength=8}const sp=document.querySelector('#ov .motof [data-ok="shop"]');if(sp)sp.closest(".ofrw").remove()}catch(e){}prevO();
const btn=$("#motook");btn.onclick=e=>{e.stopPropagation();const d=R.od;if(!d||!(d.name||"").trim()){toast("名前を入力してください");return}
const c=Object.assign(mkC(G.cs.length,d.name.trim(),d.sex,1),{age:d.age,hs:d.hs,hair:d.hair,skin:d.skin,shirt:d.shirt,top:d.top,bot:d.bot,pants:d.pants,eye:d.eye||0,acc:d.acc||0,accC:d.accC,h2:d.h2|0,t2:d.t2|0,b2:d.b2|0},
{act:1,cu:1,ed:1,g:-1,met:1,fp:0,taps:0,nick:d.name.trim(),hp:10,up:0,quit:0,ret:0,mo:0,moto:1,freq:.5,ap:{k:"start",v:0,p:100},ls:MOTOL.slice()});
G.cs.push(c);G.motoI=c.i;R.od=null;save();ovOff();log("💔 元恋人「"+c.name+"」が図鑑に登録された。ときどき来るみたい…");try{toast("💔 "+c.name+" を図鑑に登録しました")}catch(_){}try{rdex()}catch(_){}done&&done()}}
try{document.head.insertAdjacentHTML("beforeend",`<style>.dxno .moto{margin-left:2px}</style>`)}catch(e){}
{const _ef=evFire;evFire=function(e,after){if(e&&e.id===47&&!G.motoI&&G.cs.length<400)return _ef.call(this,e,r=>motoEdit(()=>after&&after(r)));return _ef.apply(this,arguments)}}
{const _rd=rdex;rdex=function(){const r=_rd.apply(this,arguments);try{document.querySelectorAll(".dxt[data-c]").forEach(el=>{const c=G.cs[+el.dataset.c];if(c&&c.moto){const n=el.querySelector(".dxno");if(n&&!n.querySelector(".moto"))n.insertAdjacentHTML("beforeend",'<span class="moto">💔</span>')}})}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
