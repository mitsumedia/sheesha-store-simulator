import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
GF=json.load(open('/home/claude/w/gifts.json'));BOX=open('/home/claude/w/giftbox.txt').read()
# 非売品をDECに追加（ショップ一覧には出ない：u[0]="gift"）
i=s.find('const DEC=');j=s.find('];',i);arr=json.loads(s[i+10:j+1]);arr+=GF
s=s[:i+10]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))+s[j+1:]
rep('const d=DMD[id];if(!d)return null;','const d=DMD[id]||(String(id).startsWith("gf_")?["e8505b,f7d046",%s]:null);if(!d)return null;'%json.dumps(BOX))
# ---- 置物：持ち物から置くときは無料・月の制限なし・解放条件なし
rep('if(!decOpen(x)){log("🔒 "+decCond(x)+"で解放されます");return}if(plLeft()<=0){','if(!ivF()&&!decOpen(x)){log("🔒 "+decCond(x)+"で解放されます");return}if(!ivF()&&plLeft()<=0){')
rep('if(G.money<x.p){log("お金が足りません");return}G.money-=x.p;plUse();G.decor.push','if(!ivF()&&G.money<x.p){log("お金が足りません");return}if(ivF())ivUse();else{G.money-=x.p;plUse()}G.decor.push')
# ---- 壁アイテム
rep('if(!x)return;if(plLeft()<=0){log("🔒 今月はもう"+PLMAX+"個設置しました。来月まで待ちましょう");return}let k2=null','if(!x)return;if(!ivF()&&plLeft()<=0){log("🔒 今月はもう"+PLMAX+"個設置しました。来月まで待ちましょう");return}let k2=null')
rep('if(G.money<x.p){log("お金が足りません");return}G.money-=x.p;plUse();G.wall.push','if(!ivF()&&G.money<x.p){log("お金が足りません");return}if(ivF())ivUse();else{G.money-=x.p;plUse()}G.wall.push',2)
# ---- 客席
rep('if(!seatOpen(k,sr)){log("🔒 "+seatCond(sr));return}','if(!ivF()&&!seatOpen(k,sr)){log("🔒 "+seatCond(sr));return}')
rep('if(splLeft()<=0){log("🔒 今月はもう客席を"','if(!ivF()&&splLeft()<=0){log("🔒 今月はもう客席を"')
rep('const pr=seatPrice(k,sr);if(G.money<pr){log("お金が足りません");return}','const pr=seatPrice(k,sr);if(!ivF()&&G.money<pr){log("お金が足りません");return}')
rep('G.money-=pr;splUse();G.furn.push(F)','if(ivF())ivUse();else{G.money-=pr;splUse()}G.furn.push(F)')
# ---- 模様替え：売却 → しまう
rep('<button data-mv="sell">💰 売却 +¥${mvPrice(m).toLocaleString()}</button>','<button data-mv="sell">📦 しまう</button>')
rep('if(a==="sell"){const pr=mvPrice(m),nm=mvName(m);if(m.t==="f"){','if(a==="sell"){const nm=mvName(m);if(ivFull()){log("📦 持ち物がいっぱいです（"+IVMAX+"個まで）");return}if(m.t==="f"){')
rep('G.furn.splice(m.i,1)}else if(m.t==="d")G.decor.splice(m.i,1);else G.wall.splice(m.i,1);G.money+=pr;log("💰 "+nm+" を売却 +¥"+pr.toLocaleString());mvOff();mvDone()}',
    'const F=G.furn[m.i];G.inv.push({t:"f",k:F.k,sr:F.sr});G.furn.splice(m.i,1)}else if(m.t==="d"){G.inv.push({t:"d",id:G.decor[m.i].id});G.decor.splice(m.i,1)}else{G.inv.push({t:"w",id:G.wall[m.i].id});G.wall.splice(m.i,1)}log("📦 "+nm+" をしまいました（持ち物 "+G.inv.length+"/"+IVMAX+"）");mvOff();mvDone()}')
rep('🔧 模様替え（移動・回転・売却）','🔧 模様替え（移動・回転・しまう）')
rep('移動・回転・売却（半額）ができます（開店前だけ）。','移動・回転・しまう（📦 持ち物へ）ができます（開店前だけ）。')
# ---- タブとパネル
rep('<button id="rm" class="dcw">','<button data-dc="inv" class="dcw">📦 持ち物</button><button id="rm" class="dcw">')
rep('<div class="card" id="sec-clr" hidden>','<div class="card" id="sec-inv" hidden><div id="ivl"></div></div><div class="card" id="sec-clr" hidden>')
# ---- 話しかけでプレゼント
rep('NOGOBI=1;sayX(p,cl.length?rnd(cl):"……");NOGOBI=0;','NOGOBI=1;sayX(p,cl.length?rnd(cl):"……");NOGOBI=0;giftTry(p);')
rep('if(lv(c)>b)log("📖 "+nm(c)+" の新しい情報が解禁！（図鑑）")}\nfunction endDay(){','giftTry(p);if(lv(c)>b)log("📖 "+nm(c)+" の新しい情報が解禁！（図鑑）")}\nfunction endDay(){')
ADD=r'''
/* ===== 📦 持ち物（インベントリ）：1個=1枠、最大300 ===== */
const IVMAX=300;
function ivInit(){if(!G.inv)G.inv=[];if(!G.ivPend)G.ivPend=[]}
function ivFull(){ivInit();return G.inv.length>=IVMAX}
function ivTool(it){return it.t==="f"?"st:"+it.k+":"+it.sr:it.id}
function ivF(){return!!(R.ivp&&R.ivp.tool===R.tool)}
function ivUse(){ivInit();const p=R.ivp;if(p&&G.inv[p.i]&&ivTool(G.inv[p.i])===p.tool)G.inv.splice(p.i,1);R.ivp=null}
function ivName(it){if(it.t==="f")return seatName({k:it.k,sr:it.sr});const x=(it.t==="w"?WP:DEC).find(q=>q.id===it.id);return x?x.n:"？"}
function ivPrice(it){if(it.t==="f")return Math.floor(seatPrice(it.k,it.sr)/2);const x=(it.t==="w"?WP:DEC).find(q=>q.id===it.id);return x?Math.floor(x.p/2):0}
function ivIcon(it){try{if(it.t==="f")return furnIcon(it.k,it.sr);if(it.t==="d")return decIcon(it.id);const x=WP.find(q=>q.id===it.id);return x?(x.img||(typeof wpThumb==="function"?wpThumb(x):"")):""}catch(e){return""}}
function ivAdd(it){ivInit();if(G.inv.length>=IVMAX){G.ivPend.push(it);return false}G.inv.push(it);return true}
function rinv(){ivInit();const el=$("#ivl");if(!el)return;const c=R.ivc||"d",L={d:"🪴 置物",w:"🖼 壁アイテム",f:"🛋 客席"},gr={};
G.inv.forEach((it,i)=>{if(it.t!==c)return;const k=ivTool(it);(gr[k]=gr[k]||{it,ix:[]}).ix.push(i)});
let h=`<div class="m" style="font-size:12px;margin-bottom:6px">持ち物 <b>${G.inv.length}</b>/${IVMAX}　しまった物・買ってしまった物・お客さんからもらった物が入ります。<b>取り出す</b>を押してから店内をタップすると置けます（お金も、月の設置数もかかりません）</div>`;
if(G.ivPend.length)h+=`<div class="dgh">🎁 受け取り待ち（持ち物がいっぱい）</div>`+G.ivPend.map((it,i)=>`<div class="ivr"><span>${esc(ivName(it))}</span><button data-ivpk="${i}" ${G.inv.length>=IVMAX?"disabled":""}>受け取る</button><button data-ivpx="${i}">捨てる</button></div>`).join("");
h+=`<div class="row" style="margin:4px 0 6px">`+Object.keys(L).map(k=>`<button data-ivc="${k}" class="${c===k?"on":""}">${L[k]}（${G.inv.filter(x=>x.t===k).length}）</button>`).join("")+`</div>`;
const ks=Object.keys(gr);h+=ks.length?ks.map(k=>{const g=gr[k],it=g.it,ic=ivIcon(it),on=R.ivp&&R.ivp.tool===k&&ivF(),gf=it.t==="d"&&String(it.id).startsWith("gf_");return`<div class="ivr ${on?"on":""}">${ic?`<img src="${ic}" alt="">`:"<span class=\"ivn\">📦</span>"}<span>${esc(ivName(it))}${g.ix.length>1?` <b>×${g.ix.length}</b>`:""}${gf?' <small style="color:#d4a017">非売品</small>':""}</span><button data-ivo="${g.ix[0]}" class="${on?"on":""}">${on?"選択中":"取り出す"}</button><button data-ivs="${g.ix[0]}">売る ¥${ivPrice(it).toLocaleString()}</button></div>`}).join(""):`<div class="m" style="font-size:12px;padding:8px 0">まだ何も入っていません</div>`;
el.innerHTML=h}
{const _rd=rdeco;rdeco=function(){_rd();const c=R.dcat||"obj",s=$("#sec-inv");if(s)s.hidden=c!=="inv";if(c==="inv")rinv();
/* 買ってしまう */const e=$("#plc");if(e&&R.tool&&R.tool!=="mv"&&!ivF()){const by=ivBuyInfo(R.tool);if(by)e.innerHTML+=`<div style="margin-top:6px"><button id="ivbuy">📦 「${esc(by.n)}」を買って持ち物にしまう（¥${by.p.toLocaleString()}）</button></div>`}
if(e&&ivF())e.innerHTML+=`<div style="margin-top:6px;color:#2e9d4f">📦 持ち物から「${esc(ivName(G.inv[R.ivp.i]))}」を選択中：置きたい場所をタップ</div>`}}
function ivBuyInfo(t){if(String(t).startsWith("st:")){const[,k,sr]=t.split(":");return{t:"f",k,sr,n:seatName({k,sr}),p:seatPrice(k,sr)}}const w=WP.find(q=>q.id===t);if(w)return{t:"w",id:t,n:w.n,p:w.p};const d=DEC.find(q=>q.id===t);if(d&&d.u[0]!=="gift")return{t:"d",id:t,n:d.n,p:d.p};return null}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("#ivbuy,[data-ivc],[data-ivo],[data-ivs],[data-ivpk],[data-ivpx]");if(!b)return;ivInit();const d=b.dataset;
if(b.id==="ivbuy"){const by=ivBuyInfo(R.tool);if(!by)return;if(ivFull()){log("📦 持ち物がいっぱいです（"+IVMAX+"個まで）");return}
 if(by.t==="f"){if(!seatOpen(by.k,by.sr)){log("🔒 "+seatCond(by.sr));return}if(splLeft()<=0){log("🔒 今月はもう客席を"+SPLMAX+"個買いました。来月まで待ちましょう");return}}
 else{if(by.t==="d"&&!decOpen(DEC.find(q=>q.id===by.id))){log("🔒 まだ解放されていません");return}if(plLeft()<=0){log("🔒 今月はもう"+PLMAX+"個設置しました。来月まで待ちましょう");return}}
 if(G.money<by.p){log("お金が足りません");return}G.money-=by.p;if(by.t==="f")splUse();else plUse();G.inv.push(by.t==="f"?{t:"f",k:by.k,sr:by.sr}:{t:by.t,id:by.id});log("📦 "+by.n+" を買って持ち物にしまいました");R.tool=null;save();hud();rdeco();return}
if(d.ivc){R.ivc=d.ivc;rinv();return}
if(d.ivo!==undefined){const i=+d.ivo,it=G.inv[i];if(!it)return;if(it.t==="f"&&R.phase!=="prep"){log("🛋 客席は開店前に設置できます");return}const t=ivTool(it);if(ivF()&&R.ivp.tool===t){R.tool=null;R.ivp=null}else{if(R.tool==="mv"){try{mvOff()}catch(e){}}R.tool=t;R.ivp={i,tool:t};const sh=$("#sheet");if(sh)sh.classList.remove("open")}rdeco();return}
if(d.ivs!==undefined){const i=+d.ivs,it=G.inv[i];if(!it)return;const pr=ivPrice(it),n=ivName(it);G.inv.splice(i,1);if(R.ivp)R.ivp=null;G.money+=pr;log("💰 "+n+" を売却 +¥"+pr.toLocaleString());save();hud();rdeco();return}
if(d.ivpk!==undefined){const i=+d.ivpk;if(G.inv.length>=IVMAX)return;const it=G.ivPend.splice(i,1)[0];if(it){G.inv.push(it);log("📦 "+ivName(it)+" を持ち物に入れました")}save();rdeco();return}
if(d.ivpx!==undefined){const it=G.ivPend.splice(+d.ivpx,1)[0];if(it)log("🗑 "+ivName(it)+" を捨てました");save();rdeco();return}});
/* ===== 🎁 お客さんからのプレゼント（図鑑No.70〜の82人・1人1種類の非売品） ===== */
const GIFT={};DEC.forEach(x=>{if(x.u&&x.u[0]==="gift")GIFT[x.g]=x});
function giftTry(p){try{const c=p&&p.c;if(!c||!GIFT[c.i])return;if(G.gfD===G.day)return;if(spx(c)?(c.vn||0)<3:c.fp<30)return;if(Math.random()>=.005)return;
G.gfD=G.day;const x=GIFT[c.i],ok=ivAdd({t:"d",id:x.id});const ln="これ、よかったら使ってください";setTimeout(()=>{if(spx(c)){NOGOBI=1;sayX(p,ln);NOGOBI=0}else say(p,ln)},1600);
log("🎁 "+(nm(c)==="？？？"?"お客さん":nm(c)+" さん")+"から「"+x.n+"」をもらった！"+(ok?"（📦 持ち物へ）":"（持ち物がいっぱい：受け取り待ちへ）"));G.gfN=G.gfN||{};G.gfN[x.id]=(G.gfN[x.id]||0)+1;save();if(typeof rdeco==="function")rdeco()}catch(e){}}
'''
CSS='<style>.ivr{display:flex;align-items:center;gap:6px;padding:5px 4px;border-bottom:1px solid rgba(128,128,128,.2);font-size:13px}.ivr>span{flex:1}.ivr img{width:30px;height:30px;object-fit:contain}.ivr .ivn{flex:0 0 30px;text-align:center}.ivr button{font-size:12px;padding:4px 8px}.ivr.on{background:rgba(60,200,100,.15)}</style>'
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T)
s=s.replace('</head>',CSS+'</head>',1)
open(f,'w').write(s);print('ok')
s=open(f).read()
assert s.count('const PLMAX=3;')==1
s=s.replace('const PLMAX=3;','const PLMAX=10;');open(f,'w').write(s);print('plmax10')
