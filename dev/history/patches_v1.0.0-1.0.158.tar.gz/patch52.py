import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
SAN={"sex":"男性","age":60,"hs":0,"hair":"#2a211c","skin":"#e3b994","acc":0,"accC":"#3a2e28","shirt":"#18181b","pants":"#24252b","shoe":"#151515","eye":0,"top":0,"bot":0,"sp":"santy"}
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot']==141:e.update(SAN)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
ADD=r'''
/* ===== さんてぃ（レジェンド）：短い黒髪・メガネ・黒い半袖シャツに紺のインナー ===== */
SPF.santy=({H,Q4,hr})=>{const NV="#1f2a44",CL="#33343a";
 for(let z=6.5;z<7.6;z+=.25){const w=(z-6.5)*.45;for(let x=2-w;x<2+w-.01;x+=.25)Q4(x,3.04,z,NV)}
 for(let z=6.75;z<7.6;z+=.25){Q4(1.5-(z-6.75)*.3,3.06,z,CL);Q4(2.5+(z-6.75)*.3-.25,3.06,z,CL)}
 for(let z=4.5;z<6.5;z+=.5)Q4(2,3.05,z,"#2a2b30",.15);
 H(0,0,6,8,6,1,hr);H(5,4,5,3,2,1,hr);
 /* 細い長方形のメガネ（ボクセルより細かく描く） */
 const G="#3b2f29",s=.125,y=3.03,P=(x,z)=>Q4(x,y,z,G,s),RT=(x0,x1,z0,z1)=>{for(let x=x0;x<=x1+1e-6;x+=s){P(x,z0);P(x,z1)}for(let z=z0;z<=z1+1e-6;z+=s){P(x0,z);P(x1,z)}};
 RT(.375,1.625,9.0,9.625);RT(2.375,3.625,9.0,9.625);for(let x=1.75;x<2.3;x+=s)P(x,9.5);
 for(let yy=1.5;yy<3;yy+=s){Q4(.25,yy,9.5,G,s);Q4(3.625,yy,9.5,G,s)}
};
{const K=%s;if(!G.san1){const c=G.cs[141];if(c&&!c.ed)Object.assign(c,K);G.san1=1;try{save()}catch(e){}}}
''' % json.dumps(SAN,ensure_ascii=False)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
