import sys
f=sys.argv[1]
s=open(f).read()
def rep(old,new,n=1):
    global s
    c=s.count(old)
    assert c==n,(c,old[:90])
    s=s.replace(old,new)

# ===== フレーバーを教えてもらう確率 3% → 1% =====
rep('if(c.fp>=50&&Math.random()<.03){','if(c.fp>=50&&Math.random()<.01){')

# ===== 返済額が最低（3万円）のときは別のアドバイス =====
rep('今月は赤字でした。来月も赤字だと資金が足りなくなるかも。返済額を下げることも考えてみて</div>`:"")',
    '今月は赤字でした。来月も赤字だと資金が足りなくなるかも。${r.bal>0&&G.loan.pay>PAYS[0]?"返済額を下げることも考えてみて":"SNSや置物を見直して、お客さんを増やそう"}</div>`:"")')

# ===== 技術は小数1桁で表示 =====
rep('${Math.round(o.skill)}','${sk1(o.skill)}',2)
rep('dl("技術",r.b0.skill,o.skill,ri)','dl("技術",r.b0.skill,o.skill,sk1)')
rep('const yen=n=>','const sk1=v=>(Math.round(v*10)/10).toFixed(1);const yen=n=>')

# ===== 来店回数を数える（いちばんの常連さん用） =====
rep('m.forEach((c,i)=>{const s=ss[i],first=!c.met;','m.forEach((c,i)=>{const s=ss[i],first=!c.met;c.vt=(c.vt||(first?0:1))+1;')

# ===== 廃業：お金がマイナスのときは専用画面へ =====
rep('<b>所持金がマイナスになりました。廃業です…</b></div><button id="reset0" class="on">最初からやり直す</button>',
    '<b>所持金がマイナスになりました。廃業です…</b></div><button id="goover" class="on">🔒 お店をたたむ…</button>')
rep('function showMotOver(){ov(','function showMotOver(){if(typeof showOver==="function"){ovOff();showOver("mot");return}ov(')

ADD = r'''
/* ===== 通算の記録（廃業画面のまとめ用） ===== */
{const _dd=dayDone;dayDone=function(en){if(!en.closed){G.tvis=(G.tvis||0)+(en.visits||0);G.bestS=Math.max(G.bestS||0,en.sales||0)}return _dd(en)}}
/* ===== シャッター ===== */
function shutterEl(){let d=$("#shut");if(!d){d=document.createElement("div");d.id="shut";d.innerHTML='<div class="sh"><div class="hd"></div></div>';document.body.appendChild(d)}return d}
function shutterDown(cb,ms){const d=shutterEl(),sh=d.querySelector(".sh");d.classList.remove("up");sh.style.transition="none";sh.style.height="0";void sh.offsetHeight;sh.style.transition="height "+((ms||1300)/1000)+"s cubic-bezier(.55,.05,.7,1)";sh.style.height="100%";setTimeout(()=>{if(cb)cb()},(ms||1300)+250)}
function shutterUp(){const d=$("#shut");if(!d||d.dataset.go)return;d.dataset.go=1;const sh=d.querySelector(".sh");sh.style.transition="height .9s cubic-bezier(.3,0,.45,1)";sh.style.height="0";setTimeout(()=>d.remove(),950)}
/* ===== 閉店：店長がひとこと → シャッター → 今日の結果 → 今日のログ ===== */
const CLL=["今日もおつかれ、自分","よし、炭の火を落とすか","また明日も来てくれるといいな","本日の営業、これにて終了！","ふう…いい一日だった","ありがとうございました〜…って誰もいないか","今日の煙も、いい煙だった","片付けて、帰ってシャワー浴びよ"];
{const _ed=endDay;endDay=function(){if(R.clA)return;R.clA=1;R.clT=R.t;R.clL=rnd(CLL);try{say(OW,R.clL)}catch(e){}setTimeout(()=>shutterDown(()=>{R.clA=0;_ed()}),2300)}}
{const _sdl=showDayLog;showDayLog=function(dl,s){_sdl(dl,s);const o=$("#ov"),cd=o&&o.querySelector(".card");if(!cd)return;const k=[...cd.children],li=k.findIndex(x=>/^今日のログ/.test(x.textContent||"")),bt=cd.querySelector("#dlok");if(li<0||!bt)return;const lt=k[li],lb=k[li+1],before=k.slice(0,li);
lt.hidden=true;lb.hidden=true;bt.hidden=true;const nb=document.createElement("button");nb.className="on";nb.style.cssText="width:100%;margin-top:10px";nb.textContent="📝 今日のログを見る（"+dl.length+"件）";cd.appendChild(nb);
nb.onclick=()=>{before.forEach(x=>{x.hidden=true});nb.remove();const h=document.createElement("b");h.textContent="📝 今日のログ（"+dl.length+"件）";h.style.cssText="display:block;margin-bottom:6px";cd.insertBefore(h,lt);lb.hidden=false;lb.style.maxHeight="58vh";bt.hidden=false;o.scrollTop=0}}}
/* 閉店後の画面が全部閉じたらシャッターを上げる */
{const _hs=hud;hud=function(){_hs();if(R.clA&&R.clT!=null){R.t=R.clT;if(R.clL&&OW.bub!==R.clL){OW.bub=R.clL;OW.bk=0}if(R.clL)OW.bt=Math.max(OW.bt||0,.6)}const d=$("#shut");if(d&&!R.clA&&!$("#gov")&&$("#ov").hidden&&R.phase==="prep")shutterUp()}}
/* ===== 店長：暇なときのひとりごと ===== */
const OIDL=["ボトル、磨いておこうかな","新しいミックス、考えちゃお","誰か来ないかな〜","SNSに何載せよう…","BGM変えようかな","看板、もうちょい目立たせたい","この時間がいちばん眠い…","ホース、洗っとくか","お客さんの好み、メモ見返しとこ"];
{const _ot=ownThought;ownThought=function(){if(R.phase==="run"&&inStore()===0&&Math.random()<.6)return rnd(OIDL);return _ot()}}
{const _hi=hud;hud=function(){_hi();try{if(R.phase==="run"&&!R.closed&&!R.clA&&G.ow&&R.speed&&inStore()===0&&!(OW.bt>0)&&!OW.mode){if(R.idT==null)R.idT=R.t+20+Math.random()*30;if(R.t>=R.idT){say(OW,rnd(OIDL));R.idT=R.t+50+Math.random()*60}}else if(inStore()>0)R.idT=null}catch(e){}}}
/* ===== 廃業画面：シャッターが下りて、まとめを出す ===== */
function showOver(why){if($("#gov"))return;ovOff();const o=G.ow||{},met=G.cs.filter(c=>c.met).length,comp=G.cs.filter(c=>lv(c)>=NL).length,days=G.day||0,
best=G.cs.filter(c=>c.met&&!spx(c)).sort((a,b)=>((b.vt||0)-(a.vt||0))||(b.fp-a.fp))[0],tv=(G.tvis||0),bs=Math.max(G.bestS||0,...(G.week||[]).map(d=>d.sales||0)),
st=(k,v)=>`<div class="gs"><div>${k}</div><b>${v}</b></div>`,mo=Math.floor(days/7),dd=days%7,per=(mo?mo+"か月":"")+(dd||!mo?dd+"日":"");
const head=why==="mot"?["🥀 やる気が尽きて廃業…","お客さんも少なく、話す相手もいない日が続き、心が折れてしまいました"]:["💸 資金が尽きて廃業…","所持金が "+yen(G.money)+" になり、お店を続けられなくなりました"];
const BYE=["また、どこかで店やってくださいね","店長のシーシャ、忘れません","次のお店ができたら、一番に行きます","ここ、好きだったんだけどな…"];
const d=document.createElement("div");d.id="gov";d.innerHTML=`<div class="sh"><div class="hd"></div></div><div class="pp"><div style="font-size:12px">お知らせ</div><div style="font-size:16px;margin:4px 0">「${esc(shopNm())}」は<br>閉店いたしました</div><div style="font-size:11px;font-weight:400">長い間ご愛顧いただき<br>ありがとうございました　店主 ${esc(o.name||"")}</div></div>
<div class="cd"><div style="font-weight:800;font-size:16px;margin-bottom:2px">${head[0]}</div><div style="font-size:12px;color:#b9b0c8;margin-bottom:10px">${head[1]}</div>
<div class="gg">${st("営業した期間",per)}${st("のべ来店数",tv.toLocaleString()+"人")}${st("出会ったお客さん",met+" / "+G.cs.length+"人")}${st("図鑑コンプリート",comp+"人")}${st("最高の売上（1日）",yen(bs))}${st("最終の借入残高",yen(G.loan?G.loan.bal:0))}</div>
${best?`<div class="gb"><img class="xf" data-fi="${best.i}" ${FACEC[best.i]?`src="${FACEC[best.i]}"`:""} alt=""><div style="font-size:12px"><div style="color:#ffcf5a;font-weight:700">いちばんの常連さん</div><div>${esc(nm(best))}${best.vt?"（来店 "+best.vt+"回）":""}</div><div style="color:#b9b0c8;font-size:11px">「${rnd(BYE)}」</div></div></div>`:""}
<button id="reset0" class="on" style="width:100%;margin-top:12px;padding:11px;font-weight:800">最初からやり直す</button></div>`;document.body.appendChild(d);faceFill(d);
const sh=d.querySelector(".sh");requestAnimationFrame(()=>{sh.style.height="100%"});setTimeout(()=>d.classList.add("in"),1500)}
document.addEventListener("click",e=>{if(e.target.closest("#goover"))showOver("money")});
setTimeout(()=>{try{if(G.over&&G.setup)showOver(G.overR||"money")}catch(e){}},600);
/* ===== チェキ（1営業日に1回、図鑑の解禁60%以上のお客さんとツーショット） ===== */
const CKQ=(a,x,y,z,col,s)=>a.push([x,y,z,col,undefined,s||.5]);
const CKB=(a,x,y,z,w,d,h,col,s)=>{s=s||.5;for(let i=0;i<w;i+=s)for(let j=0;j<d;j+=s)for(let k=0;k<h;k+=s)CKQ(a,x+i,y+j,z+k,col,s)};
function ckArmX(c,side){const FT=c.fat|0;return side==="L"?(FT===2?-1:FT?-.5:0):(FT===2?4:FT?3.5:3)}
function ckStrip(a,ox,c,Y0){const xs=[ox+ckArmX(c,"L"),ox+ckArmX(c,"R")];return a.filter(v=>!((v[5]===undefined||v[5]===1)&&xs.includes(v[0])&&v[1]>=Y0+1&&v[1]<Y0+3&&v[2]>=5&&v[2]<8))}
function ckArm(a,ox,c,side,kind,hold,dx){const x=ox+ckArmX(c,side),sk=c.skin,sl=(c.top|0)===4?c.skin:c.shirt,out=side==="L"?-1:1;
if(kind==="down"){CKB(a,x,1,6,1,2,2,sl,1);CKB(a,x,1,5,1,2,1,sk,1);return}
CKB(a,x,1,6.5,1,1.5,1.5,sl);
if(kind==="peace"){const hx=x+out,fx=hx-.25*out+.25,gx=hx+.75*out+.25-(out>0?.5:0);CKB(a,x,1.5,7.5,1,1,1,sl);CKB(a,hx,1.5,8,1,1,1.5,sk);[9.5,10,10.5].forEach(z=>{CKQ(a,fx,1.5,z,sk);CKQ(a,gx,1.5,z,sk)});return}
if(kind==="mouth"){CKB(a,x,2.5,6.5,1,1,.5,sk);CKB(a,x,3,7,1,.5,1,sk);if(hold)hold(a,x+(out>0?-.5:.5),3.5,7.5);return}
if(kind==="thumb"){CKB(a,x,2.5,6.5,1,1.5,.5,sk);CKB(a,x,3.5,6.5,1,1,1,sk);CKQ(a,x+(out>0?0:.5),4,7.5,sk);CKQ(a,x+(out>0?0:.5),4,8,sk);return}
if(kind==="hug"){const x0=Math.min(x,x+dx),w=Math.abs(dx)+1;CKB(a,x0,.5,7.5,w,1,.5,sl);CKB(a,x+dx,1,8,1,1.5,.5,sk);CKB(a,x+dx,2.5,7.5,1,.5,.5,sk);return}}
function ckArmW(a,ox,Y0,c,side,kind,hold,dx){const t=[];ckArm(t,ox,c,side,kind,hold,dx);t.forEach(v=>a.push([v[0],v[1]+Y0,v[2],v[3],v[4],v[5]]))}
const ckBurger=(a,x,y,z)=>{CKB(a,x-.5,y,z+1,1.5,1,.5,"#d9a05b");CKB(a,x-.5,y,z+.5,1.5,1,.5,"#5d3a1a");CKB(a,x-.5,y,z,1.5,1,.5,"#e8b06a");CKQ(a,x,y+.5,z+.75,"#6cbf4a")};
const CKP=[["🧍 並んで立つ",{}],["🛋 座って吸う",{sit:1,hd:1,hk:1}],["✌️ ピース",{arms:[["L","peace"],["R","down"]],arms2:[["L","down"],["R","peace"]]}],["👍 グッド",{arms:[["L","thumb"],["R","down"]],arms2:[["L","down"],["R","thumb"]]}],["🤝 肩を組む",{arms:[["L","down"],["R","hug",null,5]],arms2:[["L","down"],["R","down"]],close:1}],["💨 煙を吐く",{sit:1,hd:1,hk:1,smoke:1,ss:2.5}],["🍔 もぐもぐ",{arms:[["L","down"],["R","mouth",ckBurger]],arms2:[["L","mouth",ckBurger],["R","down"]]}]];
function chekiDraw(cv,cust,pi){const pose=CKP[pi][1],c2=cv.getContext("2d"),Wd=cv.width,Hd=cv.height,sv={cam:R.cam,TX,TY,BASE,ox:OW.x,oy:OW.y,pp:R.people,tool:R.tool},gap=pose.close?4:5;
let spot=null;const F=FLT.slice().sort((a,b)=>(b[1]-a[1])||(a[0]-b[0]));for(const[tx,ty]of F){if(!occ(tx,ty)&&FLS.has((tx+1)+","+ty)&&!occ(tx+1,ty)){spot=[tx,ty];break}}if(!spot)spot=FLT[0];
const X0=spot[0]*6+1.5,Y0=spot[1]*6+1;
try{R.people=[];OW.x=-999;OW.y=-999;R.tool=null;TX=X0+(gap+4)/2;TY=Y0+2;R.cam={yaw:.22,pit:.24,zoom:(pose.hk?4.4:4.9)*(Math.min(W,CH*.93)/520)};
draw();const k=camVec(),MC=$("#cv"),cw=Math.min(W,CH*.93),chh=cw*Hd/Wd,sx=(W-cw)/2,sy=CH*.54-chh*.6;
c2.save();c2.filter="blur(1.2px)";c2.drawImage(MC,sx*dpr,sy*dpr,cw*dpr,chh*dpr,0,0,Wd,Hd);c2.restore();c2.fillStyle="rgba(20,10,30,.10)";c2.fillRect(0,0,Wd,Hd);
cx.setTransform(dpr,0,0,dpr,0,0);cx.clearRect(0,0,W,CH);
const ow=Object.assign({},OW.c,G.ow,{i:99}),cu=Object.assign({},cust);let a=[];
if(pose.sit){box(a,X0-.5,Y0,0,gap+5,3,2,"#7a4e2d");box(a,X0-.5,Y0-1,0,gap+5,1,6,"#5e3a1e")}
let p1=[],p2=[];pv(p1,X0,Y0,1,ow,pose.sit?1:0,0,pose.hd?1:0);pv(p2,X0+gap,Y0,1,cu,pose.sit?1:0,0,pose.hd?2:0);
if(pose.hk){const S=.8;[[X0-1.9,1],[X0+gap+5.6,2]].forEach(([hx],n)=>{const hc={x:hx,y:Y0+4.2,rot:0,sc:S};HKV[0].forEach(v=>a.push([v[0]*S+hc.x,v[1]*S+hc.y,v[2]*S,v[3],undefined,(v[5]||1)*S]));hosePush(a,{seat:{px:n?X0+gap:X0,Y0:Y0,f:1}},hc,n?2:1)})}
if(pose.arms){p1=ckStrip(p1,X0,ow,Y0);pose.arms.forEach(([sd,kd,h,dx])=>ckArmW(p1,X0,Y0,ow,sd,kd,h,dx));p2=ckStrip(p2,X0+gap,cu,Y0);pose.arms2.forEach(([sd,kd,h,dx])=>ckArmW(p2,X0+gap,Y0,cu,sd,kd,h,dx))}
a=a.concat(p1,p2);[[X0+2,Y0+2],[X0+gap+2,Y0+2]].forEach(([x,y])=>{const[px,py]=P3(x,y,0,k);cx.fillStyle="rgba(0,0,0,.22)";cx.beginPath();cx.ellipse(px,py,2.6*k.s,1*k.s,0,0,7);cx.fill()});
a.map(v=>({v,d:dep(v,k)})).sort((p,q)=>p.d-q.d).forEach(o=>dv(o.v,k));
if(pose.smoke){const T0=.75,ss=pose.ss||1;[[X0+2],[X0+gap+2]].forEach(([mx],n)=>{const dir=n?1:-1;for(let q=0;q<7;q++){const a2=T0-q*.07;if(a2<0)continue;const o=P3(mx+dir*(.4+a2*(1.4+2.6*ss))+Math.sin(q*2.3)*.4,Y0+3.6+a2*7,8.5+a2*2.6+q*.1,k);cx.fillStyle=`rgba(125,135,155,${.62*(1-a2*.8)})`;cx.beginPath();cx.arc(o[0],o[1],k.s*.3*(1.3+a2*3.6)*ss,0,7);cx.fill()}})}
c2.drawImage(MC,sx*dpr,sy*dpr,cw*dpr,chh*dpr,0,0,Wd,Hd)}catch(e){console.log(e)}
R.cam=sv.cam;TX=sv.TX;TY=sv.TY;BASE=sv.BASE;OW.x=sv.ox;OW.y=sv.oy;R.people=sv.pp;R.tool=sv.tool}
const ckPct=c=>Math.floor(lv(c)/NL*100),ckDate=()=>(Math.floor((G.month||0)/12)+1)+"年目 "+MN[(G.month||0)%12]+"月"+WD[G.wd]+"曜";
function chekiPanel(){const old=$("#ckp");if(old)old.remove();if(!G.setup||G.over)return;const d=document.createElement("div");d.id="ckp";d.className="xpan";const done=G.ckD===G.day;
const L=G.cs.filter(c=>c.met).sort((a,b)=>ckPct(b)-ckPct(a)||a.i-b.i),okN=L.filter(c=>ckPct(c)>=60).length;
d.innerHTML=`<div class="xin"><div class="xh">📸 チェキを撮る</div><div class="xs">誰と撮る？（図鑑の解禁が60%以上のお客さん・1営業日に1回）</div>${done?`<div class="xw">今日はもう撮りました。次の営業日にまた撮れます</div>`:okN?"":`<div class="xw">まだ解禁60%以上のお客さんがいません。話しかけて仲良くなろう</div>`}
<div class="ckg">${L.length?L.map(c=>{const p=ckPct(c),ok=p>=60&&!done;return`<button class="ckt ${ok?"":"lk"}" data-ck="${c.i}" ${ok?"":"disabled"}><span class="cki"><img class="xf" data-fi="${c.i}" ${FACEC[c.i]?`src="${FACEC[c.i]}"`:""} alt="">${p>=60?"":"<i>🔒</i>"}</span><small>${esc(nm(c))}</small><small class="ckpc">${p}%</small></button>`}).join(""):`<div class="xs">まだ図鑑に登録されたお客さんがいません</div>`}</div>
<div class="xb"><button data-cx="x" style="flex:1">閉じる</button></div></div>`;document.body.appendChild(d);faceFill(d);
d.onclick=e=>{if(e.target.closest("[data-cx=x]")){d.remove();return}const t=e.target.closest("[data-ck]");if(!t||t.disabled)return;const c=G.cs[+t.dataset.ck];if(nm(c)==="？？？")ckNick(d,c);else ckShoot(d,c)}}
function ckNick(d,c){d.querySelector(".xin").innerHTML=`<div class="xh">📸 あだ名をつけよう</div><div class="xs">まだ本名を知らないお客さんです。チェキに書くあだ名をつけてください（図鑑にも保存されます）</div><div style="display:flex;justify-content:center;margin:10px 0"><img class="xf" data-fi="${c.i}" ${FACEC[c.i]?`src="${FACEC[c.i]}"`:""} style="width:84px;height:84px;border-radius:14px;background:linear-gradient(160deg,#4fb37a,#24734a);image-rendering:pixelated"></div><input id="cknk" maxlength="12" placeholder="あだ名（12文字まで）" style="width:100%;box-sizing:border-box;padding:10px;font-size:16px"><div class="xb"><button data-nk="b" style="flex:1">戻る</button><button data-nk="ok" class="on" style="flex:2">決定</button></div>`;faceFill(d);
d.onclick=e=>{const b=e.target.closest("[data-nk]");if(!b)return;if(b.dataset.nk==="b"){d.remove();chekiPanel();return}const v=($("#cknk").value||"").trim();if(!v){toast("あだ名を入力してください");return}c.nick=v;save();try{rdex()}catch(_){}ckShoot(d,c)}}
function ckShoot(d,c){let pi=0;const shop=shopNm();
d.querySelector(".xin").innerHTML=`<div class="xh">📸 チェキ</div><div class="ckf" id="ckf"><canvas id="ckc" width="520" height="560"></canvas><div class="ckn"><b>${esc((G.ow||{}).name||"店長")} × ${esc(nm(c))}</b><small>${esc(shop)}　${ckDate()}</small></div></div>
<div class="xs">ポーズ</div><div class="ckps">${CKP.map((p,i)=>`<button class="xr ${i?"":"on"}" data-pz="${i}">${p[0]}</button>`).join("")}</div><div class="xb"><button data-sh="b" style="flex:1">戻る</button><button data-sh="go" class="on" style="flex:2">📸 撮る</button></div>`;
const cv=$("#ckc");chekiDraw(cv,c,0);
d.onclick=e=>{const z=e.target.closest("[data-pz]");if(z){pi=+z.dataset.pz;d.querySelectorAll("[data-pz]").forEach(b=>b.classList.toggle("on",b===z));chekiDraw(cv,c,pi);return}const b=e.target.closest("[data-sh]");if(!b)return;if(b.dataset.sh==="b"){d.remove();chekiPanel();return}
if(G.ckD===G.day){toast("今日はもう撮りました");return}G.ckD=G.day;save();xrow();log("📸 "+nm(c)+" とチェキを撮った");try{motAdd(2)}catch(_){}
const out=document.createElement("canvas"),PW=600,PH=760,g=out.getContext("2d");out.width=PW;out.height=PH;g.fillStyle="#fffefa";g.fillRect(0,0,PW,PH);g.drawImage(cv,40,40,520,560);g.fillStyle="#333";g.textAlign="center";g.font="bold 30px 'Hiragino Maru Gothic ProN','Hiragino Sans',sans-serif";g.fillText(((G.ow||{}).name||"店長")+" × "+nm(c),PW/2,665);g.fillStyle="#888";g.font="20px 'Hiragino Sans',sans-serif";g.fillText(shop+"　"+ckDate(),PW/2,705);
const url=out.toDataURL("image/png"),txt="「"+shop+"」で "+nm(c)+" さんとチェキ📸 #シーシャ屋さん経営";
d.querySelector(".xin").innerHTML=`<div class="xh">📸 撮れた！</div><img src="${url}" alt="チェキ" style="width:100%;max-width:300px;align-self:center;transform:rotate(-1.5deg);box-shadow:0 8px 20px rgba(0,0,0,.35);margin:10px 0"><div class="xs" style="text-align:center">画像を長押しでも保存できます</div><div class="xb"><button data-fin="sh" style="flex:1">📤 画像を共有・保存</button><a class="ckx" href="https://x.com/intent/post?text=${encodeURIComponent(txt)}" target="_blank" rel="noopener">𝕏 に投稿</a></div><div class="xb" style="margin-top:6px"><button data-fin="x" style="flex:1">閉じる</button></div>`;
d.onclick=async e=>{const q=e.target.closest("[data-fin]");if(!q)return;if(q.dataset.fin==="x"){d.remove();return}
const bl=await new Promise(r=>out.toBlob(r,"image/png"));
try{const dl=window.claude&&window.claude.use?await window.claude.use("downloads"):null;if(dl){try{await dl.save({filename:"cheki.png",data:bl});toast("画像を保存しました")}catch(er){if(er&&er.code!=="declined")toast("画像を長押しで保存してください")}return}}catch(_){}
try{const fl=new File([bl],"cheki.png",{type:"image/png"});if(navigator.canShare&&navigator.canShare({files:[fl]})){await navigator.share({files:[fl],text:txt});return}}catch(_){}
try{const a=document.createElement("a");a.href=url;a.download="cheki.png";document.body.appendChild(a);a.click();a.remove()}catch(_){}toast("保存されない場合は、画像を長押しで保存してください")}}}
/* ===== ボタン列：雰囲気タグの下に並べる。チェキボタンを追加 ===== */
{const _xr=xrow;xrow=function(){_xr();const r=$("#xrow");if(!r)return;let b=$("#chekib");if(!b){b=document.createElement("button");b.id="chekib";r.appendChild(b);b.onclick=e=>{e.stopPropagation();chekiPanel()}}const ok=G.ckD!==G.day&&G.setup&&!G.over;b.textContent=ok?"📸 チェキ":"📸 チェキ（済）";b.classList.toggle("done",!ok);
try{const a=$("#atm").getBoundingClientRect(),c=$(".cvw").getBoundingClientRect();if(a.height)r.style.top=Math.round(a.bottom-c.top+6)+"px"}catch(_){}}}
document.head.insertAdjacentHTML("beforeend",`<style>
.fs #atm{flex-wrap:wrap!important;row-gap:3px}
#xrow{flex-wrap:wrap;right:84px}
#xrow #chekib{background:#ff8fb1;color:#2a2233}#xrow #chekib.done{background:rgba(255,255,255,.88);opacity:.75}
#shut{position:fixed;inset:0;z-index:9;pointer-events:none}
body:has(#shut) #ov{background:rgba(20,10,35,.22)}
#shut .sh,#gov .sh{position:absolute;left:0;right:0;top:0;height:0;background:repeating-linear-gradient(180deg,#8d949c 0 18px,#6f767e 18px 21px,#a3aab2 21px 24px);box-shadow:0 6px 0 #3d4248,0 10px 30px rgba(0,0,0,.6);overflow:hidden}
#shut .sh::after,#gov .sh::after{content:"";position:absolute;left:0;right:0;bottom:0;height:16px;background:linear-gradient(#585e65,#2f3338)}
#shut .hd,#gov .hd{position:absolute;left:50%;bottom:22px;transform:translateX(-50%);width:70px;height:8px;border-radius:4px;background:#2f3338}
#gov{position:fixed;inset:0;z-index:120;overflow:auto;font-family:inherit;color:#f1ecf8}
#gov .sh{transition:height 1.4s cubic-bezier(.55,.05,.7,1)}
#gov .pp,#gov .cd{opacity:0;transition:opacity .6s}#gov.in .pp,#gov.in .cd{opacity:1}
#gov .pp{position:absolute;left:50%;top:14%;transform:translateX(-50%) rotate(-2deg);background:#fffdf3;color:#2a2233;padding:12px 18px;border-radius:4px;box-shadow:0 4px 10px rgba(0,0,0,.4);text-align:center;font-weight:700;line-height:1.6;width:230px}
#gov .cd{position:absolute;left:14px;right:14px;top:36%;max-width:420px;margin:0 auto;background:rgba(20,14,30,.93);border-radius:16px;padding:14px;box-shadow:0 10px 30px rgba(0,0,0,.5);margin-bottom:20px}
#gov .gg{display:grid;grid-template-columns:1fr 1fr;gap:6px}#gov .gs{background:rgba(255,255,255,.07);border-radius:10px;padding:6px 8px}#gov .gs div{font-size:10px;color:#b9b0c8}#gov .gs b{font-size:16px}
#gov .gb{display:flex;align-items:center;gap:10px;margin-top:10px;background:rgba(255,207,90,.12);border-radius:10px;padding:8px}#gov .gb img{width:46px;height:46px;image-rendering:pixelated;border-radius:8px;background:#4a74c9;flex:none}
.ckg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:8px;overflow:auto;flex:1;min-height:120px;align-content:start}
.ckt{display:flex;flex-direction:column;align-items:center;gap:2px;padding:0;border:0;background:none;color:#2a2233;min-width:0}
.ckt .cki{position:relative;width:100%;aspect-ratio:1;border-radius:14px;background:linear-gradient(160deg,#4fb37a,#24734a);overflow:hidden;display:block}
.ckt .cki img{width:100%;height:100%;image-rendering:pixelated}.ckt .cki i{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:20px;font-style:normal}
.ckt.lk{opacity:.4}.ckt.lk .cki{background:#3a4256}
.ckt small{font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;text-align:center}.ckt .ckpc{color:#888;font-size:9px}
.ckf{background:#fff;padding:10px 10px 0;border-radius:4px;box-shadow:0 8px 20px rgba(0,0,0,.35);transform:rotate(-1.5deg);margin:8px auto 10px;width:240px}
.ckf canvas{width:100%;display:block}.ckf .ckn{height:52px;display:flex;flex-direction:column;justify-content:center;align-items:center;color:#333}.ckf .ckn b{font-size:14px}.ckf .ckn small{font-size:10px;color:#888}
.ckps{display:flex;gap:6px;overflow-x:auto;padding:4px 0}.ckps .xr{flex:none}
.ckx{flex:1;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#111;color:#fff!important;text-decoration:none;font-weight:700;padding:10px}
body.mvmode #chekib{pointer-events:none}
</style>`);
'''
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
if TAIL in s: rep(TAIL, ADD+TAIL)
else:
    i=s.rfind('</script>'); s=s[:i]+ADD+s[i:]
open(f,'w').write(s)
print('ok')
