import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 軽量モードの判定：描画にかかる時間だけで決める（画面の更新間隔は見ない）。14ms以上が4秒続いたら
rep('if(L.dw>12||L.fi>24)L.bad+=st;else L.bad=Math.max(0,L.bad-st*2);if(L.bad>3000){R.lite=1;try{fitCv()}catch(e){}}','if(L.dw>14&&!G.liteNo)L.bad+=st;else L.bad=Math.max(0,L.bad-st*2);if(L.bad>4000){R.lite=1;try{fitCv()}catch(e){}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* 軽量モード中の表示と解除 */
{const _mc2=mvCard;mvCard=function(){_mc2.apply(this,arguments);const c=$("#mvcard");if(!c||!R.lite)return;c.insertAdjacentHTML("beforeend",`<div style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:12.5px"><div style="flex:1;color:var(--mut)">⚡ 軽量モード中（動きを少なめにしています）</div><button id="litoff" style="flex:none">解除する</button></div>`)}}
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest("#litoff")){e.stopPropagation();R.lite=0;G.liteNo=1;try{LITE.bad=0;fitCv()}catch(_){}save();mvCard();toast("軽量モードを解除しました")}},true);
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
