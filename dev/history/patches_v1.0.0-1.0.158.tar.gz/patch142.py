import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 景品の割合：フォロワー・イベント 45%／チケット・フレーバー 33%／チェキ素材・図鑑 15%／着せ替え 7%。所持金2倍は廃止
rep('GACHA=[["tix",15],["money",5],["dex",10],["ev",25],["flv",20],["fol",25],["deco",8],["ow",10]]',
    'GACHA=[["fol",22.5],["ev",22.5],["tix",16.5],["flv",16.5],["deco",7.5],["dex",7.5],["ow",7]]')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== ガチャ専用画面（ボクセルのシーシャ台が点火→煙→カード） ===== */
const GTH={fol:["#4a7de0","#cfe0ff","フォロワー"],ev:["#8e5bd6","#e6d6ff","イベント"],tix:["#e0558f","#ffd6e8","招待チケット"],flv:["#3aa86a","#d6f5e2","フレーバー"],deco:["#2bb3c9","#d2f4f9","チェキ素材"],dex:["#e08a2b","#ffe6c8","図鑑"],ow:["#f0b93a","#fff0b0","着せ替え"]};
const GNEW={ow:1,deco:1,flv:1,dex:1};
function gvr(g,vox,ang,ox,oy,sc,cx,cy,cz,LT){LT=LT||[1,.78,.62];const co=Math.cos(ang),si=Math.sin(ang),shd=(hex,k)=>{const n=parseInt(hex.slice(1),16),f=c=>Math.max(0,Math.min(255,Math.round(c*k)));return`rgb(${f(n>>16&255)},${f(n>>8&255)},${f(n&255)})`};
 const pr=(x,y,z)=>{const dx=x-cx,dy=y-cy,X=co*dx-si*dy,Y=si*dx+co*dy;return[ox+(X-Y)*.866*sc,oy-(z-cz)*sc+(X+Y)*.42*sc]};
 const L=vox.map(v=>{const s=v[5]||1,dx=v[0]+s/2-cx,dy=v[1]+s/2-cy;return[(co*dx-si*dy)+(si*dx+co*dy),v[2],v]}).sort((p,q)=>p[0]-q[0]||p[1]-q[1]);
 const fx=co+si>0,fy=co-si>0,poly=(p,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(p[0][0],p[0][1]);for(let i=1;i<4;i++)g.lineTo(p[i][0],p[i][1]);g.closePath();g.fill();g.strokeStyle=c;g.lineWidth=.6;g.stroke()};
 for(const[,,v]of L){const s=v[5]||1,x=v[0],y=v[1],z=v[2],c=v[3],a0=pr(x,y,z+s),a1=pr(x+s,y,z+s),a2=pr(x+s,y+s,z+s),a3=pr(x,y+s,z+s),b0=pr(x,y,z),b1=pr(x+s,y,z),b2=pr(x+s,y+s,z),b3=pr(x,y+s,z);
  if(fx)poly([a1,a2,b2,b1],shd(c,LT[1]));else poly([a0,a3,b3,b0],shd(c,LT[1]));if(fy)poly([a3,a2,b2,b3],shd(c,LT[2]));else poly([a0,a1,b1,b0],shd(c,LT[2]));poly([a0,a1,a2,a3],shd(c,LT[0]))}}
const gbox=(v,x0,x1,y0,y1,z0,z1,c,s)=>{s=s||.5;for(let x=x0;x<x1-1e-6;x+=s)for(let y=y0;y<y1-1e-6;y+=s)for(let z=z0;z<z1-1e-6;z+=s)v.push([x,y,z,c,0,s])};
const gcyl=(v,cx,cy,r,z0,z1,c,s,hol)=>{s=s||.5;for(let x=cx-r;x<cx+r;x+=s)for(let y=cy-r;y<cy+r;y+=s){const d=Math.hypot(x+s/2-cx,y+s/2-cy);if(d>r||(hol&&d<r-hol))continue;for(let z=z0;z<z1-1e-6;z+=s)v.push([x,y,z,c,0,s])}};
function gMachine(t,st){const v=[];gcyl(v,0,0,9,0,1,"#3b2a1e",1);gcyl(v,0,0,8,1,1.5,"#5a3f2b",.5);
 const prof=z=>z<2?4.2:z<6?4.6-.15*(z-2):z<9?4-.8*(z-6):1.4;for(let z=1.5;z<11;z+=.5){const r=prof(z-1.5),w=z<6.5;gcyl(v,0,0,r,z,z+.5,w?st.water:"#cfeef3",.5,w?0:.6)}
 if(st.bub)for(let i=0;i<10;i++){const p=(i*.37+t*1.3)%1;v.push([-2+(i*1.7)%4,-1+(i%3),1.5+p*5,"#ffffff",0,.5])}
 gcyl(v,0,0,.7,11,21,"#c9cdd4",.5);gbox(v,-1.5,1.5,-1.5,1.5,15,15.5,"#9aa0aa");gbox(v,-2.5,2.5,-2.5,2.5,17.5,18,"#d9d9d9");
 for(let i=0;i<24;i++){const a=i/23;v.push([1+a*7,Math.sin(a*3)*1.5,16-a*13+Math.sin(a*3.1)*2,"#6658a6",0,1])}
 for(let z=21;z<24;z+=.5)gcyl(v,0,0,1.4+(z-21)*.6,z,z+.5,"#b5553a",.5);gcyl(v,0,0,3.6,24,24.5,"#e2e2e2",.5);
 const ig=st.ig,h=x=>Math.max(0,Math.min(255,x|0)).toString(16).padStart(2,"0"),cc=ig<=0?"#2a2a2a":"#"+h(255*ig+40*(1-ig))+h(110*ig+40*(1-ig)+30*Math.sin(t*14)*ig)+h(30);
 [[-2,-1],[1,-1.5],[-.5,1]].forEach(([x,y])=>gbox(v,x,x+1.5,y,y+1.5,24.5,25.5,cc));
 st.sparks.forEach(([x,y,z])=>v.push([x,y,z,"#ffb347",0,.5]));st.smoke.forEach(([x,y,z,s,c])=>v.push([x,y,z,c,0,s]));return v}
function gCard(col,lt){const v=[],s=.5,Wc=11,Hc=15,Q=[".XXX.","X...X","....X","...X.","..X..","..X..",".....","..X.."];
 for(let x=0;x<Wc;x+=s)for(let z=0;z<Hc;z+=s){const fr=x<1||x>=Wc-1||z<1||z>=Hc-1;let b="#4b3f8a";if(fr)b="#ffffff";else{const qx=Math.floor(x-3),qr=Q[Math.floor(11.5-z)]||"";if(qx>=0&&qr[qx]==="X")b="#ffffff";else if(((x*2+z*2)|0)%4===0)b="#5a4d9e"}v.push([x,0,z,b,0,s]);
  let f=fr?(((x*2+z*2)|0)%3===0?lt:col):(z>=3&&z<13&&x>=1.5&&x<9.5)?"#fffdf6":col;v.push([x,s,z,f,0,s])}return v}
function gachaPanel(){const old=$("#gap");if(old)old.remove();const done=G.gaD===G.day,ok=G.setup&&G.ow&&!G.over;
 const d=document.createElement("div");d.id="gap";d.style.cssText="position:fixed;inset:0;z-index:300;background:#0c1b19;overflow:hidden;touch-action:none";
 d.innerHTML=`<canvas id="gacv" style="position:absolute;inset:0;width:100%;height:100%"></canvas>
<div style="position:absolute;left:14px;right:14px;top:calc(env(safe-area-inset-top,0px) + 12px);height:58px;border-radius:18px;background:#005d4d;display:flex;align-items:center;justify-content:space-between;padding:0 12px 0 16px;font-family:'Dela Gothic One',sans-serif;color:#fff;font-weight:900"><span style="font-size:19px;letter-spacing:1px">SHISHA GACHA</span><button data-gx="list" style="background:#6658a6;color:#fff;border:0;border-radius:16px;padding:7px 12px;font-weight:900;font-size:12px">景品一覧</button></div>
<div id="galist" hidden style="position:absolute;left:14px;right:14px;top:calc(env(safe-area-inset-top,0px) + 78px);background:#f3f1ea;color:#123a33;border-radius:14px;padding:10px 12px;font-size:12px;line-height:1.8;z-index:3"></div>
<div id="gamsg" style="position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 92px);text-align:center;color:#ffd86b;font-weight:900;font-size:20px;pointer-events:none"></div>
<div id="gares" style="position:absolute;left:24px;right:24px;bottom:calc(env(safe-area-inset-bottom,0px) + 104px);text-align:center;color:#fff;pointer-events:none"></div>
<div id="gabtn" style="position:absolute;left:16px;right:16px;bottom:calc(env(safe-area-inset-bottom,0px) + 22px);display:flex;gap:10px"></div>`;
 document.body.appendChild(d);
 const cvs=$("#gacv"),g=cvs.getContext("2d");let W=0,H=0;const fit=()=>{const r=d.getBoundingClientRect(),dp=Math.min(2,window.devicePixelRatio||1);W=r.width;H=r.height;cvs.width=W*dp|0;cvs.height=H*dp|0;g.setTransform(dp,0,0,dp,0,0)};fit();
 let seed=11;const RN=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
 const bok=[...Array(16)].map(()=>[RN(),RN()*.75,10+RN()*26,RN()]),spS=[...Array(30)].map(()=>[RN()*2-1,RN()*2-1,RN(),RN()]),smS=[...Array(60)].map(()=>[RN(),RN()*2-1,RN()*2-1,RN()]),conf=[...Array(70)].map(()=>[RN(),-RN()*300,RN()*6.28,RN(),["#f5c542","#ff6fb1","#6fd3ff","#7ee08a","#ffffff","#b08cff"][RN()*6|0]]);
 const E=t=>t<0?0:t>1?1:t,ease=t=>1-Math.pow(1-E(t),3),io=t=>{t=E(t);return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2};
 let st="idle",t0=0,res=null,kk=null,card=null,raf=0;const sc0=()=>Math.min(W/390,H/844);
 const btns=()=>{const b=$("#gabtn");if(!b)return;const B=(k,txt,on,dis)=>`<button data-gx="${k}" ${dis?"disabled":""} style="flex:1;height:58px;border-radius:29px;border:${on?"0":"2px solid #fff"};background:${on?"#6658a6":"#fff"};color:${on?"#fff":"#005d4d"};font-weight:900;font-size:16px;${dis?"opacity:.5":""}">${txt}</button>`;
  if(st==="idle")b.innerHTML=B("x","とじる",0)+(done||G.gaD===G.day?B("none","今日はもう回しました",1,1):B("ad","▶ 広告を見て回す",1,!ok));
  else if(st==="anim")b.innerHTML=`<div style="flex:1"></div><button data-gx="skip" style="height:38px;border-radius:19px;border:0;background:rgba(255,255,255,.15);color:#fff;font-weight:900;padding:0 16px">スキップ ▶▶</button>`;
  else if(st==="res")b.innerHTML=B("x","とじる",0)+(kk==="ow"?B("try","着せ替えで試す ▶",1):"");else b.innerHTML=""};
 const draw=now=>{if(!document.body.contains(d))return;const t=st==="anim"||st==="res"?(now-t0)/1000:0,s0=sc0(),cx=W/2,th=GTH[kk]||["#f0b93a","#fff0b0"],col=t>2.6&&kk?th[0]:null;
  g.clearRect(0,0,W,H);const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,"#0c1b19");bg.addColorStop(1,"#1d3d36");g.fillStyle=bg;g.fillRect(0,0,W,H);
  bok.forEach(([x,y,r,p])=>{g.fillStyle=`rgba(255,${200+p*40|0},130,${.05+.04*Math.sin(now/700+p*6)})`;g.beginPath();g.arc(x*W,y*H,r,0,7);g.fill()});
  const my=H*.74,tg=g.createRadialGradient(cx,my,10,cx,my,190*s0);tg.addColorStop(0,col?col+"66":"rgba(102,88,166,.38)");tg.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=tg;g.fillRect(0,0,W,H);
  const ig=st==="idle"?0:ease((t-.3)/.8),sparks=[],smoke=[];
  if(t>.3&&t<1.9)spS.forEach(([vx,vy,dd])=>{const lt=t-.3-dd*.6;if(lt<0||lt>.9)return;sparks.push([vx*6*lt,vy*6*lt,25.5+14*lt-14*lt*lt])});
  if(t>1.1)smS.forEach(([dd,sx,sy,p])=>{const lt=t-1.1-dd*1.5;if(lt<0||lt>2.6)return;const sz=lt<.6?.5:lt<1.4?1:1.5;const z=26+lt*9,x=sx*(1+lt*3)+Math.sin(lt*2+p*6)*1.5,y=sy*(1+lt*2.4);const c=t>2.6&&kk?[th[0],th[1],"#ffffff"][(p*3)|0]:["#e9eef2","#ffffff","#d7dde2"][(p*3)|0];smoke.push([Math.round(x*2)/2,Math.round(y*2)/2,Math.round(z*2)/2,sz,c])});
  const shake=(t>.3&&t<2.7&&st==="anim")?Math.sin(now/16)*1.2:0;
  gvr(g,gMachine(now/1000,{water:col||"#7f6fc4",ig,bub:t>1.1&&t<3.4,sparks,smoke}),5.62+Math.sin(now/1400)*.06,cx+shake,my,10.5*s0,0,0,0);
  if(t>2.55&&t<3.0&&kk){g.fillStyle=`rgba(255,250,230,${(1-(t-2.55)/.45)*.7})`;g.fillRect(0,0,W,H)}
  if(t>3.0&&card){const k=ease((t-3.0)/.9),cy=-260*s0+k*(H*.47+260*s0),fl=io((t-4.0)/.7),a=5.62+Math.PI*(1-fl);
   if(t>4.4){g.save();g.translate(cx,cy-70*s0);g.rotate(now/1600);for(let i=0;i<12;i++){g.rotate(Math.PI/6);g.fillStyle=`rgba(255,240,200,${.14*E((t-4.4)/.4)})`;g.beginPath();g.moveTo(0,0);g.lineTo(-24,-H);g.lineTo(24,-H);g.closePath();g.fill()}g.restore()}
   gvr(g,card,a,cx,cy,15*s0,5.5,.5,7.5,[1.05,.85,1]);
   if(fl>=1&&res){const k2=ease((t-4.7)/.35);g.save();g.globalAlpha=k2;g.font=`${Math.round(70*s0)}px sans-serif`;g.textAlign="center";g.textBaseline="middle";g.fillText(res[0],cx-4*s0,cy-62*s0);g.restore();
    if(GNEW[kk]&&t>4.8){const k3=ease((t-4.8)/.3);g.save();g.translate(cx+92*s0,cy-150*s0);g.rotate(-.2);g.scale(k3,k3);g.fillStyle="#ff3b6b";g.beginPath();g.roundRect?g.roundRect(-34,-16,68,32,16):g.rect(-34,-16,68,32);g.fill();g.font="900 16px sans-serif";g.fillStyle="#fff";g.textAlign="center";g.textBaseline="middle";g.fillText("NEW!",0,1);g.restore()}}}
  if(t>4.8&&st!=="idle")conf.forEach(([x,y0,a,p,c])=>{const lt=t-4.8,y=y0+lt*(180+p*120),xx=x*W+Math.sin(lt*3+p*6)*20;if(y>H)return;g.save();g.translate(xx,y);g.rotate(a+lt*5);g.fillStyle=c;g.fillRect(-4,-4,8,8);g.restore()});
  if(st==="anim"&&t>=5){st="res";btns();const rs=$("#gares");if(rs&&res)rs.innerHTML=`<div style="display:inline-block;background:rgba(0,0,0,.55);border-radius:14px;padding:10px 16px"><b style="font-size:18px">${esc(res[1])}</b><div style="font-size:12.5px;color:#d9f2ea;margin-top:4px">${esc(res[2])}</div></div>`}
  const m=$("#gamsg");if(m){const tx=st==="anim"&&t>2.6&&t<3.6&&kk?"！？ 煙の色が変わった…":"";if(m.textContent!==tx)m.textContent=tx}
  raf=requestAnimationFrame(draw)};
 const start=()=>{st="anim";kk=gachaRoll();res=gachaGive(kk);save();try{hud();xrow()}catch(e){}card=gCard(GTH[kk][0],GTH[kk][1]);t0=performance.now();btns()};
 d.onclick=e=>{const b=e.target.closest("[data-gx]");if(!b||b.disabled)return;const k=b.dataset.gx;
  if(k==="x"){if(st==="anim"||st==="ad")return;cancelAnimationFrame(raf);d.remove();return}
  if(k==="list"){const L=$("#galist");if(L.hidden){const tot=GACHA.filter(([q])=>gachaOk(q)).reduce((a,b)=>a+b[1],0)||1;L.innerHTML=GACHA.map(([q,w])=>{const on=gachaOk(q);return`<div style="display:flex;justify-content:space-between;${on?"":"opacity:.4"}"><span>${{fol:"📱 フォロワー+100",ev:"⚡ 次の営業日にイベント確定",tix:"🎟 招待チケット+1",flv:"🍃 フレーバー1種解禁",deco:"📸 チェキの限定素材",dex:"📖 図鑑に1人登録",ow:"👕 着せ替え"}[q]}${q==="ow"?`（${OWG.filter(x=>owHas(x)).length}/${OWG.length}）`:""}</span><b>${on?(w/tot*100).toFixed(1)+"%":"コンプリート"}</b></div>`}).join("")+`<div style="font-size:11px;color:#6b7f7a;margin-top:4px">持っているものは出ません。全部そろった景品は抽選から外れます</div>`}L.hidden=!L.hidden;return}
  if(k==="skip"){if(st==="anim")t0=performance.now()-4800;return}
  if(k==="try"){cancelAnimationFrame(raf);d.remove();try{$("#sheet").classList.add("open");fmTab("owner");setTimeout(()=>{const b2=document.querySelector('[data-owk="edit"]');b2&&b2.click()},120)}catch(_){}return}
  if(k==="ad"&&G.gaD!==G.day&&ok){st="ad";G.gaD=G.day;save();btns();let n=5;const box=document.createElement("div");box.style.cssText="position:absolute;inset:0;z-index:5;background:rgba(10,8,16,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#cfc6dc";d.appendChild(box);
   const tk=()=>{box.innerHTML=`<div style="font-size:12px;opacity:.7">広告（テスト用のダミー）</div><div style="font-size:40px;margin:8px 0">📺</div><div style="font-size:14px">あと <b>${n}</b> 秒</div>`;if(n--<=0){clearInterval(iv);box.remove();start()}};const iv=setInterval(tk,1000);tk()}};
 window.addEventListener("resize",fit);btns();raf=requestAnimationFrame(draw)}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
