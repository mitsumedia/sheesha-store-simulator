import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 季節の客足（閑散期 9・2月 −20%／繁忙期 8・12月 +20%）
rep('const wxm=()=>WXI[G.wx[G.wd]][2]*(G.ev[G.wd]?G.ev[G.wd].m:1);','const seaM=()=>{const m=MN[G.month%12];return m===9||m===2?.8:m===8||m===12?1.2:1};const wxm=()=>WXI[G.wx[G.wd]][2]*(G.ev[G.wd]?G.ev[G.wd].m:1)*seaM();')
rep('（${SEA(MN[G.month%12])}）','（${SEA(MN[G.month%12])}）${seaM()<1?\'<span class="neg" style="font-size:11px">閑散期 客足×0.8</span>\':seaM()>1?\'<span class="pos" style="font-size:11px">繁忙期 客足×1.2</span>\':""}')
# 精算画面に税金の行
rep('-r.pay+(r.s2?r.s2.net:0);','-r.pay+(r.s2?r.s2.net:0)-(r.txp||0);')
rep('${typeof s2Rows==="function"?s2Rows(r,row):""}${row("今回の収支"','${typeof s2Rows==="function"?s2Rows(r,row):""}${typeof taxRows==="function"?taxRows(r,row):""}${row("今回の収支"')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 確定申告（1〜12月分を翌2月に納付。払えない分は延滞金10%で3月から分割） ===== */
function taxInit(){if(!G.tax)G.tax={acc:{},cnt:{},due:null,ar:0,ins:0,n:0}}
const calY=m=>Math.floor((m+3)/12);
function calcTax(inc){inc=Math.round(inc);if(inc<=0)return{inc,ao:0,sh:0,kz:0,it:0,jt:0,bt:0,tot:0};
const ao=Math.min(650000,inc),sh=inc-ao,kz=Math.floor(Math.max(0,sh-580000)/1000)*1000;
const B=[[1950000,.05,0],[3300000,.1,97500],[6950000,.2,427500],[9000000,.23,636000],[18000000,.33,1536000],[40000000,.4,2796000],[Infinity,.45,4796000]],b=B.find(x=>kz<=x[0]);
const it=Math.floor(Math.max(0,kz*b[1]-b[2])*1.021/100)*100,jt=Math.floor(Math.max(0,sh-430000)*.1/100)*100+(sh>450000?5000:0),bt=Math.floor(Math.max(0,inc-2900000)*.05/100)*100;
return{inc,ao,sh,kz,it,jt,bt,tot:it+jt+bt}}
function taxEst(){taxInit();const cm=MN[G.month%12],y=calY(G.month);if(G.tax.due&&!G.tax.due.paid)return{fix:1,y:G.tax.due.y,...G.tax.due};
const a=G.tax.acc[y]||0,n=G.tax.cnt[y]||0,rest=12-cm,pj=n?a+a/n*rest:0;return{fix:0,y,...calcTax(pj)}}
function taxRows(r,row){const t=r.tx;if(!t)return"";let h="";
if(t.pay){const d=t.pay;h+=`<div style="height:6px"></div><div class="f"><b>🧾 確定申告（${d.y+1}年目の分）</b><span></span></div>`+row("年間の所得（売上−経費）",yen(d.inc))+row("所得税（復興税2.1%込み）","-"+yen(d.it),"neg")+row("住民税（10%）","-"+yen(d.jt),"neg")+row("個人事業税（290万円を超えた分の5%）","-"+yen(d.bt),"neg")+`<div class="m" style="font-size:11px">青色申告特別控除65万円・基礎控除58万円を引いて計算</div>`+row("今回納めた税金","-"+yen(d.tot-(t.short||0)),"neg");
if(t.short>0)h+=`<div class="neg" style="font-size:12px;margin:4px 0">払えなかった ${yen(t.short)} は延滞金10%を付けて、3月から毎月分割で払います（未納 ${yen(G.tax.ar)}）</div>`}
if(t.inst)h+=row("税金の分割払い（残り "+yen(G.tax.ar)+"）","-"+yen(t.inst),"neg");
if(t.note){const e=t.note;h+=`<div style="margin:8px 0 2px;padding:8px;border-radius:8px;background:#fff6e5;font-size:12px;line-height:1.6"><b>🧾 確定申告のお知らせ</b><br>来年2月の精算で、今年1〜12月分の税金をまとめて払います。<br>${e.fix?"納める額":"今のペースだと"}：<b>約${yen(Math.round(e.tot/1000)*1000)}</b>（所得 ${yen(Math.max(0,e.inc))}）<br><span class="neg">2月は閑散期で客も減ります。お金を残しておこう</span></div>`}
return h}
{const _st=settle;settle=function(){const r=_st.apply(this,arguments);try{const L=G.last;taxInit();if(L&&!L.tx&&L.month===G.month&&L.after!=null&&!G.over){const T=G.tax,cm=MN[L.month%12],y=calY(L.month),x=L.s2||{};
const prof=(L.est||0)-(L.rent||0)-(L.util||0)-(L.flv||0)-(L.dc||0)-(L.coal||0)-(L.brk?L.brk.cost:0)+(x.net||0);
T.acc[y]=(T.acc[y]||0)+prof;T.cnt[y]=(T.cnt[y]||0)+1;const tx={};let paid=0;const rsv=(()=>{try{return rentAt(L.month+1)+utilNow()+(G.loan.bal>0?G.loan.pay:0)}catch(e){return 100000}})(),cash=()=>Math.max(0,G.money-rsv);
if(cm===12){T.due={y,...calcTax(T.acc[y]),paid:false}}
if(T.ar>0&&cm!==2){const v=Math.min(T.ar,T.ins,cash());if(v>0){G.money-=v;T.ar-=v;paid+=v;tx.inst=v;if(T.ar<=0)log("🧾 税金の分割払いが終わりました")}}
if(cm===2&&T.due&&!T.due.paid){const d=T.due,v=Math.min(d.tot,cash()),sh=d.tot-v;G.money-=v;paid+=v;d.paid=true;T.n++;tx.pay=d;tx.short=sh;
if(sh>0){T.ar+=Math.ceil(sh*1.1);T.ins=Math.max(10000,Math.ceil(T.ar/6/1000)*1000);log("🧾 税金が払いきれず、未納 "+yen(T.ar)+"（延滞金込み）を3月から分割で払います")}else log("🧾 確定申告を済ませ、税金 "+yen(d.tot)+" を納めました");
if(T.ar>0&&sh===0){}}
if(cm>=10||cm===1){tx.note=taxEst();log("🧾 確定申告のお知らせ：来年2月に税金 約"+yen(Math.round(tx.note.tot/1000)*1000)+" を納めます")}
L.tx=tx;L.txp=paid;if(paid){L.after=G.money;const hm=G.hist&&G.hist.m[G.hist.m.length-1];if(hm&&hm.m===L.month){hm.p-=paid;hm.mo=G.money}}
save();showResult();if(typeof grfDraw==="function")grfDraw()}}catch(e){console.error(e)}return r}}
{const _rf=rfin;rfin=function(){_rf.apply(this,arguments);try{taxInit();const T=G.tax,el=$("#fin");if(!el)return;let h="";const cm=MN[G.month%12];
if(T.ar>0)h+=`<div class="f"><span>🧾 税金の未納</span><span class="neg">${yen(T.ar)}（毎月 ${yen(Math.min(T.ar,T.ins))}）</span></div>`;
else if(cm>=10||cm<=2){const e=taxEst();if(e.tot>0)h+=`<div class="f"><span>🧾 2月の納税${e.fix?"":"見込み"}</span><span class="neg">約${yen(Math.round(e.tot/1000)*1000)}</span></div>`}
if(h){const d=document.createElement("div");d.innerHTML=h;el.appendChild(d)}}catch(e){}}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
