import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 経過月は「営業した日数」からも数える（月末レポートを飛ばして G.month がずれた人も、プレイ3年で虎虎セットが届く）
PM='Math.max(G.month||0,Math.floor(((G.day||1)-1)/7))'
rep('if(k==="year")return(G.month||0)>=n*12;','if(k==="year")return '+PM+'>=n*12;')
rep('const visUnl=()=>(G.month||0)>=3;','const visUnl=()=>'+PM+'>=3;')
rep('f:()=>(G.month||0)>=12}','f:()=>'+PM+'>=12}')
open(f,'w').write(s)
