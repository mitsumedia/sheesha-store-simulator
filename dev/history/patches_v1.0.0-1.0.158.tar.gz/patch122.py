import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 2号店：新しい朝の画面でも「2号店の日」「開業のお誘い」を出す（月末を繰り返す不具合の修正） ===== */
{const _smS=showMorning;showMorning=function(){const pre=R.phase==="prep"&&G.setup&&G.ow&&!G.over&&!(G.last&&!G.last.seen);
if(pre&&G.s2p&&!G.at2){s2Card();return}
if(pre&&!G.at2&&s2Ok()&&!G.s2no&&G.money>=S2ASK&&!G.ow.acted){s2Ask();return}
const r=_smS.apply(this,arguments);
try{if(s2Ok()&&G.s2no&&!$("#s2open")){const cd=$("#ov .mnc")||$("#ov .card");if(cd){const mb=cd.querySelector(".mb"),h=`<div style="padding:0 14px"><button id="s2open" style="width:100%;margin-top:6px" ${G.money>=S2COST?"":"disabled"}><b>🏪 2号店を開業する（${yen(S2COST)}）</b></button></div>`;if(mb)mb.insertAdjacentHTML("beforebegin",h);else cd.insertAdjacentHTML("beforeend",h)}}}catch(e){}
return r}}
/* 2号店の日が残ったまま営業開始しない（同じ日を繰り返さない） */
{const _st2=start;start=function(){if(R.phase==="prep"&&G.s2p&&!G.at2&&G.setup&&!G.over){s2Card();return}return _st2.apply(this,arguments)};$("#go").onclick=start}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
