import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 非売品のもらえる確率：全員0.5%（EX客も）
rep('Math.random()>=(c.ex?.05:.005)','Math.random()>=.005')
# さんてぃ：好きなフレーバー（ボムシェル）とセリフ
LS=["シーシャうまいねぇ","今日も3本も吸ってしまった…","次はどこに行こうかな","今日は休煙日です","ポン！","これはほんとにうまい！","明日はけむりーぐです","はぁ"]
i=s.find('const FL=');FLN=None
m=s.find('["ボムシェル"');assert m>0
# FLのインデックスを数える
import re
fl_i=s.find('FL=[[');fl_j=s.find(']];',fl_i)
names=re.findall(r'\["([^"]+)","#',s[fl_i:fl_j+3]);bi=names.index("ボムシェル")
SA={"ls":LS,"fl":bi}
a=s.find('const PRESET=');b=s.find('];',a);arr=json.loads(s[a+13:b+1])
for e in arr:
    if e['slot']==141:e.update(SA)
s=s[:a+13]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[b:]
CODE='''
/* ===== さんてぃのセリフ・好きなフレーバー（遊んでいるデータにも反映） ===== */
{const SA=%s;if(!G.san3){const c=G.cs[141];if(c&&c.name==="さんてぃ"&&!c.ed)Object.assign(c,SA);G.san3=1;try{save()}catch(e){}}}
''' % json.dumps(SA,ensure_ascii=False)
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
