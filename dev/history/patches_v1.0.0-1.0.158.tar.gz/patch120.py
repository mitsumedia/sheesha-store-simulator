import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# やる気システムを廃止
rep('function motAdd(v,why){if(G.over)return;','function motAdd(v,why){G.mot=100;return;if(G.over)return;')
rep('function motFloor(v){','function motFloor(v){G.mot=100;return;')
rep('function evEndMot(){','function evEndMot(){return;')
rep('m0=G.mot;motAdd(mv);evEndMot();log("🔥 今日のやる気 "+(mv>=0?"+":"")+Math.round(mv*10)/10+"（"+Math.round(m0)+"→"+Math.round(G.mot)+"）");','m0=G.mot;G.mot=100;')
rep('+dl("やる気",r.b0.mot??100,G.mot??100,ri)','')
rep('／やる気 1日 <b style="color:${m<0?"#ff7a7a":"#7adf8f"}">${m>0?"+"+m+"（短時間ボーナス）":m<0?m+"（長時間営業）":"±0"}</b>','')
rep('<br>🔥 やる気が減りやすくなります（10時間を超えると1時間ごとに−1、14時間を超えると−2ずつ）','')
rep('<br><br>8時間以下にすると、やる気が少し回復します（1日+1）','')
rep('3位以下はやる気−40','3位以下は賞金なし')
rep('else{motAdd(-40,"大会で負けた");m="やる気 <b>−40</b>"}','else{m="賞金なし…次こそ優勝を目指そう"}')
rep('if(rw.mot)o.push("🔥やる気全回復");','')
open(f,'w').write(s)
