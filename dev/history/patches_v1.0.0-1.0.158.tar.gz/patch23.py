import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
EXD=json.load(open('/home/claude/w/exd.json'))
GX=json.load(open('/home/claude/w/gift/gex.json'))
# 図鑑の人数・コンプ判定はEXを除く
rep('const dexN=()=>G.cs?G.cs.filter(c=>c.met).length:0;','const dexN=()=>G.cs?G.cs.filter(c=>c.met&&!c.ex).length:0;')
rep('(G.cs||[]).length>0&&dexN()>=G.cs.length','(G.cs||[]).length>0&&dexN()>=G.cs.filter(c=>!c.ex).length')
rep('function rdex(){if(R.dxm==="f"){rflv();return}if(R.dxm==="e"){rev();return}const A=G.cs,','function rdex(){if(R.dxm==="f"){rflv();return}if(R.dxm==="e"){rev();return}const A=G.cs.filter(c=>R.dxm==="x"?c.ex:!c.ex),')
rep('<button data-dxm="e" class="${m==="e"?"on":""}">⚡ イベント</button>','<button data-dxm="e" class="${m==="e"?"on":""}">⚡ イベント</button>${G.s2?`<button data-dxm="x" class="${m==="x"?"on":""}">🏪 EX</button>`:""}')
rep('function dxNo(c){return String(dxN(c)).padStart(3,"0")}','function dxNo(c){return c.ex?"EX"+String(c.exn).padStart(2,"0"):String(dxN(c)).padStart(3,"0")}')
rep('for(const c of G.cs){if(!c.act&&k<n)','for(const c of G.cs){if(!c.act&&!c.ex&&k<n)')
rep('const L=G.cs.filter(c=>!c.met),c=L[','const L=G.cs.filter(c=>!c.met&&!c.ex),c=L[')
rep('if(k==="dex")return G.cs.some(c=>!c.met);','if(k==="dex")return G.cs.some(c=>!c.met&&!c.ex);')
rep('return G.cs.filter(c=>c.act&&!c.quit&&!pr.has(c.i)','return G.cs.filter(c=>c.act&&!c.quit&&(!c.ex||G.at2)&&!pr.has(c.i)')
# EXは2号店にだけ来る（来店しやすい）
rep('const pr=k=>!k.act||','const pr=k=>k.ex?(G.at2&&k.act?(k.met?.4:.25)*(k.exn===30?(G.spB?.25:.5):1):0):!k.act||')
rep('if(Math.random()>=.005)return;\nG.gfD=G.day;','if(Math.random()>=(c.ex?.05:.005))return;\nG.gfD=G.day;')
# EXは仲良くなりやすい
rep('const w=Math.floor(c.fpx+1e-9);c.fp+=w;c.fpx-=w}','const w=Math.floor(c.fpx+1e-9);c.fp+=w*(c.ex?4:1);c.fpx-=w}')
ADD=r'''
/* ===== 2号店のEXのお客さん（30人） ===== */
const EXD=%s;
{const GX=%s;GX.forEach(([id,n,md])=>{DMD[id]=md;DEC.push({id,n,p:id==="gx_30"?200000:30000,t:{luxury:1},u:["gift",0]})})}
const EXSTN={0:"床「船の甲板」",1:"床「月面」",2:"床「氷の床」",3:"床「檜の床」",4:"床「銭湯のタイル」",5:"床「サーカスのリング」",6:"壁紙「丸太小屋」",7:"壁紙「レトロ喫茶の板壁」",8:"壁紙「歯車の壁」",9:"壁紙「夜空の花火」",10:"壁紙「ホテルのダマスク柄」",11:"壁紙「本棚の壁」"};
function exInit(){if(!G.cs)return;if(!G.cs.some(c=>c.ex)){const base=G.cs.length;EXD.forEach((d,k)=>{const c=mkC(base+k,d.name,d.sex,0);Object.assign(c,{age:d.age,job:d.job,hs:d.hs,hair:d.hair,skin:d.skin,shirt:d.shirt,top:d.top,bot:d.bot,pants:d.pants,eye:d.eye,acc:d.acc,accC:d.accC,pe:d.pe,fav:d.fav,hb:d.hb,ls:d.ls.slice(),ex:1,exn:k+1,est:d.st,act:0,ap:{k:"ex",v:0,p:0},g:-1,tl:Math.max(3,c.tl),first:.7,repeat:.8});delete c.rar;G.cs.push(c)})}
G.cs.forEach(c=>{if(!c.ex)return;const d=EXD[c.exn-1];if(d&&d.gx)GIFT[c.i]=DEC.find(x=>x.id==="gx_"+d.gx)});
if(G.s2)G.cs.forEach(c=>{if(c.ex&&c.exn<30)c.act=1});spChk()}
function spOk(){return G.cs.filter(c=>!c.ex).every(c=>lv(c)>=NL)&&G.cs.filter(c=>c.ex&&c.exn<30).every(c=>lv(c)>=NL)}
function spChk(){const sp=G.cs.find(c=>c.ex&&c.exn===30);if(sp&&!sp.act&&G.s2&&spOk()){sp.act=1;log("🌫 2号店に、不思議なお客さんが来るようになったらしい…")}}
function exChk(p){const c=p&&p.c;if(!c||!c.ex||lv(c)<NL)return;
if(c.est>=0&&!(G.exg||[]).includes(c.est)){G.exg=(G.exg||[]).concat([c.est]);const t=EXSTN[c.est];setTimeout(()=>say(p,"いつもありがとう。これ、お店に使ってください"),1600);log("🎁 "+nm(c)+" さんから"+t+"をもらった！（模様替えの壁紙・床から選べます）");try{toast("🎁 "+t+"をもらった！",3500)}catch(e){}save()}
if(c.exn===30&&!G.spB){G.spB=1;ivAdd({t:"d",id:"gx_30"});setTimeout(()=>say(p,"ありがとう。この店の煙は、とてもあたたかかった"),800);log("🌫 ？？？の正体は「煙の精」だった。煙の精から「黄金のシーシャ」をもらった！（📦 持ち物へ）");
setTimeout(()=>{try{log("🌫 煙の精は、ふわりと煙になって消えた…");leaveNow(p);p.gone=1}catch(e){}},4200);save()}
spChk()}
{const _t=talk;talk=function(p){_t(p);try{exChk(p)}catch(e){}}}
{const _o=s2Open;s2Open=function(){_o();exInit();if(G.s2)log("🏪 2号店には、ここでしか会えないお客さんが来るらしい（図鑑の「🏪 EX」）")}}
exInit();
'''%(json.dumps(EXD,ensure_ascii=False),json.dumps(GX,ensure_ascii=False))
rep(TAIL,ADD+TAIL)
open(f,'w').write(s)
