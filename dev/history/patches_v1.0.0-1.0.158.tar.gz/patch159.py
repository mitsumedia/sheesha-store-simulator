import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 人の絵も街の層で描く（dyn では描かない）
rep('{const _dy=dyn;dyn=function(){const a=_dy.apply(this,arguments);try{if(!mbOn()','{const _dy=dyn;dyn=function(){const a=_dy.apply(this,arguments);try{if(MB.v2)return a;if(!mbOn()')
# 軽量モードでも少なめに出す
rep('function mbOn(){return!G.mbOff&&!R.lite&&G.setup&&!R.vis&&R.phase==="run"}','function mbOn(){return!G.mbOff&&G.setup&&!R.vis&&R.phase==="run"}')
rep('if(nc<3&&Math.random()','if(nc<(R.lite?2:3)&&Math.random()')
rep('if(np<4&&Math.random()','if(np<(R.lite?2:4)&&Math.random()')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 通行人の描き方：歩道・車道の上だけを通り、手前の建物や柱にはちゃんと隠れる ===== */
MB.v2=1;
/* 店の両隣（道ぞい）の建物を少し間引いて、通行人を見やすくする */
{const _gs3=genScn;genScn=function(){const r=_gs3.apply(this,arguments);try{const g=mbGeo();for(let i=SCN.length-1;i>=0;i--){const b=SCN[i];if((b.t===1||b.t===3)&&b.x<g.L+20)SCN.splice(i,1)}}catch(e){}return r}}
function mbHull(pts){pts.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]),lo=[],up=[];for(const p of pts){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],p)<=0)lo.pop();lo.push(p)}for(let i=pts.length-1;i>=0;i--){const p=pts[i];while(up.length>=2&&cr(up[up.length-2],up[up.length-1],p)<=0)up.pop();up.push(p)}up.pop();lo.pop();return lo.concat(up)}
const MBO={key:"",list:[]};
function mbOcc(k,g){const key=[k.s.toFixed(3),k.rx.toFixed(4),k.ry.toFixed(4),k.ux.toFixed(4),k.uy.toFixed(4),k.uz.toFixed(4),k.ox,k.oy,W,CH,dpr,SCN.length,FLT.length,R.stV,g.L].join();if(MBO.key===key)return MBO.list;MBO.key=key;
 const WB=[];FLT.forEach(([tx,ty])=>{const h=(dx,dy)=>FLS.has((tx+dx)+","+(ty+dy)),X=tx*6,Y=ty*6;if(!h(0,-1))WB.push({x:X-1,y:Y-1,z:0,w:8,d:1,h:24,t:1});if(!h(0,1))WB.push({x:X-1,y:Y+6,z:0,w:8,d:1,h:24,t:3});if(!h(-1,0)&&!(tx===0&&ty===2))WB.push({x:X-1,y:Y,z:0,w:1,d:6,h:24,t:2});if(!h(1,0))WB.push({x:X+6,y:Y,z:0,w:1,d:6,h:24,t:4})});
 MBO.list=SCN.concat(WB).filter(b=>(b.t===0||wallVis(b.t,k))&&!(b.t===2&&b.x+b.w<=g.L-42)&&!(b.t===0&&b.y<-200)).map(b=>{const pts=[];for(const x of[b.x,b.x+b.w])for(const y of[b.y,b.y+b.d])for(const z of[b.z,b.z+b.h])pts.push(P3(x,y,z,k));const h=mbHull(pts);let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;h.forEach(p=>{x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0]);y0=Math.min(y0,p[1]);y1=Math.max(y1,p[1])});
  return{b,h,bb:[x0,y0,x1,y1],d:(b.x+b.w/2)*k.cx+(b.y+b.d/2)*k.cy+(b.z+b.h/2)*k.cz,near:b.x+b.w>g.L-16}}).sort((a,b)=>a.d-b.d);return MBO.list}
let MBLY=null;
mbDraw=function(k,fg){if(!mbOn()||(fg?wallVis(2,k):!wallVis(2,k))){return}const now=performance.now(),dt=Math.min(.1,(now-(MB.last||now))/1000);MB.last=now;const sp=typeof mbSpd==="function"?mbSpd():1;try{wkGhosts()}catch(e){}
 MB.cd=(MB.cd||0)-dt*sp;if(MB.cd<=0){MB.cd=.8+Math.random()*1.6;mbSpawn()}const g=mbGeo();
 const L=LTN||{oa:0,ov:"#000000"},tint=c=>L.oa>.05?mixc(c,L.ov,Math.min(.6,L.oa*.65)):c,items=[],inS=new Set((R.people||[]).map(p=>p.c));
 MB.L=MB.L.filter(m=>{m.t+=dt*sp;
  if(m.gh){const p=R.people.find(q=>q.c===m.gh.c);if(p)return false;const atD=m.s>0?m.y>=15:m.y<=15;if(atD){if(R.sched.includes(m.gh.e)){m.y=15;m.x+=(-5-m.x)*Math.min(1,dt*sp*3);m.wait=(m.wait||0)+dt;m.face=1;if(m.wait<20)return true}m.gh=null;m.face=0}}
  if(m.pk&&!m.pkd&&(m.s>0?m.y>=15:m.y<=15)){m.pkt=(m.pkt||0)+dt*sp;m.face=1;if(m.pkt<1.6)return true;m.pkd=1;m.face=0}
  if(m.ax){m.x+=m.s*m.sp*sp*dt;if(m.x<m.x0-80||m.x>m.x1+80)return false}else{let st=m.s*m.sp*sp*dt;const rd=m.T.k==="car"||m.T.k==="bike";if(rd){let gap=1e9;const lm=m.T.l||8;for(const o of MB.L){if(o===m||o.s!==m.s||o.ax||!(o.T.k==="car"||o.T.k==="bike")||Math.abs(o.x-m.x)>5)continue;const dy=(o.y-m.y)*m.s;if(dy<=0)continue;const g2=dy-(lm+(o.T.l||8))/2-2;if(g2<gap){gap=g2;m.ld=o}}if(gap<1e9){const mv=Math.max(0,Math.min(Math.abs(st),gap));st=m.s*mv;if(gap<6&&m.ld)m.sp=Math.min(m.sp,m.ld.sp)}}m.y+=st;if(m.T.wob)m.x+=Math.sin(m.t*3+m.a)*dt*2;if(m.y<g.Y0-(m.tr?110:40)||m.y>g.Y1+(m.tr?110:40))return false}
  const mid=(g.Y0+g.Y1)/2;if(!m.seen&&(m.ax?Math.abs(m.x-(m.x0+m.x1)/2)<20:(m.s>0?m.y>mid+6:m.y<mid-6))){m.seen=1;if(!m.tag)mbSeen(m.T,m)}
  const it={m,parts:[],d:m.x*k.cx+m.y*k.cy+4*k.cz};const ped=m.T.k==="ped"&&!m.T.cat;
  let P=ped?[]:(m._P||m.T.mk(m.a,m.t,m.um));if(!ped&&m.T.k!=="ped")m._P=P;if(m.T.dog){P=P.concat(mbDog(m.s>0?1.8:-1.8,m.s>0?7.4:-3,m.T.dog,m.T.big,m.t))}if(m.T.pet){P=P.concat(m.T.pet(m.t,m.a))}if(m.T.fly){const fz=m.T.fly+Math.sin(m.t*2+m.a)*.8;P=P.map(p=>[p[0],p[1],p[2]+fz,p[3],p[4],p[5],p[6],p[7]])}
  const l=m.T.l||8;P.forEach(p=>{let b;if(m.ax){const x=m.s>0?m.x+p[1]-l/2:m.x-(p[1]+p[4])+l/2;b={x,y:m.y+p[0],z:p[2]+(m.zo||0),w:p[4],d:p[3],h:p[5],c:p[7]&&L.oa>.2?p[6]:tint(p[6])}}else{const x=m.x+p[0],y=m.s>0?m.y+p[1]-l/2:m.y-(p[1]+p[4])+l/2;b={x,y,z:p[2],w:p[3],d:p[4],h:p[5],c:p[7]&&L.oa>.2?p[6]:tint(p[6])}}const x=b.x,y=b.y;it.parts.push({b,d:(x+b.w/2)*k.cx+(y+b.d/2)*k.cy+(b.z+b.h/2)*k.cz})});
  if(ped){if(!m.c){if(!m.tag&&!m.T.ni&&Math.random()<.12&&["kaisha","gakusei","kaimono","sumaho","couple","jog"].includes(m.T.id)){const met=G.cs.filter(c=>c.met&&!c.sp&&!(typeof spx==="function"&&spx(c))&&!inS.has(c));if(met.length){m.c=met[Math.floor(Math.random()*met.length)];m.dex=1}}if(!m.c)m.c=mbLook(m.T,m.a)}
   if(m.dex&&!m.dexL&&m.seen){m.dexL=1;G.mbDx=G.mbDx||{};if(G.mbDx[m.c.i]!==G.day){G.mbDx[m.c.i]=G.day;try{const t="👀 "+nm(m.c)+" が店の前を通りすぎた";log(t);mbBand(t)}catch(e){}}}
   const dd=m.face?1:(m.s>0?0:2),ox=m.x-2,oy=m.y-1.5+(!m.face&&Math.sin(m.t*10)>0?.15:0),save=GLS;GLS=[];const va=[];try{if(!walkSpr(va,m.c,dd,ox,oy))pv(va,ox,oy,1,m.c,0,dd);mbProps(m,ox,oy,dd).forEach(v=>va.push(v))}catch(e){}it.spr=GLS;it.vox=va;GLS=save}
  items.push(it);return true});
 if(!items.length)return;items.sort((a,b)=>a.d-b.d);
 const occ=fg?[]:mbOcc(k,g);
 const drawIt=it=>{it.parts.sort((p,q)=>p.d-q.d).forEach(o=>dvb(o.b,k));if(it.vox&&it.vox.length)it.vox.forEach(v=>{try{dv(v,k)}catch(e){}});if(it.spr)it.spr.forEach(q=>{try{q.fn(k)}catch(e){}})};
 const L2=items.slice(),used=new Set();items.forEach(it=>{const m=it.m,r=(m.T.l||10)*.6+3,zt=(m.T.fly||0)+14;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const[dx,dy,z]of[[-r,-r,0],[r,r,0],[-r,r,0],[r,-r,0],[-r,-r,zt],[r,r,zt],[-r,r,zt],[r,-r,zt]]){const q=P3(m.x+dx,m.y+dy,z,k);x0=Math.min(x0,q[0]);x1=Math.max(x1,q[0]);y0=Math.min(y0,q[1]);y1=Math.max(y1,q[1])}
  occ.forEach(o=>{if(o.d>it.d&&!used.has(o)&&!(o.bb[2]<x0||o.bb[0]>x1||o.bb[3]<y0||o.bb[1]>y1)){used.add(o);L2.push({oc:o,d:o.d})}})});
 L2.sort((a,b)=>a.d-b.d);const A=typeof scnA==="function"?scnA():.3,LT=LTN||{oa:0},tc=c=>LT.oa>.02&&/^#/.test(c)?mixc(c,LT.ov,LT.oa):c;
 L2.forEach(e=>{if(!e.oc){drawIt(e);return}const h=e.oc.h;cx.save();cx.beginPath();h.forEach((p,i)=>i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]));cx.closePath();cx.clip();cx.setTransform(1,0,0,1,0,0);try{cx.drawImage(BGC,0,0)}catch(_){}cx.restore()})};
/* 道が手前に来る向きでは、店の中より手前に描く */
{const _au=auraDraw;auraDraw=function(k,fg){const r=_au.apply(this,arguments);if(fg)try{mbDraw(k,1)}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
