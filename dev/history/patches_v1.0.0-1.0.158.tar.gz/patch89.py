import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== お店めぐりはゲーム内で3ヶ月たってから解禁 ===== */
const visUnl=()=>(G.month||0)>=3;
{const _xr=xrow;xrow=function(){_xr();const b=$("#visb");if(b)b.hidden=!visUnl()}}
{const _vp=visPanel;visPanel=function(){if(!visUnl())return;return _vp.apply(this,arguments)}}
function visUnlPop(){G.visU=1;save();try{xrow()}catch(e){}const d=document.createElement("div");d.className="xpan";d.id="visup";d.innerHTML=`<div class="xin" style="text-align:center"><div style="font-size:46px;line-height:1.2">🏪</div><div class="xh" style="justify-content:center">お店めぐりが解禁された！</div><div class="xs" style="font-size:14px;line-height:1.8;margin:8px 0">リアルで会った店主さんとスマホを見せ合うと、その人のお店に遊びに行けます。<br>滞在できるのは<b>15分だけ</b>。<br>会えた時だけの特別な時間を楽しもう！</div><div class="xb"><button data-vu="ok" class="on" style="flex:1">OK</button></div></div>`;document.body.appendChild(d);d.onclick=e=>{if(e.target.closest("[data-vu]"))d.remove()}}
{const _hu=hud;hud=function(){const r=_hu.apply(this,arguments);try{if(!G.visU&&G.setup&&!G.over&&visUnl()&&R.phase==="prep"&&!R.vis&&$("#ov").hidden&&!document.querySelector(".xpan")&&!document.querySelector("#sheet.open")&&!document.body.classList.contains("mvmode")&&!(typeof TUT!=="undefined"&&TUT))visUnlPop()}catch(e){}return r}}
try{xrow()}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
