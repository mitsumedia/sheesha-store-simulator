import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# スペシャル客：来店回数（vn）が古いデータで数えられていなくても、通算の来店（vt）が3回以上なら名前を出す
rep('const lv=c=>c.met?(spx(c)?((c.vn||0)>=3?NL:0):','const lv=c=>c.met?(spx(c)?(((c.vn||0)>=3||(c.vt||0)>=3)?NL:0):')
# チェキ：座る席の家具も一緒に重ねて描く（ソファに沈んで座る、普段の来店と同じ見た目に）
rep('a=a.concat(p1,p2);(sp2?[]:','if(sp2){const fs=new Set(sp2.map(q=>q.fid)),FF=(typeof ckFS!=="undefined"&&ckFS)||G.furn;fs.forEach(fid=>{const F=FF[fid];if(F)furnVox(F).forEach(v=>a.push(v))})}a=a.concat(p1,p2);(sp2?[]:')
open(f,'w').write(s)
