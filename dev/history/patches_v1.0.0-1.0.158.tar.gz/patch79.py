import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# --- 描画：追加の髪型・服・ズボンのときは土台を差し替え ---
rep('const hs=c.hs!==undefined?c.hs:c.i%3,','const hs=c.h2?99:c.hs!==undefined?c.hs:c.i%3,')
rep('const TP=c.top|0,BT=c.bot|0,','const TP=c.t2?0:c.top|0,BT=c.b2?[0,0,0,1,0,0,2,0,0,0][c.b2-1]:c.bot|0,')
rep('OW.c.top+OW.c.bot+OW.c.pants;','OW.c.top+OW.c.bot+OW.c.pants+"|"+(OW.c.h2|0)+(OW.c.t2|0)+(OW.c.b2|0);')
rep('c.top+c.bot+c.pants;','c.top+c.bot+c.pants+"|"+(c.h2|0)+(c.t2|0)+(c.b2|0);')
# --- 店主の見た目フォーム：追加の髪型・服・ズボン（未解禁は🔒） ---
rep('const v=k==="sex"?(c.sex==="男性"?0:1):c[k];return`<label><span>${l}</span><select data-ok="${k}">',
    'if(k==="hs"||k==="top"||k==="bot")return owSel(k,l,o,c);const v=k==="sex"?(c.sex==="男性"?0:1):c[k];return`<label><span>${l}</span><select data-ok="${k}">')
rep('else if(["hs","acc","eye","top","bot"].includes(ok))c[ok]=+v;','else if(ok==="hs"||ok==="top"||ok==="bot"){const n=+v,m={hs:"h2",top:"t2",bot:"b2"}[ok];if(n>=100)c[m]=n-99;else{c[m]=0;c[ok]=n}}else if(["acc","eye"].includes(ok))c[ok]=+v;')
rep('top:c.top|0,bot:c.bot|0,pants:c.pants,acc:c.acc,accC:c.accC})};','top:c.top|0,bot:c.bot|0,pants:c.pants,acc:c.acc,accC:c.accC,h2:c.h2|0,t2:c.t2|0,b2:c.b2|0})};')
rep('Object.assign(o,{shop:n.shop,name:n.name,age:n.age,sex:n.sex,eye:n.eye||0,hs:n.hs,hair:n.hair,skin:n.skin,shirt:n.shirt,acc:n.acc,accC:n.accC})',
    'Object.assign(o,{shop:n.shop,name:n.name,age:n.age,sex:n.sex,eye:n.eye||0,hs:n.hs,hair:n.hair,skin:n.skin,shirt:n.shirt,acc:n.acc,accC:n.accC,top:n.top,bot:n.bot,pants:n.pants,h2:n.h2,t2:n.t2,b2:n.b2})')
rep('o.pants?{pants:o.pants}:{});OW._pc=null}','o.pants?{pants:o.pants}:{},{h2:o.h2|0,t2:o.t2|0,b2:o.b2|0});OW._pc=null}')
rep('pants:o.pants||OW.c.pants,acc:o.acc,accC:o.accC};ov(','pants:o.pants||OW.c.pants,acc:o.acc,accC:o.accC,h2:o.h2|0,t2:o.t2|0,b2:o.b2|0};ov(')
CODE=r'''
/* ===== 店主の着せ替え：解禁条件 ===== */
const OWL={h:OWH,t:OWT,b:OWB};
const OWC={
h1:["営業30日",()=>(G.day||0)>=30],h2:["借金を完済",()=>!!G.loan&&G.loan.bal<=0&&(G.month||0)>0],h3:["ガチャ"],h4:["ガチャ"],h5:["図鑑30人",()=>G.cs.filter(c=>c.met).length>=30],
h6:["ハロウィンの日に営業",()=>!!G.owHal],h7:["チェキを5回撮る",()=>(G.ckN||0)>=5],h8:["フォロワー1,000人",()=>((G.ow||{}).fol||0)>=1000],h9:["フェスに出店",()=>(G.festN||0)>=1],h10:["バトルで優勝",()=>(G.batW||0)>=1],
t1:["のべ来店300人",()=>(G.tvis||0)>=300],t2:["12〜2月に営業",()=>[12,1,2].includes(MN[(G.month||0)%12])&&(G.day||0)>1],t3:["ガチャ"],t4:["フォロワー3,000人",()=>((G.ow||{}).fol||0)>=3000],t5:["7〜8月に営業",()=>[7,8].includes(MN[(G.month||0)%12])],
t6:["バトルでベスト4",()=>(G.batBest||99)<=3],t7:["所持金500万円",()=>(G.money||0)>=5000000],t8:["増築2回",()=>(G.exN||0)>=2],t9:["野郎シーシャ会からもらう"],t10:["営業1年",()=>(G.month||0)>=12],
b1:["営業7日",()=>(G.day||0)>=7],b2:["のべ来店100人",()=>(G.tvis||0)>=100],b3:["ガチャ"],b4:["増築1回",()=>(G.exN||0)>=1],b5:["営業60日",()=>(G.day||0)>=60],
b6:["図鑑60人",()=>G.cs.filter(c=>c.met).length>=60],b7:["チェキを10回撮る",()=>(G.ckN||0)>=10],b8:["フレーバー20種",()=>(G.flu||[]).length>=20],b9:["所持金1,000万円",()=>(G.money||0)>=10000000],b10:["雪の日に営業",()=>!!G.owSnow]};
const owHas=k=>(G.owU||[]).includes(k);
function owUnlock(k,why){G.owU=G.owU||[];if(owHas(k))return null;G.owU.push(k);if(!G.owTut)G.owTut=1;const n=OWL[k[0]][+k.slice(1)-1][0];log("👕 着せ替え「"+n+"」が手に入った"+(why?"（"+why+"）":""));if(!why)try{toast("👕 新しい着せ替え「"+n+"」が手に入った！（店主の見た目から選べます）")}catch(e){}save();return n}
function owChk(){if(!G.setup)return;const nw=[];for(const k in OWC){const f=OWC[k][1];if(f&&!owHas(k)){try{if(f())nw.push(k)}catch(e){}}}if(!nw.length)return;if(nw.length===1){owUnlock(nw[0]);return}nw.forEach(k=>owUnlock(k,"条件達成"));try{toast("👕 新しい着せ替えが"+nw.length+"個手に入った！（店主の見た目から選べます）")}catch(e){}}
function owSel(k,l,o,c){const ty={hs:"h",top:"t",bot:"b"}[k],m={hs:"h2",top:"t2",bot:"b2"}[k],cur=c[m]?99+c[m]:c[k];return`<label><span>${l}</span><select data-ok="${k}">${o.map((n,i)=>`<option value="${i}" ${i===cur?"selected":""}>${esc(n)}</option>`).join("")}${OWL[ty].map((x,i)=>owHas(ty+(i+1))?`<option value="${100+i}" ${100+i===cur?"selected":""}>${esc(x[0])}</option>`:"").join("")}</select></label>`}
function owLkSel(k,l,ty,v){const L=OWL[ty];return`<label><span>${l}</span><select data-ok="${k}"><option value="0" ${v?"":"selected"}>なし（上の種類を使う）</option>${L.map((x,i)=>{const id=ty+(i+1),ok=owHas(id);return`<option value="${i+1}" ${ok?"":"disabled"} ${v===i+1?"selected":""}>${ok?"":"🔒 "}${esc(x[0])}${ok?"":"（"+OWC[id][0]+"）"}</option>`}).join("")}</select></label>`}
{const _h79=hud;hud=function(){_h79.apply(this,arguments);try{owChk()}catch(e){}}}
{const _st=start;start=function(){try{if(typeof isHallo==="function"&&isHallo())G.owHal=1;if(G.wx&&G.wx[G.wd]==="snow")G.owSnow=1}catch(e){}return _st.apply(this,arguments)}}
{const _ba=battleApply;battleApply=function(rk){G.batBest=Math.min(G.batBest||99,rk);return _ba.apply(this,arguments)}}
/* 野郎シーシャ会（No.143）からTシャツをもらう */
{const _gt=giftTry;giftTry=function(p){try{const c=p&&p.c;if(c&&c.i===142){if(owHas("t9")||G.gfD===G.day||(c.vn||0)<3||Math.random()>=.005)return;G.gfD=G.day;owUnlock("t9","野郎シーシャ会からもらった");setTimeout(()=>{NOGOBI=1;sayX(p,"これ、よかったら着てよ");NOGOBI=0},1600);try{toast("👕 野郎シーシャ会から「野郎シーシャ会T」をもらった！（店主の見た目から着られます）")}catch(e){}return}}catch(e){}return _gt.apply(this,arguments)}}
{const _tt=tutTick;tutTick=function(){try{if(G.owTut===1&&G.setup&&!TUT&&$("#ov").hidden&&R.phase==="prep"&&!document.getElementById("tut")){tutCard("新しい<b>着せ替えアイテム</b>が手に入りました！<br>☰ → 🏪 営業 → <b>✎ 店主の見た目を変える</b> から、<b>髪型・服の種類・ズボンの種類</b>の選択肢に増えています。<br>これからも、いろいろなことを達成すると着せ替えが増えていきます","わかった","#menu",()=>{G.owTut=2;save()},{tt:"👕 着せ替えアイテムが増えました！"});return}}catch(e){}return _tt.apply(this,arguments)}}
/* ガチャ：着せ替え（ガチャ限定4種） */
const OWG=["h3","h4","t3","b3"];
'''
rep(TAIL,CODE+TAIL)
rep('["deco",8]];','["deco",8],["ow",6]];')
rep('function gachaOk(k){','function gachaOk(k){if(k==="ow")return OWG.some(x=>!owHas(x));')
rep('function gachaGive(k){const o=G.ow;','function gachaGive(k){const o=G.ow;if(k==="ow"){const L=OWG.filter(x=>!owHas(x)),x=L[Math.random()*L.length|0],n=owUnlock(x,"ガチャ");return["👕","着せ替え","「"+n+"」が手に入った！店主の見た目から選べます"]}')
rep('📸 チェキの限定エフェクト・スタンプ（3種）</div>','📸 チェキの限定エフェクト・スタンプ（3種）／👕 着せ替え（4種）</div>')
open(f,'w').write(s)
