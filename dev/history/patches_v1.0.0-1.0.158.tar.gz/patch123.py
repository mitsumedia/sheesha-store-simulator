import sys,re
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
m=re.search(r'("name":"雲紅亭珍光".{0,300}?"fl":)31',s);assert m
s=s[:m.start()]+m.group(1)+'4'+s[m.end():]
rep('ORD.map((o,i)=>c.job==="シーシャ屋"&&SHX.includes(o[0])?"":','ORD.map((o,i)=>(c.job==="シーシャ屋"&&SHX.includes(o[0]))||(o[0]==="年齢"&&noAge(c))?"":')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 年齢を出さないお客さん／雲紅亭の好きなフレーバーをレモンに ===== */
const NOAGE=["雲紅亭珍光","有馬 佑亮","さんてぃ","野郎シーシャ会"];
function noAge(c){return c.job==="人外"||c.job==="シーシャ屋"||NOAGE.includes(c.name)}
function ukoFix(){try{(G.cs||[]).forEach(c=>{if(c.name==="雲紅亭珍光"&&c.fl!==4)c.fl=4})}catch(e){}}
ukoFix();setTimeout(ukoFix,1500);{const _sc10=sched;sched=function(){ukoFix();return _sc10.apply(this,arguments)}}{const _rd10=rdex;rdex=function(){ukoFix();return _rd10.apply(this,arguments)}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
