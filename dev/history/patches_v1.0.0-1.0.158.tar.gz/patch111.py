import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 床の汚れは床と一緒に背景の絵に描く（汚れが変わった時だけ描き直し）
rep('fc[0]:fc[1])});statList(k).forEach(o=>{if(o.v[4])dv(o.v,k)})','fc[0]:fc[1])});try{dirtDraw(k)}catch(e){}statList(k).forEach(o=>{if(o.v[4])dv(o.v,k)})')
rep('R.stV,Math.round(hr*6)','R.stV,(G.dv||0),Math.round(hr*6)')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 店のきれいさ：床のマスが汚れていく・掃除ミニゲーム（なぞって掃除） ===== */
const dRnd=(a,b,n)=>{const x=Math.sin(a*127.1+b*311.7+n*74.7)*43758.5453;return x-Math.floor(x)};
const dLv=v=>v<25?0:v<50?1:v<75?2:3;
function dirtTile(k,tx,ty,lv){if(lv<1)return;const X=tx*6,Y=ty*6,blob=(x,y,r,col,sq)=>{const p=P3(X+x,Y+y,0,k),s2=k.s*r;cx.fillStyle=col;cx.beginPath();cx.ellipse(p[0],p[1],s2,s2*(sq||.55),0,0,7);cx.fill()};
const n1=[0,4,6,6][lv];for(let i=0;i<n1;i++)blob(.6+dRnd(tx,ty,i)*4.8,.6+dRnd(ty,tx,i+9)*4.8,.25+dRnd(tx,i,3)*.35,"rgba(120,85,50,.3)");
if(lv>=2){for(let i=0;i<10;i++)blob(.4+dRnd(tx,ty,i+30)*5.2,.4+dRnd(ty,tx,i+40)*5.2,.08+dRnd(i,tx,5)*.1,i%3?"rgba(110,110,110,.75)":"rgba(60,60,60,.7)");for(let i=0;i<4;i++)blob(.6+dRnd(tx,ty,i+60)*4.8,.6+dRnd(ty,tx,i+70)*4.8,.12,["#d9a441","#b5482f","#e8d9b0"][i%3]);blob(1.5+dRnd(tx,ty,90)*3,1.5+dRnd(ty,tx,91)*3,.9,"rgba(150,120,80,.22)")}
if(lv>=3){blob(2+dRnd(tx,ty,100)*2,2+dRnd(ty,tx,101)*2,1.7,"rgba(40,30,25,.35)",.6);blob(1.2+dRnd(tx,ty,102)*3.5,1.2+dRnd(ty,tx,103)*3.5,1.1,"rgba(70,50,30,.4)",.5);for(let i=0;i<8;i++)blob(.4+dRnd(tx,ty,i+120)*5.2,.4+dRnd(ty,tx,i+130)*5.2,.1+dRnd(i,ty,7)*.12,"rgba(30,30,30,.8)")}}
function dirtDraw(k){const D=G.dirt;if(!D||R.vis)return;FLT.forEach(([tx,ty])=>{const v=D[tx+","+ty]||0;if(v>=25)dirtTile(k,tx,ty,dLv(v))})}
function cleanPct(){const D=G.dirt||{};let s2=0,n=0;FLT.forEach(([tx,ty])=>{s2+=Math.min(100,D[tx+","+ty]||0);n++});return n?Math.round(100-s2/n):100}
function dirtSet(key,v){G.dirt=G.dirt||{};const o=G.dirt[key]||0;v=Math.max(0,Math.min(100,v));G.dirt[key]=v;if(dLv(o)!==dLv(v))G.dv=(G.dv||0)+1}
/* 1日の終わりに汚れがたまる（席のまわり・入口付近が汚れやすい） */
function dirtDay(visits){const near=new Set();(G.furn||[]).forEach(F=>{try{furnFoot(F).forEach(k=>{const[a,b]=k.split(",").map(Number);for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++)near.add((a+dx)+","+(b+dy))})}catch(e){}});
const v=Math.max(0,visits||0);FLT.forEach(([tx,ty])=>{const key=tx+","+ty;let add=3+Math.random()*3+(near.has(key)?v*1.6:v*.45)+(tx<=2&&ty<=3?v*.8:0);dirtSet(key,(G.dirt[key]||0)+add)});G.dv=(G.dv||0)+1}
{const _dd=dayDone;dayDone=function(en){const r=_dd.apply(this,arguments);try{if(en&&!en.closed)dirtDay(en.visits)}catch(e){}return r}}
/* 汚いと口コミが下がる・不満がたまる */
{const _ra=revAdd;revAdd=function(c,p){_ra.apply(this,arguments);try{const cp=cleanPct(),r=G.rev&&G.rev[c.i];if(r&&cp<60&&Math.random()<(cp<35?.8:.45)){r.s=Math.max(1,r.s-1);r.t=rnd(["床が汚かった…","ちょっと店が汚れてたかも","掃除してほしいな","足元が気になった"])}if(G.pika===G.day&&r&&Math.random()<.5)r.s=Math.min(5,r.s+1)}catch(e){}}}
{const _ev2=endVisit;endVisit=function(c,p){try{const cp=cleanPct();if(c&&cp<50)c.up=Math.min(100,(c.up||0)+(cp<35?8:4))}catch(e){}return _ev2.apply(this,arguments)}}
/* やる気の枠を「きれいさ」に。やる気で廃業はしない */
{const _ma=motAdd;motAdd=function(){const r=_ma.apply(this,arguments);if(G.mot!=null&&G.mot<5)G.mot=5;return r}}
{const _hv4=hud;hud=function(){const r=_hv4.apply(this,arguments);try{const b=document.getElementById("mtm");if(b){const d=b.parentNode,t=d.firstChild;if(t&&t.nodeType===3&&t.textContent!=="🧹 きれいさ")t.textContent="🧹 きれいさ";const p=cleanPct(),v=p+"%";if(b.textContent!==v)b.textContent=v;const bar=document.getElementById("mtmb");if(bar){bar.style.width=p+"%";bar.style.background=p>=70?"#7bd389":p>=45?"#e0c34a":"#e06a5a"}}}catch(e){}return r}}
/* ===== 今日の行動に「🧹 掃除」 ===== */
MNA.clean=["🧹","掃除"];
{const _sm=showMorning;showMorning=function(){const r=_sm.apply(this,arguments);try{const box=document.querySelector("#ov .mnc");if(!box||box.querySelector('[data-mo="clean"]'))return r;const g=box.querySelector(".mg"),cp=cleanPct();
const b=document.createElement("button");b.dataset.mo="clean";b.innerHTML=`<span class="e">🧹</span><b>掃除</b><small>無料・なぞって掃除するミニゲーム（いま きれいさ ${cp}%）</small>`;const fc=g.querySelector('[data-mo="focus"]');g.insertBefore(b,fc);
const ms=box.querySelectorAll(".ms>div");const last=ms[ms.length-1];if(last)last.innerHTML=`<small>🧹 きれいさ</small><b style="color:${cp>=45?"inherit":"#e53935"}">${cp}%</b>`;const w=box.querySelector(".mw");if(w)w.remove()}catch(e){}return r}}
{const _ac2=act;act=function(k){if(k!=="clean")return _ac2.apply(this,arguments);const o=G.ow;if(!o||R.phase!=="prep"||o.acted||G.over||!G.setup)return;o.acted=1;G.actK="clean";G.actD=G.day;R.mOpen=0;save();ovOff();setTimeout(()=>{ovOff();cleanStart()},60)}}
/* ===== 掃除ミニゲーム ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
#clov{position:fixed;inset:0;z-index:70;touch-action:none}
#clhd{position:fixed;left:50%;top:calc(var(--uit,104px) + 8px);transform:translateX(-50%);z-index:71;background:#005d4d;color:#fff;border-radius:16px;padding:8px 16px;font-weight:900;font-size:15px;white-space:nowrap;text-align:center;pointer-events:none}
#clhd b{color:#ffd76a;font-size:20px;margin-left:6px}#clhd small{display:block;font-size:11px;color:#8fc9bc;font-weight:700}
.clc{background:#f3f1ea!important;color:#123a33!important;border:none!important;border-radius:16px!important;text-align:center}
.clc .bt{display:flex;gap:10px;margin-top:12px}
#ov .clc button{flex:1;border-radius:14px!important;padding:11px 0!important;font-weight:900!important;font-size:15px!important;border:2px solid #005d4d!important;background:#fff!important;color:#005d4d!important}
#ov .clc button.a{flex:1.5;background:#6658a6!important;border-color:#6658a6!important;color:#fff!important}
.clspk{position:fixed;z-index:72;pointer-events:none;font-size:18px;animation:clspk .6s ease-out forwards}
@keyframes clspk{from{opacity:1;transform:translate(-50%,-50%) scale(.6)}to{opacity:0;transform:translate(-50%,-90%) scale(1.3)}}
</style>`)}catch(e){}
function scr2tile(clx,cly){const r=cv.getBoundingClientRect(),X=(clx-r.left)*W/r.width,Y=(cly-r.top)*CH/r.height,k=R.cv||camVec(),a=(X-k.ox)/k.s,b=-(Y-k.oy)/k.s-(0-TZ)*k.uz,det=k.rx*k.uy-k.ry*k.ux;if(Math.abs(det)<1e-6)return null;
const dx=(a*k.uy-k.ry*b)/det,dy=(k.rx*b-a*k.ux)/det,x=dx+TX,y=dy+TY;return[Math.floor(x/6),Math.floor(y/6),x,y]}
function cleanStart(){const cp=cleanPct();ov(`<div class="card clc"><div style="font-size:44px">🧹</div><b style="font-size:18px">なぞって掃除！</b><div style="font-size:13px;margin:8px 0;line-height:1.7">制限時間は<b>15秒</b>。床を指でなぞると汚れが落ちます。<br>ひどい汚れは何回かなぞってね。<br>いまのきれいさ：<b>${cp}%</b></div><div class="bt"><button id="clauto">おまかせ（80%まで）</button><button id="clgo" class="a">スタート ▶</button></div></div>`);
const c=document.querySelector("#ov .clc");if(c)c.onclick=e=>{const b=e.target.closest("button");if(!b)return;e.stopPropagation();if(b.id==="clgo"){ovOff();cleanPlay()}else if(b.id==="clauto"){ovOff();const before=cleanPct();FLT.forEach(([tx,ty])=>{const k=tx+","+ty;dirtSet(k,Math.min(G.dirt[k]||0,20))});G.dv=(G.dv||0)+1;save();cleanEnd(before,0)}}}
function cleanPlay(){const before=cleanPct(),cam=JSON.stringify(R.cam);let left=15,last=null,lastT=0;const o=document.createElement("div");o.id="clov";document.body.appendChild(o);const h=document.createElement("div");h.id="clhd";document.body.appendChild(h);
const upd=()=>{h.innerHTML=`🧹 なぞって掃除！<b>${Math.ceil(left)}</b><small>きれいさ ${cleanPct()}%</small>`};upd();const t0=performance.now();
const scrub=(e)=>{const p=scr2tile(e.clientX,e.clientY);if(!p)return;const key=p[0]+","+p[1];if(!FLS.has(key))return;const n=performance.now();if(key===last&&n-lastT<160)return;last=key;lastT=n;const v=G.dirt&&G.dirt[key]||0;if(v<=0)return;dirtSet(key,v-34);G.dv=(G.dv||0)+1;
OW.x=Math.max(0,Math.min(60,p[2]));OW.y=Math.max(0,Math.min(60,p[3]));OW.mode="";OW.path=[];OW._pc=null;if(v-34<25){const s2=document.createElement("div");s2.className="clspk";s2.textContent="✨";s2.style.left=e.clientX+"px";s2.style.top=e.clientY+"px";document.body.appendChild(s2);setTimeout(()=>s2.remove(),650)}upd()};
let down=0;o.addEventListener("pointerdown",e=>{down=1;try{o.setPointerCapture(e.pointerId)}catch(_){}scrub(e)});o.addEventListener("pointermove",e=>{if(down)scrub(e)});o.addEventListener("pointerup",()=>{down=0});o.addEventListener("pointercancel",()=>{down=0});
const tm=setInterval(()=>{R.cam=JSON.parse(cam);left=15-(performance.now()-t0)/1000;upd();if(left<=0){clearInterval(tm);o.remove();h.remove();save();cleanEnd(before,1)}},100)}
function cleanEnd(before,game){const after=cleanPct(),pk=game&&after>=95;if(pk)G.pika=G.day;save();try{hud()}catch(e){}
ov(`<div class="card clc"><div style="font-size:44px">${pk?"✨":"🧹"}</div><b style="font-size:18px">${pk?"ピカピカ！":"掃除しました"}</b><div style="font-size:15px;margin:10px 0">きれいさ <b>${before}%</b> → <b style="color:#2a9a7c">${after}%</b></div>${pk?`<div style="font-size:12.5px;color:#6658a6;font-weight:900">ピカピカボーナス：今日の口コミが良くなりやすい！</div>`:""}<div class="bt"><button id="clok" class="a">開店準備へ</button></div></div>`);
const c=document.querySelector("#ov .clc");if(c)c.onclick=e=>{if(e.target.closest("#clok")){e.stopPropagation();ovOff();try{rown();fmAct()}catch(_){}}}}
/* 業者に頼む（行動を使わずにきれいに・¥3,000） */
{const _fa=fmAct;fmAct=function(){const r=_fa.apply(this,arguments);try{const d=$("#fmst2");if(d&&R.phase==="prep"&&!d.querySelector("[data-clpro]")){const b=document.createElement("button");b.dataset.clpro="1";b.textContent="🧹 業者に掃除を頼む ¥3,000";b.style.cssText="margin-top:8px;width:100%";d.style.flexWrap="wrap";d.appendChild(b);b.onclick=e=>{e.stopPropagation();if(G.money<3000){toast("お金が足りません");return}if(cleanPct()>=98){toast("もう十分きれいです");return}G.money-=3000;FLT.forEach(([tx,ty])=>dirtSet(tx+","+ty,0));G.dv=(G.dv||0)+1;save();hud();toast("🧹 業者さんがピカピカにしてくれました");log("🧹 清掃業者に頼んだ（¥3,000）")}}}catch(e){}return r}}
if(!G.dirt)G.dirt={};
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
