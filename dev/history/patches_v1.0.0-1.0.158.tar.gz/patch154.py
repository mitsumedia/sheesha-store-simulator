import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 背景の描き直し：明るさが変わらない時間帯（昼・夜）は描き直さない。夕方・明け方だけ20分ごと
rep('Math.round(hr*6),R.pvF!=null','bgLK(hr),R.pvF!=null')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
function bgLK(hr){let h=((hr%24)+24)%24;if(h<4)h+=24;for(let i=0;i<LKF.length-1;i++){const a=LKF[i],b=LKF[i+1];if(h>=a[0]&&h<b[0]){if(a.slice(1).join()===b.slice(1).join())return"P"+i;break}}return"T"+Math.round(hr*3)}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
