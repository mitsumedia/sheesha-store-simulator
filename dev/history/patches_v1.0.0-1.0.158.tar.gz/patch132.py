import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 今夜 山田：後ろで結んだ髪（ポニーテールに見える部分）を消す
rep('H(1,5,5,6,1,1,"#e2b48e");H(3,-1,2,2,1,2,hr);H(3,-2,1,2,1,2,hr);','H(1,5,5,6,1,1,"#e2b48e");')
rep('後ろになでつけた黒髪（後ろで小さく結ぶ）','後ろになでつけた黒髪')
open(f,'w').write(s)
