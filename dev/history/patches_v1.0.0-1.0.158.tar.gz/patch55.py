import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# --- 模様替え：動かすときは向きを保ったまま位置をずらして合わせ、どうしても無理なときだけ向きを変える ---
rep('const F=G.furn[m.i],N=Object.assign({},F,{tx,ty});if(furnFits(N,m.i))Object.assign(F,N);else Object.assign(F,fFlip(N));',
    'const F=G.furn[m.i],N=Object.assign({},F,{tx,ty});Object.assign(F,mvKeep(F,N,m.i));',2)
# --- チェキ：座るポーズは店内のソファに座らせる ---
rep('const X0=spot[0]*6+1.5,Y0=spot[1]*6+1;','const X0=spot[0]*6+1.5,Y0=spot[1]*6+1;R.ckPose=pi;const SP2=pose.sit?ckSitPairs():[],sp2=SP2.length?SP2[(((R.ckSp||0)%SP2.length)+SP2.length)%SP2.length]:null;')
rep('TX=X0+(gap+4)/2;TY=Y0+2;R.cam={yaw:[.22,-.42][spI%2],pit:.24,zoom:(pose.hk?4.4:4.9)*(Math.min(W,CH*.93)/520)};',
    'TX=X0+(gap+4)/2;TY=Y0+2;R.cam={yaw:[.22,-.42][spI%2],pit:.24,zoom:(pose.hk?4.4:4.9)*(Math.min(W,CH*.93)/520)};if(sp2){const[a1,b1]=sp2;TX=(a1.px+b1.px)/2+2;TY=(a1.Y0+b1.Y0)/2+3;R.cam.yaw=(a1.f>0?0:Math.PI)+((R.ckSp||0)%2?-.3:.25);R.cam.zoom=4.3*(Math.min(W,CH*.93)/520)}')
rep('if(pose.sit){box(a,X0-.5,Y0,0,gap+5,3,2,"#7a4e2d");box(a,X0-.5,Y0-1,0,gap+5,1,6,"#5e3a1e")}','if(pose.sit&&!sp2){box(a,X0-.5,Y0,0,gap+5,3,2,"#7a4e2d");box(a,X0-.5,Y0-1,0,gap+5,1,6,"#5e3a1e")}')
rep('let p1=[],p2=[];pv(p1,X0,Y0,1,ow,pose.sit?1:0,0,pose.hd?1:0);pv(p2,X0+gap,Y0,1,cu,pose.sit?1:0,0,pose.hd?2:0);',
    'let p1=[],p2=[];if(sp2){const[a1,b1]=sp2;pv(p1,a1.px,a1.Y0,a1.f,ow,1,0,pose.hd?1:0);seatPose(p1,a1,ow);pv(p2,b1.px,b1.Y0,b1.f,cu,1,0,pose.hd?2:0);seatPose(p2,b1,cu)}else{pv(p1,X0,Y0,1,ow,pose.sit?1:0,0,pose.hd?1:0);pv(p2,X0+gap,Y0,1,cu,pose.sit?1:0,0,pose.hd?2:0)}')
rep('if(pose.hk){const S=.8;','if(pose.hk&&!sp2){const S=.8;')
rep('a=a.concat(p1,p2);[[X0+2,Y0+2],[X0+gap+2,Y0+2]].forEach(','a=a.concat(p1,p2);(sp2?[]:[[X0+2,Y0+2],[X0+gap+2,Y0+2]]).forEach(')
rep('if(pose.smoke){const T0=.75,ss=pose.ss||1;[[X0+2],[X0+gap+2]].forEach(([mx],n)=>{const dir=n?1:-1;for(let q=0;q<7;q++){const a2=T0-q*.07;if(a2<0)continue;const o=P3(mx+dir*(.4+a2*(1.4+2.6*ss))+Math.sin(q*2.3)*.4,Y0+3.6+a2*7,8.5+a2*2.6+q*.1,k);',
    'if(pose.smoke){const T0=.75,ss=pose.ss||1;(sp2?sp2.map(q=>[q.px+2,q.Y0,q.f]):[[X0+2,Y0,1],[X0+gap+2,Y0,1]]).forEach(([mx,my,ff],n)=>{const dir=n?1:-1,fy=ff>0?1:-1,by=ff>0?my:my+6;for(let q=0;q<7;q++){const a2=T0-q*.07;if(a2<0)continue;const o=P3(mx+dir*(.4+a2*(1.4+2.6*ss))+Math.sin(q*2.3)*.4,by+fy*(3.6+a2*7),8.5+a2*2.6+q*.1,k);')
rep('function ckSpLbl(){const e=document.getElementById("cksn"),n=ckSpots().length;','function ckSpLbl(){const e=document.getElementById("cksn"),n=(R.ckPose!=null&&CKP[R.ckPose]&&CKP[R.ckPose][1].sit&&ckSitPairs().length)?ckSitPairs().length:ckSpots().length;')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* 模様替えで動かすとき：向きはそのまま。合わなければ1マスずらして試し、それでもだめなときだけ向きを変える */
function mvKeep(F,N,mi){const alts=[N];if(!N.o&&F.k!=="b"&&F.k!=="bb")alts.push(Object.assign({},N,{ty:N.ty-N.f}));if(N.o){const dx=N.o===1?1:-1;alts.push(Object.assign({},N,{tx:N.tx-dx}))}
for(const a of alts)if(furnFits(a,mi))return a;return fFlip(N)}
/* チェキ：座れるソファの2人分の組（横向きの席は除く） */
function ckSitPairs(){const L=[],seen=new Set();SEATS.forEach(s=>{if(s.o||s.kind==="bb"||s.kind==="c")return;(s.nb||[]).forEach(o=>{if(o.fid!==s.fid||o.o)return;const k=Math.min(s.id,o.id)+"-"+Math.max(s.id,o.id);if(seen.has(k))return;seen.add(k);const pr=[s,o].sort((x,y)=>x.px-y.px);L.push(pr)})});
const byF=new Map();L.forEach(p=>{const f=p[0].fid;if(!byF.has(f))byF.set(f,p)});return[...byF.values()]}
{const _cd=chekiDraw;chekiDraw=function(){const r=_cd.apply(this,arguments);try{ckSpLbl()}catch(e){}return r}}
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
