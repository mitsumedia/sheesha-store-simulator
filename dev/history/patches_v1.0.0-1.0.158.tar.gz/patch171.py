import sys
f=sys.argv[1];s=open(f).read()
a='const dd=m.face?1:(m.s>0?0:2),ox=m.x-2,oy=m.y-1.5+(!m.face&&Math.sin(m.t*10)>0?.15:0)'
c=s.count(a);assert c==1,c
s=s.replace(a,'const dd=m.dd!=null?m.dd:(m.face?1:(m.s>0?0:2)),ox=m.x-2,oy=m.y-1.5+(!m.face&&!m.ev&&Math.sin(m.t*10)>0?.15:0)+(m.q&&m.q.bob&&Math.sin(m.t*8)>0?.25:0)')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(TAIL)==1
s=s.replace(TAIL,open('/home/claude/w/p171.js').read()+'\n'+TAIL)
open(f,'w').write(s)
