import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# A 足場
rep('else{const n=SDEF[F.k].n;for(let i=0;i<n;i++){o.push((F.tx+i)+","+F.ty);o.push((F.tx+i)+","+(F.ty+F.f))}}return o}',
    'else{const n=SDEF[F.k].n;if(F.o){const dx=F.o===1?1:-1;for(let i=0;i<n;i++){o.push(F.tx+","+(F.ty+i));o.push((F.tx+dx)+","+(F.ty+i))}}else for(let i=0;i<n;i++){o.push((F.tx+i)+","+F.ty);o.push((F.tx+i)+","+(F.ty+F.f))}}return o}')
# B 席データ
rep('G.furn.forEach((F,fid)=>{const t=F.k;if(t==="b"){if(F.f>0)',
    'G.furn.forEach((F,fid)=>{const t=F.k;if(F.o){if(t==="b"){if(F.o===1)BENCH.push({tx:F.tx,ty:F.ty,n:3,f:1,o:1,kind:t,fid},{tx:F.tx+2,ty:F.ty+1,n:2,f:1,o:3,kind:t,fid});else BENCH.push({tx:F.tx+2,ty:F.ty,n:3,f:1,o:3,kind:t,fid},{tx:F.tx,ty:F.ty,n:2,f:1,o:1,kind:t,fid})}else BENCH.push({tx:F.tx,ty:F.ty,n:SDEF[t].n,f:1,o:F.o,kind:t,fid})}else if(t==="b"){if(F.f>0)')
rep('BENCH.forEach(b=>{for(let i=0;i<b.n;i++)SEATS.push({id:SEATS.length,px:(b.tx+i)*6+1,Y0:b.ty*6,f:b.f,kind:b.kind,fid:b.fid,p:null,nb:[]})});',
    'BENCH.forEach(b=>{for(let i=0;i<b.n;i++)SEATS.push(b.o?{id:SEATS.length,px:b.tx*6+1,Y0:(b.ty+i)*6,f:1,o:b.o,kind:b.kind,fid:b.fid,p:null,nb:[]}:{id:SEATS.length,px:(b.tx+i)*6+1,Y0:b.ty*6,f:b.f,kind:b.kind,fid:b.fid,p:null,nb:[]})});')
rep('SEATS.forEach(a=>SEATS.forEach(b=>{if(a!==b&&a.Y0===b.Y0&&a.f===b.f&&Math.abs(a.px-b.px)===6)a.nb.push(b)}));',
    'SEATS.forEach(a=>SEATS.forEach(b=>{if(a!==b&&a.f===b.f&&(a.o||0)===(b.o||0)&&(a.o?a.px===b.px&&Math.abs(a.Y0-b.Y0)===6:a.Y0===b.Y0&&Math.abs(a.px-b.px)===6))a.nb.push(b)}));')
rep('!ch.includes(o)&&o.f===s.f&&o.Y0===s.Y0);','!ch.includes(o)&&o.f===s.f&&(o.o||0)===(s.o||0));')
# F メガネ
rep('glFx(s.px,s.Y0,s.f,1,0,','glFxS(s,',2)
# H ホース
rep('dy=hc.rot===0?-1:1,S=hc.sc||1,A=[hc.x+.13*S,hc.y+dy*.92*S,(hc.z||0)+5.75*S]','S=hc.sc||1,pq=hc.rot===0?[.13,-.92]:hc.rot===2?[.13,.92]:hc.rot===1?[-.92,-.13]:[.92,.13],A=[hc.x+pq[0]*S,hc.y+pq[1]*S,(hc.z||0)+5.75*S]')
rep('P0=[s.px+lx+.25,(f>0?s.Y0+5.6:s.Y0+6-5.6-.5)+.25,7.25-seatZo(s)]','P0=(q=>s.o?[...sRot(s,q[0],q[1]),q[2]]:q)([s.px+lx+.25,(f>0?s.Y0+5.6:s.Y0+6-5.6-.5)+.25,7.25-seatZo(s)])')
rep('const HKC=new Map();','HKV[1]=HKV[0].map(v=>[v[1],-v[0]-HKS,v[2],v[3],undefined,HKS]);HKV[3]=HKV[0].map(v=>[-v[1]-HKS,v[0],v[2],v[3],undefined,HKS]);\nconst HKC=new Map();')
# I ビーズクッションのふくらみ
rep('for(let z=1;z<3;z++)a.push([s.px+x,s.f>0?s.Y0+y:s.Y0+5-y,z,z===2?v.cl:v.c])})}','for(let z=1;z<3;z++){const w=[s.px+x,s.f>0?s.Y0+y:s.Y0+5-y,z,z===2?v.cl:v.c];if(s.o)sRotV([w],s);a.push(w)}})}')
# J 吐く煙の向き
rep('const o=P(p.x+Math.sin(q*2.3)*2,p.y+f*(a2*8),9+a2*8+q*.3);','const so=p.seat.o,o=so?P(p.x+(so===1?1:-1)*a2*8,p.y+Math.sin(q*2.3)*2,9+a2*8+q*.3):P(p.x+Math.sin(q*2.3)*2,p.y+f*(a2*8),9+a2*8+q*.3);')
# K 店主の炭替え
rep('OW.adjF=f;OW.path=[[hc.x,hc.y+(f>0?2.4:-2.4)]]','OW.adjF=f;OW.adjO=p.seat.o||0;OW.path=[OW.adjO?[hc.x+(OW.adjO===1?2.4:-2.4),hc.y]:[hc.x,hc.y+(f>0?2.4:-2.4)]]')
rep('OW.dir=OW.adjF>0?2:0;','OW.dir=OW.adjO?(OW.adjO===1?3:1):(OW.adjF>0?2:0);')
# L 設置
rep('let F={k,sr,tx,ty,f:1};if(!furnFits(F,-1)){F={k,sr,tx,ty,f:-1};if(k==="b"||!furnFits(F,-1)){log(k==="b"?"3×3マスの空きが必要です":"席と、その前の1列（シーシャ台用）の空きが必要です");return}}',
    'let F=[{f:1},{f:-1},{f:1,o:1},{f:1,o:3}].map(q=>Object.assign({k,sr,tx,ty},q)).find(q=>furnFits(q,-1));if(!F){log(k==="b"?"3×3マスの空きが必要です":"席と、その前の1列（シーシャ台用）の空きが必要です");return}')
rep('furnFits({k:stt,tx,ty,f:1},-1)||(stt!=="b"&&furnFits({k:stt,tx,ty,f:-1},-1))','furnFits({k:stt,tx,ty,f:1},-1)||(stt!=="b"&&furnFits({k:stt,tx,ty,f:-1},-1))||furnFits({k:stt,tx,ty,f:1,o:1},-1)||furnFits({k:stt,tx,ty,f:1,o:3},-1)')
# M 移動
rep('if(furnFits(N,m.i)||(F.k!=="b"&&furnFits(Object.assign({},N,{f:-N.f}),m.i)))o.add(key)','if(furnFits(N,m.i)||furnFits(fFlip(N),m.i))o.add(key)')
rep('if(furnFits(N,m.i))Object.assign(F,N);else Object.assign(F,N,{f:-N.f});','if(furnFits(N,m.i))Object.assign(F,N);else Object.assign(F,fFlip(N));',2)
# N 回転：4方向
rep('const F=G.furn[m.i],N=Object.assign({},F,{f:-F.f});if(!furnFits(N,m.i)){log("向きを変えるには、反対側の1列にも空きが必要です");return}F.f=N.f;mvDone();mvSel(m);return}',
    'const F=G.furn[m.i],cur=F.o===1?1:F.o===3?3:(F.f>0?0:2),n=F.k==="b"?3:SDEF[F.k].n;let ok=null;for(let st=1;st<4&&!ok;st++){const nx=(cur+st)%4,q=nx===0?{f:1,o:0}:nx===2?{f:-1,o:0}:{f:1,o:nx};for(const[dx,dy]of[[0,0],[0,-(n-1)],[-(n-1),0],[1,0],[-1,0],[0,1],[0,-1]]){const N=Object.assign({},F,q,{tx:F.tx+dx,ty:F.ty+dy});if(furnFits(N,m.i)){ok=N;break}}}if(!ok){log("向きを変えるには、まわりに空きが必要です");return}Object.assign(F,ok);mvDone();mvSel(m);return}')
# O 当たり判定
rep('seat=F.k==="b"||ty===F.ty,','seat=F.k==="b"||(F.o?tx===F.tx:ty===F.ty),')
rep('/向きを変えるには|','/向きを変えるには|')
ADD=r'''
/* ===== 客席の4方向対応：横向き（o=1:右向き / o=3:左向き）は「手前向きで作ってから90°回す」 ===== */
function fFlip(N){return N.o?Object.assign({},N,{o:4-N.o}):Object.assign({},N,{f:-N.f})}
function sRot(s,x,y){const ax=s.px+2,ay=s.Y0+3,dx=x-ax,dy=y-ay;return s.o===1?[ax+dy,ay-dx]:[ax-dy,ay+dx]}
function sRotV(t,s){t.forEach(v=>{const z=v[5]||1,q=sRot(s,v[0]+z/2,v[1]+z/2);v[0]=q[0]-z/2;v[1]=q[1]-z/2})}
function glFxS(s,kind,col,ly,zo){return s.o===1?glFx(s.px-1,s.Y0+1,1,0,1,kind,col,ly,zo):s.o===3?glFx(s.px+2,s.Y0+1,1,0,3,kind,col,ly,zo):glFx(s.px,s.Y0,s.f,1,0,kind,col,ly,zo)}
{const _sp=seatPose;seatPose=function(t,s,c){_sp(t,s,c);if(s&&s.o)sRotV(t,s)}}
{const _ab=actBuild;actBuild=function(t,p,md){const n0=t.length,r=_ab(t,p,md),s=p.seat;if(s&&s.o){sRotV(t.slice(n0),s);if(r){r.bx.forEach(b=>{const c=sRot(s,b.x+b.w/2,b.y+b.d/2),w=b.d,d=b.w;b.w=w;b.d=d;b.x=c[0]-w/2;b.y=c[1]-d/2});if(r.sp){const q=sRot(s,r.sp[0],r.sp[1]);r.sp[0]=q[0];r.sp[1]=q[1]}}}return r}}
{const _hk=hkCenter;hkCenter=function(p){const s=p.seat;if(!s||!s.o)return _hk(p);const fx=s.o===1?1:-1;
 if(p.sh&&s.kind!=="c"){const A=p.sh.a.seat,B=p.sh.b.seat,o={x:(A.px+B.px)/2+2+fx*5.3,y:(A.Y0+B.Y0)/2+3,rot:s.o};if(s.kind==="b"){o.z=3;o.sc=.7}return o}
 const sh=p.sh;p.sh=null;let o;try{o=_hk(p)}finally{p.sh=sh}const q=sRot(s,o.x,o.y);o.x=q[0];o.y=q[1];o.rot=s.o;return o}}
{const _fv=furnVox;furnVox=function(F,ox,oy){if(!F.o)return _fv(F,ox,oy);const tx=ox!==undefined?ox:F.tx,ty=oy!==undefined?oy:F.ty,n=F.k==="b"?3:SDEF[F.k].n,L=6*n,D=F.k==="b"?18:6;
 return _fv(Object.assign({},F,{f:1,o:0}),0,0).map(v=>{const w=v.slice();if(F.o===1){w[0]=tx*6+v[1];w[1]=ty*6+L-1-v[0]}else{w[0]=tx*6+D-1-v[1];w[1]=ty*6+v[0]}return w})}}
try{furnRebuild()}catch(e){}
'''
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T);open(f,'w').write(s);print('ok')
