import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 元恋人は話しかけると専用セリフだけ
rep('giftTry(p);if((R.mtk||0)<8){R.mtk=(R.mtk||0)+1;motAdd(2)}return}\nif(p.tp>c.tl&&c.fp<40)','giftTry(p);if((R.mtk||0)<8){R.mtk=(R.mtk||0)+1;motAdd(2)}return}\nif(c.moto){G.talkN=(G.talkN||0)+1;c.hp=Math.min(100,c.hp+1);NOGOBI=1;sayX(p,rnd(MOTOL));NOGOBI=0;return}\nif(p.tp>c.tl&&c.fp<40)')
open(f,'w').write(s)
