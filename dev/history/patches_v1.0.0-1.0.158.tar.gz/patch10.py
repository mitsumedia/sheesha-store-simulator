import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 視察：50%でシーシャ屋（親密度100未満）と話す → 30%で7日以内に来店（条件無視・以後は出現済み）
rep('const nf=flSkill().concat(flVisit());','const nf=flSkill().concat(flVisit());let shT="";{const L=G.cs.filter(c=>c.job==="シーシャ屋"&&(c.vn||0)<3&&!(G.shF||[]).some(x=>x.i===c.i));if(L.length&&Math.random()<.5){const c=rnd(L);shT="　💬 "+(c.nick||c.name)+"さんと話した！";log("💬 視察先で "+(c.nick||c.name)+" さんと話した");if(Math.random()<.3){G.shF=(G.shF||[]).concat([{i:c.i,d:G.day+1+(Math.random()*7|0)}])}}}')
rep('"」を見つけた！":""));hud();closeDay("🚶','"」を見つけた！":"")+shT);hud();closeDay("🚶')
rep('const so=G.cs.filter(k=>k.act&&k.g<0)','(G.shF||[]).filter(x=>x.d<=G.day).forEach(x=>{const k=G.cs[x.i];if(!k||taken.has(k.i))return;taken.add(k.i);k.act=1;R.sched.push({at:at("any"),m:[k]})});G.shF=(G.shF||[]).filter(x=>x.d>G.day);\nconst so=G.cs.filter(k=>k.act&&k.g<0)')
open(f,'w').write(s);print('ok')
