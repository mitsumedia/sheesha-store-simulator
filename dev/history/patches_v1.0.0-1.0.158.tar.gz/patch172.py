import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('go:()=>{const t=td();t.dm=(t.dm||1)*.8}}','go:()=>{const t=td();t.dm=(t.dm||1)*.8;t.koji=1}}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 店の前のイベント：芸能人・YouTuberは図鑑のお客さんが出る／工事は「前の道で工事中」の日だけ一日中 ===== */
XP.selfie=(a)=>{a(3.4,1.2,7,.25,.25,6,"#9e9e9e",.25);a(3,.8,13,1,.5,1.5,"#212121",.5,1)};
(()=>{const f=id=>XEV.find(e=>e.id===id);
 const roke=f("roke");if(roke){roke.parts[0].celeb="芸能人";roke.cv="が店の前でロケをしていた"}
 const de=f("demachi");if(de){de.parts.splice(1,0,XPp(-14,2,3,null,null,{celeb:"芸能人"}));de.cv="が店の前に現れた！"}
 const ei=f("eiga");if(ei){ei.parts[2].celeb="芸能人";ei.parts[3].celeb="芸能人";ei.cv="が店の前で映画の撮影をしていた"}
 XEV.push({id:"youtube",n:"YouTuberの撮影",r:4,dur:60,talk:["外でYouTuberが撮影してましたよ！","さっきの人、動画で見たことあるかも"],cv:"が店の前で撮影していた",parts:[XPp(-8,-2,3,null,["selfie"],{celeb:"YouTuber"}),...onl(2,-12,6)]});
 const kj=f("koji");if(kj){kj.link=1;kj.talk=["前の工事、一日中やってますね","工事の音、けっこう響きますね","今日は前が工事で、来るの大変でした"]}})();
/* 図鑑のお客さんを選ぶ（会っていない人も出る。名前は「？？？」） */
function xCeleb(job,used){const inS=new Set((R.people||[]).map(p=>p.c));const L=G.cs.filter(c=>c&&c.job===job&&!inS.has(c)&&!used.includes(c));return L.length?L[Math.floor(Math.random()*L.length)]:null}
{const _xs=xEvStart;xEvStart=function(ev){const used=[];const keep=ev.parts.map(q=>q.lk);ev.parts.forEach(q=>{if(q.celeb){const c=xCeleb(q.celeb,used);if(c)used.push(c);q._c=c}});const r=_xs.apply(this,arguments);
 try{const X=MB.xev;if(X){X.ents.forEach(m=>{if(m.q&&m.q._c){m.c=m.q._c;m.cel=1}});if(used.length&&ev.cv){const nmz=used.map(c=>c.met?nm(c):"？？？").join("と");const t="👀 "+nmz+ev.cv;log(t);mbBand(t)}}}catch(e){}ev.parts.forEach(q=>{delete q._c});return r}}
/* 工事は「前の道で工事中」の日だけ。その日は一日中 */
{const _pl=xEvPlan;xEvPlan=function(){const kj=XEV.find(e=>e.id==="koji");if(td().koji&&kj){MB.xev=null;MB.xPlan={ev:Object.assign({},kj,{dur:Math.max(60,G.close*60-R.t-10)}),at:R.t};return}const sv=XEV.indexOf(kj);if(sv>=0)XEV.splice(sv,1);try{_pl.apply(this,arguments)}finally{if(sv>=0)XEV.splice(sv,0,kj)}}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
