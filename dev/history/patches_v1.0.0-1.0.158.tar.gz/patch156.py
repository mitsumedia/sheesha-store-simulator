import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 街の動き：店の前を人や車が通る（同時に車3・人4まで。軽量モードでは出さない）＋「街で見たもの」 ===== */
const MB_SK=["#ffe0c4","#f1c7a0","#e0aa7e","#c58a5c","#9b6440"],MB_HR=["#161616","#3b2a1e","#6b4a2b","#a8743c","#e0c068","#c9c9c9"],MB_CL=["#2b2b3a","#ffffff","#c0392b","#e67e22","#f1c40f","#27ae60","#2980b9","#8e44ad","#e86aa6","#7f8c8d","#455a64","#6d4c41"];
const mbP=(o,a)=>o[(a*7919|0)%o.length];
/* 部品：[横x(中心0),前後y(後ろ0),高さz,幅,長さ,高さ,色,光る] */
function mbCar(l,w,h,c,o){o=o||{};const P=[],wh="#212121",gl=o.gl||"#9ecbe0",lw=o.low?.75:1;
 P.push([-w/2,1,1,w,l-2,(h*.45)*lw,c]);if(!o.open)P.push([-w/2+.4,o.cf||l*.28,1+h*.45*lw,w-.8,o.cl||l*.45,h*.4*lw,gl]);else P.push([-w/2+.6,l*.35,1+h*.45*lw,w-1.2,1.4,1.4,"#5d4037"]);
 if(!o.open&&!o.nr)P.push([-w/2+.3,(o.cf||l*.28)+.2,1+h*.85*lw,w-.6,(o.cl||l*.45)-.4,.6,o.rc||c]);
 for(const yy of[2.2,l-4.2])for(const xx of[-w/2-.2,w/2-.8])P.push([xx,yy,0,1,2,1.6,wh]);P.push([-w/2+.6,l-1.2,1.6,1.2,.4,.8,"#fff59d",1],[w/2-1.8,l-1.2,1.6,1.2,.4,.8,"#fff59d",1],[-w/2+.6,.8,1.6,1.2,.4,.8,"#ff5252",1],[w/2-1.8,.8,1.6,1.2,.4,.8,"#ff5252",1]);return P}
function mbBox(l,w,h,c,cab,cc){const P=[],wh="#212121";P.push([-w/2,.8,1,w,l-cab-.8,h,c],[-w/2,l-cab,1,w,cab-.6,h*.75,cc||"#eceff1"],[-w/2+.3,l-1.4,1+h*.4,w-.6,.6,h*.3,"#9ecbe0"]);for(const yy of[2,l-cab+.6,l-3])for(const xx of[-w/2-.2,w/2-.8])P.push([xx,yy,0,1,2,1.6,wh]);P.push([-w/2+.5,l-.9,1.4,1.2,.4,.8,"#fff59d",1],[w/2-1.7,l-.9,1.4,1.2,.4,.8,"#fff59d",1]);return P}
function mbPer(o){const sk=o.sk,P=[],t=o.t||0,sw=Math.sin(t*9)*.7*(o.walk===0?0:1),cl=o.cl,pa=o.pa,hr=o.hr,dz=o.dz||0;
 if(!o.sit){P.push([-1.1,4.5+sw*.5,dz,1,1,4,pa],[.1,4.5-sw*.5,dz,1,1,4,pa])}else P.push([-1.1,5.2,dz+2.6,1,2.4,1,pa],[.1,5.2,dz+2.6,1,2.4,1,pa]);
 P.push([-1.5,4,dz+4,3,2,4,cl],[-2.4,4.5-(o.sit?-1:sw*.4),dz+5,.9,1,3,cl],[1.5,4.5+(o.sit?1:sw*.4),dz+5,.9,1,3,cl],[-1.2,3.8,dz+8.1,2.4,2.4,2.4,sk],[-1.3,3.7,dz+10.2,2.6,2.6,.8,o.hel||hr]);if(!o.hel)P.push([-1.3,3.7,dz+8.6,2.6,.6,1.8,hr]);
 if(o.um)P.push([-.1,4.9,dz+10.6,.2,.2,2.6,"#616161"],[-3.2,1.8,dz+13,6.4,6.4,.5,o.um]);if(o.bag)P.push([1.6,4.2,dz+4.4,1.6,1.4,2,o.bag]);if(o.ph)P.push([-.4,6.4,dz+7.4,.8,.3,1.2,"#212121",1]);return P}
function mbDog(x0,y0,c,big,t){const s=big?1.5:1,b=Math.sin(t*14)*.3;return[[x0-.6*s,y0,1.2*s,1.2*s,3*s,1.2*s,c],[x0-.6*s,y0+2.6*s,1.8*s,1.2*s,1.4*s,1.2*s,c],[x0-.5*s,y0+.2+b,0,.4*s,.4*s,1.2*s,c],[x0+.2*s,y0+.2-b,0,.4*s,.4*s,1.2*s,c],[x0-.5*s,y0+2.2-b,0,.4*s,.4*s,1.2*s,c],[x0+.2*s,y0+2.2+b,0,.4*s,.4*s,1.2*s,c],[x0-.1,y0-.6,2.2*s,.3,.8,.3,c]]}
function mbBike(o,moto){const P=[],wh="#212121",fc=o.fc||"#455a64";P.push([-.2,0,0,.4,2.6,2.6,wh],[-.2,5.4,0,.4,2.6,2.6,wh],[-.25,1.6,2,.5,5,.5,fc],[-.25,6,2,.5,.5,3,fc]);if(moto)P.push([-1,1.4,1.8,2,5,2.2,o.mc||"#c62828"],[-.6,7.2,3.4,1.2,.4,.8,"#fff59d",1]);
 if(o.box)P.push([-1.4,-.2,4,2.8,2.4,2.6,o.box]);if(o.kid)P.push([-1,6.2,3.6,2,1.6,1.6,"#ffeb3b"],[-.7,6.4,5.2,1.4,1.2,1.4,o.sk]);return P.concat(mbPer(Object.assign({},o,{sit:1,walk:0,dz:moto?.4:-.6})).map(p=>[p[0],p[1]-1.6,p[2],p[3],p[4],p[5],p[6],p[7]]))}
/* 種類（k:car 車道 / ped 歩道 / bike 車道寄り）。r=レア度。a=出やすい地域、only=その地域だけ。n=夜だけ、d=昼だけ */
const MBT=[
 {id:"kei",n:"軽自動車",k:"car",r:1,l:13,sp:26,mk:a=>mbCar(13,6,7,mbP(["#f5f5f5","#ffcdd2","#fff59d","#b3e5fc","#c5e1a5","#212121"],a),{cf:3,cl:7})},
 {id:"comp",n:"コンパクトカー",k:"car",r:1,l:15,sp:28,mk:a=>mbCar(15,6.4,6.5,mbP(["#e53935","#1e88e5","#fafafa","#9e9e9e","#43a047"],a))},
 {id:"sedan",n:"セダン",k:"car",r:1,l:18,sp:30,mk:a=>mbCar(18,6.6,5.6,mbP(["#fafafa","#212121","#9e9e9e","#37474f","#5d4037"],a))},
 {id:"wagon",n:"ワゴン",k:"car",r:1,l:18,sp:28,mk:a=>mbCar(18,6.6,6.2,mbP(["#b0bec5","#795548","#1565c0","#fafafa"],a),{cl:10})},
 {id:"mini",n:"ミニバン",k:"car",r:1,l:18,sp:27,a:[4],mk:a=>mbCar(18,6.8,8,mbP(["#fafafa","#212121","#8d6e63","#90a4ae"],a),{cf:3,cl:12})},
 {id:"suv",n:"SUV",k:"car",r:1,l:18,sp:28,mk:a=>mbCar(18,7,8,mbP(["#37474f","#fafafa","#6d4c41","#2e7d32"],a),{cl:10})},
 {id:"ktr",n:"軽トラ",k:"car",r:1,l:13,sp:24,a:[5,5,5,3],mk:()=>{const P=mbBox(13,6,4.5,"#fafafa",5,"#fafafa");P[0][5]=1.2;P.push([-3,1,2.2,.3,7,1.2,"#bdbdbd"],[2.7,1,2.2,.3,7,1.2,"#bdbdbd"]);return P}},
 {id:"taxi",n:"タクシー",k:"car",r:1,l:18,sp:30,a:[0,0,1,2,2],mk:a=>{const P=mbCar(18,6.6,5.6,mbP(["#fdd835","#1b5e20","#212121","#ef6c00"],a));P.push([-.8,8,7.6,1.6,2,1,"#fff59d",1]);return P}},
 {id:"takuhai",n:"宅配のバン",k:"car",r:1,l:17,sp:25,d:1,mk:()=>{const P=mbBox(17,6.8,8,"#fafafa",5,"#fafafa");P.push([3.45,2,3,.1,9,2,"#2e7d32"]);return P}},
 {id:"eigyo",n:"白い営業車",k:"car",r:1,l:17,sp:28,d:1,mk:()=>mbCar(17,6.4,6.6,"#f5f5f5",{cl:10})},
 {id:"bus",n:"路線バス",k:"car",r:2,l:34,sp:20,a:[2,2,0,4],mk:()=>{const P=[[-4,1,1.4,8,32,10,"#fafafa"],[-4.1,3,5.4,8.2,28,3,"#4fc3f7"],[-4.1,1,2,8.2,32,1.2,"#2e7d32"],[-1.6,32.6,9,3.2,.4,1.4,"#ff9800",1]];for(const yy of[4,26])for(const xx of[-4.2,3.2])P.push([xx,yy,0,1,2.4,2,"#212121"]);return P}},
 {id:"truck",n:"トラック",k:"car",r:2,l:26,sp:22,mk:a=>mbBox(26,7.6,10,mbP(["#eceff1","#90a4ae","#1565c0"],a),6,mbP(["#1565c0","#fafafa","#c62828"],a))},
 {id:"gomi",n:"ゴミ収集車",k:"car",r:2,l:20,sp:18,d:1,a:[4,3],mk:()=>{const P=mbBox(20,7,8,"#1e88e5",5.5,"#fafafa");P.push([-3.6,.2,1,7.2,1.6,7,"#90a4ae"]);return P}},
 {id:"hikkoshi",n:"引っ越しトラック",k:"car",r:2,l:26,sp:22,d:1,mk:()=>{const P=mbBox(26,7.6,11,"#fafafa",6,"#e65100");P.push([3.85,3,5,.1,12,3,"#e65100"]);return P}},
 {id:"kitchen",n:"キッチンカー",k:"car",r:2,l:19,sp:20,mk:()=>{const P=mbBox(19,7,9,"#ffca28",5,"#ffca28");P.push([3.5,2,7,2.4,10,.4,"#e53935"],[3.55,3,4,.1,8,2.6,"#5d4037"]);return P}},
 {id:"kyoshu",n:"教習車",k:"car",r:2,l:18,sp:16,mk:()=>{const P=mbCar(18,6.6,5.6,"#fafafa");P.push([-1.5,8.5,7.6,3,1,1.6,"#ffeb3b"]);return P}},
 {id:"retro",n:"丸目のレトロカー",k:"car",r:2,l:15,sp:22,mk:a=>mbCar(15,6,6.2,mbP(["#80cbc4","#ffccbc","#c5e1a5","#fff9c4"],a),{rc:"#fafafa"})},
 {id:"open",n:"オープンカー",k:"car",r:2,l:17,sp:32,a:[6,6,6,0],mk:a=>mbCar(17,6.6,5,mbP(["#c62828","#fafafa","#1565c0","#fdd835"],a),{open:1})},
 {id:"police",n:"パトカー",k:"car",r:3,l:18,sp:30,mk:()=>{const P=mbCar(18,6.6,5.6,"#fafafa",{rc:"#212121"});P[0][6]="#212121";P.push([-3.35,4,1.6,.1,10,1.4,"#fafafa"],[-2,8,7.7,2,1.2,.8,"#ff1744",1],[0,8,7.7,2,1.2,.8,"#2979ff",1]);return P}},
 {id:"kyukyu",n:"救急車",k:"car",r:3,l:20,sp:30,mk:()=>{const P=mbBox(20,7,9,"#fafafa",5,"#fafafa");P.push([3.55,1,4,.1,14,1,"#e53935"],[-1.5,16,10,3,1.2,.8,"#ff1744",1]);return P}},
 {id:"fire",n:"消防車",k:"car",r:3,l:30,sp:26,mk:()=>{const P=mbBox(30,7.6,8,"#d50000",7,"#d50000");P.push([-1,4,9,2,20,.6,"#cfd8dc"],[-1,4,9.6,.3,20,.6,"#cfd8dc"],[.7,4,9.6,.3,20,.6,"#cfd8dc"],[-1.5,25,9.4,3,1.2,.8,"#ff1744",1]);return P}},
 {id:"senkyo",n:"選挙カー",k:"car",r:3,l:18,sp:12,d:1,mk:()=>{const P=mbBox(18,6.8,7,"#fafafa",5,"#fafafa");P.push([-3.4,3,8,6.8,10,3,"#1565c0"],[-3.45,3.5,8.5,.1,9,2,"#fafafa"],[-1,13.5,8.2,2,1.2,1.6,"#9e9e9e"]);return P}},
 {id:"yakiimo",n:"焼き芋屋の軽トラ",k:"car",r:3,l:13,sp:10,n2:1,mk:()=>{const P=mbBox(13,6,4.5,"#fafafa",5,"#fafafa");P[0][5]=1.2;P.push([-2.6,1.4,2.2,5.2,5,4,"#6d4c41"],[-2.8,1.2,6.2,5.6,5.4,.8,"#3e2723"],[-.5,3,7,1,1,3,"#757575"]);return P}},
 {id:"reikyu",n:"霊柩車",k:"car",r:3,l:22,sp:20,d:1,mk:()=>{const P=mbCar(22,6.8,6,"#111111",{cl:14});P.push([-3,3,7.6,6,10,2.4,"#c9a227"],[-2.6,3.4,10,5.2,9.2,.8,"#ffd54f"]);return P}},
 {id:"super",n:"真っ赤なスーパーカー",k:"car",r:4,l:18,sp:40,a:[0,1],mk:()=>mbCar(18,7.4,5,"#d50000",{low:1,cf:6,cl:6})},
 {id:"lux",n:"黒塗りの高級車",k:"car",r:4,l:21,sp:28,a:[0,0,1],mk:()=>mbCar(21,7,6,"#0d0d0d",{cl:10})},
 {id:"limo",n:"リムジン",k:"car",r:4,l:32,sp:24,a:[0,1],mk:()=>mbCar(32,7,6,"#fafafa",{cf:5,cl:22})},
 {id:"ita",n:"痛車",k:"car",r:4,l:18,sp:28,a:[1,2],mk:()=>{const P=mbCar(18,6.6,5.6,"#fce4ec");P.push([-3.35,3,1.6,.1,11,2.4,"#ec407a"],[-3.36,5,2,.1,4,1.8,"#7e57c2"],[3.25,3,1.6,.1,11,2.4,"#29b6f6"],[3.26,9,2,.1,4,1.8,"#ffee58"]);return P}},
 {id:"deko",n:"デコトラ",k:"car",r:4,l:28,sp:22,n2:1,mk:()=>{const P=mbBox(28,7.8,11,"#cfd8dc",6.5,"#e0e0e0");for(let i=0;i<6;i++)P.push([3.95,2+i*3.4,1.4,.2,1,1,["#ff1744","#ffd600","#00e5ff","#76ff03","#ff4081","#ffab00"][i],1]);P.push([-3.9,27.2,12,7.8,.4,1.2,"#ffd600",1]);return P}},
 {id:"gold",n:"金色の高級車",k:"car",r:5,l:21,sp:30,mk:()=>mbCar(21,7,6,"#ffd54f",{rc:"#ffca28"})},
 {id:"neon",n:"光る改造車",k:"car",r:5,l:18,sp:34,ni:1,mk:()=>{const P=mbCar(18,7,5,"#311b92",{low:1});P.push([-3.6,1,.2,7.2,16,.3,"#00e5ff",1]);return P}},
 {id:"tractor",n:"トラクター",k:"car",r:2,l:12,sp:10,only:[5],d:1,mk:()=>[[-3,1,2,6,8,3,"#e53935"],[-2.4,3,5,4.8,4,4,"#e53935"],[-2.2,3.4,5.4,4.4,3.2,3.2,"#9ecbe0"],[-3.8,1,0,1.2,4,4.4,"#212121"],[2.6,1,0,1.2,4,4.4,"#212121"],[-3.4,8.4,0,1,2.6,2.6,"#212121"],[2.4,8.4,0,1,2.6,2.6,"#212121"]]},
 /* 人 */
 {id:"kaisha",n:"会社員",k:"ped",r:1,sp:6,a:[0,0,2,2],mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a+1),cl:mbP(["#263238","#37474f","#212121"],a),pa:"#263238",t,um:u,bag:"#3e2723"})},
 {id:"gakusei",n:"学生",k:"ped",r:1,sp:6,d:1,mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(["#1a237e","#fafafa","#263238"],a),pa:mbP(["#1a237e","#424242"],a),t,um:u,bag:"#212121"})},
 {id:"couple",n:"カップル",k:"ped",r:1,sp:5,pair:1,mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:mbP(["#3b3b4a","#c8b38a","#5b4a33"],a),t,um:u})},
 {id:"kaimono",n:"買い物帰りの人",k:"ped",r:1,sp:5,a:[3,3,4],mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:mbP(["#3b3b4a","#5b4a33","#7f8c8d"],a),t,um:u,bag:"#fafafa"})},
 {id:"jog",n:"ジョギングする人",k:"ped",r:1,sp:11,a:[4,6],mk:(a,t)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(["#ff7043","#26c6da","#d4e157"],a),pa:"#212121",t:t*1.6})},
 {id:"sumaho",n:"スマホを見ながら歩く人",k:"ped",r:1,sp:4,mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",t:t*.7,ph:1,um:u})},
 {id:"inu_s",n:"小型犬の散歩",k:"ped",r:1,sp:5,dog:"#f5f5f5",a:[4,4,3],mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a+2),pa:"#5b4a33",t,um:u})},
 {id:"inu_b",n:"大型犬の散歩",k:"ped",r:2,sp:6,dog:"#c49a5a",big:1,a:[4,5],mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a+3),pa:"#3b3b4a",t,um:u})},
 {id:"shiba",n:"柴犬の散歩",k:"ped",r:2,sp:5,dog:"#d9822b",a:[4,5],mk:(a,t,u)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a+4),pa:"#7f8c8d",t,um:u})},
 {id:"hippare",n:"犬に引っぱられる人",k:"ped",r:3,sp:12,dog:"#8d6e63",big:1,mk:(a,t)=>mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",t:t*1.8})},
 {id:"mamachari",n:"ママチャリ",k:"bike",r:1,sp:12,a:[4,4,3],noRain:1,mk:(a,t)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",fc:"#90a4ae"})},
 {id:"road",n:"ロードバイク",k:"bike",r:2,sp:20,noRain:1,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(["#ffeb3b","#00e5ff","#ff4081"],a),pa:"#212121",fc:"#212121",hel:"#fafafa"})},
 {id:"kodomo",n:"子ども乗せ自転車",k:"bike",r:2,sp:10,a:[4,4],noRain:1,d:1,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#5b4a33",fc:"#9e9e9e",kid:1})},
 {id:"demae",n:"出前の自転車",k:"bike",r:2,sp:15,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#212121",pa:"#212121",fc:"#212121",box:mbP(["#43a047","#212121","#ff7043"],a),hel:"#212121"})},
 {id:"scooter",n:"スクーター",k:"bike",r:1,sp:22,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",mc:mbP(["#fafafa","#ec407a","#4fc3f7","#9ccc65"],a),hel:mbP(["#fafafa","#212121","#e53935"],a)},1)},
 {id:"demaebike",n:"出前のバイク",k:"bike",r:2,sp:24,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#e53935",pa:"#212121",mc:"#fafafa",box:"#e53935",hel:"#fafafa"},1)},
 {id:"oogata",n:"大型バイク",k:"bike",r:3,sp:34,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#212121",pa:"#212121",mc:mbP(["#212121","#b71c1c","#1565c0"],a),hel:"#212121"},1)},
 {id:"shirobai",n:"白バイ",k:"bike",r:3,sp:30,mk:()=>{const P=mbBike({sk:"#f1c7a0",hr:"#161616",cl:"#1565c0",pa:"#1565c0",mc:"#fafafa",hel:"#fafafa"},1);P.push([-.6,1.2,6.4,.6,.6,.6,"#ff1744",1],[0,1.2,6.4,.6,.6,.6,"#2979ff",1]);return P}},
 {id:"yopparai",n:"酔っぱらい",k:"ped",r:2,sp:3,ni:1,wob:1,a:[1,1,1,2],mk:(a,t)=>{const P=mbPer({sk:"#f8a5a5",hr:mbP(MB_HR,a),cl:"#37474f",pa:"#263238",t:t*.6});P.push([-1.6,3.6,11,3.2,.4,.6,"#d32f2f"]);return P}},
 {id:"host",n:"ホスト風の人",k:"ped",r:2,sp:5,ni:1,only:[1],mk:(a,t)=>mbPer({sk:"#ffe0c4",hr:mbP(["#e0c068","#c9c9c9","#ffffff"],a),cl:"#111111",pa:"#111111",t})},
 {id:"kyakuhiki",n:"客引き",k:"ped",r:2,sp:2,ni:1,only:[1],mk:(a,t)=>{const P=mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#4a148c",pa:"#212121",t:t*.4});P.push([1.6,5.2,7.4,.3,.3,3.4,"#9e9e9e"],[1.2,5.1,10.6,2.6,.3,2,"#ffeb3b"]);return P}},
 {id:"surfer",n:"サーファー",k:"ped",r:2,sp:5,only:[6],d:1,mk:(a,t)=>{const P=mbPer({sk:"#c58a5c",hr:"#e0c068",cl:"#212121",pa:"#26c6da",t});P.push([2,1.2,3,.6,1.6,10,"#ffeb3b"]);return P}},
 {id:"kanko",n:"観光客",k:"ped",r:2,sp:4,a:[2,3,6],d:1,mk:(a,t,u)=>{const P=mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(["#ffeb3b","#4fc3f7","#ff8a65"],a),pa:"#c8b38a",t,um:u});P.push([-1.5,3.5,10.2,3,3,.6,"#fff3e0"],[-.5,6.2,7,1,.6,.8,"#212121"]);return P}},
 {id:"neko",n:"野良猫",k:"ped",r:2,sp:4,a:[5,5,3],cat:1,mk:(a,t)=>{const c=mbP(["#f5f5f5","#424242","#ff9800","#8d6e63"],a);return mbDog(0,3,c,0,t).concat([[-.5,5.4,2.6,.3,.3,.6,c],[.2,5.4,2.6,.3,.3,.6,c]])}},
 {id:"kigurumi",n:"風船を持った着ぐるみ",k:"ped",r:5,sp:4,d:1,mk:(a,t)=>{const P=mbPer({sk:"#c49a5a",hr:"#c49a5a",cl:"#c49a5a",pa:"#c49a5a",t});P.push([-1.6,3.6,10.6,.8,.8,.8,"#c49a5a"],[.8,3.6,10.6,.8,.8,.8,"#c49a5a"],[2,5,7,.1,.1,8,"#9e9e9e"],[1.2,4.2,15,2,2,2.4,"#ff1744",1]);return P}}];
const MBI={};MBT.forEach(t=>MBI[t.id]=t);
function mbHr(){return(((R.phase==="run"?R.t:G.open*60)/60)%24+24)%24}
function mbPick(k){const z=typeof areaZ==="function"?areaZ():0,h=mbHr(),night=h>=19||h<5,late=h>=2&&h<6,rain=G.wx&&/rain|typhoon/.test(G.wx[G.wd]||"");
 const W=MBT.filter(t=>t.k===k||(k==="ped"&&t.k==="bike")).map(t=>{if(t.only&&!t.only.includes(z))return[t,0];if(t.ni&&!night)return[t,0];if((t.d||t.n2&&0)&&night&&h>=21)return[t,0];if(t.late&&!late&&!(h>=3&&h<7))return[t,0];
  let w=[0,30,9,3,.8,.15][t.r];if(t.a)w*=1+t.a.filter(x=>x===z).length*1.2;if(rain&&(t.noRain||t.id==="jog"))w*=.25;if(t.k==="bike"&&k==="ped")w*=.5;if(z===5&&t.k==="car"&&t.id!=="ktr"&&t.id!=="tractor")w*=.5;if(z===3&&t.k==="car")w*=.4;return[t,w]});
 let s=W.reduce((a,b)=>a+b[1],0),r=Math.random()*s;for(const[t,w]of W){r-=w;if(r<=0)return t}return null}
const MB={L:[],last:0,nc:0,np:0};
/* 道ぞいの隣の建物が歩道や車道にはみ出さないように、店の正面の線でそろえる */
{const _gs2=genScn;genScn=function(){const r=_gs2.apply(this,arguments);try{const L=mbGeo().L;for(let i=SCN.length-1;i>=0;i--){const b=SCN[i];if((b.t===1||b.t===3||b.t===4)&&b.x<L-.5){if(b.x+b.w<=L-.5)SCN.splice(i,1);else{b.w-=(L-.5-b.x);b.x=L-.5}}}
 /* 店の前の歩道を広げる：道路から向こうを6マス分ずらす */const SH=6;SCN.forEach(b=>{if(b.x+b.w<=L-8.6)b.x-=SH});GRD.forEach(g=>{if(g.x+g.w<=L-8.6||g.x<L-9.5)g.x-=SH;else if(Math.abs(g.x-(L-9))<.01&&g.w>=8.9){g.x-=SH;g.w+=SH}})}catch(e){}MB.L=[];return r}}
function mbGeo(){const xs=FLT.map(t=>t[0]),ys=FLT.map(t=>t[1]),L=Math.min(...xs)*6,T=Math.min(...ys)*6,B=(Math.max(...ys)+1)*6;return{L,Y0:T-70,Y1:B+60}}
function mbSpawn(){const g=mbGeo(),z=typeof areaZ==="function"?areaZ():0,h=mbHr(),busy=[1.2,1.3,1.6,1,.8,.45,.7][z]||1,tm=h>=1&&h<6?.35:h>=17&&h<21?1.25:1;
 const nc=MB.L.filter(m=>m.T.k==="car"||m.T.k==="bike").length,np=MB.L.filter(m=>m.T.k==="ped").length;
 if(nc<3&&Math.random()<.5*busy*tm){const t=mbPick("car");if(t){const s=Math.random()<.5?1:-1;if(!MB.L.some(m=>m.s===s&&(m.T.k==="car"||m.T.k==="bike")&&Math.abs(m.y-(s>0?g.Y0-20:g.Y1+20))<40))MB.L.push({T:t,lane:s,s,x:s>0?g.L-28:g.L-20,y:s>0?g.Y0-20:g.Y1+20,a:Math.random()*9+1,t:0,sp:t.sp*(.85+Math.random()*.3)})}}
 if(np<4&&Math.random()<.6*busy*tm){const t=mbPick("ped");if(t){const s=Math.random()<.5?1:-1,far=Math.random()<.45,bike=t.k==="bike";const x=bike?(s>0?g.L-31:g.L-17.5):(far?g.L-37-Math.random()*2:g.L-9.5-Math.random()*3);
  const wsp=bike?t.sp*(.85+Math.random()*.3):({jog:17,hippare:18,sumaho:7,yopparai:6,kyakuhiki:3,kigurumi:7}[t.id]||(9+Math.random()*6))*(.9+Math.random()*.2);MB.L.push({T:t,s,x,y:s>0?g.Y0-10:g.Y1+10,a:Math.random()*9+1,t:0,sp:wsp,pk:!bike&&!far&&!t.cat&&Math.random()<.12,um:(!bike&&G.wx&&/rain/.test(G.wx[G.wd]||""))?mbP(["#1565c0","#e53935","#fafafa","#212121","#fdd835"],Math.random()*9):0});if(t.pair)MB.L.push({T:t,s,x:x+2.6,y:(s>0?g.Y0-10:g.Y1+10)+1,a:Math.random()*9+3,t:0,sp:MB.L[MB.L.length-1].sp,um:0,tag:1})}}}
function mbSeen(t){G.mbS=G.mbS||{};const first=!G.mbS[t.id];G.mbS[t.id]=(G.mbS[t.id]||0)+1;if(first&&t.r>=3){try{toast((["","","","★3","★4 レア！","★5 激レア！"][t.r])+" "+t.n+" が通った！（街で見たものに記録）")}catch(e){}}}
function mbOn(){return!G.mbOff&&!R.lite&&G.setup&&!R.vis&&R.phase==="run"}
function mbDraw(k){if(!mbOn()||!wallVis(2,k)){return}const now=performance.now(),dt=Math.min(.1,(now-(MB.last||now))/1000);MB.last=now;const sp=typeof mbSpd==="function"?mbSpd():1;try{wkGhosts()}catch(e){}
 MB.cd=(MB.cd||0)-dt*sp;if(MB.cd<=0){MB.cd=.8+Math.random()*1.6;mbSpawn()}const g=mbGeo();
 const parts=[],L=LTN||{oa:0,ov:"#000000"},tint=c=>L.oa>.05?mixc(c,L.ov,Math.min(.6,L.oa*.65)):c;
 MB.L=MB.L.filter(m=>{m.t+=dt*sp;
  if(m.gh){const p=R.people.find(q=>q.c===m.gh.c);if(p)return false;const atD=m.s>0?m.y>=15:m.y<=15;if(atD){if(R.sched.includes(m.gh.e)){m.y=15;m.x+=(-5-m.x)*Math.min(1,dt*sp*3);m.wait=(m.wait||0)+dt;m.face=1;if(m.wait<20)return true}m.gh=null;m.face=0}}
  if(m.pk&&!m.pkd&&(m.s>0?m.y>=15:m.y<=15)){m.pkt=(m.pkt||0)+dt*sp;m.face=1;if(m.pkt<1.6)return true;m.pkd=1;m.face=0}
  m.y+=m.s*m.sp*sp*dt;if(m.T.wob)m.x+=Math.sin(m.t*3+m.a)*dt*2;if(m.y<g.Y0-40||m.y>g.Y1+40)return false;
  const mid=(g.Y0+g.Y1)/2;if(!m.seen&&(m.s>0?m.y>mid+6:m.y<mid-6)){m.seen=1;if(!m.tag)mbSeen(m.T,m)}
  let P=m.T.k==="ped"&&!m.T.cat?[]:(m._P||m.T.mk(m.a,m.t,m.um));if(m.T.k!=="ped")m._P=P;if(m.T.dog){P=P.concat(mbDog(m.s>0?1.8:-1.8,m.s>0?7.4:-3,m.T.dog,m.T.big,m.t))}
  const l=m.T.l||8;P.forEach(p=>{const x=m.x+p[0],y=m.s>0?m.y+p[1]-l/2:m.y-(p[1]+p[4])+l/2;const b={x,y,z:p[2],w:p[3],d:p[4],h:p[5],c:p[7]&&L.oa>.2?p[6]:tint(p[6])};parts.push({b,d:(x+b.w/2)*k.cx+(y+b.d/2)*k.cy+(b.z+b.h/2)*k.cz})});return true});
 if(!parts.length)return;parts.sort((p,q)=>p.d-q.d);cx.save();cx.globalAlpha=.92;try{parts.forEach(o=>dvb(o.b,k))}finally{cx.restore()}}
{const _db=drawBG;drawBG=function(k){const r=_db.apply(this,arguments);try{mbDraw(k)}catch(e){}return r}}

/* ===== 歩く人をお客さんと同じ細かさに（見た目ごとに絵にして使い回す）。たまに図鑑のお客さんも通る ===== */
const MBLK={kaisha:{shirt:["#263238","#37474f","#212121"],top:2,pants:["#263238"]},gakusei:{shirt:["#1a237e","#fafafa","#263238"],top:5,pants:["#1a237e","#424242"]},jog:{shirt:["#ff7043","#26c6da","#d4e157"],top:6,bot:1,pants:["#212121"]},
 host:{hair:["#e0c068","#c9c9c9","#ffffff"],shirt:["#111111"],top:5,pants:["#111111"],hs:[10,15]},kyakuhiki:{shirt:["#4a148c"],top:5},surfer:{skin:["#c58a5c","#9b6440"],hair:["#e0c068"],shirt:["#26c6da"],top:4,bot:1},kanko:{shirt:["#ffeb3b","#4fc3f7","#ff8a65"],top:7,acc:2},yopparai:{shirt:["#37474f"],top:2,skin:["#f8a5a5"]},couple:{},kaimono:{},sumaho:{},inu_s:{},inu_b:{},shiba:{},hippare:{}};
function mbLook(t,a){const pool=G.cs.filter(c=>c&&!c.sp&&!(typeof spx==="function"&&spx(c))&&!c.moto&&c.i!=null);const tp=pool.length?pool[Math.floor(Math.random()*pool.length)]:OW.c,o=MBLK[t.id]||{},pk=(L,d)=>L&&L.length?L[Math.floor(Math.random()*L.length)]:d;
 const c=Object.assign({},tp,{acc:o.acc||0,accC:"#333333",accV:null,h2:0,t2:0,b2:0,kg:0,pump:0,hair:pk(o.hair,pk(MB_HR)),skin:pk(o.skin,pk(MB_SK)),shirt:pk(o.shirt,pk(MB_CL)),pants:pk(o.pants,pk(["#3b3b4a","#1e1e1e","#2c3e66","#5b4a33","#7f8c8d","#c8b38a"])),top:o.top!=null?o.top:Math.floor(Math.random()*TOPN.length),bot:o.bot!=null?o.bot:Math.floor(Math.random()*BOTN.length),hs:o.hs?pk(o.hs):Math.floor(Math.random()*HSN.length)});
 delete c.sp;delete c.moto;if(t.id==="kigurumi")c.kg=1+Math.floor(Math.random()*(KGL.length-1));return c}
function mbProps(m,ox,oy,dir){const P=[],f=dir===0?1:-1,px=(x,y,z,w,d,h,c,s)=>{s=s||.5;for(let i=0;i<w;i+=s)for(let j=0;j<d;j+=s)for(let k=0;k<h;k+=s)P.push([ox+x+i,oy+y+j,z+k,c,undefined,s])};
 if(m.um){px(1.9,1.4,7,.25,.25,5,"#616161",.25);px(-.6,-1.1,12,5,5,.5,m.um,1)}const id=m.T.id;
 if(id==="kyakuhiki")px(3.6,1.5,6,.5,.5,5,"#9e9e9e"),px(3.1,1.3,10.5,1.5,.5,2,"#ffeb3b");if(id==="surfer")px(-.6,1,2,.5,2,10,"#ffeb3b");if(id==="yopparai")px(.5,.8,12,3,.5,.5,"#d32f2f",.5);
 if(id==="kigurumi"){px(3.5,1.5,6,.25,.25,9,"#9e9e9e",.25);px(3,1,15,1.5,1.5,1.5,"#ff1744")}if(id==="kaimono"||id==="kaisha")px(3.6,1.4,4,.5,1.5,2,id==="kaimono"?"#fafafa":"#3e2723");return P}
{const _dy=dyn;dyn=function(){const a=_dy.apply(this,arguments);try{if(!mbOn()||!R.cv||!wallVis(2,R.cv))return a;const inS=new Set((R.people||[]).map(p=>p.c));
 MB.L.forEach(m=>{if(m.T.k!=="ped"||m.T.cat)return;if(!m.c){if(!m.tag&&!m.T.ni&&Math.random()<.12&&["kaisha","gakusei","kaimono","sumaho","couple","jog"].includes(m.T.id)){const met=G.cs.filter(c=>c.met&&!c.sp&&!(typeof spx==="function"&&spx(c))&&!inS.has(c));if(met.length){m.c=met[Math.floor(Math.random()*met.length)];m.dex=1}}if(!m.c)m.c=mbLook(m.T,m.a)}
  const d=m.face?1:(m.s>0?0:2),ox=m.x-2,oy=m.y-1.5+(!m.face&&Math.sin(m.t*10)>0?.15:0);if(!walkSpr(a,m.c,d,ox,oy))pv(a,ox,oy,1,m.c,0,d);mbProps(m,ox,oy,d).forEach(v=>a.push(v));
  if(m.dex&&!m.dexL&&m.seen){m.dexL=1;G.mbDx=G.mbDx||{};if(G.mbDx[m.c.i]!==G.day){G.mbDx[m.c.i]=G.day;try{const t="👀 "+nm(m.c)+" が店の前を通りすぎた";log(t);if(typeof mbBand==="function")mbBand(t)}catch(e){}}}})}catch(e){}return a}}
/* 街で見たもの */
function mbList(){const S=G.mbS||{},n=MBT.filter(t=>S[t.id]).length,AN=(typeof AREA!=="undefined"?AREA:[]).map(a=>a.n);
 const grp=[[5,"★5 激レア"],[4,"★4 レア"],[3,"★3 たまに"],[2,"★2 ときどき"],[1,"★1 よく見る"]];
 const d=document.createElement("div");d.className="xpan";d.id="mbls";d.innerHTML=`<div class="xin"><div class="xh">👀 街で見たもの　${n}/${MBT.length}</div><div class="xs">お店の前を通った人や車が記録されます。地域や時間帯、天気で出てくるものが変わります。</div><div style="max-height:56vh;overflow:auto;margin-top:6px">`+
  grp.map(([r,lb])=>`<div style="font-weight:900;font-size:12.5px;margin:10px 0 4px;color:#6658a6">${lb}</div><div class="mbg">`+MBT.filter(t=>t.r===r).map(t=>{const c=S[t.id];const hint=t.only?AN[t.only[0]]+"だけ":t.ni?"夜":t.late?"明け方":"";return`<div class="mbc ${c?"":"lk"}"><b>${c?esc(t.n):"？？？"}</b><small>${c?c+"回":hint?"ヒント："+hint:""}</small></div>`}).join("")+`</div>`).join("")+`</div><div class="xb"><button data-mbx="1" style="flex:1">閉じる</button></div></div>`;
 document.body.appendChild(d);d.onclick=e=>{if(e.target.closest("[data-mbx]"))d.remove()}}
{const _mc=mvCard;mvCard=function(){_mc.apply(this,arguments);const c=$("#mvcard");if(!c)return;const S=G.mbS||{},n=MBT.filter(t=>S[t.id]).length;c.insertAdjacentHTML("beforeend",`<div style="display:flex;gap:8px;margin-top:8px"><button id="mbgo" style="flex:1">👀 街で見たもの ${n}/${MBT.length}</button><button id="mbtg" style="flex:none">${G.mbOff?"🚶 街の動き：オフ":"🚶 街の動き：オン"}</button></div>`)}}
document.addEventListener("click",e=>{if(!e.target.closest)return;if(e.target.closest("#mbgo")){e.stopPropagation();mbList()}else if(e.target.closest("#mbtg")){e.stopPropagation();G.mbOff=!G.mbOff;if(G.mbOff)MB.L=[];save();mvCard()}},true);
(function(){const st=document.createElement("style");st.textContent=`.mbg{display:grid;grid-template-columns:repeat(2,1fr);gap:6px}.mbc{background:#fff;border:1.5px solid #e0dccf;border-radius:10px;padding:6px 8px;font-size:12.5px}.mbc small{display:block;color:var(--mut);font-size:10.5px}.mbc.lk{background:#f4f2ec;color:#9a9a9a}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
