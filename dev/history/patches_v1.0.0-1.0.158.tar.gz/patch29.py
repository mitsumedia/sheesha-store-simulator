import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 店主の定位置：置物や客席があれば近くの空いているマスへ
rep('OW.x=3;OW.y=8;','{const h=owHomeXY();OW.x=h[0];OW.y=h[1]}',2)
rep('OW.path=[[3,8]]','OW.path=[owHomeXY()]',2)
# チェキの場所を選ぶ
rep('let spot=null;const F=FLT.slice().sort((a,b)=>(b[1]-a[1])||(a[0]-b[0]));for(const[tx,ty]of F){if(!occ(tx,ty)&&FLS.has((tx+1)+","+ty)&&!occ(tx+1,ty)){spot=[tx,ty];break}}if(!spot)spot=FLT[0];',
    'const SPS=ckSpots();let spot=SPS.length?SPS[(((R.ckSp||0)%SPS.length)+SPS.length)%SPS.length]:FLT[0];')
rep('<div class="xb"><button data-sh="b" style="flex:1">戻る</button>','<div class="xs">場所</div><div class="ckps"><button class="xr" data-sp="-1">◀ 前の場所</button><button class="xr" data-sp="1">次の場所 ▶</button><span id="cksn" style="align-self:center;font-size:12px;color:var(--mut);margin-left:6px"></span></div><div class="xb"><button data-sh="b" style="flex:1">戻る</button>')
rep('d.onclick=e=>{const z=e.target.closest("[data-pz]");','ckSpLbl();d.onclick=e=>{const sp=e.target.closest("[data-sp]");if(sp){R.ckSp=(R.ckSp||0)+(+sp.dataset.sp);chekiDraw(cv,c,pi);ckSpLbl();return}const z=e.target.closest("[data-pz]");')
# 画面のズーム対策（iPhoneは文字が16px未満の入力欄を触ると拡大する）
rep('<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">','<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">')
rep('</style></head>','@supports (-webkit-touch-callout:none){input,select,textarea{font-size:16px!important}}html,body{touch-action:manipulation;-webkit-text-size-adjust:100%}</style></head>',2)
ADD=r'''
/* 店主の定位置（入口横）。ふさがっていたら一番近い空きマス */
function owHomeXY(){try{const ok=(x,y)=>{const k=x+","+y;if(!FLS.has(k)||k==="0,2")return false;if(G.decor.some(d=>d.tx===x&&d.ty===y))return false;if(k!=="0,1"&&BL.has(k))return false;return!(FR&&FR.tx===x&&(y===FR.ty||y===FR.ty+1))};if(ok(0,1))return[3,8];let best=null,bd=1e9;for(const[x,y]of FLT){if(!ok(x,y))continue;const d=Math.abs(x)+Math.abs(y-1)*1.01;if(d<bd){bd=d;best=[x,y]}}return best?[best[0]*6+3,best[1]*6+2]:[3,8]}catch(e){return[3,8]}}
{const _b=build;build=function(){const r=_b.apply(this,arguments);try{if(R.phase!=="run"&&!(OW.path&&OW.path.length)&&!OW.sitting&&OW.x>-100){const h=owHomeXY();OW.x=h[0];OW.y=h[1]}}catch(e){}return r}}
/* チェキの撮影場所：2人が並べる空きマスの一覧 */
function ckSpots(){const F=FLT.slice().sort((a,b)=>(b[1]-a[1])||(a[0]-b[0])),L=[];for(const[tx,ty]of F){if(!occ(tx,ty)&&FLS.has((tx+1)+","+ty)&&!occ(tx+1,ty))L.push([tx,ty])}return L}
function ckSpLbl(){const e=document.getElementById("cksn"),n=ckSpots().length;if(e)e.textContent=n?((((R.ckSp||0)%n)+n)%n+1)+" / "+n:"";}
/* 営業が終わったら換気のエフェクトを消す */
{const _e=endDay;endDay=function(){R.vent=0;R.vcd=0;return _e.apply(this,arguments)}}
{const _c=closeDay;closeDay=function(){R.vent=0;R.vcd=0;return _c.apply(this,arguments)}}
'''
rep(TAIL,ADD+TAIL)
# のりよしの髪を黒に（保存データも）
rep('/* ===== レア3・4の名前の変更（保存データも置きかえ） ===== */','(G.cs||[]).forEach(c=>{if(c.sp==="noriyoshi")c.hair="#141416"});\n/* ===== レア3・4の名前の変更（保存データも置きかえ） ===== */')
open(f,'w').write(s)
