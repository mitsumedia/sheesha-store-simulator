import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== お店めぐりQR：作ってから1分だけ有効（時計のずれ30秒まで許す）。見せる画面は1分ごとに作り直す ===== */
const VQR_MS=60000,VQR_SK=30000;
{const _sn=visSnap;visSnap=function(){const d=_sn.apply(this,arguments);d.qt=Date.now();return d}}
{const _dc=visDec;visDec=async function(){const o=await _dc.apply(this,arguments);if(!o.qt)throw new Error("古いQRです。相手のゲームを最新版にして、新しいQRを見せてもらってね");const age=Date.now()-o.qt;if(age>VQR_MS+VQR_SK||age<-VQR_SK)throw new Error("このQRは期限切れです（作ってから1分まで）。相手に、今表示されているQRを見せてもらってね");return o}}
{const _vs=visShow;visShow=async function(){const r=await _vs.apply(this,arguments);try{const d=$("#visp"),q=d&&d.querySelector("#visq");if(!q||!q.querySelector("canvas"))return r;
 const ct=document.createElement("div");ct.id="visct";ct.style.cssText="text-align:center;font-weight:900;font-size:14px;margin:2px 0 8px";q.querySelector("canvas").after(ct);
 let t0=Date.now(),busy=0;const tick=async()=>{if(!d.isConnected){clearInterval(iv);return}let left=Math.ceil((VQR_MS-(Date.now()-t0))/1000);
  if(left<=0&&!busy){busy=1;let c=null;for(let lv=0;lv<3&&!c;lv++){try{c=visQR(await visEnc(lv))}catch(e){c=null}}if(c&&d.isConnected){const old=q.querySelector("canvas");if(old)old.replaceWith(c);t0=Date.now();left=60}busy=0}
  ct.innerHTML=`⏱ このQRはあと <b>${Math.max(0,left)}秒</b> 有効<br><span style="font-size:11px;font-weight:700;color:var(--mut)">自動で新しいQRに変わります</span>`};
 const iv=setInterval(tick,1000);tick();const st=d._stop;d._stop=()=>{clearInterval(iv);if(st)st()}}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
rep('読んでから<b>15分</b>、あなたのお店に遊びに来られます</div>','読んでから<b>15分</b>、あなたのお店に遊びに来られます。QRは<b>1分ごと</b>に変わるので、その場で読んでもらってね</div>')
open(f,'w').write(s)
