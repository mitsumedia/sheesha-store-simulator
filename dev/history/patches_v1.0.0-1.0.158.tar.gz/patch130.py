import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ---- 日数の表示をプレイ画面と同じ「プレイ〇年〇日目」にそろえる ----
rep('var info="Ver "+ver()+"・プレイ"+day()+"日目・"+ts;','var info="Ver "+ver()+"・プレイ"+(function(n){n=Math.max(1,n|0);var y=Math.floor((n-1)/84);return(y?y+"年":"")+((n-1)%84+1)})(day())+"日目・"+ts;')
rep('ckDate=()=>(Math.floor((G.month||0)/12)+1)+"年目 "+MN[(G.month||0)%12]+"月"+WD[G.wd]+"曜";','ckDate=()=>"プレイ"+ydLbl();')
rep('Ver ${esc(r.ver||"")}・${r.day}日目','Ver ${esc(r.ver||"")}・${ydOf(r.day)}')
rep('匿名さん<br>${r.d}日目','匿名さん<br>${ydOf(r.d).replace("プレイ","")}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== メニューの回るキャラ（図鑑・着せ替え）にもメガネ・サングラスをボクセルで付ける ===== */
function glVox(a,c){if(!c||c.pump||!(c.acc===1||c.acc===7||c.acc===10))return;const q=.25,sun=c.acc===1,sq=c.acc===10,FR=sun?"#0a0a10":(()=>{const h=(c.accC||"#333333").replace("#","");const v=parseInt(h.length===3?h.split("").map(x=>x+x).join(""):h,16),l=(.3*(v>>16&255)+.59*(v>>8&255)+.11*(v&255))/255;return l>.6?dkHex(c.accC,.72):c.accC||"#333333"})(),LN="#0a0a10",y=3,M=new Set(),P=(x,z,col)=>{const k=x+","+z;if(M.has(k))return;M.add(k);a.push([x,y,z,col,undefined,q])};
for(const lc of[1,3]){for(let x=lc-1;x<lc+1-1e-6;x+=q)for(let z=8.75;z<10.5-1e-6;z+=q){const cx=x+q/2-lc,cz=z+q/2-9.6;let inside,edge;if(sq){inside=Math.abs(cx)<=.9&&Math.abs(cz)<=.75;edge=inside&&(Math.abs(cx)>.62||Math.abs(cz)>.5)}else{const r=Math.hypot(cx/.9,cz/.85);inside=r<=1;edge=inside&&r>.66}
 if(edge)P(x,z,FR);else if(inside&&sun)P(x,z,LN)}}
P(1.75,9.75,FR);P(2,9.75,FR);for(let yy=1.75;yy<3;yy+=q){a.push([-.25,yy,9.75,FR,undefined,q]);a.push([4,yy,9.75,FR,undefined,q])}}
{const _fv=fmsVox;fmsVox=function(kind,x){const a=_fv.apply(this,arguments);try{if(kind==="p"&&a.length&&x&&!x.pump&&(x.acc===1||x.acc===7||x.acc===10))a._gl={kind:x.acc,col:x.accC||"#333333"}}catch(e){}return a}}
/* お店と同じ「線のメガネ」を、回るキャラ表示の上に描く */
{const _vr=vRender;vRender=function(cv,vox,ang){const r=_vr.apply(this,arguments);try{const G0=vox&&vox._gl,b=vox&&vox._b;if(!G0||!b)return r;
const g=cv.getContext("2d"),W=cv.width,H=cv.height,co=Math.cos(ang),si=Math.sin(ang);if(co-si<.04)return r;
const hz=b.z1-b.z0,sc=Math.min(W*.42/(b.r*1.25+.5),H*.68/(hz+b.r*.55+.5)),ox=W/2,oy=H-H*.2;
const pr=(x,y,z)=>{const dx=x-b.cx,dy=y-b.cy,X=co*dx-si*dy,Y=si*dx+co*dy;return[ox+(X-Y)*.866*sc,oy-(z-b.z0)*sc+(X+Y)*.42*sc]};
const kind=G0.kind,col=G0.col,sun=kind===1,sq=kind===10,ly=3.04,pt=(lx,z,yy)=>pr(lx,yy===undefined?ly:yy,z);
const lens=lc=>{if(sq)return[[-.9,.7],[.9,.7],[.9,-.7],[-.9,-.7]].map(([dx,dz])=>pt(lc+dx,9.6+dz));const p=[];for(let i=0;i<24;i++){const t=i/12*Math.PI;p.push(pt(lc+Math.cos(t)*.85,9.6+Math.sin(t)*.8))}return p};
const fr=Math.max(1,sc*(sun?.3:.2));g.save();g.lineJoin="round";
for(const lc of[1,3]){const ps=lens(lc);g.beginPath();ps.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();
 g.fillStyle=sun?"rgba(12,12,22,.93)":sq?"rgba(210,235,255,.12)":"rgba(210,235,255,.28)";g.fill();g.lineWidth=fr;g.strokeStyle=sun?"#0a0a10":col;g.stroke();
 const h1=sq?pt(lc-.55,10.15):pt(lc-.35,10.1),h2=sq?pt(lc-.35,9.85):pt(lc+.1,9.3);g.beginPath();g.moveTo(h1[0],h1[1]);g.lineTo(h2[0],h2[1]);g.lineWidth=Math.max(1,sc*(sq?.12:.18));g.strokeStyle=sun?"rgba(150,190,255,.75)":sq?"rgba(255,255,255,.5)":"rgba(255,255,255,.8)";g.stroke()}
const b1=pt(1.85,9.8),b2=pt(2.15,9.8);g.beginPath();g.moveTo(b1[0],b1[1]);g.lineTo(b2[0],b2[1]);g.lineWidth=fr;g.strokeStyle=sun?"#0a0a10":col;g.stroke();
for(const ex of[.15,3.85]){const a=pt(ex,9.8),e=pt(ex<2?-.05:4.05,9.8,1.2);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(e[0],e[1]);g.stroke()}
g.restore()}catch(e){}return r}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
