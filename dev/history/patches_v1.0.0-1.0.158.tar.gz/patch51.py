import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
KAN={"fl":0,"ls":["名乗れば誰でも野郎シーシャ会","スミレちゃーん","今日下着何色なん？","それラッキースケベ！","最近何かオモロい事あった？","うまー！！","シーシャ結局調整力"],"name":"カナメ","sex":"男性","job":"シーシャ屋","sp":"kaname","hs":98,"top":0,"bot":1,"shirt":"#f4f4f2","pants":"#2f3a4a","skin":"#e8c3a0","acc":0,"shoe":"#e9e9e9"}
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1])
for e in arr:
    if e['slot']==147:e.update(KAN)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))[:-1]+s[j:]
ADD=r'''
/* ===== カナメ（No.148 の枠）：ゴリラの被り物・白Tシャツ・短パン ===== */
SPF.kaname=({H,Q4,Qv})=>{const F="#2a2622",F2="#3a342e",M="#5b4d44",M2="#6e5e53",K="#0e0c0b",W="#f2f0ea";
 H(-1,-1,-1,10,8,8,F);H(0,0,7,8,6,1,F);H(1,-1,7,6,4,1,F2);H(2,0,8,4,3,1,F);
 H(-2,2,2,1,2,3,F);H(9,2,2,1,2,3,F);H(-2,2,3,1,1,1,M);H(9,2,3,1,1,1,M);
 H(0,7,4,8,1,1,K);H(0,7,5,8,1,1,F);
 H(1,7,2,6,1,2,M);H(2,7,3,1,1,1,W);H(5,7,3,1,1,1,W);H(3,7,3,2,1,1,M2);H(2,7,3,1,1,1,K);H(5,7,3,1,1,1,K);
 H(1,7,-1,6,2,3,M);H(2,8,0,4,1,2,M2);H(2,9,1,1,1,1,K);H(5,9,1,1,1,1,K);H(3,9,0,2,1,1,M2);H(2,8,-1,4,1,1,K)};
SPF.kaname.ownEye=1;
{const K=%s;if(!G.kan1){const c=G.cs[147];if(c&&!c.ed)Object.assign(c,K);G.kan1=1;try{save()}catch(e){}}}
''' % json.dumps(KAN,ensure_ascii=False)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
