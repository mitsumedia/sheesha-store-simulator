import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
U="https://toratorasuienten.info/sheeshastoresimulator/"
# 𝕏ボタンで撮ったチェキの画像ごと投稿（スマホは共有メニュー→X、PCは投稿画面）
rep('<div class="xs" style="text-align:center">画像を長押しでも保存できます</div><div class="xb"><button data-fin="sh" style="flex:1">📤 画像を共有・保存</button><a class="ckx" href="https://x.com/intent/post?text=${encodeURIComponent(txt)}&url=${encodeURIComponent("'+U+'")}" target="_blank" rel="noopener">𝕏 に投稿</a></div>',
 '<div class="xb" style="flex-direction:column;gap:6px"><button data-fin="xp" class="ckx" style="width:100%;font-size:16px;padding:12px;background:#111 !important;color:#fff !important;border:none">𝕏 にこのチェキを投稿</button><div class="xs" style="text-align:center;margin:0">📱 スマホは出てきたメニューから「X」を選んでね</div><button data-fin="sh" style="width:100%">💾 画像を保存</button><div class="xs" style="text-align:center;margin:0">画像を長押しでも保存できます</div></div>')
rep('d.onclick=async e=>{const q=e.target.closest("[data-fin]");if(!q)return;if(q.dataset.fin==="x"){d.remove();return}\nconst bl=await new Promise(r=>out.toBlob(r,"image/png"));',
 'd.onclick=async e=>{const q=e.target.closest("[data-fin]");if(!q)return;if(q.dataset.fin==="x"){d.remove();return}\nconst bl=await new Promise(r=>out.toBlob(r,"image/png"));\nif(q.dataset.fin==="xp"){const t2=txt+"\\n'+U+'";try{const fl=new File([bl],"cheki.png",{type:"image/png"});if(navigator.canShare&&navigator.canShare({files:[fl]})&&/iPhone|iPad|Android/i.test(navigator.userAgent)){await navigator.share({files:[fl],text:t2});return}}catch(er){if(er&&er.name==="AbortError")return}\ntry{window.open("https://x.com/intent/post?text="+encodeURIComponent(txt)+"&url="+encodeURIComponent("'+U+'"),"_blank","noopener")}catch(_){}toast("PCの場合は、保存した画像を投稿画面に貼り付けてね");return}')
open(f,'w').write(s)
