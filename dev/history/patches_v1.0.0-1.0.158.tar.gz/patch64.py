import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 正面（カメラ目線）のポーズ：カメラを真正面・目の高さに
rep('if(sp2){const[a1,b1]=sp2;TX=(a1.px+b1.px)/2+2;','if(pose.front&&!sp2){R.cam.yaw=0;R.cam.pit=.17}if(sp2){const[a1,b1]=sp2;TX=(a1.px+b1.px)/2+2;')
rep(TAIL,'''{const P=n=>(CKP.find(q=>q[0].includes(n))||CKP[0])[1];CKP.push(["📷 カメラ目線",{front:1}],["✌️ 正面ピース",Object.assign({},P("ピース"),{front:1,arms:[["L","peace"],["R","down"]],arms2:[["L","down"],["R","peace"]]})],["💕 正面ハート",(()=>{const q=P("ハート"),lw=A=>A.map(e=>typeof e[2]==="function"?[e[0],e[1],(a,x,y,z,o)=>e[2](a,x,y,z-2.2,o)].concat(e.slice(3)):e);return Object.assign({},q,{front:1,arms:lw(q.arms),arms2:lw(q.arms2||[])})})()])}
'''+TAIL)
open(f,'w').write(s)
