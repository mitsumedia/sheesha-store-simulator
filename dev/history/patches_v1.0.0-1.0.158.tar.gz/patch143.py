import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# ガチャのフォロワー：+100人 → 今のフォロワーの4%（最低30人）
rep('if(k==="fol"){o.fol+=100;o.star=starOf(o);log("🎰 ガチャ：フォロワー+100");return["📱","フォロワー+100","フォロワー "+(o.fol-100).toLocaleString()+" → "+o.fol.toLocaleString()+"人"]}',
    'if(k==="fol"){const f0=o.fol||0,inc=Math.max(30,Math.round(f0*.04));o.fol=f0+inc;o.star=starOf(o);log("🎰 ガチャ：フォロワー+"+inc+"（4%）");return["📱","フォロワー+"+inc.toLocaleString()+"人","フォロワーが4%増えた！ "+f0.toLocaleString()+" → "+o.fol.toLocaleString()+"人"]}')
rep('fol:"📱 フォロワー+100"','fol:"📱 フォロワー+4%（最低30人）"')
open(f,'w').write(s)
