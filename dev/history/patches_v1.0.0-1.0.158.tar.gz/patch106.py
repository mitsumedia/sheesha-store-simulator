import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 1日にイベントが起こる確率を合計10%に（開店前4.5%・営業中5.7%）
rep('EVPRE=.2,EVRUN=.25;','EVPRE=.045,EVRUN=.057;')
open(f,'w').write(s)
