import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 髪型タブ：ツートンの時は一覧の上で「髪の色・2色目」を選べる。髪型タブの見本は上半身を大きく ===== */
function hcShown(){if(OWK!=="hs")return 0;return OWPV!=null?(OWPV>=100?OWPV-99:0):((G.ow||{}).h2|0)}
function hcRow(){const h=hcShown();if(!HC2.includes(h))return"";const o=G.ow||{},cur=o.hair||OW.c.hair,c2=o.hc2||"#ff5c8a";
 const sw=(k,lb,pal,v)=>`<div class="hcr"><div class="hcl">${lb}<i style="background:${v}"></i></div><div class="hcp">${pal.map(c=>`<span data-hcs="${k}" data-v="${c}" class="hcs ${String(c).toLowerCase()===String(v).toLowerCase()?"on":""}" style="background:${c}"></span>`).join("")}</div></div>`;
 return`<div id="hcbox">${sw("hair","髪の色",OWPAL.hair||[],cur)}${sw("hc2","髪の2色目",OWPAL.hc2,c2)}<div class="hcn">色はタップするとすぐ変わります</div></div>`}
{const _or=owRender;owRender=function(){const r=_or.apply(this,arguments);try{const L=$("#owlist");if(L){const h=hcRow();if(h)L.insertAdjacentHTML("afterbegin",h)}}catch(e){}return r}}
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-hcs]");if(!b)return;e.stopPropagation();const k=b.dataset.hcs,v=b.dataset.v;if(!G.ow)return;G.ow[k]=v;try{applyOwLook();owAccSync()}catch(_){}OW._pc=null;save();const sc=($("#owlist")||{}).scrollTop;owRender();owStage();const L=$("#owlist");if(L&&sc!=null)L.scrollTop=sc},true);
{const _fv=fmsVox;fmsVox=function(kind,x){const v=_fv.apply(this,arguments);try{if(kind==="p"&&FMTAB==="owner"&&OWK==="hs"&&$("#p-own2")&&!OWD&&Array.isArray(v)){const w=v.filter(q=>q[2]>=3.5);w._gl=v._gl;for(const k in v)if(isNaN(+k)&&!(k in w))w[k]=v[k];delete w._b;return w}}catch(e){}return v}}
(function(){const st=document.createElement("style");st.textContent=`
#hcbox{background:#fff;border:2px solid #d9cff5;border-radius:14px;padding:10px 12px 8px;margin:0 0 10px}
.hcr{margin-bottom:8px}.hcl{display:flex;align-items:center;justify-content:space-between;font-weight:900;font-size:13px;color:#123a33;margin-bottom:6px}
.hcl i{width:30px;height:18px;border-radius:4px;border:1px solid rgba(0,0,0,.15)}
.hcp{display:flex;flex-wrap:wrap;gap:7px}.hcs{display:block;flex:0 0 30px;width:30px;height:30px;border-radius:50%;border:2px solid #e3e3e3;box-sizing:border-box;cursor:pointer}
.hcs.on{outline:3px solid #6658a6;outline-offset:1px}
.hcn{font-size:10.5px;color:#8a8a8a;text-align:right}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
