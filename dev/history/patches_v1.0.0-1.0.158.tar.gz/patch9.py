import sys,json
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
i=s.find('const PRESET=');j=s.find('];',i)
arr=json.loads(s[i+len('const PRESET='):j+1]);n=0
for e in arr:
    if e.get('job')=='シーシャ屋' and (e.get('ap') or {}).get('k')=='day':e['ap']['v']=e['ap']['v']//2;n+=1
print('day halved',n)
s=s[:i+len('const PRESET=')]+json.dumps(arr,ensure_ascii=False,separators=(',',':'))+s[j+1:]
rep('if(!G.bye1){','if(!G.shd1){G.cs.forEach(c=>{const p=PRESET[c.i];if(p&&p.job==="シーシャ屋"&&c.job==="シーシャ屋"&&p.ap&&p.ap.k==="day"&&c.ap&&c.ap.k==="day")c.ap.v=p.ap.v});G.shd1=1}if(!G.bye1){')
open(f,'w').write(s);print('ok')
