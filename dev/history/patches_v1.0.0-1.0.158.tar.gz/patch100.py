import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 模様替え中は「模様替えを終わる」を上に大きく出す／全画面メニューの一番下が隠れないよう余白 ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>
html body.mvmode #mvbtn{position:fixed!important;top:calc(var(--uit,104px) + 10px)!important;bottom:auto!important;left:50%!important;right:auto!important;transform:translateX(-50%)!important;z-index:60!important;background:#6658a6!important;color:#fff!important;border:2px solid #fff!important;font-size:15px!important;padding:10px 18px!important;border-radius:22px!important;white-space:nowrap}
html body.mvmode #shopln,html body.mvmode #atm,html body.mvmode #tutarw{display:none!important}
html body #sheet.open{padding-bottom:calc(env(safe-area-inset-bottom,0px) + 140px)!important}
</style>`)}catch(e){}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
