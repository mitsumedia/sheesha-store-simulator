import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# エラー画面の「再読み込み」：古いページを読み直さないよう、毎回新しいURLで最新版を読み込む
rep('bar.querySelector("#errr").onclick=function(){location.reload()}',
    'bar.querySelector("#errr").onclick=function(){try{if(typeof save==="function")save()}catch(_){}location.replace(location.pathname+"?v="+Date.now())}')
# 画面をタップした時、まだ一度も描いていなければ描いてから判定（null is not an object 'k.ox' の対策）
rep('function onTap(clx,cly){const r=cv.getBoundingClientRect(),X=(clx-r.left)*W/r.width,Y=(cly-r.top)*CH/r.height,k=R.cv;','function onTap(clx,cly){const r=cv.getBoundingClientRect(),X=(clx-r.left)*W/r.width,Y=(cly-r.top)*CH/r.height;if(!R.cv){try{draw()}catch(_){}}const k=R.cv;if(!k)return;')
open(f,'w').write(s)
