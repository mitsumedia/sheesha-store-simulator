import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
SF='(c.job==="シーシャ屋"&&(c.vn||0)>=3?100:0)'
# 来店：来店頻度 ×（来店済みならリピート率）。補正なし
rep('spx(k)?k.freq/7:','spx(k)?k.freq/7*(k.job==="シーシャ屋"&&k.met?k.repeat:1):')
# 親密度：話しかけでは増えない。3回来店で100
rep('if(spx(c)){c.vn=(c.vn||0)+1;','if(spx(c)){c.vn=(c.vn||0)+1;c.fp=%s;'%SF)
rep('c.ret=1;c.quit=0;c.fp=c.hp=c.up=0;return}','c.ret=1;c.quit=0;c.hp=c.up=0;c.fp=%s;return}'%SF)
rep('G.cs.forEach(c=>{if(spx(c)){c.fp=c.hp=c.up=0;','G.cs.forEach(c=>{if(spx(c)){c.hp=c.up=0;c.fp=%s;'%SF)
rep('${spx(c)?"来店 "+(c.vn||0)+"回":"親密度 "+c.fp}','${c.job==="シーシャ屋"?"親密度 "+c.fp+"・来店 "+(c.vn||0)+"回":spx(c)?"来店 "+(c.vn||0)+"回":"親密度 "+c.fp}')
open(f,'w').write(s);print('ok')
