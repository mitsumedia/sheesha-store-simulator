import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 床のマスの光り方：2色で点滅＋ふち取り（チェック柄の床でも見える）
rep('function mvHi(k){if(!R.mvOn)return;const ph=.45+.25*Math.sin(performance.now()/180),Q=(tx,ty,c)=>{const x=tx*6,y=ty*6;poly([P3(x+.3,y+.3,0,k),P3(x+5.7,y+.3,0,k),P3(x+5.7,y+5.7,0,k),P3(x+.3,y+5.7,0,k)],c)},m=R.mvs;',
 'function mvHi(k){if(!R.mvOn)return;const ph=.45+.25*Math.sin(performance.now()/180),BL=Math.floor(performance.now()/380)%2,TW={"60,200,100":["30,215,80","250,240,40"],"90,170,255":["40,130,255","120,235,255"],"255,200,40":["255,140,0","255,60,60"]},'
 +'Q=(tx,ty,c)=>{const x=tx*6,y=ty*6,mm=/rgba\\((\\d+,\\d+,\\d+),/.exec(c),tw=mm&&TW[mm[1]];if(tw)c="rgba("+tw[BL]+",.78)";const pp=[P3(x+.3,y+.3,0,k),P3(x+5.7,y+.3,0,k),P3(x+5.7,y+5.7,0,k),P3(x+.3,y+5.7,0,k)];poly(pp,c);if(tw){cx.strokeStyle=BL?"rgba(20,20,30,.75)":"rgba(255,255,255,.95)";cx.lineWidth=2;cx.beginPath();cx.moveTo(pp[0][0],pp[0][1]);pp.slice(1).forEach(p=>cx.lineTo(p[0],p[1]));cx.closePath();cx.stroke()}},m=R.mvs;')
open(f,'w').write(s);print('ok')
s=open(f).read()
a='光っている<b style=\\"color:#2e9d4f\\">緑のマス</b>をタップすると移動します'
assert s.count(a)==1,s.count(a)
s=s.replace(a,'<b style=\\"color:#2e9d4f\\">緑⇔黄色に点滅しているマス</b>をタップすると移動します')
s=s.replace('log("緑のマスに移動できます")','log("点滅しているマスに移動できます")')
open(f,'w').write(s);print('txt')
