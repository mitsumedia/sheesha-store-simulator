import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('着せ替え（店主の見た目）からいつでも着られます','店主の「着せ替え」→「🧸 着ぐるみ」タブからいつでも着られます')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 着ぐるみを着せ替えのタブにする（髪型・服・ズボン・着ぐるみ・色・名前） ===== */
OWL.k=KGL.slice(1).map(x=>[x.n]);
OWCAT.kg=["着ぐるみ","k","kg",()=>["着ない"],"🧸"];
function kgSyncU(){if(!G||!G.kgH||!G.kgH.length)return;G.owU=G.owU||[];G.kgH.forEach(i=>{if(!G.owU.includes("k"+i))G.owU.push("k"+i)})}
{const _hk2=hud;hud=function(){const r=_hk2.apply(this,arguments);try{kgSyncU()}catch(e){}return r}}
kgRow=function(){return""};
{const _or4=owRender;owRender=function(){try{kgSyncU();if(OWK==="kg"&&!(G.kgH||[]).length){OWK="top";OWPV=null}}catch(e){}const r=_or4.apply(this,arguments);try{
 if(!(G.kgH||[]).length){const b=document.querySelector('#owcat [data-owk="kg"]');if(b)b.remove()}
 if(OWK==="kg"){const L=$("#owlist");if(L){const cur=owCur("kg");let h=`<button class="kgc kg2 ${OWPV===0||(OWPV==null&&cur===0)?"on":""}" data-owv="0"><div class="kgx">なし</div><b>着ない</b>${cur===0?`<i>着用中</i>`:""}</button>`;
  for(let i=1;i<KGL.length;i++){const v=99+i;h+=kgOwn(i)?`<button class="kgc kg2 ${OWPV===v||(OWPV==null&&cur===v)?"on":""}" data-owv="${v}"><canvas data-kgc="${i}" width="160" height="200"></canvas><b>${KGL[i].e} ${KGL[i].n}</b>${cur===v?`<i>着用中</i>`:""}</button>`:`<button class="kgc kg2 lk" data-kgl="${i}"><canvas data-kgc="${i}" data-sil="1" width="160" height="200"></canvas><b>？？？</b><i>${esc(KGL[i].q)}</i></button>`}
  L.innerHTML=`<div class="kgg">${h}</div><div style="font-size:11px;color:#8a8a8a;margin:10px 4px 2px;line-height:1.6">タップで試着、「着がえる」で着ます。着ぐるみの時は、目元（メガネなど）以外の装飾品は外れます。シルエットのものは、条件を達成するとお店に届きます。</div>`;kgPaint()}}}catch(e){}return r}}
(function(){const st=document.createElement("style");st.textContent=`#owlist button.kgc.kg2{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:flex-start;gap:2px!important;width:auto!important;min-height:130px!important;padding:6px 2px 8px!important;border:2px solid #cfd8d4!important;border-radius:12px!important;background:#fff!important;text-align:center!important;font-size:12px!important}#owlist button.kgc.kg2.on{border-color:#6658a6!important;background:#f1eefb!important;box-shadow:0 0 0 2px #6658a6 inset!important}#owlist button.kgc.kg2.lk{background:#f4f2ec!important}#owlist .kgc.kg2 canvas{width:72px;height:90px}#owlist .kgc.kg2 i{font-style:normal;font-size:10.5px;color:#6658a6;font-weight:900}#owlist .kgc.kg2.lk i{color:#8a8a8a;font-weight:700}#owlist .kgg{gap:8px}`;document.head.appendChild(st)})();
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
