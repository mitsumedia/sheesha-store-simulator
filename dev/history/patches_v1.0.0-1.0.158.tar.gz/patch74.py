import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== ひめ：赤茶→ピンクのグラデの縦ロールツインテ・ぱっつん前髪・ピンクの大きなフリルのヘッドドレス・黒リボン・ハートの紫の目・黒×ピンクのメイド服 ===== */
SPF.hime=({H,Q4,hr,sit})=>{const D="#5e1830",M="#8e3048",L="#c86878",E="#e8a0aa",PK="#f4a6c8",PK2="#e27fb0",WT="#fff6fa",K="#1b1b22",PB="#f5b8d0";
 /* 髪：頭頂・後ろ・ぱっつん前髪・横 */
 H(0,0,6,8,6,1,D);H(0,0,-2,8,1,8,D);H(-1,1,-1,1,5,7,D);H(8,1,-1,1,5,7,D);
 H(0,5,4,8,1,2,M);H(0,5,4,1,1,1,D);H(7,5,4,1,1,1,D);
 /* 縦ロール（左右）：下にいくほど明るく、段ごとにずらしてくるくる感 */
 for(const sx of[-3,9]){for(let z=2;z>-13;z--){const t=(2-z)/15,col=t<.3?M:t<.6?L:E,o=((z%2)+2)%2;H(sx-(sx<0?o:0),1+o,z,2,2,1,col);if(z%3===0)H(sx+(sx<0?1:-1)*0,2,z,1,1,1,D)}H(sx,1,-13,2,1,1,E)}
 /* 黒いリボン（ツインテの根元） */
 for(const sx of[-4,9]){H(sx,2,3,3,2,1,K);H(sx+(sx<0?-1:2),2,4,1,2,2,K);H(sx+(sx<0?-1:2),2,1,1,2,2,K);H(sx+1,2,2,1,2,2,"#33333d")}
 /* ピンクの大きなフリルのヘッドドレス */
 H(-1,4,6,10,2,1,WT);H(-1,5,6,10,1,1,"#e8d4f0");H(-2,1,7,12,5,1,PK);H(-2,0,8,12,4,1,PK2);for(let x=-2;x<10;x+=3){H(x,1,9,2,3,1,PK);H(x,4,8,2,1,1,"#ffd0e4")}H(-3,1,6,1,4,2,PK);H(10,1,6,1,4,2,PK);
 /* 目：紫・ハートのハイライト */
 for(const x0 of[1,5]){const Lf=x0===1;H(x0,5,3,2,1,1,"#3a1a2a");H(x0,5,2,2,1,1,"#8a4fb0");H(x0,5,1,2,1,1,"#b07ad8");H(Lf?x0:x0+1,5,2,1,1,1,"#ffffff");H(Lf?x0+1:x0,5,1,1,1,1,"#ff8fc8");H(Lf?x0-1:x0+2,5,3,1,1,1,"#3a1a2a")}
 H(0,5,0,1,1,1,"#ffb6c6");H(7,5,0,1,1,1,"#ffb6c6");H(3,5,0,2,1,1,"#e38a9c");
 /* 服：ピンクのリボン・ボタン・エプロン・フリル */
 const y=3.04;for(let x=1.25;x<2.75;x+=.25)Q4(x,y,7.75,(x>1.7&&x<2.3)?PB:"#f7c6dc");Q4(1,y,7.5,PB);Q4(2.75,y,7.5,PB);Q4(1.75,y,7.25,PB);Q4(2,y,7.25,PB);
 [6.75,6.25,5.75].forEach(z=>Q4(1.875,y+.02,z,PK2,.25));
 for(let z=3.25;z<5.5;z+=.25)for(let x=1.25;x<2.75;x+=.25)Q4(x,y,z,(x<1.4||x>2.55)?K:"#f7c6dc");for(let x=1;x<3;x+=.25)Q4(x,y,5.5,K);
 for(let x=.5;x<3.6;x+=.25)Q4(x,3.1,6.25,"#e9a8c4",.25);
 if(!sit){for(let x=.25;x<3.8;x+=.5)Q4(x,3.52,2.75,(x*2)%2?PK:"#ffd0e4");for(let x=.5;x<3.6;x+=.5)Q4(x,3.52,3.25,K)}};
SPF.hime.ownEye=1;
/* ひめの脚はグレーのニーハイ */
{const _pv=pv;pv=function(t){const n0=t.length,r=_pv.apply(this,arguments),c=arguments[4];try{if(c&&c.sp==="hime")for(let i=n0;i<t.length;i++){const v=t[i];if(v[3]===c.skin&&v[2]<3.6)v[3]=v[2]<1.2?"#3b3942":"#55525e"}}catch(e){}return r}}
'''
s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
