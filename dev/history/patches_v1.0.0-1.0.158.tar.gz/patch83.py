import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
# 非売品：誰からもらったかを表示（持ち物の一覧・模様替えで選んだとき）
rep("""${gf?' <small style="color:#d4a017">非売品</small>':""}</span>""","""${gf?' <small style="color:#d4a017">非売品</small>':""}${gfFrom(it.id)}</span>""")
CODE=r'''
/* ===== 非売品をくれたお客さんの名前 ===== */
function gfGiver(id){if(!id)return null;for(const k in GIFT){const x=GIFT[k];if(x&&x.id===id)return G.cs[+k]||null}return null}
function gfFrom(id){const c=gfGiver(id);if(!c)return"";const n=c.nick||(lv(c)>=NL?c.name:"No."+String(dxN(c)).padStart(3,"0")+"のお客さん");return`<div class="gfr" style="font-size:11px;color:#e8954a;margin-top:2px">🎁 ${esc(n)} からもらった</div>`}
{const _mb=mvBar;mvBar=function(){_mb.apply(this,arguments);try{const m=R.mvs;if(!m||m.t==="f")return;const id=m.t==="d"?(G.decor[m.i]||{}).id:(G.wall[m.i]||{}).id,h=gfFrom(id),b=document.querySelector("#mvbar .tc");if(h&&b&&!b.querySelector(".gfr")){const t=b.querySelector("b");t?t.insertAdjacentHTML("afterend",h):b.insertAdjacentHTML("afterbegin",h)}}catch(e){}}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
