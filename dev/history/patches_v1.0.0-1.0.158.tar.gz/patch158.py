import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# グループ（3人以上の列）
rep('if(t.pair)MB.L.push({T:t,s,x:x+2.6,y:(s>0?g.Y0-10:g.Y1+10)+1,a:Math.random()*9+3,t:0,sp:MB.L[MB.L.length-1].sp,um:0,tag:1})}}}',
 'const gn=t.grp||(t.pair?2:1),sp0=MB.L[MB.L.length-1].sp;for(let i=1;i<gn;i++)MB.L.push({T:t,s,x:x+(i%2)*2.6,y:(s>0?g.Y0-10:g.Y1+10)-s*Math.floor(i/2)*4.5+(i%2),a:Math.random()*9+3+i,t:0,sp:sp0,um:0,tag:1})}}try{mbSpecial(g,z)}catch(e){}}')
rep('if(m.y<g.Y0-40||m.y>g.Y1+40)return false;','if(m.y<g.Y0-(m.tr?110:40)||m.y>g.Y1+(m.tr?110:40))return false;')
# 季節・空を飛ぶもの・連れている動物
rep('W=MBT.filter(t=>t.k===k||(k==="ped"&&t.k==="bike")).map(t=>{','W=MBT.filter(t=>(t.k===k||(k==="ped"&&t.k==="bike"))&&!t.sp0).map(t=>{if(t.mo&&!t.mo.includes(MN[(G.month||0)%12]))return[t,0];')
rep('if(m.T.dog){P=P.concat(mbDog(m.s>0?1.8:-1.8,m.s>0?7.4:-3,m.T.dog,m.T.big,m.t))}','if(m.T.dog){P=P.concat(mbDog(m.s>0?1.8:-1.8,m.s>0?7.4:-3,m.T.dog,m.T.big,m.t))}if(m.T.pet){P=P.concat(m.T.pet(m.t,m.a))}if(m.T.fly){const fz=m.T.fly+Math.sin(m.t*2+m.a)*.8;P=P.map(p=>[p[0],p[1],p[2]+fz,p[3],p[4],p[5],p[6],p[7]])}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 通行人を追加（乗り物・人・動物・季節限定・地域限定） ===== */
/* 4本足の動物：[横,前後,高さ,幅,長さ,高さ,色] 前が+y */
function mbQ(l,w,h,c,t,o){o=o||{};const b=Math.sin(t*12)*.25,lg=o.lg||h*.55,P=[[-w/2,0,lg,w,l,h-lg,c],[-w*.4,l-.2,lg+(h-lg)*.4,w*.8,w*.9,(h-lg)*.9,o.hc||c]];
 for(const[xx,yy,k]of[[-w/2,.2,1],[w/2-.4*w/2-.2,.2,-1],[-w/2,l-1,-1],[w/2-.4*w/2-.2,l-1,1]])P.push([xx,yy+b*k,0,Math.max(.4,w*.3),.5,lg,o.lc||c]);
 if(o.ear)P.push([-w*.35,l+w*.3,lg+(h-lg)*1.25,.4,.4,o.ear,o.ec||c],[w*.35-.4,l+w*.3,lg+(h-lg)*1.25,.4,.4,o.ear,o.ec||c]);if(o.tail)P.push([-.2,-o.tail,lg+(h-lg)*.6,.4,o.tail,.4,o.tc||c]);if(o.horn)P.push([-w*.3,l+w*.2,lg+(h-lg)*1.3,.3,.3,o.horn,"#e0d6c4"],[w*.3-.3,l+w*.2,lg+(h-lg)*1.3,.3,.3,o.horn,"#e0d6c4"]);if(o.ex)o.ex(P);return P}
function mbBird(c,s,t,o){o=o||{};const f=Math.sin(t*(o.fly?16:3))*(o.fly?.6:0),P=[[-.5*s,0,.8*s,s,2*s,s,c],[-.4*s,1.8*s,1.4*s,.8*s,.9*s,.8*s,o.hc||c],[-.1*s,2.7*s,1.6*s,.2*s,.5*s,.2*s,o.bk||"#ffb300"]];if(o.fly)P.push([-2.2*s,.4*s,1.3*s+f,1.7*s,1.2*s,.2*s,o.wc||c],[.5*s,.4*s,1.3*s+f,1.7*s,1.2*s,.2*s,o.wc||c]);else P.push([-.3*s,.6*s,0,.2,.2,.8*s,"#ff8a65"],[.1*s,.6*s,0,.2,.2,.8*s,"#ff8a65"]);return P}
const MOS=[4],MSU=[7,8],MOC=[10],MDE=[12];
MBT.push(
 /* 乗り物 */
 {id:"yubin",n:"郵便のバイク",k:"bike",r:2,sp:20,d:1,mk:(a)=>mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#455a64",pa:"#455a64",mc:"#d32f2f",box:"#d32f2f",hel:"#fafafa"},1)},
 {id:"toshokan",n:"移動図書館",k:"car",r:3,l:22,sp:16,d:1,a:[4,4,5],mk:()=>{const P=mbBox(22,7.4,10,"#4caf50",5,"#fafafa");P.push([3.75,2,4,.1,13,3,"#fff59d"],[3.76,3,4.6,.1,2,1.8,"#e53935"],[3.76,6,4.6,.1,2,1.8,"#1e88e5"],[3.76,9,4.6,.1,2,1.8,"#8e24aa"]);return P}},
 {id:"ramen",n:"ラーメンの屋台",k:"car",r:3,l:12,sp:6,ni:1,a:[1,1,2],mk:()=>[[-3,1,2,6,9,5,"#8d6e63"],[-3.2,.6,7,6.4,9.8,.6,"#c62828"],[-3.25,.7,5.6,.1,9.4,1.4,"#fff3e0"],[-2.8,1,7.6,.4,.4,3,"#5d4037"],[2.4,1,7.6,.4,.4,3,"#5d4037"],[-.6,1.2,10.6,1.2,1.2,1.4,"#ff5252",1],[-3.6,2,0,.6,2.4,2.4,"#212121"],[3,2,0,.6,2.4,2.4,"#212121"],[-.5,10,2,1,3,.4,"#6d4c41"]]},
 {id:"hanayome",n:"花嫁を乗せたオープンカー",k:"car",r:4,l:18,sp:14,d:1,mk:()=>{const P=mbCar(18,6.8,5,"#fafafa",{open:1});P.push([-2.2,6,4,2.2,2,4,"#ffffff"],[-2,6.2,8,1.8,1.6,1.8,"#ffe0c4"],[-2.4,5.8,9.6,2.6,2.6,.6,"#ffffff"],[.6,6,4,2.2,2,4.2,"#212121"],[.8,6.2,8.2,1.8,1.6,1.8,"#f1c7a0"],[-1,-.4,2,2,.4,1.4,"#f8bbd0"],[-2.6,-1.6,1.2,.6,.6,.6,"#bdbdbd"],[1.8,-1.4,1.2,.6,.6,.6,"#bdbdbd"]);return P}},
 {id:"ensoku",n:"校外学習のバス",k:"car",r:3,l:32,sp:18,d:1,mk:()=>{const P=[[-4,1,1.4,8,30,10,"#ffd54f"],[-4.1,3,5.4,8.2,26,3,"#81d4fa"],[-4.1,1,2,8.2,30,1.2,"#e65100"]];for(let i=0;i<6;i++)P.push([-3.6,4+i*4.2,6.6,.8,.8,.9,"#ffe0c4"]);for(const yy of[4,24])for(const xx of[-4.2,3.2])P.push([xx,yy,0,1,2.4,2,"#212121"]);return P}},
 {id:"kanko_bus",n:"観光バス",k:"car",r:2,l:36,sp:20,a:[2,2,6,3],mk:(a)=>{const c=mbP(["#e91e63","#3949ab","#00897b","#f4511e"],a),P=[[-4,1,1.4,8,34,11,"#fafafa"],[-4.1,3,6,8.2,30,3.4,"#263238"],[-4.1,1,2,8.2,34,3,c],[-4.12,8,3.4,.1,18,1.6,"#ffd54f"]];for(const yy of[4,28])for(const xx of[-4.2,3.2])P.push([xx,yy,0,1,2.4,2,"#212121"]);return P}},
 {id:"roller",n:"ロードローラー",k:"car",r:3,l:14,sp:5,d:1,mk:()=>[[-3.6,9,0,7.2,4,4,"#9e9e9e"],[-3,1,1,6,8,4,"#fbc02d"],[-2.4,2,5,4.8,5,4,"#fbc02d"],[-2.2,2.4,5.4,4.4,4,3,"#9ecbe0"],[-3.8,1.4,0,1.2,3,3,"#212121"],[2.6,1.4,0,1.2,3,3,"#212121"]]},
 {id:"shovel",n:"ショベルカー",k:"car",r:3,l:16,sp:6,d:1,mk:()=>[[-3.6,1,0,7.2,12,2,"#424242"],[-3,2,2,6,10,4,"#fbc02d"],[-2.6,3,6,4,5,4,"#fbc02d"],[-2.4,3.4,6.4,3.6,3,3,"#9ecbe0"],[-.6,10,4,1.2,6,1.2,"#f9a825"],[-.6,15,1,1.2,1.2,4.4,"#f9a825"],[-1.4,15.2,.2,2.8,2,1.6,"#616161"]]},
 {id:"wrecker",n:"レッカー車",k:"car",r:3,l:34,sp:18,mk:(a)=>{const P=mbBox(16,7,6,"#f57c00",6,"#f57c00").map(p=>[p[0],p[1]+18,p[2],p[3],p[4],p[5],p[6],p[7]]);P.push([-.4,16,6,.8,4,.8,"#424242"],[-1.8,22,7.6,3.6,1.2,.6,"#ff1744",1]);return P.concat(mbCar(16,6.4,6,mbP(["#1e88e5","#9e9e9e","#e53935"],a)).map(p=>[p[0],p[1],p[2]+(p[1]>8?.8:0),p[3],p[4],p[5],p[6],p[7]]))}},
 {id:"genyu",n:"現金輸送車",k:"car",r:4,l:18,sp:24,d:1,mk:()=>{const P=mbBox(18,7,8,"#37474f",5,"#37474f");P.push([3.55,2,3,.1,10,.6,"#ffd54f"],[-3.55,2,3,.1,10,.6,"#ffd54f"]);return P}},
 {id:"basha",n:"馬車",k:"car",r:5,l:28,sp:10,mk:(a,t)=>{const P=[[-3,1,3,6,10,7,"#fafafa"],[-3.2,.8,10,6.4,10.4,1,"#ffd54f"],[-3.05,3,5,.1,6,3,"#9ecbe0"],[-3.6,1.4,0,.6,4,4,"#ffd54f"],[3,1.4,0,.6,4,4,"#ffd54f"],[-3.6,7.6,0,.6,3,3,"#ffd54f"],[3,7.6,0,.6,3,3,"#ffd54f"],[-.3,11,3,.6,6,.4,"#6d4c41"]];return P.concat(mbQ(9,2.6,7,"#fafafa",t||0,{lg:4,ear:1,tail:2,tc:"#e0e0e0"}).map(p=>[p[0],p[1]+16,p[2],p[3],p[4],p[5],p[6]]))}},
 {id:"jinriki",n:"人力車",k:"bike",r:4,sp:9,a:[3,3,2],d:1,mk:(a,t)=>{const P=[[-3,0,2.6,6,5,4,"#212121"],[-3.2,-.2,6.6,6.4,5.4,.6,"#c62828"],[-3.6,1.4,0,.6,5,5,"#5d4037"],[3,1.4,0,.6,5,5,"#5d4037"],[-2.6,4.8,3,.4,6,.4,"#5d4037"],[2.2,4.8,3,.4,6,.4,"#5d4037"]];return P.concat(mbPer({sk:"#c58a5c",hr:"#161616",cl:"#212121",pa:"#212121",t:t*1.4,hel:"#d7ccc8"}).map(p=>[p[0],p[1]+6,p[2],p[3],p[4],p[5],p[6],p[7]]))}},
 {id:"segway",n:"セグウェイ",k:"bike",r:3,sp:12,mk:(a)=>[[-1.6,0,0,.6,1.8,1.8,"#212121"],[1,0,0,.6,1.8,1.8,"#212121"],[-1,0,.8,2,1.8,.4,"#424242"],[-.2,1.6,1,.4,.4,6,"#9e9e9e"],[-1.2,1.4,7,2.4,.4,.4,"#9e9e9e"]].concat(mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",walk:0,dz:1.2}).map(p=>[p[0],p[1]-4,p[2],p[3],p[4],p[5],p[6],p[7]]))},
 {id:"kick",n:"キックボード",k:"bike",r:2,sp:13,mk:(a,t)=>[[-.3,0,0,.6,1,1,"#212121"],[-.3,5,0,.6,1,1,"#212121"],[-.6,.4,.6,1.2,5,.3,"#26c6da"],[-.2,5.2,.8,.4,.4,6,"#9e9e9e"],[-1.2,5,6.6,2.4,.4,.4,"#212121"]].concat(mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(MB_CL,a),pa:"#3b3b4a",walk:0,dz:.9}).map(p=>[p[0],p[1]-2,p[2],p[3],p[4],p[5],p[6],p[7]]))},
 {id:"ichirin",n:"一輪車の子ども",k:"bike",r:3,sp:6,d:1,a:[4,4],mk:(a,t)=>[[-.3,1,0,.6,2.6,2.6,"#e53935"],[-.2,2.1,2.6,.4,.4,2.4,"#9e9e9e"],[-.8,1.6,5,1.6,1.4,.4,"#212121"]].concat(mbPer({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:mbP(["#ffeb3b","#4fc3f7","#f48fb1"],a),pa:"#3b3b4a",walk:0,dz:1.6}).map(p=>[p[0]*.75,p[1]*.75-1.2,p[2]*.75+1.4,p[3]*.75,p[4]*.75,p[5]*.75,p[6],p[7]]))},
 {id:"ryoshi",n:"漁師の軽トラ",k:"car",r:2,l:13,sp:22,only:[6],mk:()=>{const P=mbBox(13,6,4.5,"#fafafa",5,"#fafafa");P[0][5]=1.2;P.push([-2.6,1.4,2.2,2.4,2.4,1.6,"#1e88e5"],[.2,1.4,2.2,2.4,2.4,1.6,"#1e88e5"],[-2.4,4.2,2.2,4.8,2.6,1.2,"#cfd8dc"],[-1.8,4.4,3.4,3.6,2,.4,"#90a4ae"]);return P}},
 {id:"taue",n:"田植え機",k:"car",r:3,l:11,sp:5,only:[5],d:1,mo:[4,5,6],mk:()=>[[-3.4,0,1,6.8,3,1,"#8bc34a"],[-2.4,3,1.4,4.8,6,3,"#e53935"],[-.4,5,4.4,.8,.8,4,"#424242"],[-1.6,5.6,8.4,3.2,.4,.4,"#424242"],[-3,4,0,1,3,3,"#212121"],[2,4,0,1,3,3,"#212121"]]},
 {id:"yaoya",n:"八百屋の配達",k:"bike",r:2,sp:11,only:[3],d:1,mk:(a)=>{const P=mbBike({sk:mbP(MB_SK,a),hr:mbP(MB_HR,a),cl:"#2e7d32",pa:"#3b3b4a",fc:"#616161",box:"#a1887f"});P.push([-1.2,0,6.6,.8,.8,.8,"#ff7043"],[-.2,.6,6.6,.8,.8,.8,"#7cb342"],[.4,0,6.6,.6,.6,.8,"#fdd835"]);return P}},
 {id:"train",n:"電車",k:"train",r:2,l:62,sp:34,only:[2],sp0:1,mk:()=>{const P=[];for(let i=0;i<4;i++){const y=i*15.5;P.push([-2.3,y,.6,4.6,15,4.4,"#eceff1"],[-2.35,y+1,2.4,4.7,13,1.4,"#4fc3f7"],[-2.35,y,3.9,4.7,15,.6,"#2e7d32"],[-2.5,y,5,5,15,.4,"#90a4ae"])}P.push([-1,61.6,2.2,2,.4,1,"#fff59d",1]);return P}},
 /* 人 */
 {id:"shogaku",n:"ランドセルの小学生の列",k:"ped",r:2,sp:7,grp:4,d:1,a:[4,4,5],mk:()=>[]},
 {id:"hoikuen",n:"保育園のお散歩カート",k:"ped",r:3,sp:5,d:1,a:[4,4,3],pet:(t)=>{const b=Math.sin(t*14)*.1,P=[[-2.4,6.6,1.2,4.8,7,3,"#f5f5f5"],[-2.5,6.5,4.2,5,7.2,.4,"#e53935"],[-2.6,6.8,0,1,1,1.2,"#212121"],[1.6,6.8,0,1,1,1.2,"#212121"],[-2.6,12.2,0,1,1,1.2,"#212121"],[1.6,12.2,0,1,1,1.2,"#212121"]];for(let i=0;i<4;i++)P.push([-1.6+(i%2)*2,7.6+Math.floor(i/2)*3,4.6+b,1.4,1.4,1.4,"#ffe0c4"],[-1.7+(i%2)*2,7.5+Math.floor(i/2)*3,5.9+b,1.6,1.6,.5,["#ffeb3b","#4fc3f7","#f48fb1","#aed581"][i]]);return P},mk:()=>[]},
 {id:"babycar",n:"ベビーカーを押す人",k:"ped",r:1,sp:7,d:1,a:[4,4,3],pet:(t)=>[[-1.4,6.2,2,2.8,3.6,2.4,"#5c6bc0"],[-1.5,8.2,4.4,3,1.8,2.2,"#3949ab"],[-1.6,6,0,.6,.6,1.2,"#212121"],[1,6,0,.6,.6,1.2,"#212121"],[-1.6,9.2,0,.6,.6,1.2,"#212121"],[1,9.2,0,.6,.6,1.2,"#212121"],[-.2,4.6,4.2,.4,2,.4,"#9e9e9e"]],mk:()=>[]},
 {id:"tsue",n:"杖をついたおじいさん",k:"ped",r:1,sp:5,d:1,a:[3,4,5],mk:()=>[]},
 {id:"cameraman",n:"カメラマン",k:"ped",r:2,sp:6,a:[2,6,3],mk:()=>[]},
 {id:"youtuber",n:"自撮り棒のユーチューバー",k:"ped",r:2,sp:6,a:[0,1,2],mk:()=>[]},
 {id:"drone",n:"配達ドローン",k:"ped",r:4,sp:16,fly:18,cat:1,d:1,mk:(a,t)=>{const r=Math.sin(t*40)*.3;return[[-1.4,0,0,2.8,2.8,1.4,"#eceff1"],[-1,.4,-1.4,2,2,1.4,"#ff7043"],[-2.6-r,-.8,1.6,1.6,.3,.2,"#424242"],[1+r,-.8,1.6,1.6,.3,.2,"#424242"],[-2.6+r,3.3,1.6,1.6,.3,.2,"#424242"],[1-r,3.3,1.6,1.6,.3,.2,"#424242"],[-.3,1.2,1.4,.6,.6,.4,"#00e676",1]]}},
 {id:"chirashi",n:"チラシ配り",k:"ped",r:2,sp:3,a:[2,2,1,0],mk:()=>[]},
 {id:"kouho",n:"選挙の候補者",k:"ped",r:3,sp:4,d:1,mk:()=>[]},
 {id:"marathon",n:"マラソン大会の集団",k:"ped",r:4,sp:16,grp:6,d:1,mk:()=>[]},
 {id:"awa",n:"阿波踊りの列",k:"ped",r:4,sp:5,grp:5,mo:MSU,mk:()=>[]},
 {id:"santa",n:"サンタクロース",k:"ped",r:4,sp:7,mo:MDE,mk:()=>[]},
 {id:"halloween",n:"ハロウィンの仮装",k:"ped",r:3,sp:7,grp:3,mo:MOC,mk:()=>[]},
 {id:"hanami",n:"花見帰りの人",k:"ped",r:2,sp:6,grp:2,mo:MOS,mk:()=>[]},
 {id:"yukata",n:"浴衣のカップル",k:"ped",r:2,sp:5,pair:1,mo:MSU,mk:()=>[]},
 {id:"yatai",n:"屋台を引くおじさん",k:"ped",r:3,sp:4,ni:1,only:[1],pet:(t)=>[[-2.4,6,2,4.8,6,4,"#8d6e63"],[-2.6,5.8,8,5.2,6.4,.6,"#ff7043"],[-2.65,6,6.6,.1,6,1.4,"#fff3e0"],[-2.8,7,0,.6,2.4,2.4,"#212121"],[2.2,7,0,.6,2.4,2.4,"#212121"],[-.4,11.6,9,.8,.8,1.2,"#ff5252",1]],mk:()=>[]},
 {id:"katanoneko",n:"肩に猫を乗せた人",k:"ped",r:4,sp:6,pet:(t)=>[[1.1,3.6,10.2,1.4,2.6,1.2,"#ff9800"],[1.1,5.8,11,1.4,1.2,1.2,"#ff9800"],[1.2,5.9,12.2,.3,.3,.5,"#ff9800"],[2.1,5.9,12.2,.3,.3,.5,"#ff9800"],[1.6,2.4,10.6,.3,1.4,.3,"#ff9800"]],mk:()=>[]},
 {id:"yagi",n:"ヤギの散歩",k:"ped",r:4,sp:6,a:[5,5],pet:(t)=>mbQ(4.4,1.8,4.4,"#f5f5f5",t,{lg:2.4,horn:1,tail:.6,ex:P=>P.push([-.2,4.8,2.4,.4,.3,1,"#f5f5f5"])}).map(p=>[p[0]+2.4,p[1]+5,p[2],p[3],p[4],p[5],p[6]])},
 {id:"alpaca",n:"アルパカの散歩",k:"ped",r:5,sp:5,pet:(t)=>mbQ(5,2.4,5,"#f3e5c8",t,{lg:3,ear:1,ex:P=>P.push([-.7,4.4,4.6,1.4,1.4,4,"#f3e5c8"],[-.8,4.6,8.4,1.6,1.8,1.6,"#f3e5c8"])}).map(p=>[p[0]+2.6,p[1]+5,p[2],p[3],p[4],p[5],p[6]])},
 /* 動物 */
 {id:"karasu",n:"カラス",k:"ped",r:1,sp:3,cat:1,a:[1,1,3],mk:(a,t)=>mbBird("#212121",1.2,t,{bk:"#424242"})},
 {id:"hato",n:"ハト",k:"ped",r:1,sp:2,cat:1,grp:3,a:[2,2,3,0],mk:(a,t)=>mbBird("#90a4ae",1,t,{hc:"#607d8b"})},
 {id:"suzume",n:"スズメの群れ",k:"ped",r:1,sp:4,cat:1,grp:4,a:[4,5],mk:(a,t)=>mbBird("#8d6e63",.6,t,{hc:"#5d4037"})},
 {id:"kamome",n:"カモメ",k:"ped",r:2,sp:10,cat:1,fly:16,only:[6],mk:(a,t)=>mbBird("#fafafa",1.4,t,{fly:1,wc:"#cfd8dc"})},
 {id:"karasu_f",n:"空を飛ぶカラス",k:"ped",r:2,sp:12,cat:1,fly:20,mk:(a,t)=>mbBird("#212121",1.3,t,{fly:1,bk:"#424242"})},
 {id:"fukuro",n:"フクロウ",k:"ped",r:4,sp:9,cat:1,fly:17,ni:1,a:[5,5,4],mk:(a,t)=>mbBird("#8d6e63",1.5,t,{fly:1,hc:"#a1887f",bk:"#ffd54f"})},
 {id:"komori",n:"コウモリ",k:"ped",r:3,sp:13,cat:1,fly:19,ni:1,a:[5,1],mk:(a,t)=>mbBird("#37474f",.9,t,{fly:1,bk:"#37474f"})},
 {id:"maigo",n:"迷子の犬",k:"ped",r:3,sp:7,cat:1,mk:(a,t)=>mbDog(0,2,mbP(["#d9822b","#fafafa","#5d4037"],a),0,t).concat([[-.5,4.6,2.2,1,.3,.3,"#e53935"]])},
 {id:"oyakoneko",n:"猫の親子",k:"ped",r:3,sp:4,cat:1,a:[3,5],mk:(a,t)=>{const c=mbP(["#fafafa","#ff9800","#424242"],a);return mbDog(0,4,c,0,t).concat(mbDog(.2,0,c,0,t+1).map(p=>[p[0]*.6,p[1]*.6,p[2]*.6,p[3]*.6,p[4]*.6,p[5]*.6,p[6]]))}},
 {id:"karugamo",n:"カルガモ親子の行列",k:"ped",r:4,sp:3,cat:1,a:[4,6,5],mk:(a,t)=>{let P=mbBird("#8d6e63",1.2,t,{hc:"#5d4037",bk:"#fdd835"}).map(p=>[p[0],p[1]+9,p[2],p[3],p[4],p[5],p[6]]);for(let i=0;i<4;i++)P=P.concat(mbBird("#a1887f",.6,t+i,{bk:"#fdd835"}).map(p=>[p[0]+(i%2)*.6,p[1]+i*2,p[2],p[3],p[4],p[5],p[6]]));return P}},
 {id:"tanuki",n:"たぬき",k:"ped",r:3,sp:5,cat:1,ni:1,only:[5,4],mk:(a,t)=>mbQ(3.4,1.8,2.6,"#8d6e63",t,{lg:1,hc:"#a1887f",ear:.5,tail:1.4,tc:"#5d4037",lc:"#3e2723",ex:P=>P.push([-.8,3.6,1.6,1.6,.3,.5,"#3e2723"])})},
 {id:"kitsune",n:"キツネ",k:"ped",r:4,sp:8,cat:1,only:[5],mk:(a,t)=>mbQ(3.6,1.4,3,"#ef6c00",t,{lg:1.4,ear:.8,tail:2.4,tc:"#ffe0b2",lc:"#3e2723"})},
 {id:"inoshishi",n:"イノシシ",k:"ped",r:4,sp:11,cat:1,only:[5],mk:(a,t)=>mbQ(5,2.6,3.6,"#5d4037",t,{lg:1.4,hc:"#4e342e",ear:.5,tail:.6,ex:P=>P.push([-.9,6.1,1.4,.3,.3,.6,"#fafafa"],[.6,6.1,1.4,.3,.3,.6,"#fafafa"])})},
 {id:"shika",n:"シカ",k:"ped",r:4,sp:8,cat:1,only:[5],mk:(a,t)=>mbQ(5,1.8,6,"#a1887f",t,{lg:3.6,ear:.6,horn:2.2,tail:.5,tc:"#fafafa"})},
 {id:"saru",n:"サル",k:"ped",r:4,sp:7,cat:1,only:[5],mk:(a,t)=>mbQ(2.6,1.6,3.2,"#8d6e63",t,{lg:1.4,hc:"#f8bbd0",tail:.8})},
 {id:"usagi",n:"野ウサギ",k:"ped",r:3,sp:8,cat:1,only:[5],mk:(a,t)=>mbQ(2,1.4,1.8,"#a1887f",t,{lg:.6,ear:1.8,tail:.3,tc:"#fafafa"})},
 {id:"hebi",n:"ヘビ",k:"ped",r:3,sp:3,cat:1,only:[5],mk:(a,t)=>{const P=[];for(let i=0;i<7;i++)P.push([Math.sin(t*4+i)*.8-.3,i*.8,0,.6,.8,.5,i===6?"#33691e":"#558b2f"]);return P}},
 {id:"nezumi",n:"ネズミ",k:"ped",r:2,sp:9,cat:1,ni:1,a:[1,1,3],mk:(a,t)=>mbQ(1.6,.8,.8,"#757575",t,{lg:.3,ear:.3,tail:1.4,tc:"#9e9e9e"})},
 {id:"hakubishin",n:"ハクビシン",k:"ped",r:3,sp:8,cat:1,ni:1,only:[4,3],mk:(a,t)=>mbQ(4,1.4,2.2,"#616161",t,{lg:.9,hc:"#eeeeee",tail:2.6,tc:"#424242"})},
 {id:"kame",n:"ウミガメ",k:"ped",r:4,sp:1.5,cat:1,only:[6],mk:(a,t)=>[[-1.6,0,.3,3.2,3.6,1.2,"#6d4c41"],[-1.2,.4,1.5,2.4,2.8,.4,"#8d6e63"],[-.5,3.6,.4,1,1,.8,"#a1887f"],[-2.4,1+Math.sin(t*3)*.3,.2,1,1,.3,"#a1887f"],[1.4,1-Math.sin(t*3)*.3,.2,1,1,.3,"#a1887f"]]},
 {id:"kani",n:"カニ",k:"ped",r:2,sp:3,cat:1,only:[6],mk:(a,t)=>[[-.8,0,.4,1.6,1.2,.6,"#e53935"],[-1.4,.2,0,.2,.2,.5,"#c62828"],[1.2,.2,0,.2,.2,.5,"#c62828"],[-1.6,1.2,.6,.6,.6,.4,"#e53935"],[1,1.2,.6,.6,.6,.4,"#e53935"]]}
);
MBT.forEach(t=>MBI[t.id]=t);
Object.assign(MBLK,{shogaku:{shirt:["#fafafa","#ffcc80","#90caf9"],acc:2,accC:"#ffeb3b",pants:["#1a237e"],bot:1},tsue:{hair:["#e0e0e0","#bdbdbd"],shirt:["#8d6e63","#607d8b"],top:5},cameraman:{shirt:["#5d4037","#455a64"],top:5,acc:2},youtuber:{hair:["#e86aa6","#4fc3f7","#e0c068"],shirt:["#fafafa","#212121"]},chirashi:{shirt:["#ff7043","#fdd835"],top:0},kouho:{shirt:["#263238"],top:2,pants:["#263238"]},
 marathon:{shirt:["#e53935","#1e88e5","#43a047","#fdd835","#8e24aa"],top:4,bot:1,pants:["#212121"]},awa:{shirt:["#1565c0","#e3f2fd","#ad1457"],top:5,pants:["#fafafa"]},santa:{shirt:["#d32f2f"],top:5,pants:["#d32f2f"],hair:["#fafafa"],acc:4,accC:"#fafafa",akU:1},halloween:{shirt:["#4a148c","#212121","#ff6f00"],top:5},hanami:{shirt:["#f8bbd0","#fafafa"]},yukata:{shirt:["#1a237e","#ad1457","#00695c","#f8bbd0"],top:5,pants:["#1a237e","#ad1457"]},yatai:{hair:["#9e9e9e"],shirt:["#fafafa"],top:0,acc:9},katanoneko:{},yagi:{},alpaca:{},hoikuen:{shirt:["#f48fb1","#81d4fa"],top:5},babycar:{}});
{const _lk=mbLook;mbLook=function(t,a){const c=_lk.apply(this,arguments),o=MBLK[t.id]||{};if(o.accC)c.accC=o.accC;if(o.akU)c.akU=1;if(t.id==="shogaku"){c.fat=0}return c}}
{const _pp=mbProps;mbProps=function(m,ox,oy,dir){const P=_pp.apply(this,arguments),px=(x,y,z,w,d,h,c,s)=>{s=s||.5;for(let i=0;i<w;i+=s)for(let j=0;j<d;j+=s)for(let k=0;k<h;k+=s)P.push([ox+x+i,oy+y+j,z+k,c,undefined,s])},id=m.T.id,back=dir===0?-.6:3.2;
 if(id==="shogaku")px(.6,back,5,3,1,3,mbP(["#c62828","#212121","#8e24aa","#795548"],m.a));if(id==="tsue")px(3.6,2.6,0,.5,.5,7,"#6d4c41");if(id==="cameraman")px(1,dir===0?3.4:-.6,8.4,2,1,1.4,"#212121");if(id==="youtuber")px(3.4,dir===0?3:0,8,.5,.5,5,"#9e9e9e"),px(3.2,dir===0?3:0,13,1,.5,1.5,"#212121");
 if(id==="chirashi")px(3.4,1.6,6.6,1,1.5,.5,"#fafafa");if(id==="kouho"){for(let k=0;k<4;k++)px(.6+k*.7,1.2,5+k*.7,.7,2,.5,"#fafafa");px(3.4,1.6,8,1,1.5,1,"#bdbdbd")}if(id==="marathon")px(1.2,dir===0?3.2:-.4,5.5,1.6,.5,1.6,"#fafafa");
 if(id==="awa")px(.2,.4,12,3.6,3,.5,"#fff59d"),px(1,1.2,12.5,2,1.5,.5,"#fff59d");if(id==="santa")px(.4,back,6,3,1.6,3.5,"#6d4c41");if(id==="halloween")m.a%2<1?px(.6,.6,8,3,3,3,"#ff6f00"):(px(.2,.2,12,3.6,3.6,.5,"#212121"),px(1,1,12.5,2,2,2,"#212121"));if(id==="hanami")px(3.4,1.6,6,.5,.5,4,"#6d4c41"),px(3,1.2,10,1.5,1.5,1,"#f8bbd0");
 if(id==="yukata")px(.6,1.4,6.5,2.8,1.4,.5,"#fdd835");return P}}
/* 駅前の電車：線路の上を時々走る */
function mbSpecial(g,z){if(z!==2)return;const now=performance.now();if(MB.L.some(m=>m.T.id==="train")||now<(MB.trN||0))return;MB.trN=now+(12000+Math.random()*10000)/Math.max(1,mbSpd());const xs=FLT.map(t=>t[0]),ys=FLT.map(t=>t[1]),L=Math.min(...xs)*6,Rr=(Math.max(...xs)+1)*6,T=Math.min(...ys)*6,s=Math.random()<.5?1:-1;MB.L.push({T:MBI.train,s,ax:1,zo:14.4,x:s>0?L-150:Rr+150,y:T-17+(s>0?1.6:4.8)+2.3,a:1,t:0,sp:34,tr:1,x0:L-160,x1:Rr+160})}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
