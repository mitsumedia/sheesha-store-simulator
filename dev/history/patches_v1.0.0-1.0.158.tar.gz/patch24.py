import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== EXのお客さんの専用パーツ ===== */
{const ring=(H,z,cols,x0=-1,y0=-1,w=10,d=8)=>{let k=0;for(let x=x0;x<x0+w;x++){H(x,y0,z,1,1,1,cols[k++%cols.length]);H(x,y0+d-1,z,1,1,1,cols[k%cols.length])}for(let y=y0+1;y<y0+d-1;y++){H(x0,y,z,1,1,1,cols[k++%cols.length]);H(x0+w-1,y,z,1,1,1,cols[k%cols.length])}};
const hachi=(H,c1,c2)=>{ring(H,5,[c1,c1,c2]);H(5,6,5,2,1,1,c1);H(6,7,4,1,1,2,c1);H(5,7,5,1,1,1,c2)};
const kimono=({B,Q4},col,obi,obi2)=>{B(1,1,1,2,2,3,col);for(let x=1;x<3;x+=.25)for(const z of[5.5,5.75,6,6.25])Q4(x,3,z,z===5.75?obi2:obi);
[[1.5,7.75],[1.75,7.5],[1.75,7.25],[2.25,7.75],[2,7.5],[2,7.25]].forEach(([x,z])=>Q4(x,3,z,"#ffffff"))};
Object.assign(SPF,{
/* EX01 船長：白い船長帽・金のボタン */
ex1:({H,Q4})=>{const W="#ffffff",N="#1e293b",Gd="#d4af37";H(-1,-1,6,10,8,1,N);H(-1,-1,7,10,8,2,W);H(-2,-2,9,12,10,1,W);H(0,6,6,8,2,1,"#111111");H(3,7,7,2,1,1,Gd);H(2,7,8,4,1,1,Gd);[5,6,7].forEach(z=>{Q4(1.5,3,z,Gd);Q4(2.25,3,z,Gd)})},
/* EX02 宇宙飛行士：首のリング・背中の生命維持装置・ワッペン */
ex2:({H,B,Q4})=>{ring(H,-1,["#9ca3af"]);B(1,0,5,2,1,3,"#cbd5e1");B(1,0,7,2,1,1,"#94a3b8");Q4(1.25,3,7,"#ef4444");Q4(1.5,3,7,"#1e3a8a");Q4(1.25,3,6.75,"#1e3a8a");Q4(1.5,3,6.75,"#ef4444");[5,5.5,6].forEach(z=>Q4(2.5,3,z,"#38bdf8"))},
/* EX03 南極観測隊員：毛皮つきのフード */
ex3:({H})=>{const O="#f97316",F="#f5f5f4";H(-1,-1,6,10,8,1,O);H(-1,-1,0,10,2,6,O);H(-1,-1,0,2,7,6,O);H(7,-1,0,2,7,6,O);H(-1,6,-1,10,1,1,F);H(-1,6,6,10,1,1,F);H(-1,6,0,1,1,6,F);H(8,6,0,1,1,6,F)},
/* EX10 女将：着物と帯 */
ex10:o=>kimono(o,"#7c2d12","#facc15","#b45309"),
/* EX12 和菓子職人：白い和帽子 */
ex12:({H})=>{H(-1,-1,5,10,8,3,"#ffffff");H(-1,6,6,10,1,1,"#e5e7eb")},
/* EX13 着物の仕立て屋：着物と帯 */
ex13:o=>kimono(o,"#6b21a8","#e5e7eb","#9ca3af"),
/* EX14 寿司職人：ねじり鉢巻（白と紺） */
ex14:({H})=>hachi(H,"#ffffff","#1e3a8a"),
/* EX15 ラーメン屋：ねじり鉢巻（白と赤） */
ex15:({H})=>hachi(H,"#ffffff","#dc2626"),
/* EX20 プロゲーマー：虹色に光るヘッドホン */
ex20:({H})=>{const RB=["#ef4444","#f97316","#facc15","#22c55e","#3b82f6","#a855f7"];for(let k=0;k<4;k++){H(-2,1+k,0,2,1,4,RB[k]);H(8,1+k,0,2,1,4,RB[(k+3)%6])}for(let x=0;x<8;x++)H(x,2,8,1,2,1,RB[x%6])},
/* EX24 ピエロ：赤い鼻・白塗り・とんがり帽子・えり */
ex24:({H,hr})=>{H(-2,0,1,2,5,5,hr);H(8,0,1,2,5,5,hr);H(3,6,1,2,1,1,"#ef4444");H(1,6,1,1,1,1,"#3b82f6");H(6,6,1,1,1,1,"#3b82f6");
 const Y="#facc15",P="#ec4899";H(0,0,6,8,6,1,Y);H(1,1,7,6,4,1,P);H(2,1,8,4,4,1,Y);H(2,2,9,4,2,1,P);H(3,2,10,2,2,1,Y);H(3,2,11,2,2,1,"#ffffff");ring(H,-1,["#ffffff","#f1f5f9"])},
/* EX25 引退した手品師：シルクハット */
ex25:({H})=>{const K="#111111";H(-1,-1,6,10,8,1,K);H(0,0,7,8,6,5,K);H(0,0,7,8,6,1,"#b91c1c")},
/* EX26 探偵：鹿撃ち帽・トレンチコートのベルトとすそ */
ex26:({H,Q4})=>{for(let x=-1;x<9;x++)for(let y=-1;y<7;y++)for(let z=5;z<8;z++){if(z===7&&(x<0||x>7||y<0||y>5))continue;H(x,y,z,1,1,1,(x+y+z)%2?"#a16207":"#78350f")}
 H(1,7,5,6,1,1,"#78350f");H(1,-2,5,6,1,1,"#78350f");H(3,2,8,2,2,1,"#78350f");
 for(let x=1;x<3;x+=.25){Q4(x,3,5.5,"#7c5a2e");for(let z=2;z<4;z+=.25)Q4(x,3,z,"#c8a26a")}},
/* EX27 占い師：紫のベールと金の飾り */
ex27:({H})=>{const V="#7c3aed",Gd="#facc15";H(-1,-1,6,10,8,1,V);H(-1,-1,-4,10,1,10,V);H(-1,-1,-3,1,7,9,V);H(8,-1,-3,1,7,9,V);for(let x=0;x<8;x+=2)H(x,6,5,1,1,1,Gd);H(1,6,0,6,1,1,"#c4b5fd")},
/* EX29 鉄道運転士：制帽 */
ex29:({H})=>{const N="#1e3a8a";H(-1,-1,6,10,8,1,"#111111");H(-1,-1,7,10,8,2,N);H(0,6,6,8,2,1,"#111111");H(3,7,7,2,1,1,"#d4af37")},
/* EX30 煙の精：足元がけむりで、頭の上にもふわふわ */
ex30:({H,Q4,B})=>{const S1="#ede9fe",S2="#ddd6fe";B(1,1,0,2,2,4,S1);[[.5,1,.5],[3,2,1],[1.5,3,1.5],[.75,2.5,2.5],[2.75,.75,2],[2,3.25,.25]].forEach(([x,y,z])=>{Q4(x,y,z,S2);Q4(x+.25,y,z+.25,S1)});
 H(1,1,8,2,2,1,S1);H(4,3,9,2,1,1,S2);H(6,1,8,1,2,1,S1);H(2,6,7,1,1,1,S2)}
})}

/* EX30 煙の精：ぷっくりした煙のおばけ。足のかわりにくるんとしたしっぽ、大きな目とほっぺ */
SPH.ex30=function(a,ox,Y0,f,c,sit,dr,hd,nh){
const map=(x,y,w,d)=>{let X=x,Y=f>0?y:6-y-d,Wd=w,D=d;if(!sit){if(dr===2){X=4-x-w;Y=3-y-d}else if(dr===1){X=y;Y=4-x-w;Wd=d;D=w}else if(dr===3){X=3-y-d;Y=x;Wd=d;D=w}else Y=y}return[X,Y,Wd,D]};
const q=.25,M=new Map(),K=(x,y,z)=>Math.round(x*8)+","+Math.round(y*8)+","+Math.round(z*8);
const P=(x,y,z,col)=>M.set(K(x,y,z),[x,y,z,col]);
const C1="#f7f5ff",C2="#ebe5ff",C3="#d9cdfb",C4="#c4b5fd";
const ball=(cx,cy,cz,rx,ry,rz,colf)=>{for(let x=cx-rx;x<=cx+rx;x+=q)for(let y=cy-ry;y<=cy+ry;y+=q)for(let z=cz-rz;z<=cz+rz;z+=q){const gx=Math.round(x*4)/4,gy=Math.round(y*4)/4,gz=Math.round(z*4)/4,e=((gx+.125-cx)/rx)**2+((gy+.125-cy)/ry)**2+((gz+.125-cz)/rz)**2;if(e<=1)P(gx,gy,gz,colf(gx,gy,gz))}};
const bz=sit?6.3:7.6,shade=(x,y,z)=>z<bz-1.4||y<.6?C3:z>bz+1.2&&y>1.6?C1:C1;
/* しっぽ（くるんと渦を巻いて細くなる） */
const t0=sit?2.4:.5;for(let z=t0;z<bz-1;z+=q){const u=(z-t0)/(bz-1-t0),r=.3+u*1.5,a2=z*1.6;ball(2+Math.sin(a2)*(.7-u*.5),1.4+Math.cos(a2)*(.4-u*.3),z,r,r*.9,.2,(x,y,zz)=>Math.round(zz*4)%3===0?C4:C2)}
/* 体（ぷっくりした雲） */
ball(2,1.5,bz,2.1,1.6,2.2,shade);ball(.6,1.5,bz+1.3,.9,1,.9,shade);ball(3.4,1.5,bz+1.3,.9,1,.9,shade);ball(2,1.6,bz+1.9,1.1,1.1,.8,shade);
/* 頭のてっぺんのくるん（煙の巻き毛） */
ball(2.4,1.5,bz+2.6,.45,.45,.45,()=>C1);ball(2.85,1.5,bz+3.05,.32,.32,.32,()=>C2);ball(2.55,1.5,bz+3.4,.22,.22,.22,()=>C4);
/* ちっちゃい手 */
const hand=(x)=>ball(x,1.9,bz-.6,.45,.45,.45,()=>C2);if(!(nh&1)&&hd!==2)hand(-.15);if(!(nh&2)&&hd!==1)hand(4.15);
/* 顔：前の面を探して目・ほっぺ・口を置く */
const front=(x,z)=>{for(let y=4;y>=0;y-=q)if(M.has(K(x,y,z)))return y;return null};
const fc=(x,z,col)=>{const y=front(x,z);if(y!==null)P(x,y+q,z,col)};
const E="#2b2240",W="#ffffff",PK="#ffb3c7",ez=bz+.35;
for(const ex of[1.25,2.5]){for(let dx=0;dx<.5;dx+=q)for(let dz=0;dz<.75;dz+=q)fc(ex+dx,ez+dz,(dx===0&&dz===.5)?W:E)}
for(const bx of[.75,1,3,3.25])fc(bx,ez-.25,PK);
[[1.75,ez-.5],[2,ez-.75],[2.25,ez-.5]].forEach(([x,z])=>fc(x,z,E));
/* きらきら */
[[-.6,2,bz+2.2],[4.6,1,bz+1.6],[4.4,2.6,bz-2.6],[-.4,1,bz-1.8]].forEach(([x,y,z])=>P(x,y,z,"#fff3a8"));
/* ホースを持つとき */
if(hd){const XS=v=>hd===2?4-v-.5:v;for(let t=0;t<=1.001;t+=1/7)a.push((()=>{const[X,Y]=map(XS(3.7-1.6*t),5.6-2.5*t,.5,.5);return[ox+X,Y0+Y,bz-1+1.2*t,t>.8?"#222222":t<.15?"#8d6e63":"#d4af37",undefined,.5]})());ball(hd===2?.6:3.4,2.6,bz-.4,.45,.45,.45,()=>C2)}
const has=(x,y,z)=>M.has(K(x,y,z));
M.forEach(([x,y,z,col])=>{if(has(x+q,y,z)&&has(x-q,y,z)&&has(x,y+q,z)&&has(x,y-q,z)&&has(x,y,z+q)&&has(x,y,z-q))return;const[X,Y]=map(x,y,q,q);a.push([ox+X,Y0+Y,z,col,undefined,q])})};
const EXLOOK={1:{sp:"ex1"},2:{sp:"ex2"},3:{sp:"ex3",acc:0},10:{sp:"ex10",top:0,bot:0},12:{sp:"ex12",hs:9},13:{sp:"ex13",top:0,bot:0},14:{sp:"ex14"},15:{sp:"ex15"},20:{sp:"ex20",acc:0},24:{sp:"ex24",hs:98},25:{sp:"ex25"},26:{sp:"ex26"},27:{sp:"ex27"},29:{sp:"ex29",acc:0},30:{sp:"ex30",aura:"#c4b5fd",pants:"#ede9fe",shoe:"#ede9fe"}};
function exLook(){(G.cs||[]).forEach(c=>{if(c.ex&&EXLOOK[c.exn])Object.assign(c,EXLOOK[c.exn])})}
{const _ei=exInit;exInit=function(){_ei();exLook()}}
exLook();
'''
rep(TAIL,ADD+TAIL)
open(f,'w').write(s)
