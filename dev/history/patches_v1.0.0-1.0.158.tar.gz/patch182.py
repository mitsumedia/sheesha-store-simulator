import sys
f=sys.argv[1];s=open(f).read()
a='cx.font="10.5px sans-serif";const bs=[];'
i=s.find(a);assert s.count(a)==1
j=s.find('\nfunction floorAt',i);assert j>i
old=s[i:j]
assert old.endswith('})}'),old[-30:]
new=r'''cx.font="10.5px sans-serif";const bs=[];(R.mvOn?[]:R.people.concat(R.cat?[OW,R.cat]:[OW])).forEach(p=>{if(!(p.bt>0)&&p.bq){const t=p.bq;p.bq=null;sayX(p,t)}if(p.bt>0){p.bt-=1/60;const[X,Y]=P(p.x,p.y,15),fc=bubFace(p),FW=fc?18:0,ls=wrap(p.bub,105),w=Math.min(115,Math.max(...ls.map(l=>cx.measureText(l).width))+10)+FW,h=Math.max(ls.length*13+6,fc?22:0);bs.push({p,X,Y,ls,w,h,fc,FW,pr:(p===OW?3:/^❤|♥/.test(p.bub||"")?2:p.bk?2:0)+Math.min(.99,(p.bt||0)/10)})}});
/* 同時に出すのは6個まで（店長との会話・♥を優先、あとは新しい順） */
const MX=6;let show=bs;if(bs.length>MX){show=bs.slice().sort((a,b)=>b.pr-a.pr).slice(0,MX)}
const pl=[];show.sort((a,b)=>b.Y-a.Y).forEach(b=>{const bx=clamp(b.X-b.w/2,4,W-b.w-4);let by=b.Y-b.h-8,n=0;const hit=()=>pl.some(r=>bx<r.x+r.w+3&&bx+b.w+3>r.x&&by<r.y+r.h+3&&by+b.h+3>r.y);while(n<10&&hit()){by-=b.h+4;n++}
const moved=n>0;by=Math.max(2,by);pl.push({x:bx,y:by,w:b.w,h:b.h});const m=b.p.c?b.p.c.hp-b.p.c.up:0,fill=b.p.bk?"#e4f6ec":m<=-15?"#e8e6f3":m>=25?"#fff3f6":"#fffdf5",line=b.p.bk?"#2f9a6b":m<=-15?"#5b4f8a":m>=25?"#d9638c":"#6b5a80";
cx.fillStyle=fill;cx.strokeStyle=line;cx.lineWidth=1.2;
if(moved&&!b.fc){cx.beginPath();cx.moveTo(bx+b.w/2,by+b.h);cx.lineTo(b.X,b.Y);cx.setLineDash([2,3]);cx.stroke();cx.setLineDash([])}
cx.beginPath();cx.roundRect(bx,by,b.w,b.h,8);cx.fill();cx.stroke();
if(!moved){const tx=clamp(b.X,bx+8,bx+b.w-8);cx.beginPath();cx.moveTo(tx-4,by+b.h);cx.lineTo(tx,by+b.h+7);cx.lineTo(tx+4,by+b.h);cx.fill()}
if(b.fc){try{cx.drawImage(b.fc,bx+1,by+b.h/2-10,20,20)}catch(e){}}
cx.fillStyle="#2b2236";const ty=by+(b.h-(b.ls.length*13+6))/2;b.ls.forEach((l,q)=>cx.fillText(l,bx+5+b.FW,ty+13+q*13))})}'''
s=s[:i]+new+s[j:]
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 吹き出しの顔（図鑑の顔を小さく） ===== */
const BFC={};let BFN=0;
function bubFace(p){try{const c=p===OW?OW.c:p.c;if(!c||p===R.cat)return null;if(p!==OW&&(c.mob||c.i==null||c.i>=9000||!c.met))return null;const k=p===OW?"ow":c.i;if(BFC[k]!==undefined)return BFC[k]||null;if(BFN>=2)return null;BFN++;
 let cv=document.getElementById("fcache");if(!cv){cv=document.createElement("canvas");cv.id="fcache";cv.width=cv.height=120;cv.style.display="none";document.body.appendChild(cv)}drawFace("#fcache",c);const g=cv.getContext("2d"),im=g.getImageData(0,0,120,120),a=im.data;for(let q=0;q<a.length;q+=4)if(Math.abs(a[q]-239)<3&&Math.abs(a[q+1]-230)<3&&Math.abs(a[q+2]-218)<3)a[q+3]=0;g.putImageData(im,0,0);const o=document.createElement("canvas");o.width=o.height=60;o.getContext("2d").drawImage(cv,0,0,60,60);BFC[k]=o;return o}catch(e){BFC[p===OW?"ow":(p.c&&p.c.i)]=0;return null}}
{const _dr4=draw;draw=function(){BFN=0;return _dr4.apply(this,arguments)}}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
