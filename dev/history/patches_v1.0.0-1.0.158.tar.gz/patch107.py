import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
OLD='const A=statFG(k),Bn=dyn().map(v=>({v,d:dep(v,k)})).concat(GLS.map(g=>({v:{fn:g.fn},d:g.pos[0]*k.cx+g.pos[1]*k.cy+g.pos[2]*k.cz+.6})));decPush(Bn,k);Bn.sort((p,q)=>p.d-q.d);let i=0,j=0;\nwhile(i<A.length||j<Bn.length){const o=(j>=Bn.length||(i<A.length&&A[i].d<=Bn[j].d))?A[i++]:Bn[j++];o.v.fn?o.v.fn(k):dv(o.v,k)}'
rep(OLD,'if(!scnDraw(k)){'+OLD+'}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 描画の高速化：動かない物（壁・家具・置物）は1枚の絵にしておき、人や煙など動く物の周りだけ描き直す ===== */
const SCNC={key:"",c:null,items:null,tiles:null,gw:0,gh:0,T:40,off:0,n:0};
function scnKey(k){let ds="";const D=G.decor||[];for(let i=0;i<D.length;i++){const d=D[i];ds+=d.id+","+d.tx+","+d.ty+","+(d.r||0)+";"}return SC.key+"|"+ds+"|"+W+","+CH+","+dpr+"|"+k.s.toFixed(4)+","+k.rx.toFixed(5)+","+k.ry.toFixed(5)+","+k.ux.toFixed(5)+","+k.uy.toFixed(5)+","+k.uz.toFixed(5)+","+k.ox+","+k.oy}
function wbb(x0,x1,y0,y1,z0,z1,k){let a=1e9,b=1e9,c=-1e9,d=-1e9;for(const x of[x0,x1])for(const y of[y0,y1])for(const z of[z0,z1]){const p=P3(x,y,z,k);if(p[0]<a)a=p[0];if(p[1]<b)b=p[1];if(p[0]>c)c=p[0];if(p[1]>d)d=p[1]}return[a-1,b-1,c+1,d+1]}
function scnBuild(k){const A=statFG(k),items=A.map(o=>{const v=o.v,s2=v[5]||1;return{v,d:o.d,bb:wbb(v[0],v[0]+s2,v[1],v[1]+s2,v[2],v[2]+s2,k)}});
(G.decor||[]).forEach(dd=>{const ox=dd.tx*6,oy=dd.ty*6,sl=decVox(dd.id,dd.r);if(!sl)return;sl.forEach(s2=>{const d=(ox+s2.cx)*k.cx+(oy+s2.cy)*k.cy+(s2.si+.5)*k.cz,sp=decSprite(dd.id,s2,k,dd.r);let bb;
if(sp){const P0=P3(ox,oy,0,k);bb=[P0[0]-sp.ax-1,P0[1]-sp.ay-1,P0[0]-sp.ax+sp.w+1,P0[1]-sp.ay+sp.h+1]}else{const b=s2.bb;bb=b?wbb(ox+b[0],ox+b[1],oy+b[2],oy+b[3],b[4],b[5],k):[0,0,W,CH]}
items.push({v:{fn:k2=>{const sp2=decSprite(dd.id,s2,k2,dd.r);if(!sp2){s2.v.map(v=>[v[0]+ox,v[1]+oy,v[2],v[3],undefined,.5]).map(v=>({v,d:dep(v,k2)})).sort((p,q)=>p.d-q.d).forEach(o=>dv(o.v,k2));return}const P0=P3(ox,oy,0,k2);cx.drawImage(sp2.c,P0[0]-sp2.ax,P0[1]-sp2.ay,sp2.w,sp2.h)}},d,bb})})});
items.sort((p,q)=>p.d-q.d);
if(!SCNC.c)SCNC.c=document.createElement("canvas");const c=SCNC.c;if(c.width!==cv.width||c.height!==cv.height){c.width=cv.width;c.height=cv.height}const g=c.getContext("2d");g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,CH);
const oc=cx;cx=g;try{for(const o of items)o.v.fn?o.v.fn(k):dv(o.v,k)}finally{cx=oc}
const T=SCNC.T,gw=Math.ceil(W/T),gh=Math.ceil(CH/T),tiles=Array.from({length:gw*gh},()=>[]);
items.forEach((o,i)=>{const b=o.bb,x0=Math.max(0,Math.floor(b[0]/T)),y0=Math.max(0,Math.floor(b[1]/T)),x1=Math.min(gw-1,Math.floor(b[2]/T)),y1=Math.min(gh-1,Math.floor(b[3]/T));for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)tiles[y*gw+x].push(i)});
SCNC.items=items;SCNC.tiles=tiles;SCNC.gw=gw;SCNC.gh=gh;SCNC.n++}
function scnDraw(k){if(SCNC.off||window.SCN_OFF||typeof document==="undefined"||!document.createElement)return false;
try{const key=scnKey(k);if(SCNC.key!==key){scnBuild(k);SCNC.key=key}
const Bn=dyn().map(v=>({v,d:dep(v,k)})).concat(GLS.map(g=>({v:{fn:g.fn},d:g.pos[0]*k.cx+g.pos[1]*k.cy+g.pos[2]*k.cz+.6,g:g.pos})));
const T=SCNC.T,gw=SCNC.gw,gh=SCNC.gh,mk=new Uint8Array(gw*gh);let any=0;
const mark=(a,b,c,d)=>{const x0=Math.max(0,Math.floor(a/T)),y0=Math.max(0,Math.floor(b/T)),x1=Math.min(gw-1,Math.floor(c/T)),y1=Math.min(gh-1,Math.floor(d/T));for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){mk[y*gw+x]=1;any=1}};
for(const o of Bn){if(o.g){const p=o.g,b=wbb(p[0]-5,p[0]+5,p[1]-5,p[1]+5,Math.max(-1,p[2]-6),p[2]+10,k);mark(b[0],b[1],b[2],b[3])}else{const v=o.v,s2=v[5]||1,p=P3(v[0]+s2/2,v[1]+s2/2,v[2]+s2/2,k),r=k.s*s2*1.05+1;mark(p[0]-r,p[1]-r,p[0]+r,p[1]+r)}}
const rects=()=>{cx.beginPath();for(let y=0;y<gh;y++){let x=0;while(x<gw){if(!mk[y*gw+x]){x++;continue}let e=x;while(e+1<gw&&mk[y*gw+e+1])e++;cx.rect(x*T,y*T,(e-x+1)*T,T);x=e+1}}};
cx.save();if(any){rects();cx.rect(0,0,W,CH);cx.clip("evenodd")}cx.setTransform(1,0,0,1,0,0);cx.drawImage(SCNC.c,0,0);cx.restore();
if(!any)return true;
const seen=new Uint8Array(SCNC.items.length),S=[];for(let t=0;t<mk.length;t++){if(!mk[t])continue;const L=SCNC.tiles[t];for(let q=0;q<L.length;q++){const id=L[q];if(!seen[id]){seen[id]=1;S.push(id)}}}S.sort((a,b)=>a-b);
Bn.sort((p,q)=>p.d-q.d);cx.save();rects();cx.clip();let i=0,j=0;const IT=SCNC.items;
while(i<S.length||j<Bn.length){const o=(j>=Bn.length||(i<S.length&&IT[S[i]].d<=Bn[j].d))?IT[S[i++]]:Bn[j++];o.v.fn?o.v.fn(k):dv(o.v,k)}cx.restore();return true}
catch(e){SCNC.off=1;try{console.error(e)}catch(_){}return false}}
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
s=open(f).read()
rep('draw();hud();requestAnimationFrame(tick)}','draw();{const _n=performance.now();if(_n-(window._hudT||0)>=90){window._hudT=_n;hud()}}requestAnimationFrame(tick)}')
open(f,'w').write(s)
s=open(f).read()
# 歩いているお客さんは向きごとに1枚の絵にして使い回す
rep('else{const d=p.dir||0,o=d%2,fw=o?3:4,fd=o?4:3;pv(a,p.x-fw/2,p.y-fd/2,1,c,0,d)}});','else{const d=p.dir||0,o=d%2,fw=o?3:4,fd=o?4:3;if(!walkSpr(a,c,d,p.x-fw/2,p.y-fd/2))pv(a,p.x-fw/2,p.y-fd/2,1,c,0,d)}});')
s=s.replace(TAIL,r"""
const WSPR=new WeakMap();
function walkSpr(a,c,d,ox,oy){if(window.SCN_OFF||typeof document==="undefined"||!document.createElement||typeof sprPush!=="function")return false;try{let m=WSPR.get(c);if(!m){m={};WSPR.set(c,m)}const key=d+"|"+[c.hs,c.acc,c.hair,c.skin,c.shirt,c.accC,c.eye,c.top,c.bot,c.pants,c.pump,c.h2,c.t2,c.b2,c.sp].join();let pc=m[key];if(!pc){const t=[];pv(t,0,0,1,c,0,d);pc=m[key]={l:t}}
const n0=GLS.length;sprPush(pc,a,[ox+2,oy+1.5,5]);if(GLS.length!==n0+1)return true;const g=GLS.pop(),inner=g.fn;GLS.push({pos:[ox+2,oy+1.5,5],fn:k=>{const p0=P3(0,0,0,k),p1=P3(ox,oy,0,k);cx.save();cx.translate(Math.round((p1[0]-p0[0])*dpr)/dpr,Math.round((p1[1]-p0[1])*dpr)/dpr);try{inner(k)}finally{cx.restore()}}});return true}catch(e){return false}}
"""+TAIL,1)
open(f,'w').write(s)
