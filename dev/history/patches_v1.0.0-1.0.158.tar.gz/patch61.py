import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
U="https://toratorasuienten.info/sheeshastoresimulator/"
IMG="https://raw.githubusercontent.com/mitsumedia/sheesha-store-simulator/main/ogp2.png"
D="お店を育てて、常連さんとチェキ📸 ブラウザですぐ遊べるシーシャ屋の経営ゲーム"
meta=f'''<meta charset=utf8>
<meta name="description" content="{D}">
<meta property="og:type" content="website"><meta property="og:url" content="{U}"><meta property="og:title" content="シーシャ屋さん経営"><meta property="og:description" content="{D}"><meta property="og:image" content="{IMG}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="675"><meta property="og:site_name" content="シーシャ屋さん経営">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="シーシャ屋さん経営"><meta name="twitter:description" content="{D}"><meta name="twitter:image" content="{IMG}">'''
i=s.index('<meta charset=utf8>');s=s[:i]+meta+s[i+len('<meta charset=utf8>'):]
# X投稿にゲームのURLをつける（リンクカードが出る）
rep('href="https://x.com/intent/post?text=${encodeURIComponent(txt)}"','href="https://x.com/intent/post?text=${encodeURIComponent(txt)}&url=${encodeURIComponent("'+U+'")}"')
open(f,'w').write(s)
