import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('wt:0,nl:NSL[Math.min(2,m.length-1)]};R.people.push(p);return}','wt:0,nl:R.away!=null?["店主がいないな、、帰るか"]:NSL[Math.min(2,m.length-1)]};R.people.push(p);return}')
rep('OW.mode="back";OW.path=[[3,15],[3,8]];say(OW,"ただいま！お待たせしました")','OW.mode="back";OW.path=[[3,15],[3,8]];R.idle0=R.t+15;say(OW,"ただいま！お待たせしました")')
open(f,'w').write(s)
