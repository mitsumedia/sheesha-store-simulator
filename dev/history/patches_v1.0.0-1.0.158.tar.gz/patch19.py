import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# 選択中は「点滅マスをタップ＝必ず移動」（手前の物に隠れていても動かせる）
rep('if(m&&m.t!=="w"&&R.mvT&&R.mvT.has(key)&&(!pk||mvSame(pk,m))){','if(m&&m.t!=="w"&&R.mvT&&R.mvT.has(key)){')
# 模様替え中の「できない理由」は画面に出す（ログだけだと気づけない）
ADD=r'''
{const _lg=log;log=function(t){_lg(t);try{if(R.mvOn&&/向きを変えるには|そこには貼れません|点滅しているマス|客席を全部なくす|持ち物がいっぱい/.test(t))toast(esc(t),2200)}catch(e){}}}
'''
T=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
assert s.count(T)==1
s=s.replace(T,ADD+"\n"+T);open(f,'w').write(s);print('ok')
