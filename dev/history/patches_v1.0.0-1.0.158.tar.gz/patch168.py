import sys
f=sys.argv[1];s=open(f).read()
a='occ.forEach(o=>{if(o.d>it.d&&!used.has(o)&&!(o.bb[2]<x0||o.bb[0]>x1||o.bb[3]<y0||o.bb[1]>y1)){used.add(o);L2.push({oc:o,d:o.d})}})});'
assert s.count(a)==1
b='occ.forEach(o=>{if(o.bb[2]<x0||o.bb[0]>x1||o.bb[3]<y0||o.bb[1]>y1)return;const B=o.b,px=Math.max(B.x,Math.min(B.x+B.w,m.x)),py=Math.max(B.y,Math.min(B.y+B.d,m.y)),pd=px*k.cx+py*k.cy+4*k.cz;if(pd>it.d+.05){L2.push({oc:o,d:Math.max(o.d,it.d+.001)})}})});'
s=s.replace(a,b)
open(f,'w').write(s)
