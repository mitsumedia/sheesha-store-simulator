import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('data-owt="shop" maxlength="14"','data-owt="shop" maxlength="10"')
rep('data-ok="shop" maxlength="14"','data-ok="shop" maxlength="10"')
rep('o.shop=(d.shop||"").trim();','o.shop=[...(d.shop||"").trim()].slice(0,10).join("");')
rep('{shop:(c.shop||"").trim(),','{shop:[...(c.shop||"").trim()].slice(0,10).join(""),')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== 店名は10文字まで（今のセーブで長い店名は10文字に） ===== */
try{if(G&&G.ow&&G.ow.shop&&[...G.ow.shop].length>10){const o=G.ow.shop;G.ow.shop=[...o].slice(0,10).join("");save();setTimeout(()=>{try{toast("店名は10文字までになりました（「"+G.ow.shop+"」）。店主の見た目から変えられます")}catch(e){}},2500)}}catch(e){}
'''
s=s.replace(TAIL,CODE+TAIL)
open(f,'w').write(s)
