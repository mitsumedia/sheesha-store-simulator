import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* ===== iPhoneのSafariで画面ごと拡大されないように（ピンチ・ダブルタップのズームを止める） ===== */
try{document.head.insertAdjacentHTML("beforeend",`<style>html,body{touch-action:manipulation;-webkit-text-size-adjust:100%;text-size-adjust:100%}</style>`)}catch(e){}
["gesturestart","gesturechange","gestureend"].forEach(t=>document.addEventListener(t,e=>{e.preventDefault()},{passive:false}));
document.addEventListener("touchmove",e=>{if(e.touches&&e.touches.length>1)e.preventDefault()},{passive:false});
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
