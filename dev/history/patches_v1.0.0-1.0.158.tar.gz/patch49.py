import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
rep('登録 ${st.players}人・直近7日にセーブ ${st.week}人</div>','登録 ${st.players}人・直近7日にセーブ ${st.week}人</div><div style="margin-top:10px;padding:8px;border-radius:8px;background:#f4effb"><b style="font-size:13px">🔄 ゲームの更新</b><div id="dplv" style="font-size:12px;margin:4px 0">確認中…</div><div style="display:flex;gap:6px"><button id="dplgo" class="on" style="flex:2">最新版に更新</button><button id="dplrb" style="flex:1">1つ前に戻す</button></div><div id="dplm" style="font-size:12px;margin-top:4px"></div></div>')
rep(';margin-top:8px"></div></div>`);admGifts()}',';margin-top:8px"></div></div>`);admGifts();dplLoad()}')
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
ADD=r'''
/* ===== 管理：GitHubから最新版に更新 ===== */
async function dplLoad(){const el=document.getElementById("dplv");if(!el)return;try{const j=await aapi({a:"a_ver"});el.innerHTML=`サーバー：<b>Ver ${esc(j.cur||"?")}</b>　GitHub：<b>Ver ${esc(j.gh||"取得できず")}</b>${j.gh&&j.gh!==j.cur?' <span style="color:#e5484d">← 新しい版があります</span>':j.gh?' <span style="color:#22a06b">最新です</span>':""}`;const rb=document.getElementById("dplrb");if(rb)rb.disabled=!j.prev}catch(e){el.textContent=e.message}}
document.addEventListener("click",async e=>{const b=e.target.closest("#dplgo,#dplrb");if(!b)return;e.stopImmediatePropagation();if(b.dataset.arm!=="1"){b.dataset.arm="1";b.dataset.t=b.textContent;b.textContent="もう一度押すと実行";setTimeout(()=>{b.dataset.arm="";b.textContent=b.dataset.t},4000);return}
b.dataset.arm="";b.textContent=b.dataset.t;b.disabled=true;sysMsg("dplm","実行中…");try{const j=await aapi({a:b.id==="dplgo"?"a_deploy":"a_rollback"});sysMsg("dplm","✅ Ver "+esc(j.ver)+" にしました。みんなの画面も次に開いたとき切り替わります");dplLoad()}catch(er){sysMsg("dplm",esc(er.message),1)}b.disabled=false},true);
'''
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
