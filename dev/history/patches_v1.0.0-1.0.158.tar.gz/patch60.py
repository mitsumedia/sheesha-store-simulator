import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# シーシャ屋・レジェンドは2回の来店で名前がわかる（ほかの特別枠は3回のまま）
rep('const lv=c=>c.met?(spx(c)?(((c.vn||0)>=3||(c.vt||0)>=3)?NL:0):','const lv=c=>c.met?(spx(c)?(((c.vn||0)>=ckRv(c)||(c.vt||0)>=ckRv(c))?NL:0):')
rep('const lv=c=>c.met?','const ckRv=c=>c.job==="シーシャ屋"||c.job==="レジェンド"?2:3;const lv=c=>c.met?')
open(f,'w').write(s)
