import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:80];s=s.replace(a,b)
rep('function rList(){const q=Q("#bd-q").value.trim(),fl=Q("#bd-fl").value,n3=i=>String(i+1).padStart(3,"0");\nQ("#bd-list").innerHTML=CS0.map((_,i)=>{',
'''/* 図鑑番号はレア順（ゲームと同じ並び）。書き出しの番号（no）は中の番号のまま */
function bdOrd(){const o=CS0.map((_,i)=>i).sort((a,b)=>{const ra=cur(a).rar||9,rb=cur(b).rar||9;return a>=151||b>=151?a-b:(ra-rb)||(a-b)}),m={};o.forEach((i,n)=>{m[i]=n+1});return{o,m}}
function bdNo(i){return String(bdOrd().m[i]||i+1).padStart(3,"0")}
function rList(){const q=Q("#bd-q").value.trim(),fl=Q("#bd-fl").value,BO=bdOrd(),n3=i=>String(BO.m[i]||i+1).padStart(3,"0");
Q("#bd-list").innerHTML=BO.o.map(i=>{''')
rep('<span class="no">No.${n3(i)}</span>','<span class="no">No.${n3(i)}${BO.m[i]!==i+1?`<br><small style="font-size:9px;opacity:.7">ID ${String(i+1).padStart(3,"0")}</small>`:""}</span>')
rep('function rForm(){const c=cur(sel),n3=String(sel+1).padStart(3,"0");','function rForm(){const c=cur(sel),n3=bdNo(sel)+(bdNo(sel)!==String(sel+1).padStart(3,"0")?"（ID "+String(sel+1).padStart(3,"0")+"）":"");')
open(f,'w').write(s);print('ok')
