import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
D=json.load(open('/home/claude/w/bike_dmd.json'))
ADD='\n/* ===== 有馬からもらえる「ライムグリーンのバイク」を作り直し（オリジナルのフルカウルのスポーツバイク） ===== */\nDMD.gf_94=%s;\n' % json.dumps(D)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
