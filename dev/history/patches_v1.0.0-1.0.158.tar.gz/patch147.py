import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 税務署からの手紙：1回目の確定申告を済ませた後だけ
rep('ef:"追徴課税で先月の売上の20%を支払う、次の日は行動できない",ok:()=>G.last&&G.last.est>0,','ef:"追徴課税で先月の売上の20%を支払う、次の日は行動できない（1回目の確定申告のあとから起こる）",ok:()=>G.last&&G.last.est>0&&!!(G.tax&&G.tax.n>=1),')
open(f,'w').write(s)
