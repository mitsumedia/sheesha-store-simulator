import sys
f=sys.argv[1];s=open(f).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:80]);s=s.replace(a,b)
# 管理ページにエラー記録の欄
rep('<div style="margin-top:10px"><b style="font-size:13px">👤 ユーザーを探す</b>','<div style="margin-top:10px;padding:8px;border-radius:8px;background:#fdecec"><b style="font-size:13px">⚠️ エラー記録</b><button id="errb" style="width:100%;margin-top:4px">最近のエラーを見る</button><div id="errl" style="font-size:11px;margin-top:6px;max-height:260px;overflow:auto"></div></div>\n<div style="margin-top:10px"><b style="font-size:13px">👤 ユーザーを探す</b>')
# 一番最初（ほかのスクリプトより前）にエラーを拾う仕組みを置く
HEAD=r'''<script>
/* ===== エラー表示：何か起きたら画面上部に赤い帯（スクショ用）＋サーバーに記録 ===== */
(function(){var shown={},bar=null,sent=0;function ver(){try{return (typeof GVER!=="undefined"?GVER:"?")}catch(e){return"?"}}
function day(){try{return (typeof G!=="undefined"&&G&&G.day)||0}catch(e){return 0}}
function show(msg,src){var k=String(msg).slice(0,120);if(shown[k])return;shown[k]=1;var t=new Date(),ts=t.getFullYear()+"/"+(t.getMonth()+1)+"/"+t.getDate()+" "+t.getHours()+":"+String(t.getMinutes()).padStart(2,"0");
var info="Ver "+ver()+"・プレイ"+day()+"日目・"+ts;try{if(!bar){bar=document.createElement("div");bar.id="errbar";bar.style.cssText="position:fixed;left:8px;right:8px;top:calc(env(safe-area-inset-top,0px) + 6px);z-index:99999;background:#c62828;color:#fff;border-radius:12px;padding:10px 12px;font:12px/1.5 sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.4);word-break:break-all";document.body.appendChild(bar)}
bar.innerHTML='<b style="font-size:14px">⚠️ エラーが発生しました</b><div style="opacity:.9">このままスクショを撮って運営に送ってください</div><div style="margin-top:4px;background:rgba(0,0,0,.25);border-radius:6px;padding:6px;max-height:110px;overflow:auto">'+String(msg).replace(/[<>&]/g,function(c){return{"<":"&lt;",">":"&gt;","&":"&amp;"}[c]})+(src?'<br><span style="opacity:.75">'+String(src).replace(/[<>&]/g,"")+'</span>':"")+'</div><div style="margin-top:4px;opacity:.85">'+info+'</div><div style="display:flex;gap:6px;margin-top:6px"><button id="errx" style="flex:1;padding:7px;border-radius:8px;border:0">閉じる</button><button id="errr" style="flex:1;padding:7px;border-radius:8px;border:0;font-weight:700">再読み込み</button></div>';
bar.querySelector("#errx").onclick=function(){bar.remove();bar=null};bar.querySelector("#errr").onclick=function(){location.reload()}}catch(e){}
try{if(sent<5){sent++;var c=null;try{c=JSON.parse(localStorage.getItem("shisha_cloud")||"null")}catch(e){}fetch("api.php",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({a:"err",uid:c&&c.uid||"",token:c&&c.token||"",ver:ver(),day:day(),msg:String(msg).slice(0,800),src:String(src||"").slice(0,300),ua:navigator.userAgent.slice(0,200)})}).catch(function(){})}}catch(e){}}
window.addEventListener("error",function(e){var m=e.message||(e.error&&e.error.message)||"不明なエラー";if(/^Script error/.test(m))return;show(m,(e.filename?String(e.filename).split("/").pop():"")+(e.lineno?":"+e.lineno+":"+(e.colno||0):"")+(e.error&&e.error.stack?"\n"+String(e.error.stack).split("\n").slice(0,3).join(" / "):""))});
window.addEventListener("unhandledrejection",function(e){var r=e.reason,m=(r&&r.message)||String(r);if(/通信できませんでした|サーバーの応答/.test(m))return;show("（非同期）"+m,r&&r.stack?String(r.stack).split("\n").slice(0,3).join(" / "):"")});
window.showErr=show})();
</script>'''
i=s.find('<script>');assert i>0
s=s[:i]+HEAD+s[i:]
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
CODE=r'''
/* 管理ページ：エラー記録の一覧 */
document.addEventListener("click",async e=>{if(!e.target.closest||!e.target.closest("#errb"))return;const el=document.getElementById("errl");if(!el)return;el.textContent="読み込み中…";try{const j=await aapi({a:"a_errs"});el.innerHTML=j.list.length?j.list.map(r=>`<div style="padding:5px 0;border-bottom:1px solid #f3d6d6"><b>${new Date(r.at*1000).toLocaleString("ja-JP")}</b>　Ver ${esc(r.ver||"")}・${r.day}日目${r.code?"・"+esc(r.code):""}${r.shop?"（"+esc(r.shop)+"）":""}<br>${esc(r.msg||"")}<br><span style="opacity:.6">${esc(r.src||"")}</span><br><span style="opacity:.5">${esc(r.ua||"")}</span></div>`).join(""):"エラーの記録はありません"}catch(err){el.textContent=err.message}},true);
'''
rep(TAIL,CODE+TAIL)
open(f,'w').write(s)
