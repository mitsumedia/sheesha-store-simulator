import sys,json
f=sys.argv[1];s=open(f).read()
TAIL=';(function(){const app=$("#app"),sh=document.createElement("div");sh.id="sheet";'
m=json.load(open('/home/claude/w/radio2.json'))
ADD='\n/* レトロ棚とラジカセを1マスの奥行きに */\nDMD.radio=%s;\n'%json.dumps(m)
assert s.count(TAIL)==1;s=s.replace(TAIL,ADD+TAIL);open(f,'w').write(s)
